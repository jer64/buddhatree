// ===========================================================
// LaunchApp.c - ELF32 application launcher for JTMOS.
//
// Based on the original 2002-2005 LaunchApp prototype by
// Jari Tuominen.  The raw-binary copy has been replaced by an
// ELF32/i386 PT_LOAD loader while preserving the existing JTMOS
// process/thread ownership and page-table model.
// ===========================================================

#include "int.h"
#include "cpu.h"
#include "sysglvar.h"
#include "kernel32.h" // FATALEXCEPTION
#include "delay.h"
#include "threads.h"
#include "centralprocess.h"
#include "mm.h"
#include "mmAlloc.h"
#include <sys/mman.h>
#include "elf32.h"
#include "LaunchApp.h"
#include "exeidentificationmodule.h"
#include "mutex.h"

static DEFINE_MUTEX(launchapp_mutex);

/* Loader-local result state. Access is serialized by launchapp_mutex; it is
 * deliberately separate from the Central Process request record. */
static int launchapp_error;
static int launchapp_detail;

#define ELF32_MAX_PROGRAM_HEADERS 128

static int range_inside(DWORD offset, DWORD amount, DWORD total)
{
    if(offset > total)
        return FALSE;
    if(amount > (total - offset))
        return FALSE;
    return TRUE;
}

static int add_overflows(DWORD a, DWORD b)
{
    return a > (0xffffffffUL - b);
}

static const Elf32_Phdr *elf32_program_header(const BYTE *abin,
                                               const Elf32_Ehdr *eh,
                                               int index)
{
    DWORD off;

    off = eh->e_phoff + ((DWORD)index * (DWORD)eh->e_phentsize);
    return (const Elf32_Phdr *)(abin + off);
}

static int elf32_validate(const BYTE *abin, DWORD length,
                          DWORD *image_end, DWORD *entry)
{
    const Elf32_Ehdr *eh;
    const Elf32_Phdr *ph;
    DWORD ph_bytes;
    DWORD seg_end;
    DWORD max_end;
    int entry_is_executable;
    int load_count;
    int i;

    if(abin == 0 || length < sizeof(Elf32_Ehdr))
        return LAUNCHAPP_ELF_BAD_ARGUMENT;

    eh = (const Elf32_Ehdr *)abin;

    if(eh->e_ident[EI_MAG0] != ELFMAG0 ||
       eh->e_ident[EI_MAG1] != ELFMAG1 ||
       eh->e_ident[EI_MAG2] != ELFMAG2 ||
       eh->e_ident[EI_MAG3] != ELFMAG3)
        return LAUNCHAPP_ELF_BAD_MAGIC;

    if(eh->e_ident[EI_CLASS] != ELFCLASS32 ||
       eh->e_ident[EI_DATA] != ELFDATA2LSB ||
       eh->e_ident[EI_VERSION] != EV_CURRENT ||
       eh->e_version != EV_CURRENT ||
       eh->e_machine != EM_386 ||
       eh->e_type != ET_EXEC)
        return LAUNCHAPP_ELF_UNSUPPORTED;

    if(eh->e_ehsize != sizeof(Elf32_Ehdr) ||
       eh->e_phentsize != sizeof(Elf32_Phdr) ||
       eh->e_phnum == 0 ||
       eh->e_phnum > ELF32_MAX_PROGRAM_HEADERS)
        return LAUNCHAPP_ELF_BAD_HEADER;

    if(add_overflows((DWORD)eh->e_phnum * (DWORD)eh->e_phentsize,
                     eh->e_phoff))
        return LAUNCHAPP_ELF_BAD_HEADER;

    ph_bytes = (DWORD)eh->e_phnum * (DWORD)eh->e_phentsize;
    if(!range_inside(eh->e_phoff, ph_bytes, length))
        return LAUNCHAPP_ELF_BAD_HEADER;

    max_end = RTCODE;
    load_count = 0;
    entry_is_executable = FALSE;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, i);
        if(ph->p_type != PT_LOAD)
            continue;

        ++load_count;

        if(ph->p_memsz < ph->p_filesz)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(!range_inside(ph->p_offset, ph->p_filesz, length))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(add_overflows(ph->p_vaddr, ph->p_memsz))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        seg_end = ph->p_vaddr + ph->p_memsz;

        /* Keep the original 16 KiB stack/runtime area reserved. */
        if(ph->p_vaddr < RTCODE || seg_end > MM_USER_TOP)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        /* ELF requires p_vaddr and p_offset to be congruent modulo p_align
           when p_align is greater than one. */
        if(ph->p_align > 1)
        {
            if((ph->p_align & (ph->p_align - 1)) != 0)
                return LAUNCHAPP_ELF_BAD_SEGMENT;
            if((ph->p_vaddr % ph->p_align) != (ph->p_offset % ph->p_align))
                return LAUNCHAPP_ELF_BAD_SEGMENT;
        }

        if(seg_end > max_end)
            max_end = seg_end;

        if((ph->p_flags & PF_X) != 0 &&
           eh->e_entry >= ph->p_vaddr &&
           eh->e_entry < seg_end)
            entry_is_executable = TRUE;
    }

    if(load_count == 0)
        return LAUNCHAPP_ELF_BAD_SEGMENT;

    if(eh->e_entry < RTCODE || eh->e_entry >= MM_USER_TOP ||
       !entry_is_executable)
        return LAUNCHAPP_ELF_BAD_ENTRY;

    *image_end = max_end;
    *entry = eh->e_entry;
    return LAUNCHAPP_ELF_OK;
}

static int elf32_copy_segments(const BYTE *abin,
                               BYTE *app_space,
                               const Elf32_Ehdr *eh)
{
    const Elf32_Phdr *ph;
    BYTE *dst;
    DWORD i;
    DWORD n;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, (int)i);
        if(ph->p_type != PT_LOAD)
            continue;

        dst = app_space + (ph->p_vaddr - RTBASE);

        for(n = 0; n < ph->p_filesz; ++n)
            dst[n] = abin[ph->p_offset + n];

        /* .bss and any other memsz > filesz tail. */
        for(n = ph->p_filesz; n < ph->p_memsz; ++n)
            dst[n] = 0;
    }

    return LAUNCHAPP_ELF_OK;
}


static int elf32_verify_process_image(int pid, BYTE *app_space,
                                      const Elf32_Ehdr *eh)
{
    const Elf32_Phdr *ph;
    DWORD map_start, map_end, seg_end;
    DWORD va, source_page, source_pte, target_pte;
    DWORD expected_phys;
    int i;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header((const BYTE *)eh, eh, i);
        if(ph->p_type != PT_LOAD || ph->p_memsz == 0)
            continue;

        seg_end = ph->p_vaddr + ph->p_memsz;
        map_start = mm_page_align_down(ph->p_vaddr);
        map_end = mm_page_align_up(seg_end);
        if(map_end == 0 || map_end <= map_start)
            return -1;

        source_page = ((DWORD)app_space + (map_start - RTBASE)) / PAGESIZE;
        for(va = map_start; va < map_end; va += PAGESIZE, ++source_page)
        {
            source_pte = GetPage(source_page);
            target_pte = mm_get_process_pte(pid, va);
            expected_phys = source_pte & 0xfffff000UL;

            if((source_pte & 1U) == 0 || expected_phys < PG_STRUCTURES_PHYS_END ||
               (target_pte & 1U) == 0 ||
               (target_pte & 4U) == 0 ||
               (target_pte & 0xfffff000UL) != expected_phys)
            {
                dprintk("ELF32 PID%d PTE verify failed va=0x%x src=0x%x dst=0x%x\n",
                       pid, va, source_pte, target_pte);
                return -1;
            }
            if((ph->p_flags & PF_W) && (target_pte & 2U) == 0)
            {
                dprintk("ELF32 PID%d writable segment mapped read-only va=0x%x pte=0x%x\n",
                       pid, va, target_pte);
                return -1;
            }
        }
    }
    return 0;
}

static int elf32_segment_prot(const Elf32_Phdr *ph)
{
    int prot;

    prot = PROT_NONE;
    if(ph->p_flags & PF_R)
        prot |= PROT_READ;
    if(ph->p_flags & PF_W)
        prot |= PROT_WRITE;
    if(ph->p_flags & PF_X)
        prot |= PROT_EXEC;
    return prot;
}

static int elf32_page_prot(const Elf32_Ehdr *eh, DWORD page_start)
{
    const Elf32_Phdr *ph;
    DWORD page_end;
    DWORD seg_end;
    int prot=PROT_NONE;
    int i;

    if(page_start > 0xffffffffUL-PAGESIZE)
        return PROT_NONE;
    page_end=page_start+PAGESIZE;

    for(i=0;i<eh->e_phnum;++i)
    {
        ph=elf32_program_header((const BYTE *)eh,eh,i);
        if(ph->p_type!=PT_LOAD || ph->p_memsz==0)
            continue;
        seg_end=ph->p_vaddr+ph->p_memsz; /* validated before this point */
        if(ph->p_vaddr>=page_end || seg_end<=page_start)
            continue;
        prot|=elf32_segment_prot(ph);
    }
    return prot;
}

static int elf32_map_process_image(int pid, BYTE *app_space,
                                   const Elf32_Ehdr *eh,
                                   DWORD image_end, DWORD bytes,
                                   DWORD stack_base)
{
    const Elf32_Phdr *ph;
    DWORD heap_start;
    DWORD heap_end;
    DWORD first_image_page=MM_USER_TOP;
    DWORD last_image_page=0;
    DWORD map_start,map_end,seg_end,va;
    BYTE *source;
    int prot;
    int i;

    /* V65 userspace layout:
     *   ELF PT_LOAD image | process-private heap | guard page | 256 KiB stack
     * The full requested backing allocation belongs to the process. */
    heap_start = mm_page_align_up(image_end);
    heap_end = stack_base - APP_GUARD_SIZE;
    if(heap_start == 0 || heap_end < heap_start ||
       stack_base > 0xffffffffUL-APP_STACK_SIZE ||
       stack_base + APP_STACK_SIZE != RTBASE + bytes)
        return -1;

    if(heap_end > heap_start &&
       mm_map_process_range(pid, heap_start,
                            app_space + (heap_start - RTBASE),
                            heap_end - heap_start,
                            PROT_READ | PROT_WRITE) != 0)
        return -1;

    /* APP_GUARD_SIZE immediately below stack_base is intentionally unmapped. */
    if(mm_map_process_range(pid, stack_base,
                            app_space + (stack_base - RTBASE),
                            APP_STACK_SIZE, PROT_READ | PROT_WRITE) != 0)
        return -1;

    /* ELF permits two PT_LOAD segments to share a physical page at a segment
     * boundary.  Mapping one complete segment at a time made the second range
     * look like an illegal remap and could reject otherwise valid ELF32 files.
     * Build the image one virtual page at a time and merge permissions of all
     * PT_LOAD segments touching that page.  The backing alias is identical, so
     * each destination PTE is published exactly once. */
    for(i=0;i<eh->e_phnum;++i)
    {
        ph=elf32_program_header((const BYTE *)eh,eh,i);
        if(ph->p_type!=PT_LOAD || ph->p_memsz==0)
            continue;
        seg_end=ph->p_vaddr+ph->p_memsz;
        map_start=mm_page_align_down(ph->p_vaddr);
        map_end=mm_page_align_up(seg_end);
        if(map_end==0 || map_end<=map_start)
            return -1;
        if(map_start<first_image_page) first_image_page=map_start;
        if(map_end>last_image_page) last_image_page=map_end;
    }
    if(first_image_page==MM_USER_TOP || last_image_page<=first_image_page)
        return -1;

    for(va=first_image_page;va<last_image_page;va+=PAGESIZE)
    {
        prot=elf32_page_prot(eh,va);
        if(prot==PROT_NONE)
            continue; /* genuine inter-segment hole stays unmapped */
        source=app_space+(va-RTBASE);
        if(mm_map_process_range(pid,va,source,PAGESIZE,prot)!=0)
            return -1;
        if(va>0xffffffffUL-PAGESIZE)
            break;
    }
    return 0;
}

void Indication(void)
{
    nop();
    nop();
    nop();
    nop();
}

int LaunchAppIsELF32(const BYTE *abin, int length)
{
    if(abin == 0 || length < 5)
        return FALSE;

    return abin[EI_MAG0] == ELFMAG0 &&
           abin[EI_MAG1] == ELFMAG1 &&
           abin[EI_MAG2] == ELFMAG2 &&
           abin[EI_MAG3] == ELFMAG3 &&
           abin[EI_CLASS] == ELFCLASS32 &&
           abin[EI_DATA] == ELFDATA2LSB;
}

/* One authoritative pre-launch validator.  All kernel entry points, including
 * direct LaunchAppEx callers, pass through this function before any process
 * memory is allocated. */
int LaunchAppValidateImage(const BYTE *abin, int length, int *format_out)
{
    DWORD image_end, entry;
    int fmt, rv;

    rv=verifyExeBinary(abin,length,&fmt);
    if(format_out) *format_out=fmt;
    if(rv!=EXEIDENT_OK)
        return (rv==EXEIDENT_BAD_IDENTITY) ? LAUNCHAPP_DETAIL_IDENTITY
                                           : LAUNCHAPP_DETAIL_FORMAT;

    if(fmt==JTMOS_EXE_FORMAT_ELF32) {
        rv=elf32_validate(abin,(DWORD)length,&image_end,&entry);
        if(rv!=LAUNCHAPP_ELF_OK) return rv;
    } else if(fmt!=JTMOS_EXE_FORMAT_LEGACY_RAW) {
        return LAUNCHAPP_DETAIL_FORMAT;
    }
    return LAUNCHAPP_ELF_OK;
}

/* Launch application with the current kernel caller as the origin. */
int LaunchApp(BYTE *abin, int length)
{
    LAUNCHAPP_CONTEXT ctx;
    ctx.callerPID=GetCurrentThread();
    ctx.callerDNR=GetCurrentDNR();
    ctx.callerDB=GetCurrentDB();
    ctx.runDNR=ctx.callerDNR;
    ctx.runDB=ctx.callerDB;
    ctx.deferStart=0;
    return LaunchAppExContext(abin,length,DEF_APP_SPACE_K/64,&ctx);
}

/* Legacy compatibility helper. Keep the original two-argument ABI for any
   older kernel code that still calls AdaptAppPages() directly. New ELF code
   uses mm_map_process_range() with an explicit length. */
void AdaptAppPages(int pid, DWORD srcOffset, DWORD length)
{
    DWORD *dst;
    DWORD src;
    DWORD page;
    DWORD i;
    DWORD pages;

    dst = (DWORD *)(PG_USER_PAGE_TABLES_PHYS +
                    ((DWORD)pid * MM_PROCESS_PAGE_TABLE_BYTES));

    for(i = 0; i < 4096; ++i)
        dst[i] = 0;

    src = srcOffset / MM_PAGE_SIZE;
    /* V69.6: map only the allocation owned by this process.  The historical
     * "walk until GetPage() fails" behavior could publish adjacent kernel-heap
     * pages to CPL3 when the following virtual pages happened to be mapped. */
    pages = (length + MM_PAGE_SIZE - 1U) / MM_PAGE_SIZE;
    if(pages > MM_USER_PAGES) pages = MM_USER_PAGES;
    for(i = 0; i < pages; ++i)
    {
        page = GetPage(src + i);
        if(page < 8)
            break;
        /* Legacy binaries now execute at CPL3 too.  Preserve the physical
         * page but publish it as present+writable+user in the per-PID window.
         * Kernel aliases remain supervisor-only in the normal page tables. */
        dst[i] = (page & 0xfffff000UL) | 7U;
    }
}

/*
 * LaunchAppEx()
 *
 * abin/length : complete ELF32 file in memory
 * memkb       : minimum process backing allocation in KiB
 * dnr/db      : inherited JTMOS directory/database context
 *
 * Supported ELF profile:
 *   - ELFCLASS32
 *   - little endian
 *   - EM_386
 *   - ET_EXEC
 *   - PT_LOAD segments linked at >= 0x80004000
 *
 * V29 keeps the legacy 0x80004000 ELF link address but places a 256 KiB
 * stack immediately after the page-aligned ELF image.
 * Returns a PID, or 0 on error.
 */
static int LaunchAppELF32Ex(BYTE *abin, int length, int memkb, int dnr, int db, int defer_start)
{
    const Elf32_Ehdr *eh;
    BYTE *appSpace;
    DWORD image_end;
    DWORD required_bytes;
    DWORD requested_bytes;
    DWORD bytes;
    DWORD stack_base;
    DWORD stack_end;
    DWORD entry;
    int flags;
    int pid;
    int status;
    int backing_owner;
    DWORD launch_entry;
    DWORD launch_stack;

    if(abin == 0 || length <= 0)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_ARGUMENT;
        return 0;
    }

    status = elf32_validate(abin, (DWORD)length, &image_end, &entry);
    if(status != LAUNCHAPP_ELF_OK)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = status;
        dprintk("%s: invalid/unsupported ELF32 image (%d).\n",
               __FUNCTION__, status);
        return 0;
    }

    /* Reserve enough address space for the loaded image, a process-private
       heap, one unmapped guard page and the fixed 256 KiB stack. */
    required_bytes = mm_page_align_up(image_end - RTBASE);
    if(required_bytes == 0 ||
       required_bytes > MM_USER_SIZE - APP_MIN_HEAP_SIZE - APP_GUARD_SIZE - APP_STACK_SIZE)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_LAYOUT;
        return 0;
    }
    /* V67: always reserve a real private heap between image and guard. */
    required_bytes += APP_MIN_HEAP_SIZE + APP_GUARD_SIZE + APP_STACK_SIZE;

    if(memkb < 256)
        memkb = 256;

    if((DWORD)memkb > (0xffffffffUL / 1024UL))
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_LAYOUT;
        return 0;
    }

    requested_bytes = mm_page_align_up((DWORD)memkb * 1024UL);
    if(requested_bytes == 0)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_LAYOUT;
        return 0;
    }

    bytes = requested_bytes;
    if(bytes < required_bytes)
        bytes = required_bytes;

    if(bytes > MM_USER_SIZE)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_LAYOUT;
        dprintk("%s: ELF32 process requests %d KiB; maximum is %d KiB.\n",
               __FUNCTION__, bytes / 1024UL, MM_USER_SIZE / 1024UL);
        return 0;
    }

    stack_end = RTBASE + bytes;
    stack_base = stack_end - APP_STACK_SIZE;
    if(stack_base < mm_page_align_up(image_end) + APP_MIN_HEAP_SIZE + APP_GUARD_SIZE)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_LAYOUT;
        dprintk("%s: layout failed image_end=0x%x stack_base=0x%x bytes=%d KiB.\n",
               __FUNCTION__, image_end, stack_base, bytes / 1024UL);
        return 0;
    }

    flags = get_eflags();

    /* V70.42: do not hold CLI across allocation/copy/page-table construction.
     * The launch mutex and the stopped PID provide the transaction boundary,
     * while MM/thread internals use their own short critical sections.
     * This lets timer IRQs and unrelated tasks continue during large launches.
     *
     * V67.4: keep one contiguous kernel virtual application window, but back
     * it with independently allocated physical pages.  This removes the last
     * requirement for an 8/12 MiB physically contiguous run while preserving
     * thread_base[], A2K() and the established 0x80000000 ELF32 ABI.
     *
     * SYSMEMREQ remains a preference.  If there are not enough individual
     * pages for the requested reservation, retain the V67.3 page-aligned
     * fallback down to the exact ELF+heap+guard+stack minimum.
     */
    backing_owner = GetCurrentThread();
    appSpace = NULL;
    while(bytes >= required_bytes)
    {
        appSpace = (BYTE *)mm_sparse_alloc(bytes, backing_owner,
                                           "ELF32 sparse backing");
        if(appSpace != NULL)
            break;

        if(bytes == required_bytes)
            break;

        {
            DWORD next_bytes = mm_page_align_up(bytes / 2UL);
            if(next_bytes == 0 || next_bytes < required_bytes)
                next_bytes = required_bytes;
            if(next_bytes >= bytes)
                next_bytes = required_bytes;

            dprintk("%s: %u KiB sparse backing failed; retrying with %u KiB.\n",
                   __FUNCTION__, bytes / 1024UL, next_bytes / 1024UL);
            bytes = next_bytes;
            stack_end = RTBASE + bytes;
            stack_base = stack_end - APP_STACK_SIZE;
        }
    }

    if(appSpace == NULL)
    {
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_ALLOC;
        dprintk("%s: sparse allocation failed even at minimum %u KiB reservation.\n",
               __FUNCTION__, required_bytes / 1024UL);
        set_eflags(flags);
        return 0;
    }

    if(bytes != requested_bytes)
        printk("%s: requested %u KiB, granted %u KiB after memory-pressure fallback.\n",
               __FUNCTION__, requested_bytes / 1024UL, bytes / 1024UL);

    eh = (const Elf32_Ehdr *)abin;
    status = elf32_copy_segments(abin, appSpace, eh);
    if(status != LAUNCHAPP_ELF_OK)
    {
        mm_sparse_free(appSpace, bytes);
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_COPY;
        set_eflags(flags);
        return 0;
    }

    /* V67: shared flat ring-3 CS/DS.  Per-PID paging supplies isolation. */
    /* V70.42: never stage process state in the historical global
     * launchapp.asm variables.  Those words are shared by every CPU/task and
     * made concurrent/asynchronous launches overwrite each other's EIP/ESP.
     * The modern TSS constructor already takes the values explicitly. */
    launch_entry = entry;
    launch_stack = stack_end - 16;

    pid = _createAppThread(USER_CS, USER_DS,
                              appSpace, launch_entry, launch_stack);
    if(!pid)
    {
        mm_sparse_free(appSpace, bytes);
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_THREAD;
        set_eflags(flags);
        return 0;
    }

    /* Install the dynamically placed 256 KiB stack and ELF PT_LOAD pages.
       Segment PF_R/PF_W/PF_X
       flags are translated to JTMOS page protections where IA-32 permits it.
       The PID is still stopped here, so the application cannot race mapping
       setup even though unrelated multitasking/IRQs remain enabled. */
    mm_clear_process_space(pid);
    if(elf32_map_process_image(pid, appSpace, eh, image_end, bytes, stack_base) != 0)
    {
        /* The application constructor deliberately leaves the PID stopped.
         * Tear it down before publication so a failed mapping can never leave
         * a task that later runs with an empty/stale userspace page table. */
        mm_clear_process_space(pid);
        KillThreadEx(pid, KT_NO_THREAD_SWITCH);
        mm_sparse_free(appSpace, bytes);
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_MAP;
        printk("%s: unable to map ELF32 process pages for PID%d; task rolled back.\n",
               __FUNCTION__, pid);
        set_eflags(flags);
        return 0;
    }

    if(elf32_verify_process_image(pid, appSpace, eh) != 0)
    {
        mm_clear_process_space(pid);
        KillThreadEx(pid, KT_NO_THREAD_SWITCH);
        mm_sparse_free(appSpace, bytes);
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_MAP;
        printk("%s: ELF32 page-table verification failed for PID%d.\n",
               __FUNCTION__, pid);
        set_eflags(flags);
        return 0;
    }

    if(mm_sparse_change_owner((void *)appSpace, bytes, backing_owner, pid) != 0)
    {
        mm_clear_process_space(pid);
        KillThreadEx(pid, KT_NO_THREAD_SWITCH);
        mm_sparse_free(appSpace, bytes);
        launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail = LAUNCHAPP_DETAIL_ALLOC;
        printk("%s: unable to transfer sparse backing ownership to PID%d.\n",
               __FUNCTION__, pid);
        set_eflags(flags);
        return 0;
    }

    SetThreadDNR(pid, dnr);
    SetThreadDB(pid, db);
    ReportMessage("%s: Set PID%d DNR/DB to %d/%d\n",
                  __FUNCTION__, pid, dnr, db);

    /* Mandatory thread accounting used by the existing deallocator. */
    thread_base[pid] = JTM_PTR_TO_DWORD(appSpace);
    thread_ss[pid] = USER_DS;
    thread_selector[pid] = USER_CS;
    thread_banks[pid] = (bytes + (64UL * 1024UL - 1)) /
                                  (64UL * 1024UL);
    thread_memkb[pid] = bytes / 1024UL;

    SetThreadType(pid,
                  (GetThreadType(pid) & (~THREAD_TYPE_KERNEL))
                  | THREAD_TYPE_APPLICATION);

    TrackThread(pid, TRUE);
    /* Runnable publication may be deferred to Central Process, which still
     * has to install argv/cmdline, stdio, terminal and inherited environment.
     * This closes the old race where the child could execute those APIs while
     * CP was still filling them in. */
    if(!defer_start)
        SetThreadPriority(pid, THREAD_PRIORITY_NORMAL);

    ReportMessage("%s: ELF32 ring3 PID%d CS=%x DS=%x entry=0x%x base=0x%x memory=%d KiB heap=%x-%x guard=%x-%x stack=%x-%x\n",
                  __FUNCTION__, pid, USER_CS, USER_DS, launch_entry,
                  thread_base[pid], bytes / 1024UL,
                  mm_page_align_up(image_end), stack_base - APP_GUARD_SIZE,
                  stack_base - APP_GUARD_SIZE, stack_base,
                  stack_base, stack_end);

    launchapp_detail = LAUNCHAPP_ELF_OK;
    Indication();
    set_eflags(flags);
    return pid;
}

/* ------------------------------------------------------------------
 * Legacy flat-binary loader retained for existing JTMOS applications.
 * ------------------------------------------------------------------ */
static int LaunchAppLegacyRawEx(BYTE *abin, int length, int memkb, int dnr, int db, int defer_start)
{
	int i,l,bytes,flags,pid;
	DWORD stackBaseOffs, requiredBytes;
	BYTE *appSpace,*dummy JTM_UNUSED;
	BYTE *appStack;
	int l_appStack;
	DWORD launch_entry,launch_stack;

	if(abin==NULL || length<=0)
	{
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_ARGUMENT;
		return 0;
	}
	//
	if(memkb<16)
	{
		printk("%s: memkb=%d, won't run with this small memory!\n",
			__FUNCTION__,
			memkb);
		return NULL; // min. executable size is 16K.
	}

	//
	flags = get_eflags();
	/* V70.42: launch remains preemptible; the new PID is stopped until its
	 * complete image/accounting state has been published. */

	//
	puts("(A) ");

	// Preserve the historical code load offset (RTCODE = RTBASE+0x4000),
	// but place a large stack after the binary so old binaries do not need
	// to be relinked.
	l_appStack = 256*1024;
	if((DWORD)length > 0xffffffffUL-0x4000UL-4095UL ||
	   (DWORD)memkb > 0x7fffffffUL/1024UL)
	{
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_LAYOUT;
		set_eflags(flags);
		return 0;
	}
	stackBaseOffs = (0x4000UL + (DWORD)length + 4095UL) & ~4095UL;
	if(stackBaseOffs > 0xffffffffUL-(DWORD)l_appStack)
	{
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_LAYOUT;
		set_eflags(flags);
		return 0;
	}
	requiredBytes = stackBaseOffs + (DWORD)l_appStack;
	bytes = 1024*memkb;
	if((DWORD)bytes < requiredBytes) bytes = (int)requiredBytes;
	/* Per-process user page tables cover exactly MM_USER_SIZE.  Reject a
	 * legacy request that cannot be represented without escaping that window. */
	if((DWORD)bytes > MM_USER_SIZE)
	{
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_LAYOUT;
		set_eflags(flags);
		return 0;
	}
	appSpace = malloc(bytes);
	if(appSpace==NULL)
	{
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_ALLOC;
		set_eflags(flags);
		return 0;
	}
	memset(appSpace, 0, bytes);
	appStack = JTM_DWORD_TO_PTR(BYTE, RTBASE + stackBaseOffs);

	puts("(B) ");
	// Copy binary.
	l = bytes;
	for(i=0; i<length; i++)
	{
		if( (i+0x4000)>=l )
		{
			launchapp_error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
			launchapp_detail=LAUNCHAPP_DETAIL_COPY;
			free(appSpace);
			set_eflags(flags);
			return 0;
		}
		appSpace[i+0x4000] = abin[i];
	}

	puts("(C) ");
	// Get properties.
	/* V69.6: legacy raw binaries no longer execute with the kernel CS/DS.
	 * Their historical 0x80000000 address ABI is preserved by paging, while
	 * privilege is enforced by the shared flat Ring-3 descriptors. */
	/* V70.42: keep launch EIP/ESP request-local.  The old asm globals are
	 * retained only for the obsolete asmlaunchapp compatibility symbol. */
	launch_stack = JTM_PTR_TO_DWORD(appStack+l_appStack-16);
	launch_entry = RTCODE;

	puts("(D) ");
	//---------------------------------------------------------------------------
	// Process creation.
	//
	pid = _createAppThread(USER_CS, USER_DS, appSpace, launch_entry, launch_stack);
	if(pid<=0)
	{
		free(appSpace);
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_THREAD;
		set_eflags(flags);
		return 0;
	}

	/* V70.44: legacy raw launch now uses the same transactional VM mapper as
	 * ELF. The old AdaptAppPages() path could leave a partial mapping and
	 * transferred heap ownership before mapping was known-good. */
	mm_clear_process_space(pid);
	if(mm_map_process_range(pid,RTBASE,appSpace,(DWORD)bytes,
	                        PROT_READ|PROT_WRITE|PROT_EXEC)!=0)
	{
		mm_clear_process_space(pid);
		KillThreadEx(pid,KT_NO_THREAD_SWITCH);
		free(appSpace);
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_MAP;
		set_eflags(flags);
		return 0;
	}
	if(ChangeChunkOwner((void*)appSpace,pid)!=pid)
	{
		mm_clear_process_space(pid);
		KillThreadEx(pid,KT_NO_THREAD_SWITCH);
		free(appSpace);
		launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		launchapp_detail=LAUNCHAPP_DETAIL_ALLOC;
		set_eflags(flags);
		return 0;
	}

	puts("(E) ");
	// Set path
	SetThreadDNR(pid, dnr);
	SetThreadDB(pid, db);
	ReportMessage("%s: Set PID%d DNR/DB to %d/%d\n",
		__FUNCTION__,
		pid, dnr, db);

	puts("(F) ");
	// Mandatory for deallocation of the thread:
	thread_base[pid] =	JTM_PTR_TO_DWORD(appSpace);
	thread_ss[pid] =	USER_DS;
	thread_selector[pid] =	USER_CS;
	thread_banks[pid] =	(bytes + 65535) / 65536;
	thread_memkb[pid] =	(bytes + 1023) / 1024;

	puts("(G) ");
	// Define as an application before making the PID runnable.
	SetThreadType(pid,
		(GetThreadType(pid) & (~THREAD_TYPE_KERNEL))
			| THREAD_TYPE_APPLICATION);

	// Enable tracking. Central Process may defer runnable publication until
	// all external process metadata is installed.
	TrackThread(pid, TRUE);
	if(!defer_start)
		SetThreadPriority(pid, THREAD_PRIORITY_NORMAL);

	//
	ReportMessage("%s: THREAD BASE for PID%d = 0x%x stack=%x-%x (%d KiB)\n",
		__FUNCTION__, pid, thread_base[pid],
		appStack, appStack+l_appStack, l_appStack/1024);

	puts("(H) ");
	// Indicate that the process have been created successfully
	// (debug functionallity for bochs)
	Indication();

	//
//	ESCLOCK();

	// Restore flags
	set_eflags(flags);

	puts("(I) ");
	// Return PID
	return pid;
}

//


/*
 * Public format-dispatch entry.
 *
 * Older JTMOS programs are flat binaries linked for RTCODE and continue to use
 * the historical loader.  Current libc programs are ELF32/i386 ET_EXEC files;
 * those are copied by PT_LOAD metadata and start at their ELF e_entry.
 */
static int launchapp_dispatch(BYTE *abin, int length, int memkb,
                              const LAUNCHAPP_CONTEXT *ctx)
{
    int fmt,rv;

    if(!ctx) {
        launchapp_error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        launchapp_detail=LAUNCHAPP_DETAIL_CONTEXT;
        return 0;
    }

    rv=LaunchAppValidateImage(abin,length,&fmt);
    if(rv!=LAUNCHAPP_ELF_OK) {
        launchapp_error=CENTRALPROCESS_ERROR_CORRUPTEDEXE;
        launchapp_detail=rv;
        dprintk("LaunchApp: rejected image detail=%d format=%d caller=%d cwd=%d/%d run=%d/%d.\n",
               rv,fmt,ctx->callerPID,ctx->callerDNR,ctx->callerDB,
               ctx->runDNR,ctx->runDB);
        return 0;
    }

    if(fmt==JTMOS_EXE_FORMAT_ELF32)
        return LaunchAppELF32Ex(abin,length,memkb,ctx->runDNR,ctx->runDB,ctx->deferStart);
    if(fmt==JTMOS_EXE_FORMAT_LEGACY_RAW)
        return LaunchAppLegacyRawEx(abin,length,memkb,ctx->runDNR,ctx->runDB,ctx->deferStart);

    launchapp_error=CENTRALPROCESS_ERROR_CORRUPTEDEXE;
    launchapp_detail=LAUNCHAPP_DETAIL_FORMAT;
    return 0;
}


/*
 * V70.42 launch serialization.
 *
 * The loader touches process page tables, PID lifecycle/accounting and legacy
 * compatibility state.  It is legal to call it from several normal threads,
 * but only one publication transaction may be active at a time.  Sleeping
 * mutex contention keeps interrupts enabled and lets the scheduler run.  An
 * atomic/IF=0 caller may not sleep, so it gets a non-blocking trylock failure
 * instead of corrupting another launch.
 */
int LaunchAppExContextResult(BYTE *abin, int length, int memkb,
                             const LAUNCHAPP_CONTEXT *ctx, LAUNCHAPP_RESULT *result)
{
    int rv;
    int locked;

    if(result)
    {
        result->error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
        result->detail=LAUNCHAPP_DETAIL_ARGUMENT;
    }

    if(get_eflags() & 0x200UL)
    {
        mutex_lock(&launchapp_mutex);
        locked=1;
    }
    else
    {
        locked=mutex_trylock(&launchapp_mutex);
        if(!locked)
        {
            if(result)
            {
                result->error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
                result->detail=LAUNCHAPP_DETAIL_BUSY;
            }
            dprintk("LaunchApp: concurrent launch rejected in atomic context (PID%d).\n",
                    GetCurrentThread());
            return 0;
        }
    }

    /* V70.44: LaunchApp owns a loader-local result slot protected by the
     * launch mutex. Never borrow Central Process request fields here: CP may
     * be validating/aborting a different request after its loader phase. */
    launchapp_error=0;
    launchapp_detail=0;
    rv=launchapp_dispatch(abin,length,memkb,ctx);
    if(result)
    {
        result->error=launchapp_error;
        result->detail=launchapp_detail;
    }
    mutex_unlock(&launchapp_mutex);
    return rv;
}

int LaunchAppExContext(BYTE *abin, int length, int memkb,
                       const LAUNCHAPP_CONTEXT *ctx)
{
    LAUNCHAPP_RESULT result;
    int rv=LaunchAppExContextResult(abin,length,memkb,ctx,&result);

    /* Compatibility callers historically read global status. Never allow one
     * to overwrite a live CP request's result. */
    if(!centralprocess.isBusy)
    {
        centralprocess.error=result.error;
        centralprocess.launch_detail=result.detail;
    }
    return rv;
}

/* Compatibility ABI for older kernel code.  dnr/db are explicit child cwd,
 * while the origin is still recorded as the actual caller rather than the
 * Central Process service by accident. */
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db)
{
    LAUNCHAPP_CONTEXT ctx;
    ctx.callerPID=GetCurrentThread();
    ctx.callerDNR=GetCurrentDNR();
    ctx.callerDB=GetCurrentDB();
    ctx.runDNR=dnr;
    ctx.runDB=db;
    ctx.deferStart=0;
    return LaunchAppExContext(abin,length,memkb,&ctx);
}
