#ifndef __INCLUDED_PANIC_H__
#define __INCLUDED_PANIC_H__

extern volatile int kernel_panic_active;
void IRQStatusCritical(void);
void KernelPanicFaultContext(unsigned long code,unsigned long eip,
                             unsigned long ebp,unsigned long esp,
                             unsigned long eflags);
__attribute__((noreturn)) void KernelFatalAt(const char *msg,
    const char *file, const char *function, int line);
__attribute__((noreturn)) void FATALERROR(const char *s);
/* Legacy kernel-link compatibility. New code should use KERNEL_FATAL for
 * true invariants or return an error for recoverable failures. */
__attribute__((noreturn)) void panic(const char *s);

#endif
