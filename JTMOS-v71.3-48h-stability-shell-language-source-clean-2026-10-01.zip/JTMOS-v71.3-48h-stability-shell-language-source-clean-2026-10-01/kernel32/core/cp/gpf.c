/**********************************************************************
 * JTMOS General Purpose Exception Handler.
 * (C) 1999-2006 by Jari Tuominen.
 *
 * GPF/Etc. handler functions. Isolated from kernel32.c.
 * Check out FATALEXCEPTION.
 *
 * See exception.code for exception code.
 *
 **********************************************************************/

// Required includes.
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "sb.h"
#include "syssh.h"
#include "ega.h"
#include "driver_sys.h"
#include "zero.h"
#include "null.h"
#include "pci.h"
#include "vga.h"
#include "threads.h"
#include "syssh_applications2.h"
#include "statusline.h" // statusline_terminate trigger
#include "panic.h"
#include "mm.h"
#include "keropt.h"
#include "logging.h"
#include "vesa.h"
#include "linuxabi.h"

//
int EXCEPTION_HANDLER_ACTIVE=FALSE;
/* PID whose exception is currently being contained.  Nested faults use this
 * to sacrifice the offending ordinary process instead of recursively
 * faulting the whole kernel. */
static volatile int exception_owner_pid=-1;

// from corner.mac
char irqActive=FALSE;

//------------------------------------------------------------------------------------------------------
//
inline void TellAtB8000(char *s)
{
	static char str[100];
	static int i,i2,l;
	static DWORD *ptr JTM_UNUSED;
        static TSSEG *ts JTM_UNUSED;
	static char *excact = "Exception caught";
	static char *excdea JTM_UNUSED = "                ", *p;

	// Tell about exception.
	p = JTM_DWORD_TO_PTR(char,0xB8000);
	
	// Wipe off some space.
	for(i=0; i<(80*2*5); i+=2)
	{
		p[i+0] = ' ';
		p[i+1] = 0x0F;
	}

	//
	l = strlen(excact);
	for(i=0,i2=0; i<l; i++,i2+=2)
	{
		p[i2+0] = excact[i];
		p[i2+1] = 0x0F;
	}
	l = strlen(s); p+=160;
	for(i=0,i2=0; i<l; i++,i2+=2)
	{
		p[i2+0] = s[i];
		p[i2+1] = 0x0F;
	}

	//
	sprintf(str, "PID=%d, Last IRQ ID(irqActive)=%d, taskSwitchNr=%d",
		nr_curthread, irqActive,
		taskSwitchNr);
	p+=160;
	for(i=0,i2=0; str[i]!=0; i++,i2+=2)
	{
		p[i2+0] = str[i];
		p[i2+1] = 0x0F;
	}

	//
	sprintf(str, "Press ESC to continue.");
	p+=160;
	for(i=0,i2=0; str[i]!=0; i++,i2+=2)
	{
		p[i2+0] = str[i];
		p[i2+1] = 0x0F;
	}
	/* Do not poll i8042 port 0x60 here: that can consume PS/2 mouse data.
	 * Exception diagnostics are non-interactive now; keyboard input remains
	 * owned exclusively by the keyboard IRQ path. */
}

/* V70.62 exception policy: CPU state-corruption exceptions are never resumed
 * or converted into process exits. Everything else can be contained when it
 * belongs to an ordinary non-immortal PID>0 task. */
static int ExceptionIsSystemFatal(int code)
{
    return code==2 || code==8 || code==18; /* NMI, #DF, #MC */
}

static int ExceptionCanContainProcess(int pid,int code,int immortal)
{
    return pid>0 && !immortal && Multitasking &&
           !ExceptionIsSystemFatal(code) && EXCEPTION_CONTAIN_NONZERO_PID;
}

static int ExceptionSignalForCode(int code)
{
    switch(code) {
        case 0: case 4: case 16: case 19: return JTMOS_SIGFPE;
        case 1: case 3: return JTMOS_SIGTRAP;
        case 6: return JTMOS_SIGILL;
        case 17: return JTMOS_SIGBUS;
        case 5: case 10: case 11: case 12: case 13: case 14:
        case 20: case 21: case 28: case 29: case 30:
            return JTMOS_SIGSEGV;
        default: return JTMOS_SIGABRT;
    }
}

/* V70 process-close exception path.
 *
 * Ordinary PID>0 tasks are quarantined and transferred away from immediately;
 * expensive/user-visible reporting is deferred to CPU_IDLE.  This is the
 * kernel equivalent of "CLOSE APPLICATION": a bad #PF/#GP/#UD/etc. terminates
 * the offending task instead of turning a recoverable application bug into a
 * machine-wide panic.  PID0, immortal tasks, NMI, #DF and #MC never enter here.
 */
static __attribute__((noreturn)) void CloseFaultingTaskFromException(int pid,int code)
{
    int recovery_pid;

    KernelResourceOwnerFaulted(pid);
    KernelBootWorkerFaulted(pid);
    KernelServiceSupervisorFaulted(pid);
    SystemLoggingWorkerFaulted(pid);
    /* Preserve a meaningful waitpid() status before KillThreadEx() later sees
     * the quarantined process and would otherwise record generic SIGKILL. */
    LinuxProcessExit(pid,0,ExceptionSignalForCode(code));
    CrashAnalysisSetDisposition(pid,CRASH_DISPOSITION_QUARANTINE);
    ThreadQuarantineFromException(pid);
    exception_frame_valid=0;
    gp_frame_valid=0;
    pf_frame_valid=0;
    mm_page_fault_context_reset();
    exception_owner_pid=-1;
    EXCEPTION_HANDLER_ACTIVE=FALSE;

    enable();
    recovery_pid=(IdleThread.pid>0 && IdleThread.pid<nr_threads &&
                  valid_pid(IdleThread.pid) && thread_states[IdleThread.pid])
                 ? IdleThread.pid : 0;
    (void)SwitchToThreadEx(recovery_pid);
    for(;;) { enable(); SwitchToThread(); }
}

/* 
 * ------------------------------------------
 * FATALEXCEPTION - Default exception handler
 * ------------------------------------------
 */
//
// Update: terminates thread and calls SwitchToThread();
//
// Exception handler process (TSS task).
//
__attribute__ ((__noreturn__)) void FATALEXCEPTION(const char *s)
{
    TSSEG *ts;
    int pid;
    int from_user;
    int live_gp;
    int live_pf;
    int live_generic;
    int live_authoritative;
    int recover_kernel_gp;
    int recover_if0_task;
    int recover_klogger_task;
    int recover_nested_pf_task;
    int recover_process_fault;
    int task_immortal;
    int recovery_pid;
    DWORD live_cs=0;
    DWORD live_eip=0;
    DWORD live_eflags=0;
    JTMOS_CRASH_FRAME crash_frame;

    /* V69.39 NMI invariant: an exception handler must never IRET back into an
     * active NMI task.  On IA-32 an IRET executed for a fault nested inside an
     * NMI can release the processor's NMI-blocking latch too early.  Returning
     * would also leave the dedicated NMI TSS busy, so fail closed immediately
     * with the lock-free panic path instead of attempting process containment. */
    if(NmiTaskGateInProgress())
        KernelFatalAt("CPU exception inside NMI task", "NMI task gate",
                      s ? s : "unknown exception", exception.code);

    /* V68.216: if diagnostics/containment itself faults while handling an
     * ordinary process, do not recursively format another report.  Quarantine
     * the original owner with the absolute minimum of work and escape to the
     * idle task.  PID 0/immortal owners and catastrophic #DF/#MC still fail
     * closed because the kernel can no longer promise global consistency. */
    if(EXCEPTION_HANDLER_ACTIVE) {
        int owner=(int)exception_owner_pid;
        int owner_immortal=0;
        if(owner>0 && owner<nr_threads && owner<N_MAX_THREADS && valid_pid(owner))
            owner_immortal=(GetThreadType(owner)&THREAD_TYPE_IMMORTAL)?1:0;
        if(owner>0 && !owner_immortal && Multitasking &&
           exception.code!=8 && exception.code!=18) {
            KernelResourceOwnerFaulted(owner);
            KernelBootWorkerFaulted(owner);
            KernelServiceSupervisorFaulted(owner);
            SystemLoggingWorkerFaulted(owner);
            LinuxProcessExit(owner,0,ExceptionSignalForCode(exception.code));
            CrashAnalysisSetDisposition(owner,CRASH_DISPOSITION_QUARANTINE);
            ThreadQuarantineFromException(owner);
            exception_frame_valid=0;
            gp_frame_valid=0;
            pf_frame_valid=0;
            mm_page_fault_context_reset();
            exception_owner_pid=-1;
            EXCEPTION_HANDLER_ACTIVE=FALSE;
            enable();
            recovery_pid=(IdleThread.pid>0 && IdleThread.pid<nr_threads &&
                          valid_pid(IdleThread.pid) && thread_states[IdleThread.pid])
                         ? IdleThread.pid : 0;
            (void)SwitchToThreadEx(recovery_pid);
            for(;;) { enable(); SwitchToThread(); }
        }
        KernelFatalAt("nested CPU exception", "CPU exception handler", s, exception.code);
    }

    /* The tick-only boot gate temporarily disables task switching.  If the
     * isolated init worker faults there, first restore the normal scheduler;
     * then the standard PID>0 quarantine can escape to CPU_IDLE.  Leave NMI,
     * #DF, #MC and PID0 on the fatal path. */
    pid=GetCurrentThread();
    if(pid>0 && KernelBootWorkerActive(pid) && PitStorageSafeActive() &&
       exception.code!=2 && exception.code!=8 && exception.code!=18)
        PitStorageSafeAbortFromException();

    EXCEPTION_HANDLER_ACTIVE=TRUE;
    pid=GetCurrentThread();
    exception_owner_pid=pid;
    if(tasks==NULL || pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS)
        KernelFatalAt("CPU exception with invalid current task", "CPU exception handler", s, exception.code);

    ts=&tasks->tss[pid];
    /* #DF and #MC are system-corruption signals and remain fail-closed. */
    live_gp=(exception.code==13 && gp_frame_valid==JTMOS_GP_FRAME_MAGIC);
    live_pf=(exception.code==14 && pf_frame_valid==JTMOS_PF_FRAME_MAGIC);
    live_generic=(exception.code!=8 && exception.code!=18 &&
                  exception.code!=13 && exception.code!=14 &&
                  exception_frame_valid==JTMOS_EXCEPTION_FRAME_MAGIC);
    live_authoritative=(live_gp || live_pf || live_generic);

    if(live_gp) {
        live_cs=gp_frame_cs;
        live_eip=gp_frame_eip;
        live_eflags=gp_frame_eflags;
        from_user=((gp_frame_cs & 3U)==3U);
    } else if(live_pf) {
        live_cs=pf_frame_cs;
        live_eip=pf_frame_eip;
        live_eflags=pf_frame_eflags;
        from_user=((pf_frame_cs & 3U)==3U);
    } else if(live_generic) {
        live_cs=exception_frame_cs;
        live_eip=exception_frame_eip;
        live_eflags=exception_frame_eflags;
        from_user=((exception_frame_cs & 3U)==3U);
    } else {
        /* Very early/legacy stubs may still have only a scheduler snapshot. */
        live_cs=ts->cs;
        live_eip=ts->eip;
        live_eflags=ts->eflags;
        from_user=((ts->cs & 3U)==3U);
    }

    /* Decide containment before verbose diagnostics. A recoverable task may
     * have faulted inside malloc/JTMFS/logging with IF=0; walking page tables,
     * stacks or console code before quarantining it can itself page-fault and
     * turn one process crash into a nested-exception system halt. */
    task_immortal=(GetThreadType(pid)&THREAD_TYPE_IMMORTAL)?1:0;
    recover_kernel_gp=(exception.code==13 && pid!=0 && !task_immortal &&
                       Multitasking && GPF_RECOVER_NONZERO_PID);
    recover_if0_task=(pid!=0 && !task_immortal && Multitasking &&
                      live_authoritative && !(live_eflags&0x200U) &&
                      EXCEPTION_RECOVER_IF0_NONZERO_PID);
    recover_klogger_task=(pid!=0 && !task_immortal && Multitasking &&
                          SystemLoggingIsWorker(pid));
    recover_nested_pf_task=(exception.code==14 && pid!=0 && !task_immortal &&
                            Multitasking && mm_page_fault_context_nested());
    /* Default policy: an ordinary process is expendable; the operating system
     * is not.  This deliberately covers kernel-mode worker processes too, so
     * a KLOGGER/mkfs/filesystem fault cannot strand the entire machine merely
     * because CS happened to be ring 0 or IF happened to be clear. */
    recover_process_fault=ExceptionCanContainProcess(pid,exception.code,task_immortal);

    memset(&crash_frame,0,sizeof(crash_frame));
    crash_frame.eip=live_eip;
    crash_frame.cs=live_cs;
    crash_frame.eflags=live_eflags;
    crash_frame.cr2=GETCR2();
    crash_frame.authoritative=live_authoritative?1:0;
    crash_frame.from_user=from_user?1:0;
    if(live_gp) {
        crash_frame.error=gp_frame_error;
        crash_frame.entry_esp=gp_frame_entry_esp;
        crash_frame.user_esp=gp_frame_user_esp;
        crash_frame.user_ss=gp_frame_user_ss;
        crash_frame.eax=gp_frame_eax; crash_frame.ebx=gp_frame_ebx;
        crash_frame.ecx=gp_frame_ecx; crash_frame.edx=gp_frame_edx;
        crash_frame.esi=gp_frame_esi; crash_frame.edi=gp_frame_edi;
        crash_frame.ebp=gp_frame_ebp;
        crash_frame.regs_authoritative=1;
    } else if(live_pf) {
        crash_frame.error=pf_frame_error;
        crash_frame.entry_esp=pf_frame_entry_esp;
        crash_frame.user_esp=pf_frame_user_esp;
        crash_frame.user_ss=pf_frame_user_ss;
        crash_frame.eax=pf_frame_eax; crash_frame.ebx=pf_frame_ebx;
        crash_frame.ecx=pf_frame_ecx; crash_frame.edx=pf_frame_edx;
        crash_frame.esi=pf_frame_esi; crash_frame.edi=pf_frame_edi;
        crash_frame.ebp=pf_frame_ebp;
        crash_frame.regs_authoritative=1;
    } else if(live_generic) {
        crash_frame.error=exception_frame_error;
        crash_frame.entry_esp=exception_frame_entry_esp;
        crash_frame.user_esp=exception_frame_user_esp;
        crash_frame.user_ss=exception_frame_user_ss;
    }
    if(!crash_frame.regs_authoritative) {
        crash_frame.eax=ts->eax; crash_frame.ebx=ts->ebx;
        crash_frame.ecx=ts->ecx; crash_frame.edx=ts->edx;
        crash_frame.esi=ts->esi; crash_frame.edi=ts->edi; crash_frame.ebp=ts->ebp;
    }
    CrashAnalysisCaptureException(s,exception.code,pid,&crash_frame,ts);

    /* Make the fault visible on an active VESA/GraOS framebuffer immediately.
     * The desktop's next full present restores graphics after an isolated
     * application fault; a system panic overwrites this with its fatal text. */
    if(VesaEmergencyTextBegin()) {
        VesaEmergencyTextLine(0,"*** JTMOS EXCEPTION ***");
        VesaEmergencyTextLine(1,s ? s : "unknown CPU exception");
        VesaEmergencyTextHex(3,"PID 0x",(DWORD)pid);
        VesaEmergencyTextHex(4,"CS  0x",live_cs);
        VesaEmergencyTextHex(5,"EIP 0x",live_eip);
        VesaEmergencyTextHex(6,"CR2 0x",crash_frame.cr2);
        VesaEmergencyTextHex(7,"Stack ESP 0x",crash_frame.entry_esp);
        VesaEmergencyTextHex(8,"Stack EBP 0x",crash_frame.ebp);
        VesaEmergencyTextHex(9,"EFLAGS 0x",live_eflags);
        VesaEmergencyTextLine(11,"Full crash context: serial console / logs/crash.log");
    }

    DebugSerialEmergencyWrite("\n[EXCEPTION] "); DebugSerialEmergencyWrite(s ? s : "unknown");
    DebugSerialEmergencyWrite(" PID="); DebugSerialEmergencyWriteHex32((DWORD)pid);
    DebugSerialEmergencyWrite(" LIVE_CS="); DebugSerialEmergencyWriteHex32(live_cs);
    DebugSerialEmergencyWrite(" LIVE_EIP="); DebugSerialEmergencyWriteHex32(live_eip);
    DebugSerialEmergencyWrite(" LIVE_EFLAGS="); DebugSerialEmergencyWriteHex32(live_eflags);
    DebugSerialEmergencyWrite(" CR2="); DebugSerialEmergencyWriteHex32(GETCR2());
    DebugSerialEmergencyWrite("\n");

    /* Recoverable process faults use only the fixed RAM crash snapshot and
     * emergency serial line here. Detailed formatting is deferred to CPU_IDLE.
     * This is especially important for KLOGGER and IF=0 faults. */
    if(ExceptionCanContainProcess(pid,exception.code,task_immortal) &&
       (recover_process_fault || from_user || recover_kernel_gp || recover_if0_task ||
        recover_klogger_task || recover_nested_pf_task))
        CloseFaultingTaskFromException(pid,exception.code);

    printk("\nPID %d/%d(%s): %s  taskSwitchNr=%d\n",pid,nr_threads-1,
           thread_name[pid],s ? s : "unknown exception",taskSwitchNr);

    if(live_gp) {
        DWORD selector_index=(gp_frame_error>>3)&0x1fffU;
        printk("LIVE #GP: CS:EIP=%x:%x ERR=%x EFLAGS=%x ENTRY_ESP=%x\n",
               gp_frame_cs,gp_frame_eip,gp_frame_error,gp_frame_eflags,
               gp_frame_entry_esp);
        printk("LIVE regs: EAX=%x EBX=%x ECX=%x EDX=%x ESI=%x EDI=%x EBP=%x",
               gp_frame_eax,gp_frame_ebx,gp_frame_ecx,gp_frame_edx,
               gp_frame_esi,gp_frame_edi,gp_frame_ebp);
        if((gp_frame_cs & 3U)==3U)
            printk(" USER_SS:ESP=%x:%x",gp_frame_user_ss,gp_frame_user_esp);
        printk("\nGP decode: EXT=%u IDT=%u TI=%u selector-index=%u (%x)\n",
               (unsigned)(gp_frame_error&1U),
               (unsigned)((gp_frame_error>>1)&1U),
               (unsigned)((gp_frame_error>>2)&1U),
               (unsigned)selector_index,(unsigned)(selector_index<<3));
        printk("GP live frame is authoritative; TSS snapshot below may be stale.\n");
    } else if(live_pf) {
        printk("LIVE #PF: CS:EIP=%x:%x ERR=%x EFLAGS=%x CR2=%x ENTRY_ESP=%x\n",
               pf_frame_cs,pf_frame_eip,pf_frame_error,pf_frame_eflags,GETCR2(),
               pf_frame_entry_esp);
        printk("LIVE regs: EAX=%x EBX=%x ECX=%x EDX=%x ESI=%x EDI=%x EBP=%x",
               pf_frame_eax,pf_frame_ebx,pf_frame_ecx,pf_frame_edx,
               pf_frame_esi,pf_frame_edi,pf_frame_ebp);
        if((pf_frame_cs & 3U)==3U)
            printk(" USER_SS:ESP=%x:%x",pf_frame_user_ss,pf_frame_user_esp);
        printk("\nPF decode: %s %s %s%s%s\n",
               (pf_frame_error&1U)?"protection":"not-present",
               (pf_frame_error&2U)?"write":"read",
               (pf_frame_error&4U)?"user":"supervisor",
               (pf_frame_error&8U)?" reserved-bit":"",
               (pf_frame_error&16U)?" instruction-fetch":"");
        printk("TSS snapshot below is scheduler state and may have a stale EIP for interrupt-gate faults.\n");
    } else if(live_generic) {
        printk("LIVE exception: CS:EIP=%x:%x ERR=%x EFLAGS=%x ENTRY_ESP=%x",
               exception_frame_cs,exception_frame_eip,exception_frame_error,
               exception_frame_eflags,exception_frame_entry_esp);
        if((exception_frame_cs & 3U)==3U)
            printk(" USER_SS:ESP=%x:%x",exception_frame_user_ss,exception_frame_user_esp);
        printk("\n");
    }

    tss_dump(ts);
    AnalyzeFault(ts,exception.code);

    /* Only genuinely system-fatal contexts reach this point. */
    CrashAnalysisSetDisposition(pid,CRASH_DISPOSITION_FATAL);
    KernelPanicFaultContext((DWORD)exception.code,live_eip,crash_frame.ebp,
                            crash_frame.entry_esp,live_eflags);
    mm_page_fault_context_reset();
    exception_owner_pid=-1;
    KernelFatalAt(s ? s : "fatal CPU exception", "CPU exception handler",
                  "FATALEXCEPTION", exception.code);

}

//
void Disassemble(BYTE *p)
{
	//
	if(p[0]==0xCD)
	{
		printk("Disassembly:    %x  INT 0x%x\n",
			p,p[1]);
	}
}

//
inline void ESCLOCK (void)
{
	/* Historical ESCLOCK polled port 0x60 directly.  0x60 is the shared
	 * i8042 output data register, so that stole AUX mouse bytes.  Use the
	 * software key-state table maintained by IRQ1 instead.  This routine is
	 * intentionally non-blocking when interrupts are disabled. */
	if(!kbstr.ktab)
		return;
	if(!(get_eflags() & (1U<<9)))
		return;
	while(kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
	while(!kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
	while(kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
}

//------------------------------------------------------------------------------
// Backtrace.
//
void STACKWALK(DWORD ptr)
{
	DWORD i, i2 JTM_UNUSED, unit JTM_UNUSED,ad;
	BYTE *p;

	//
	p = JTM_DWORD_TO_PTR(BYTE,ptr);

	//
	if(illegal(p))
	{
		return;
	}

	//
	printk("Backtrace: ");
	for(i=0; i<10; i++,p+=4)
	{
		ad = (p[3]<<24)|(p[2]<<16)|(p[1]<<8)|p[0];
		printk("%x ", ad);
	}
	printk("\n");
}

//------------------------------------------------------------------------------
// Displays a stack dump.
//
void STACKDUMP(DWORD whereAD)
{
	DWORD i, i2, unit;
	BYTE *p;

	// expecting that there is 80 marks per a line
	unit = 16;

	//
	p = A2K(whereAD);

	//
	printk("ESP=0x%x (fixed=0x%x)  ", whereAD, p);
	printk("Base=0x%x\n", GetCurrentThreadBase());

	//
	if(illegal(p))
	{
		printk("Stack pointer refers to an illegal memory region, won't make a stack dump.\n");
		PageDumpNear(JTM_PTR_TO_DWORD(p));
		return;
	}

	//
	printk("stack dump:\n");
	for(i=0; i<0x20; i+=unit)
	{
		//
		p32(JTM_PTR_TO_DWORD(p - i));
		printk(": ");
		for(i2 = 0; i2 < unit; i2++)
		{
			p8(p[i-i2-1]);
			printk(" ");
		}
		printk("\n");
	}
}

// Displays a program binary dump
void PRGDUMP(void)
{
	DWORD i, i2, unit;
	BYTE *p;

	// expecting that there is 80 marks per a line
	unit = 16;

	//
	p = A2K(tasks->tss[GetCurrentThread()].eip);

	//
	if(illegal(p))
	{
		printk("Program counter CS:EIP points to an illegal memory region, won't dump.\n");
		PageDumpNear(JTM_PTR_TO_DWORD(p));
		return;
	}

	//
	printk("executable binary dump:\n");
	for(i=0; i<0x20; i+=unit)
	{
		//
		p32(JTM_PTR_TO_DWORD(p - i));
		printk(": ");
		for(i2 = 0; i2 < unit; i2++)
		{
			p8(p[i+i2]);
			printk(" ");
		}
		printk("\n");
	}
}

//-----------------------------------------------------------------------------
//
void AnalyzeFault(TSSEG *s JTM_UNUSED, int code)
{
	DWORD p1,p2;

	//
	p1 = GetThreadMemoryStart(GetCurrentThread());
	p2 = GetThreadMemoryEnd(GetCurrentThread());

	//
	if(code==14)
	{
		// Page fault:
		//------------------------------------------

		//
        {
            DWORD fault = GETCR2();
            DWORD *pd = (DWORD *)GetKernelPageDirPTR();
            DWORD pde = 0;
            DWORD pte = 0;
            int pid = GetCurrentThread();

            if(pd != NULL)
                pde = pd[fault >> 22];

            printk("Page fault address=0x%x, PID%d memory area 0x%x-0x%x.\n",
                   fault, pid, p1, p2);
            if(fault>=MM_USER_BASE && fault<MM_USER_TOP) {
                DWORD user_page=(fault-MM_USER_BASE)/PAGESIZE;
                pte=mm_get_process_pte(pid,fault);
                printk("Ring3 paging: PDE[%u]=0x%x PID-PTE[%u]=0x%x CR3=0x%x\n",
                       (unsigned)(fault >> 22),pde,(unsigned)user_page,pte,GetCR3());
            } else {
                printk("Ring3 paging: PDE[%u]=0x%x PID-PTE=n/a CR3=0x%x\n",
                       (unsigned)(fault >> 22),pde,GetCR3());
            }

            /* A Ring-3 NULL/low-address fault has no useful kernel flat-page
             * dump.  Avoid extra page-walker/console work while already inside
             * the exception path; kernel-origin faults still get that dump. */
            if(!(pf_frame_valid==JTMOS_PF_FRAME_MAGIC &&
                 (pf_frame_cs & 3U)==3U) &&
               (fault < MM_USER_BASE || fault >= MM_USER_TOP))
                PageDumpNear(fault);
        }
	}
}

//-----------------------------------------------------------------------------
//
void tss_dump(TSSEG *s)
{
	// Print registers
	printk("EAX=%x  EBX=%x  ECX=%x  EDX=%x\n",
		s->eax, s->ebx, s->ecx, s->edx);
	printk("ESI=%x  EDI=%x  EBP=%x  SS:ESP=%x:%x\n",
		s->esi, s->edi, s->ebp, s->ss, s->esp);
	printk("CS=%x  DS=%x  ES=%x  FS=%x  GS=%x  SS=%x\n",
		s->cs, s->ds, s->es, s->fs, s->gs, s->ss);
	printk("CS:EIP=%x:%x  Link=%x  EFLAGS=%x  CR3=%x  CR2=%x\n",
		s->cs, s->eip, s->link, s->eflags, s->cr3, GETCR2());
	if( !(s->eflags&(1<<9)) )
	{
		printk("eflags: Interrupts were disabled.\n");
	}
	else
	{
		printk("eflags: Interrupts were enabled.\n");
	}
}

//
void PROCESSINFO (void)
{
  int i;

  //
  for (i = 0; i < nr_threads; i++)
    {
      printk
	("PID %d: state %d, ESP=%x, SS=%x, tick=%d, name=%s, base=%x, limit=%x\n",
	 i + 1, thread_states[i], thread_esps[i], thread_ss[i],
	 thread_tick[i], thread_name[i], GetThreadBase(i),
	 GetThreadLimit (i));
    }

  //
}

//
