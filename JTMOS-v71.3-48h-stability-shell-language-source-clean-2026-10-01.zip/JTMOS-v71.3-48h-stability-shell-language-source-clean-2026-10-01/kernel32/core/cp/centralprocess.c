// ================================================================
// centralprocess.c - The process creator & Debug window view & Recycler
// (C) 2002-2005,2017 by Jari Tuominen(jari.t.tuominen@gmail.com).
// ================================================================
/*
 * How much to allocate memory for each of the processes?
 *
 * Check out file 'LaunchApp.h' for the amount of memory
 * the kernel will spend on each of the application
 * that runs inside it's own memory space.
 * For instance centralprocess process will be creating processes
 * that are depending on the setting of LaunchApp.h.
 */
#include "kernel32.h" // STATIC_APP_MEM_SIZE
#include "threads.h"
#include "centralprocess.h"
#include "centralprocessInit.h"
#include "sysglvar.h"
#include "keyb.h"
#include "syssh.h"	// ShellMain
#include "driver_api.h"	// driver_getLock
#include "centralprocessMain.h"
#include "linuxabi.h"
#include "jtmfsPath.h"
#include "jtmfsAccess.h"
#include "filedir.h"
#include "scheduler.h"
#include "fs/api.h"

//#define centralprocess_DEBUG

//
VERBATIM centralprocess;
//
int turn=1;

// This function's purpose is to explain the happended error
// in human friendly English language, so that the user
// can understand the error. This information is used in
// debugging.
void centralprocessExplainError(void)
{
	//
	switch(centralprocess.error)
	{
		// No error
		case 0:
		break;
		//
		case CENTRALPROCESS_ERROR_LAUNCHAPPERROR:
		printk("CENTRALPROCESS: Application launch error, detail=%d.\n",
			centralprocess.launch_detail);
		break;
		//
		case CENTRALPROCESS_ERROR_FILENOTFOUND:
		printk("CENTRALPROCESS: Executable binary file not found.\n");
		break;
		//
		case CENTRALPROCESS_ERROR_CORRUPTEDEXE:
		printk("CENTRALPROCESS: Corrupted or non-JTMOS executable binary file.\n");
		break;
		//
		default:
		printk("CENTRALPROCESS: Unknown error occured while creating a process.\n");
		break;
	}
}

//
void trap1(void)
{
}

// fname = file name, ends at the first space(space not included)
// path = whole command line with arguments
int centralprocess_exec(const char *fname, const char *path, int dnr, int db,
		const char *runPath,
		int terID)
{
	return centralprocess_exec_flags(fname,path,dnr,db,runPath,terID,0);
}

int centralprocess_exec_flags(const char *fname, const char *path, int dnr, int db,
		const char *runPath, int terID, unsigned int execFlags)
{
	int caller=GetCurrentThread();
	return centralprocess_exec_stdio_flags(fname,path,dnr,db,runPath,terID,
		LinuxGetStdioRoute(caller,0),LinuxGetStdioRoute(caller,1),
		LinuxGetStdioRoute(caller,2),execFlags);
}

int centralprocess_exec_stdio(const char *fname, const char *path, int dnr, int db,
		const char *runPath, int terID, int stdinFD, int stdoutFD, int stderrFD)
{
	return centralprocess_exec_stdio_flags(fname,path,dnr,db,runPath,terID,
		stdinFD,stdoutFD,stderrFD,0);
}

int centralprocess_exec_stdio_flags(const char *fname, const char *path, int dnr, int db,
		const char *runPath, int terID, int stdinFD, int stdoutFD, int stderrFD,
		unsigned int execFlags)
{
	DWORD entry_flags,cs_flags;
	int pid,error;
	int requesterPID;
	int run_dnr,run_db,run_rv;
	char canonical_runpath[256];
	const char *requested_runpath;

	if(fname==NULL)return 0;
	if(path==NULL) path=fname;
	if(execFlags & ~JTMOS_EXEC_F_VALID_MASK)
	{
		dprintk("CP: rejecting unknown exec flags 0x%x from PID%d.\n",
			execFlags,GetCurrentThread());
		return 0;
	}
	/* V70.42: the request record is shared kernel memory; never let an external
	 * API caller overflow it while another task is runnable. */
	if((unsigned int)strlen(fname)>=sizeof(centralprocess.fname) ||
	   (unsigned int)strlen(path)>=sizeof(centralprocess.path) ||
	   (runPath && (unsigned int)strlen(runPath)>=sizeof(centralprocess.runPath)))
	{
		dprintk("CP: exec request too long from PID%d.\n",GetCurrentThread());
		return 0;
	}

	/* V67.8.57.10.18.16.31: libc cexec()/bgexec() use terminal -1 as
	 * the portable "inherit my controlling terminal" sentinel.  Never copy
	 * that sentinel into thread_terminal[]: console syscalls index screens[]
	 * with the child's terminal number, so -1 turns the first printf/getch into
	 * an out-of-bounds access.  SMSH passed an explicit terminal and therefore
	 * hid this bug; SQSH uses libc and exposed it almost every launch. */
	requesterPID=GetCurrentThread();

	/* Resolve the requested child CWD while the submitting process context is
	 * still authoritative.  The permanent Central Process has its own DNR/DB;
	 * resolving/chdir'ing later in that service loses device-qualified cwd
	 * information (for example hda:/work becoming /).  Empty workDir means
	 * inherit the caller exactly. */
	/* Empty workDir means exact CWD inheritance.  Do not round-trip the
	 * request through a textual path at all: DNR/DB is the authoritative
	 * filesystem location and preserves ram:/bin versus ram:/ exactly. */
	if(runPath==NULL || !runPath[0])
	{
		requested_runpath="<inherit>";
		run_dnr=dnr;
		run_db=db;
		run_rv=JTMFS_PATH_OK;
	}
	else
	{
		requested_runpath=runPath;
		run_dnr=dnr; run_db=db;
		run_rv=jtmfsResolvePathAt(dnr,db,requested_runpath,&run_dnr,&run_db);
		if(run_rv!=JTMFS_PATH_OK)
		{
			printk("CP: requester PID%d workdir '%s' cannot be resolved from DNR/DB=%d/%d (rv=%d).\n",
				requesterPID,requested_runpath,dnr,db,run_rv);
			return 0;
		}
	}
	canonical_runpath[0]=0;
    if(runPath==NULL || !runPath[0])
    {
        /* Exact inheritance: ask the per-thread cwd cache first.  This string is
         * diagnostic only; execution continues to use run_dnr/run_db directly. */
        if(jtmfs_GetThreadCWD(requesterPID,canonical_runpath,sizeof(canonical_runpath))!=JTMFS_PATH_OK)
            canonical_runpath[0]=0;
    }
    else if(jtmfsBuildPath(run_dnr,run_db,canonical_runpath,sizeof(canonical_runpath))!=JTMFS_PATH_OK)
    {
        canonical_runpath[0]=0;
    }

	if(!canonical_runpath[0])
	{
		/* A display-only fallback must not change the real runDNR/runDB. */
		if(runPath!=NULL && runPath[0])
			strncpy(canonical_runpath,runPath,sizeof(canonical_runpath)-1);
		else
			strncpy(canonical_runpath,"<caller-cwd>",sizeof(canonical_runpath)-1);
		canonical_runpath[sizeof(canonical_runpath)-1]=0;
	}

	if(terID==-1)
		terID=GetThreadTerminal(requesterPID);
	if(terID<0 || terID>=N_MAX_SCREENS)
	{
		printk("CP: invalid terminal %d for requester PID%d; using terminal 0.\n",
			terID,requesterPID);
		terID=0;
	}

	/* V68.153: centralprocess_exec() is a blocking process-context service.
	 * Build 151 kept CLI active across all of the SwitchToThread() wait loops;
	 * vt2 autostart made that path run on every normal boot.  That propagated
	 * IF=0 through voluntary task switches and left exception recovery without
	 * IRQ0/IRQ1.  Only the shared request publication itself needs to be atomic.
	 */
	entry_flags=get_eflags();
	for(;;)
	{
		cs_flags=get_eflags();
		disable();
		if(!centralprocess.isBusy && !centralprocess.resultPending)
		{
			centralprocess.isBusy=1;
			centralprocess.appPID=0;
			centralprocess.error=0;
			centralprocess.launch_detail=0;
			launchapp_cleartogo=0;
			centralprocess.terminalID=terID;
			centralprocess.requesterPID=requesterPID;
			centralprocess.requesterMagic=thread_magic[requesterPID];
			centralprocess.stdinFD=stdinFD;
			centralprocess.stdoutFD=stdoutFD;
			centralprocess.stderrFD=stderrFD;
			centralprocess.execFlags=execFlags;
			strcpy(centralprocess.fname,fname);
			strcpy(centralprocess.path,path);
			if(strstr(centralprocess.fname,".")==NULL) strcat(centralprocess.fname,".bin");
			strcpy(centralprocess.runPath,canonical_runpath);
			centralprocess.dnr=dnr;
			centralprocess.db=db;
			centralprocess.callerDNR=dnr;
			centralprocess.callerDB=db;
			centralprocess.runDNR=run_dnr;
			centralprocess.runDB=run_db;
			centralprocess.inheritCWD=(runPath==NULL || !runPath[0]) ? 1 : 0;
			set_eflags(cs_flags);
			/* V70.11: request publication is an event.  Do not wait for the
			 * Central Process polling deadline to expire. */
			if(centralprocessPID>0) SchedulerWakeThread(centralprocessPID);
			break;
		}
		set_eflags(cs_flags);
		SchedulerWaitPause(1000UL);
	}

	/* A blocking launch must not yield repeatedly with maskable interrupts
	 * disabled.  If a legacy caller entered with IF clear, temporarily enable
	 * IRQs while waiting and restore its entry state before returning. */
	if(!(entry_flags & 0x200UL))
	{
		dprintk("CP: exec requester PID%d entered with IF=0; enabling IRQs for blocking wait.\n",
			requesterPID);
		enable();
	}

	while(!launchapp_cleartogo) { SchedulerWaitPause(1000UL); }
	while(centralprocess.isBusy) { SchedulerWaitPause(1000UL); }

	/* Copy and release the single published result atomically.  resultPending
	 * prevents a second submitter from reusing the request record before this
	 * caller has consumed appPID/error. */
	cs_flags=get_eflags();
	disable();
	if(centralprocess.requesterPID!=requesterPID ||
	   centralprocess.requesterMagic!=thread_magic[requesterPID])
	{
		/* PID reuse must never consume another task's asynchronous result. */
		pid=0;
		error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
	}
	else
	{
		pid=centralprocess.appPID;
		error=centralprocess.error;
	}
	centralprocess.resultPending=0;
	set_eflags(cs_flags);

	/* Preserve the caller's original IF contract, but only after all blocking
	 * work and cooperative yields have completed. */
	if(!(entry_flags & 0x200UL))
		disable();
	if(error) return 0;
	return pid;
}

// FILE NAME, PATH, TERMINAL ID
//
// dnr,db =	location where the EXE binary resides
// fname =	file name of the EXE binary file
// runPath =	the path where program will run/work at
//		(aka work path, e.g. '/tmp')
//
int centralprocessExecEx(const char *fname, const char *path, int terminalID,
		int dnr, int db, const char *runPath)
{
	return centralprocess_exec_stdio(fname,path,dnr,db,runPath,terminalID,-1,-1,-1);
}

//
void centralprocess_wait_moment(void)
{
	int i;

	//
	for(i=0; i<10; i++)
		SchedulerWaitPause(1000UL);
}

/* V70.35: executable media discovery is deliberately independent from CWD.
 * A desktop may run with ram:/ as its current filesystem while applications
 * are installed on hda1:/bin.  Probe registered device /bin directories only
 * after normal namespace/active-device/PATH resolution has failed. */
static int cp_find_registered_device_bin(const char *name,char *found,int cap,char *devout,int devcap)
{
    int i,amount,fd,sz,n;
    char dev[32],candidate[256];
    if(!name || !name[0] || !found || cap<=1) return 0;
    amount=driver_getdeviceamount();
    for(i=0;i<amount;i++) {
        dev[0]=0;
        if(getdevicename(i,dev)==NULL || !dev[0]) continue;
        n=sprintf(candidate,"%s:/bin/%s",dev,name);
        if(n<=0 || n>=(int)sizeof(candidate)) continue;
        fd=open(candidate,O_RDONLY);
        if(fd<0) continue;
        sz=lseek(fd,0,SEEK_END); close(fd);
        if(sz<=0) continue;
        if((int)strlen(candidate)>=cap) continue;
        strcpy(found,candidate);
        if(devout && devcap>1) { strncpy(devout,dev,(unsigned int)devcap-1U); devout[devcap-1]=0; }
        return 1;
    }
    return 0;
}

// Called by centralprocess main porcess to load up the exe
int centralprocess_loadEXE(const char *fname)
{
	static int sz;
	int NeedToLoad;
	char path[256],found[256],loadname[256];
	int fd;

	//
	NeedToLoad=1;

	// -----------------------------------------------
	// INITIALIZE
	// Set error
	centralprocess.error=0;
	// Set device
	SetThreadCWDContext(GetCurrentThread(), centralprocess.dnr, centralprocess.db);

	/* V70.34: keep the submitting process's visible PATH synchronized with
	 * the authoritative DNR/DB carried by SYS_cexec, even for explicit /bin
	 * launches.  This repairs stale GraOS/shell PATH snapshots before children
	 * inherit them. */
	(void)ProcessEnvEnsureDeviceBin(centralprocess.requesterPID,centralprocess.dnr);

	// -----------------------------------------------
	// LOAD EXECUTABLE FILE INTO centralprocess.bin -BUFFER

	/* Preserve the const input contract. Direct callers may pass a bare name. */
	strncpy(loadname,fname,sizeof(loadname)-1);
	loadname[sizeof(loadname)-1]=0;
	if(strstr(loadname, ".")==NULL && strlen(loadname)+4U<sizeof(loadname))
		strcat(loadname, ".bin");
	fname=loadname;

	// INTERNAL APPLICATION
	if(!strcmp(fname, ":install.bin"))
	{
		sz = 65536;
		//memcpy(centralprocess.bin, testapp, 65536);
		NeedToLoad=0;
		goto past11;
	}

	// INTERNAL DRIVER
	if(!strcmp(fname, ":hd.bin"))
	{
		sz = 65536;
	//	memcpy(centralprocess.bin, testdrv, 65536);
		NeedToLoad=0;
		goto past11;
	}

	/* V68.119: executable resolution has one important shell invariant:
	 * a bare command name must first mean "the file in the caller's current
	 * directory".  `ls` and `cexec("unz.bin", "")` must therefore agree.
	 *
	 * centralprocess_loadEXE() has already installed centralprocess.dnr/db as
	 * the CP thread's temporary filesystem context above, so open(fname) here
	 * is an exact probe against the original SYS_cexec caller DNR/DB.  Only if
	 * that probe fails do we search PATH.  This also avoids converting the cwd
	 * to text and back, which can lose device identity (ram:/ versus hda1:/).
	 *
	 * Explicit paths -- including device-qualified names such as ram:/unz.bin
	 * and ram:unz.bin -- never fall through to PATH. */
	strcpy(found, "");
	if(strchr(fname,'/')!=NULL || strchr(fname,'\\')!=NULL || strchr(fname,':')!=NULL)
	{
		int explicit_ok=0;
		strcpy(found,fname);
		{ int efd=open(found,O_RDONLY); if(efd>=0) { int esz=lseek(efd,0,SEEK_END); close(efd); if(esz>0) explicit_ok=1; } }

		if(!explicit_ok && fname[0]=='/' && !strncmp(fname,"/bin/",5))
		{
			const char *base=fname+5;
			char devname[32],devbin[256],pathbuf[256],discovered[32];
			int dev_fd,dev_sz;
			found[0]=0;
			devname[0]=0;
			if(getdevicename(centralprocess.dnr,devname)!=NULL && devname[0] &&
			   strlen(devname)+strlen(fname)+2U<sizeof(devbin))
			{
				sprintf(devbin,"%s:%s",devname,fname);
				dev_fd=open(devbin,O_RDONLY);
				if(dev_fd>=0) { dev_sz=lseek(dev_fd,0,SEEK_END); close(dev_fd); if(dev_sz>0) strcpy(found,devbin); }
			}

			/* Unlike V70.33/34, legacy /bin is also allowed to resolve through
			 * the submitter's PATH.  This is the crucial case when GraOS runs
			 * on ram:/ but its application set is installed on hda1:/bin. */
			if(!found[0]) {
				pathbuf[0]=0;
				if(ProcessEnvGet(centralprocess.requesterPID,"PATH",pathbuf,sizeof(pathbuf))<0 || !pathbuf[0])
					(void)kgetglobalenv("PATH",pathbuf,sizeof(pathbuf));
				if(pathbuf[0]) (void)SearchThroughPath(pathbuf,base,found);
			}

			/* Self-healing fallback: discover a registered volume that actually
			 * contains the executable, then remember its /bin in requester PATH. */
			if(!found[0]) {
				discovered[0]=0;
				if(cp_find_registered_device_bin(base,found,sizeof(found),discovered,sizeof(discovered))) {
					(void)ProcessEnvEnsureNamedDeviceBin(centralprocess.requesterPID,discovered);
					printk("Exec resolver: discovered '%s' and healed PID%d PATH with %s:/bin.\n",
						found,centralprocess.requesterPID,discovered);
				}
			}
			if(!found[0]) goto error;
		}
		else if(!explicit_ok)
		{
			goto error;
		}
	}
	else
	{
		int cwd_fd;
		int cwd_sz;
		cwd_fd=open(fname,O_RDONLY);
		if(cwd_fd>=0) { cwd_sz=lseek(cwd_fd,0,SEEK_END); close(cwd_fd); if(cwd_sz>0) strcpy(found,fname); }

		if(!found[0])
		{
			char devname[32],devbin[256]; int dev_fd,dev_sz;
			devname[0]=0;
			if(getdevicename(centralprocess.dnr,devname)!=NULL && devname[0] &&
			   strlen(devname)+strlen(fname)+8U<sizeof(devbin)) {
				sprintf(devbin,"%s:/bin/%s",devname,fname);
				dev_fd=open(devbin,O_RDONLY);
				if(dev_fd>=0) { dev_sz=lseek(dev_fd,0,SEEK_END); close(dev_fd); if(dev_sz>0) strcpy(found,devbin); }
			}
		}

		if(!found[0])
		{
			strcpy(path, "");
			if(ProcessEnvGet(centralprocess.requesterPID,"PATH",path,sizeof(path))<0 || !path[0])
				(void)kgetglobalenv("PATH",path,sizeof(path));
			if(path[0]) (void)SearchThroughPath(path,fname,found);
		}

		if(!found[0])
		{
			char discovered[32]; discovered[0]=0;
			if(cp_find_registered_device_bin(fname,found,sizeof(found),discovered,sizeof(discovered))) {
				(void)ProcessEnvEnsureNamedDeviceBin(centralprocess.requesterPID,discovered);
				printk("Exec resolver: discovered '%s' and healed PID%d PATH with %s:/bin.\n",
					found,centralprocess.requesterPID,discovered);
			}
		}
		if(!found[0]) {
			printk("Exec resolver: '%s' not found in cwd, active /bin, PATH, or registered device bins.\n",fname);
			goto error;
		}
	}


	//-----------------------------------------------------------------------
	/*
	 * Use the kernel's integer file-descriptor API here.  The historical
	 * code accidentally called fopen(found, O_RDONLY), stored the FILE *
	 * in an int and then passed it to lseek().  SearchThroughPath() had
	 * already found the file correctly, but this second size check could
	 * therefore report zero and reject a perfectly valid executable.
	 */
	fd = open(found, O_RDONLY);
	if(fd >= 0)
	{
		sz = lseek(fd, 0, SEEK_END);
		close(fd);
		if(sz < 0) sz = 0;
	}
	else
	{
		sz = 0;
	}
past11:
	centralprocess.exesz = sz;
	printf("FILE '%s' SIZE = %d bytes (%x), maxsz = %d\n",
		fname, sz,sz, centralprocess.l_bin);
//	getch();
	if(sz>=centralprocess.l_bin)	goto error;
	if(sz<=0)
	{
		printk("centralprocess: File '%s'(%s) not found, sz=%d(0x%x)\n",
			fname, found, sz, sz);
error:
		/* V68.189: do NOT CLI on a failed executable lookup.  The request is
		 * still owned by the permanent Central Process while isBusy is set, so
		 * these result fields do not need a long interrupt-disabled critical
		 * section.  The old path called disable() and then returned without
		 * restoring EFLAGS; a normal ENOENT (for example sqsh.bin before
		 * utilities.iso has been unpacked) therefore left the CP service with
		 * IF=0 and could wedge/crash the scheduler on its next wait. */
		centralprocess.error = CENTRALPROCESS_ERROR_FILENOTFOUND; // 1 = file not found
		centralprocess.appPID=0;
		launchapp_cleartogo=3;
		/* centralprocess_run() publishes the completed result after diagnostics. */
		goto past;
	}

	// 1. Read exe binary
	if(NeedToLoad)
	{
		int got,total;

		printk("%s: Reading file '%s', size=%dK bytes, Buffer* = 0x%x.\n",
			__FUNCTION__, found, sz/1024+1,  centralprocess.bin);

		/* A regular read is allowed to return fewer bytes than requested.
		 * The old loader ignored the return value and immediately validated /
		 * executed the staging buffer.  On JTMFS/FlexFAT a read that ends at a
		 * cache, cluster or device boundary can therefore leave the tail of a
		 * larger ELF image stale from the previous executable.  Small commands
		 * then appear reliable while larger libc programs fail nondeterministically.
		 *
		 * Clear the image and read exactly the size established by lseek(). */
		memset(centralprocess.bin,0,sz);
		fd = open(found, O_RDONLY);
		if(fd < 0)
		{
			printk("centralprocess: unable to reopen executable '%s'.\n",found);
			goto error;
		}

		total=0;
		while(total < sz)
		{
			got=read(fd,centralprocess.bin+total,sz-total);
			if(got <= 0)
				break;
			total += got;
			SchedulerCooperate();
		}
		close(fd);

		if(total != sz)
		{
			printk("centralprocess: short executable read '%s': expected=%d got=%d.\n",
				found,sz,total);
			goto error;
		}
	}

	// 2. Confirm executable identity + structural format using the same
	// validator that every LaunchApp entry point enforces.
	{
		int exe_format=0;
		int verify_rv=LaunchAppValidateImage(centralprocess.bin,sz,&exe_format);
		if(verify_rv!=LAUNCHAPP_ELF_OK)
		{
			/* Same rule as ENOENT above: publishing a load failure must never
			 * strand the permanent CP task with IF clear. */
			centralprocess.appPID=0;
			centralprocess.error = CENTRALPROCESS_ERROR_CORRUPTEDEXE;
			centralprocess.launch_detail=verify_rv;
			printk("centralprocess: executable verify failed detail=%d format=%d.\n",
				verify_rv,exe_format);
			launchapp_cleartogo=3;
			/* centralprocess_run() publishes the completed result after diagnostics. */
			goto past;
		}
	}

	// 3. Get memory requirement
	centralprocess.memrq = getExeMemReq(centralprocess.bin, sz);
	printk("Memory requirement = %dK\n", centralprocess.memrq);

	// 4. Report
	printk("Read complete, launching up application at directory '%s'\n",
		centralprocess.runPath);
past:
	// --------------------------------------------------------------
	return centralprocess.error;
}

// Called by process creator to summon up a new process.
int centralprocess_job(void)
{
	//
	// void centralprocess_createproc(const char *fname,
	// void *appcode,int appsize)
	return centralprocess_createproc(centralprocess.fname, centralprocess_runexe1, 1024*512);
}

// Called by centralprocess_job.
static int centralprocess_requester_valid(void)
{
	int pid=centralprocess.requesterPID;
	if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
	if(!valid_pid(pid) || !thread_states[pid]) return 0;
	return thread_magic[pid]==centralprocess.requesterMagic;
}

static void centralprocess_abort_loaded_child(int *pid,int detail)
{
	if(pid && *pid>0 && valid_pid(*pid))
		KillThreadEx(*pid,KT_NO_THREAD_SWITCH);
	if(pid) *pid=0;
	centralprocess.appPID=0;
	centralprocess.error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
	centralprocess.launch_detail=detail;
}

/* Final child publication is one tiny single-CPU transaction.  Revalidate the
 * requester generation and, if requested, hand off the terminal capability
 * before priority becomes runnable.  No allocation/filesystem work is allowed
 * in this critical section. */
static int centralprocess_publish_child(int pid)
{
	unsigned long flags;
	int ter,owner,requester,allowed=0;

	if(pid<=0) return -1;
	flags=irq_save();
	if(!centralprocess_requester_valid())
	{
		irq_restore(flags);
		return -2;
	}

	if(centralprocess.execFlags & JTMOS_EXEC_F_TRANSFER_TERMINAL)
	{
		ter=centralprocess.terminalID;
		requester=centralprocess.requesterPID;
		if(ter<0 || ter>=N_MAX_SCREENS)
		{
			irq_restore(flags);
			return -1;
		}
		owner=GetTerminalOwner(ter);
		if(ter>=FIRST_DYNAMIC_TERMINAL)
			allowed=(owner==requester);
		else if(owner<=0 || owner==requester || !valid_pid(owner) || !thread_states[owner])
			allowed=1;
		if(!allowed || SetTerminalOwner(ter,pid)!=0)
		{
			irq_restore(flags);
			return -1;
		}
	}

	SetThreadPriority(pid, THREAD_PRIORITY_NORMAL);
	centralprocess.appPID=pid;
	irq_restore(flags);
	return 0;
}

// Called by centralprocess_job.
int centralprocess_createproc(const char *fname JTM_UNUSED,
		void *appcode JTM_UNUSED, int appsize JTM_UNUSED)
{
	char *appstack JTM_UNUSED;
	int pid,pr JTM_UNUSED,key JTM_UNUSED,memkb;
	char str[256] JTM_UNUSED;
	LAUNCHAPP_RESULT launch_result;

	/* V70.44: keep IRQs/scheduler live across allocation, ELF mapping and
	 * process metadata setup. Only tiny ownership primitives disable IRQs. */
	printk("%s: child DNR/DB=%d/%d (cwd '%s')\n",
		__FUNCTION__, centralprocess.runDNR, centralprocess.runDB,
		centralprocess.runPath);

	memkb = STATIC_APP_MEM_SIZE;
	if(centralprocess.memrq)
		memkb = centralprocess.memrq;

	{
		LAUNCHAPP_CONTEXT launchctx;
		launchctx.callerPID=centralprocess.requesterPID;
		launchctx.callerDNR=centralprocess.callerDNR;
		launchctx.callerDB=centralprocess.callerDB;
		launchctx.runDNR=centralprocess.runDNR;
		launchctx.runDB=centralprocess.runDB;
		launchctx.deferStart=1;
		pid = LaunchAppExContextResult(centralprocess.bin,centralprocess.exesz,
			memkb,&launchctx,&launch_result);
		centralprocess.error=launch_result.error;
		centralprocess.launch_detail=launch_result.detail;
	}

	if(pid>0 && !centralprocess.error && !centralprocess_requester_valid())
		centralprocess_abort_loaded_child(&pid,LAUNCHAPP_DETAIL_CONTEXT);

	if(pid > 0 && !centralprocess.error)
	{
		if(GetThreadDNR(pid)!=centralprocess.runDNR ||
		   GetThreadDB(pid)!=centralprocess.runDB)
		{
			printk("CP: repairing child PID%d cwd DNR/DB %d/%d -> %d/%d.\n",
				pid,GetThreadDNR(pid),GetThreadDB(pid),
				centralprocess.runDNR,centralprocess.runDB);
			SetThreadCWDContext(pid,centralprocess.runDNR,centralprocess.runDB);
		}
	}

	if(pid > 0 && !centralprocess.error && centralprocess.runPath[0] &&
	   centralprocess.runPath[0]!='<')
		(void)SetThreadCWDCache(pid,centralprocess.runPath,FileDirPathGeneration());

	if(pid > 0 && !centralprocess.error &&
	   ProcessEnvInherit(pid,centralprocess.requesterPID)<0)
	{
		printk("CP: warning: environment inherit PID%d -> PID%d failed; launching with lazy defaults.\n",
			centralprocess.requesterPID,pid);
		ProcessEnvRelease(pid);
	}

	/* A parent may disappear/reuse its PID while ProcessEnvInherit yields. */
	if(pid>0 && !centralprocess.error && !centralprocess_requester_valid())
		centralprocess_abort_loaded_child(&pid,LAUNCHAPP_DETAIL_CONTEXT);

	if(pid > 0 && !centralprocess.error)
	{
		int path_rv=ProcessEnvEnsureDeviceBin(pid,centralprocess.runDNR);
		if(path_rv<0)
			printk("CP: warning: cannot add active-device /bin to PID%d PATH (dnr=%d rv=%d).\n",
				pid,centralprocess.runDNR,path_rv);
	}

	if(pid > 0 && !centralprocess.error &&
	   LinuxProcessExecSetup(pid,centralprocess.requesterPID,
		centralprocess.stdinFD,centralprocess.stdoutFD,centralprocess.stderrFD)!=0)
	{
		printk("CP: unable to attach stdio for PID%d.\n",pid);
		centralprocess_abort_loaded_child(&pid,LAUNCHAPP_DETAIL_THREAD);
	}

	/* LinuxProcessExecSetup may also yield while touching inherited FD state. */
	if(pid>0 && !centralprocess.error && !centralprocess_requester_valid())
		centralprocess_abort_loaded_child(&pid,LAUNCHAPP_DETAIL_CONTEXT);

	if(pid > 0 && !centralprocess.error)
	{
		SetThreadCmdLine(pid, centralprocess.path);
		IdentifyThread(pid, centralprocess.fname);
		SetThreadTerminal(pid, centralprocess.terminalID);

	}

	if(pid > 0 && !centralprocess.error)
	{
		int publish_rv;
		syskey_terminate=0;
		pr=1;
		publish_rv=centralprocess_publish_child(pid);
		if(publish_rv!=0)
		{
			if(publish_rv==-1)
				printk("CP: terminal %d ownership changed before PID%d publication.\n",
					centralprocess.terminalID,pid);
			centralprocess_abort_loaded_child(&pid,LAUNCHAPP_DETAIL_CONTEXT);
		}
	}
	else
	{
		centralprocess.appPID = 0;
		if(!centralprocess.error)
			centralprocess.error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
	}

	launchapp_cleartogo=1;
	if(pid > 0 && !centralprocess.error)
		SwitchToThreadEx(pid);
	return pid;
}

//
void centralprocess_runexe1(void)
{
	//
	centralprocess_runexe(centralprocess.fname);
}

// centralprocess Run Exe
// Does not return any value.
int centralprocess_runexe(const char *fname JTM_UNUSED)
{
	int memkb;

	/* The permanent CP service must not adopt the child's cwd. */

	// Get default memory requirement
	memkb = STATIC_APP_MEM_SIZE;
	// Use custom memory requirement if one defined
	if(centralprocess.memrq)
		memkb = centralprocess.memrq;

	// - Launch up application using the immutable original cexec context.
	{
		LAUNCHAPP_CONTEXT launchctx;
		LAUNCHAPP_RESULT launch_result;
		launchctx.callerPID=centralprocess.requesterPID;
		launchctx.callerDNR=centralprocess.callerDNR;
		launchctx.callerDB=centralprocess.callerDB;
		launchctx.runDNR=centralprocess.runDNR;
		launchctx.runDB=centralprocess.runDB;
		launchctx.deferStart=1;
		centralprocess.appPID = LaunchAppExContextResult(centralprocess.bin,centralprocess.exesz,memkb,&launchctx,&launch_result);
		centralprocess.error=launch_result.error;
		centralprocess.launch_detail=launch_result.detail;
	}
	if(centralprocess.appPID>0)
	{
		SetThreadDNR(centralprocess.appPID,centralprocess.runDNR);
		SetThreadDB(centralprocess.appPID,centralprocess.runDB);
		SetThreadPriority(centralprocess.appPID,THREAD_PRIORITY_NORMAL);
	}
	launchapp_cleartogo=1;
	return centralprocess.appPID;
}

//
void centralprocess_HelpPage(void)
{
	//
	printk("'k'=Kill process  [Space]=List processes  's'=Launch new shell\n");
	printk("'l'=Show DRIVER API lock PID  'h'=Show this help page\n");
	printk("'u'=Force unlock DRIVER API lock  'y'=Show last function for lock owner\n");
	printk("'d'=Directory cache info  'f'=FILEDES info  'F'=JTMFAT info\n");
	printk("'D'=List devices  'v'=toggle verbose debugging  'r'=toggle serial console redirect\n");
}

//


