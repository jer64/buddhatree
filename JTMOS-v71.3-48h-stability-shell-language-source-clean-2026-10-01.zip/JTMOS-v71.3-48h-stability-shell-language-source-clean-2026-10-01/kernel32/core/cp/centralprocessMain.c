//--------------------------------------------------------------------
// centralprocessMain.c
// Kernel Central Process / microkernel service loop.
// (C) Jari Tuominen.  Microkernel integration update 2026.
//--------------------------------------------------------------------
#include "kernel32.h"
#include "centralprocess.h"
#include "centralprocessMain.h"
#include "threads.h"
#include "centralprocessInit.h"
#include "sysglvar.h"
#include "reboot.h"
#include "msgbox.h"
#include "scheduler.h"

volatile int reboot_now=FALSE;

/*
 * The Central Process is a permanent kernel service.  It must not own a
 * terminal, clear the screen, or consume keyboard input: doing any of those
 * from a permanently running microkernel service races the shell/GraOS input
 * path.  Debug UI belongs in a separate user/kernel-debug task.
 *
 * Process creation is still serviced through the historical centralprocess
 * request state for ABI compatibility.  The CP message box is activated here
 * so the request transport can be moved completely to queued IPC without
 * changing the service lifetime or boot ordering.
 */
void centralprocess_run(void)
{
    int lt,amount,created_pid;
    int service_dnr,service_db;

    amount = 1024*256;
    centralprocess.l_bin = amount;
    centralprocess.bin = malloc(amount);
    if(centralprocess.bin==NULL)
    {
        printk("CP: cannot allocate executable staging buffer.\n");
        for(;;) SchedulerWaitPause(10000UL);
    }

    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
    ActivateThreadMessageBox(GetCurrentThread());

    printk("CP: central process kernel service online (PID=%d, queue enabled).\n",
        GetCurrentThread());

    for(;;)
    {
        if(reboot_now)
        {
            /* Deferred Ctrl-Alt-Del arrives here from IRQ1.  Perform the
             * graceful flush/reset in normal process context, never inside
             * the keyboard interrupt handler or a throw-away helper task. */
            reboot_now = FALSE;
            system_reset();
        }

        /* V68.189: the permanent Central Process is a blocking scheduler
         * service and must never process/finish an exec request with IF clear.
         * This also contains legacy filesystem/loader helpers that might return
         * with a damaged interrupt state on an error path. */
        if(!(get_eflags() & 0x200UL))
        {
            dprintk("CP: repaired IF=0 at service safe point.\n");
            enable();
        }

        if(centralprocess.isBusy)
        {
            /* centralprocess_loadEXE() temporarily adopts the requester's
             * DNR/DB for legacy open()/PATH helpers.  Never let that context
             * become the permanent service cwd. */
            service_dnr=GetCurrentDNR();
            service_db=GetCurrentDB();

            dprintk("CP: launching '%s' at '%s'\n",
                centralprocess.fname, centralprocess.runPath);

            if(centralprocess_loadEXE(centralprocess.fname))
                goto launch_failed;

            created_pid = centralprocess_job();

            if(created_pid > 0)
            {
                for(lt=GetTickCount(); centralprocess.isBusy && !launchapp_cleartogo; )
                {
                    if((GetTickCount()-lt)>CENTRALPROCESS_EXEC_WAIT_TIMEOUT)
                    {
                        KillThread(created_pid);
                        centralprocess.appPID = 0;
                        created_pid = 0;
                        centralprocess.error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
                        printk("CP: process creation timed out.\n");
                        break;
                    }
                    if(centralprocess.error)
                        break;
                    SchedulerWaitPause(1000UL);
                }

                if(created_pid > 0 && !centralprocess.error)
                    dprintk("CP: process created, PID=%d.\n", created_pid);
                else
                {
                    printk("CP: no process created.\n");
                    centralprocessExplainError();
                }
            }
            else
            {
launch_failed:
                printk("CP: process launch failed, error #%d, detail=%d.\n",
                    centralprocess.error, centralprocess.launch_detail);
            }

            /* Publish one immutable result to the submitting caller only
	     * after CP has finished using the request record.  PID+generation
	     * ownership prevents an asynchronous caller that exited mid-launch from
	     * leaving resultPending stuck forever or waking a recycled PID. */
            SetThreadCWDContext(GetCurrentThread(),service_dnr,service_db);
            if(centralprocess.requesterPID<0 ||
               !valid_pid(centralprocess.requesterPID) ||
               !thread_states[centralprocess.requesterPID] ||
               thread_magic[centralprocess.requesterPID]!=centralprocess.requesterMagic)
            {
                dprintk("CP: dropping orphaned exec result for old PID%d/magic=0x%x.\n",
                        centralprocess.requesterPID,centralprocess.requesterMagic);
                if(centralprocess.appPID>0 && valid_pid(centralprocess.appPID))
                    KillThreadEx(centralprocess.appPID,KT_NO_THREAD_SWITCH);
                centralprocess.appPID=0;
                centralprocess.resultPending=0;
                centralprocess.isBusy=0;
            }
            else
            {
                centralprocess.resultPending = 1;
                centralprocess.isBusy = 0;
                SchedulerWakeThread(centralprocess.requesterPID);
            }
        }

        /* Event-woken service: this deadline is only a safety/maintenance
         * fallback now, not the normal request latency. */
        SchedulerWaitPause(100000UL);
    }
}

/* Called once after device/filesystem initialization and after the normal
 * scheduler has been restored.  It is intentionally independent of GraOS and
 * APP_LOADER module selections: CP is part of the kernel architecture. */
void centralprocess_init(void)
{
    if(centralprocessStarted)
        return;

    memset(&centralprocess, 0, sizeof(centralprocess));
    centralprocessInit();
}
