#ifndef JTMOS_ATOMIC_H
#define JTMOS_ATOMIC_H

/* i486-compatible 32-bit atomic operations. */
#include "basdef.h"

typedef struct { volatile long counter; } atomic_t;
#define ATOMIC_INIT(value) { (long)(value) }

static __inline__ void atomic_compiler_barrier(void)
{
    __asm__ __volatile__("" : : : "memory");
}

static __inline__ long atomic_read(const atomic_t *v)
{
    long value=v->counter;
    atomic_compiler_barrier();
    return value;
}

static __inline__ void atomic_set(atomic_t *v,long value)
{
    atomic_compiler_barrier();
    v->counter=value;
    atomic_compiler_barrier();
}

static __inline__ long atomic_cmpxchg(atomic_t *v,long oldv,long newv)
{
    long previous;
    __asm__ __volatile__("lock; cmpxchgl %2,%1"
                         : "=a"(previous), "+m"(v->counter)
                         : "r"(newv), "0"(oldv)
                         : "memory","cc");
    return previous;
}

static __inline__ long atomic_xchg(atomic_t *v,long value)
{
    __asm__ __volatile__("xchgl %0,%1"
                         : "+r"(value), "+m"(v->counter)
                         : : "memory","cc");
    return value;
}

static __inline__ long atomic_fetch_add(atomic_t *v,long delta)
{
    __asm__ __volatile__("lock; xaddl %0,%1"
                         : "+r"(delta), "+m"(v->counter)
                         : : "memory","cc");
    return delta;
}

static __inline__ long atomic_add_return(atomic_t *v,long delta)
{
    long old=atomic_fetch_add(v,delta);
    return old+delta;
}

static __inline__ long atomic_inc_return(atomic_t *v)
{
    return atomic_add_return(v,1);
}

static __inline__ long atomic_dec_return(atomic_t *v)
{
    return atomic_add_return(v,-1);
}

static __inline__ void *atomic_ptr_xchg(void * volatile *ptr,void *value)
{
    __asm__ __volatile__("xchgl %0,%1"
                         : "+r"(value), "+m"(*ptr)
                         : : "memory","cc");
    return value;
}

static __inline__ void *atomic_ptr_cmpxchg(void * volatile *ptr,void *oldv,void *newv)
{
    void *previous;
    __asm__ __volatile__("lock; cmpxchgl %2,%1"
                         : "=a"(previous), "+m"(*ptr)
                         : "r"(newv), "0"(oldv)
                         : "memory","cc");
    return previous;
}

#endif
