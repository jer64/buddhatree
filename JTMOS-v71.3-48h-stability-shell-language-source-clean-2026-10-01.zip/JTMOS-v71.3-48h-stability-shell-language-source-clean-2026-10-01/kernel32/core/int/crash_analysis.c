/*
 * crash_analysis.c - JTMOS post-mortem crash recorder.
 *
 * Capture is intentionally allocation-free and filesystem-free.  The fault
 * handler copies only trusted scalar/static data into fixed RAM slots.  The
 * CPU_IDLE task later renders the snapshot and appends it to /logs/crash.log.
 */
#include "kernel32.h"
#include "crash_analysis.h"
#include "scheduler.h"
#include "logging.h"
#include "threads.h"
#include "nmi.h"
#include "debug.h"
#include "msgbox.h"
#include "graos_alert_wire.h"

#define CRASH_RECORD_SLOTS 4
#define CRASH_REASON_LEN 96
#define CRASH_NAME_LEN 64
#define CRASH_CMDLINE_LEN 160
#define CRASH_REPORT_BYTES 12288

typedef struct CRASH_SYSCALL_EVENT
{
    DWORD seq,tick,nr;
    DWORD ebx,ecx,edx,esi,edi,ebp;
} CRASH_SYSCALL_EVENT;

typedef struct CRASH_SWITCH_EVENT
{
    DWORD seq,tick;
    int old_pid,new_pid;
} CRASH_SWITCH_EVENT;

typedef struct CRASH_LOCK_EVENT
{
    DWORD seq,tick,lock_id;
    int pid,action,owner_pid,line;
    const char *function;
    const char *file;
} CRASH_LOCK_EVENT;

typedef struct CRASH_RECORD
{
    volatile BYTE pending;
    BYTE notified;
    BYTE disposition;
    BYTE authoritative;
    BYTE from_user;
    BYTE fallback_persisted;
    DWORD sequence;
    DWORD tick;
    int code;
    int pid;
    DWORD magic;
    DWORD thread_type_snapshot;
    DWORD thread_state_snapshot;
    DWORD scall_depth;
    DWORD dnr,db,terminal;
    DWORD task_switch_nr;
    DWORD irq_active;
    DWORD seconds_without_switch;
    JTMOS_CRASH_FRAME frame;
    TSSEG tss;
    JTMOS_SCHED_WATCHDOG sched;
    char reason[CRASH_REASON_LEN];
    char name[CRASH_NAME_LEN];
    char cmdline[CRASH_CMDLINE_LEN];
    CRASH_SYSCALL_EVENT syscalls[JTMOS_CRASH_SYSCALL_HISTORY];
    int syscall_count;
    CRASH_SWITCH_EVENT switches[JTMOS_CRASH_SWITCH_HISTORY];
    int switch_count;
    CRASH_LOCK_EVENT locks[JTMOS_CRASH_LOCK_HISTORY];
    int lock_count;
} CRASH_RECORD;

static CRASH_RECORD crash_records[CRASH_RECORD_SLOTS];
static volatile DWORD crash_sequence=0;
static volatile DWORD trace_sequence=0;
static volatile unsigned crash_next_slot=0;

static const char *crash_disposition(int d);

static CRASH_SYSCALL_EVENT syscall_history[N_MAX_THREADS][JTMOS_CRASH_SYSCALL_HISTORY];
static BYTE syscall_head[N_MAX_THREADS];
static BYTE syscall_count[N_MAX_THREADS];
static CRASH_SWITCH_EVENT switch_history[JTMOS_CRASH_SWITCH_HISTORY];
static BYTE switch_head=0;
static BYTE switch_count=0;
static CRASH_LOCK_EVENT lock_history[JTMOS_CRASH_LOCK_HISTORY];
static BYTE lock_head=0;
static BYTE lock_count=0;

static void crash_copy_text(char *dst,unsigned cap,const char *src)
{
    unsigned i=0;
    if(!dst || !cap) return;
    if(!src) src="";
    while(i+1U<cap && src[i]) { dst[i]=src[i]; i++; }
    dst[i]=0;
}

static DWORD crash_trace_seq(void)
{
    return ++trace_sequence;
}

void CrashAnalysisTraceSyscall(int pid,DWORD nr,DWORD ebx,DWORD ecx,DWORD edx,
                               DWORD esi,DWORD edi,DWORD ebp)
{
    BYTE h;
    int flags;
    CRASH_SYSCALL_EVENT *e;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags();
    disable();
    h=syscall_head[pid];
    e=&syscall_history[pid][h];
    e->seq=crash_trace_seq();
    e->tick=GetTickCount();
    e->nr=nr; e->ebx=ebx; e->ecx=ecx; e->edx=edx;
    e->esi=esi; e->edi=edi; e->ebp=ebp;
    h++;
    if(h>=JTMOS_CRASH_SYSCALL_HISTORY) h=0;
    syscall_head[pid]=h;
    if(syscall_count[pid]<JTMOS_CRASH_SYSCALL_HISTORY) syscall_count[pid]++;
    set_eflags(flags);
}

void CrashAnalysisTraceSwitch(int old_pid,int new_pid)
{
    int flags=get_eflags();
    CRASH_SWITCH_EVENT *e;
    disable();
    e=&switch_history[switch_head];
    e->seq=crash_trace_seq();
    e->tick=GetTickCount();
    e->old_pid=old_pid;
    e->new_pid=new_pid;
    switch_head++;
    if(switch_head>=JTMOS_CRASH_SWITCH_HISTORY) switch_head=0;
    if(switch_count<JTMOS_CRASH_SWITCH_HISTORY) switch_count++;
    set_eflags(flags);
}

void CrashAnalysisTraceLock(int pid,int action,DWORD lock_id,int owner_pid,
                            const char *function,const char *file,int line)
{
    int flags=get_eflags();
    CRASH_LOCK_EVENT *e;
    disable();
    e=&lock_history[lock_head];
    e->seq=crash_trace_seq();
    e->tick=GetTickCount();
    e->pid=pid;
    e->action=action;
    e->lock_id=lock_id;
    e->owner_pid=owner_pid;
    e->function=function;
    e->file=file;
    e->line=line;
    lock_head++;
    if(lock_head>=JTMOS_CRASH_LOCK_HISTORY) lock_head=0;
    if(lock_count<JTMOS_CRASH_LOCK_HISTORY) lock_count++;
    set_eflags(flags);
}

static void crash_snapshot_syscalls(CRASH_RECORD *r,int pid)
{
    int i,n,start;
    n=(pid>=0 && pid<N_MAX_THREADS)?syscall_count[pid]:0;
    if(n>JTMOS_CRASH_SYSCALL_HISTORY) n=JTMOS_CRASH_SYSCALL_HISTORY;
    start=(pid>=0 && pid<N_MAX_THREADS)?((int)syscall_head[pid]-n):0;
    while(start<0) start+=JTMOS_CRASH_SYSCALL_HISTORY;
    r->syscall_count=n;
    for(i=0;i<n;i++)
        r->syscalls[i]=syscall_history[pid][(start+i)%JTMOS_CRASH_SYSCALL_HISTORY];
}

static void crash_snapshot_switches(CRASH_RECORD *r)
{
    int i,n=switch_count,start=(int)switch_head-switch_count;
    while(start<0) start+=JTMOS_CRASH_SWITCH_HISTORY;
    r->switch_count=n;
    for(i=0;i<n;i++)
        r->switches[i]=switch_history[(start+i)%JTMOS_CRASH_SWITCH_HISTORY];
}

static void crash_snapshot_locks(CRASH_RECORD *r,int pid)
{
    int i,n=lock_count,start=(int)lock_head-lock_count,out=0;
    while(start<0) start+=JTMOS_CRASH_LOCK_HISTORY;
    /* Prefer events involving the faulting PID.  If there are fewer than the
     * ring size, keep global recent events too; they can expose another PID
     * holding a lock that the crashed task was waiting for. */
    for(i=0;i<n && out<JTMOS_CRASH_LOCK_HISTORY;i++) {
        CRASH_LOCK_EVENT e=lock_history[(start+i)%JTMOS_CRASH_LOCK_HISTORY];
        if(e.pid==pid || e.owner_pid==pid) r->locks[out++]=e;
    }
    if(out==0) {
        for(i=0;i<n && out<JTMOS_CRASH_LOCK_HISTORY;i++)
            r->locks[out++]=lock_history[(start+i)%JTMOS_CRASH_LOCK_HISTORY];
    }
    r->lock_count=out;
}

static void crash_serial_pair(const char *label,DWORD value)
{
    DebugSerialEmergencyWrite(label);
    DebugSerialEmergencyWriteHex32(value);
}

static void crash_serial_snapshot(const CRASH_RECORD *r)
{
    int i,start;
    DebugSerialEmergencyWrite("[CRASH-BEGIN]");
    crash_serial_pair(" seq=",r->sequence);
    crash_serial_pair(" pid=",(DWORD)r->pid);
    crash_serial_pair(" exc=",(DWORD)r->code);
    DebugSerialEmergencyWrite("\n[CRASH-FRAME]");
    crash_serial_pair(" eip=",r->frame.eip);
    crash_serial_pair(" cs=",r->frame.cs);
    crash_serial_pair(" eflags=",r->frame.eflags);
    crash_serial_pair(" err=",r->frame.error);
    crash_serial_pair(" cr2=",r->frame.cr2);
    crash_serial_pair(" entry_esp=",r->frame.entry_esp);
    crash_serial_pair(" user_esp=",r->frame.user_esp);
    crash_serial_pair(" user_ss=",r->frame.user_ss);
    DebugSerialEmergencyWrite("\n[CRASH-REGS]");
    crash_serial_pair(" eax=",r->frame.eax); crash_serial_pair(" ebx=",r->frame.ebx);
    crash_serial_pair(" ecx=",r->frame.ecx); crash_serial_pair(" edx=",r->frame.edx);
    crash_serial_pair(" esi=",r->frame.esi); crash_serial_pair(" edi=",r->frame.edi);
    crash_serial_pair(" ebp=",r->frame.ebp);
    DebugSerialEmergencyWrite("\n");

    start=r->syscall_count>4?r->syscall_count-4:0;
    for(i=start;i<r->syscall_count;i++) {
        DebugSerialEmergencyWrite("[CRASH-SC]");
        crash_serial_pair(" nr=",r->syscalls[i].nr);
        crash_serial_pair(" ebx=",r->syscalls[i].ebx);
        crash_serial_pair(" ecx=",r->syscalls[i].ecx);
        crash_serial_pair(" edx=",r->syscalls[i].edx);
        DebugSerialEmergencyWrite("\n");
    }
    start=r->switch_count>4?r->switch_count-4:0;
    for(i=start;i<r->switch_count;i++) {
        DebugSerialEmergencyWrite("[CRASH-SW]");
        crash_serial_pair(" old=",(DWORD)r->switches[i].old_pid);
        crash_serial_pair(" new=",(DWORD)r->switches[i].new_pid);
        crash_serial_pair(" tick=",r->switches[i].tick);
        DebugSerialEmergencyWrite("\n");
    }
    start=r->lock_count>4?r->lock_count-4:0;
    for(i=start;i<r->lock_count;i++) {
        DebugSerialEmergencyWrite("[CRASH-LK]");
        crash_serial_pair(" action=",(DWORD)r->locks[i].action);
        crash_serial_pair(" pid=",(DWORD)r->locks[i].pid);
        crash_serial_pair(" owner=",(DWORD)r->locks[i].owner_pid);
        crash_serial_pair(" lock=",r->locks[i].lock_id);
        crash_serial_pair(" line=",(DWORD)r->locks[i].line);
        DebugSerialEmergencyWrite("\n");
    }
    DebugSerialEmergencyWrite("[CRASH-END-SNAPSHOT]\n");
}

void CrashAnalysisCaptureException(const char *reason,int code,int pid,
                                   const JTMOS_CRASH_FRAME *frame,
                                   const TSSEG *tss)
{
    unsigned slot;
    int flags;
    CRASH_RECORD *r;

    flags=get_eflags();
    disable();
    slot=crash_next_slot++ % CRASH_RECORD_SLOTS;
    r=&crash_records[slot];
    memset(r,0,sizeof(*r));
    r->sequence=++crash_sequence;
    r->tick=GetTickCount();
    r->code=code;
    r->pid=pid;
    r->disposition=CRASH_DISPOSITION_UNKNOWN;
    if(frame) {
        r->frame=*frame;
        r->authoritative=frame->authoritative;
        r->from_user=frame->from_user;
    }
    if(tss) r->tss=*tss;
    if(pid>=0 && pid<N_MAX_THREADS) {
        r->magic=thread_magic[pid];
        r->thread_type_snapshot=thread_type[pid];
        r->thread_state_snapshot=thread_states[pid];
        r->scall_depth=thread_scall_active[pid];
        r->dnr=thread_dnr[pid];
        r->db=thread_db[pid];
        r->terminal=thread_terminal[pid];
        r->seconds_without_switch=thread_rtc_seconds_without_task_switch[pid];
        crash_copy_text(r->name,sizeof(r->name),thread_name[pid]);
        crash_copy_text(r->cmdline,sizeof(r->cmdline),thread_cmdline[pid]);
        crash_snapshot_syscalls(r,pid);
    }
    r->task_switch_nr=(DWORD)taskSwitchNr;
    r->irq_active=(DWORD)(BYTE)irqActive;
    (void)SchedulerGetWatchdogSnapshot(&r->sched);
    crash_snapshot_switches(r);
    crash_snapshot_locks(r,pid);
    crash_copy_text(r->reason,sizeof(r->reason),reason);
    r->pending=1;
    set_eflags(flags);

    /* This survives d0 and does not touch locks/filesystems.  It is the
     * fallback post-mortem for PID0/#DF/#MC where CPU_IDLE cannot flush. */
    crash_serial_snapshot(r);
}

void CrashAnalysisSetDisposition(int pid,int disposition)
{
    int i,flags=get_eflags();
    disable();
    for(i=0;i<CRASH_RECORD_SLOTS;i++) {
        CRASH_RECORD *r=&crash_records[i];
        if(r->pending && r->pid==pid && r->disposition==CRASH_DISPOSITION_UNKNOWN)
            r->disposition=(BYTE)disposition;
    }
    set_eflags(flags);
    DebugSerialEmergencyWrite("[CRASH-DISPOSITION]");
    crash_serial_pair(" pid=",(DWORD)pid);
    crash_serial_pair(" value=",(DWORD)disposition);
    DebugSerialEmergencyWrite("\n");
}

DWORD CrashAnalysisPendingCount(void)
{
    DWORD n=0;
    int i,flags=get_eflags();
    disable();
    for(i=0;i<CRASH_RECORD_SLOTS;i++) if(crash_records[i].pending) n++;
    set_eflags(flags);
    return n;
}

/* V69.17: exception capture itself must stay lock/console free, but a process
 * must never appear to vanish without an explanation.  CPU_IDLE calls this
 * after it has escaped the faulting task, so normal console output is safe. */
static const char *crash_exception_short_name(int code)
{
    switch(code) {
    case 0: return "DIVIDE BY ZERO";
    case 1: return "DEBUG/SINGLE STEP";
    case 3: return "BREAKPOINT";
    case 4: return "OVERFLOW";
    case 5: return "BOUND RANGE";
    case 6: return "INVALID OPCODE";
    case 7: return "COPROCESSOR NOT AVAILABLE";
    case 10: return "INVALID TSS";
    case 11: return "SEGMENT NOT PRESENT";
    case 12: return "STACK FAULT";
    case 13: return "GENERAL PROTECTION FAULT";
    case 14: return "PAGE FAULT";
    case 16: return "COPROCESSOR ERROR";
    case 17: return "ALIGNMENT CHECK";
    case 19: return "SIMD FLOATING POINT";
    case 20: return "VIRTUALIZATION";
    case 21: return "CONTROL PROTECTION";
    default: return "CPU EXCEPTION";
    }
}

/* Only CPU_IDLE sends this packet.  Exception/NMI entry still performs no
 * allocation, mailbox operations, blocking, formatting or task switch. */
static void crash_alert_graos(int pid,int code,DWORD eip,const char *name)
{
    MSG packet;
    JTMOS_GRAOS_ALERT_WIRE *cmd;
    int gui_pid=GetThreadPID("guiserver");
    if(gui_pid<=0 || gui_pid==pid || sizeof(JTMOS_GRAOS_ALERT_WIRE)>sizeof(packet.buf))
        return;
    memset(&packet,0,sizeof(packet));
    packet.protocol=MB_PROTOCOL_GRAOS;
    packet.amount=sizeof(JTMOS_GRAOS_ALERT_WIRE);
    cmd=(JTMOS_GRAOS_ALERT_WIRE *)packet.buf;
    cmd->magic=0xFCE2E37BUL;
    cmd->id=JTMOS_GRAOS_ALERT_ID;
    cmd->v[0]=JTMOS_GRAOS_ALERT_EXCEPTION;
    strcpy(cmd->str,"Application Exception");
    snprintf(cmd->str+JTMOS_GRAOS_ALERT_TITLE_BYTES,
             JTMOS_GRAOS_ALERT_MESSAGE_BYTES,
             "Process terminated: %s (PID %d), exception #%d, EIP=%08x.",
             name && name[0]?name:"?",pid,code,(unsigned)eip);
    (void)sendMessage(&packet,gui_pid);
}

void CrashAnalysisNotifyPending(void)
{
    int i;
    for(i=0;i<CRASH_RECORD_SLOTS;i++)
    {
        int flags,pid,code,disp,from_user;
        DWORD thread_type_snapshot,cr2,eip;
        char name[CRASH_NAME_LEN],reason[CRASH_REASON_LEN];
        flags=get_eflags();
        disable();
        if(!crash_records[i].pending || crash_records[i].notified)
        {
            set_eflags(flags);
            continue;
        }
        crash_records[i].notified=1;
        pid=crash_records[i].pid;
        code=crash_records[i].code;
        disp=crash_records[i].disposition;
        from_user=crash_records[i].from_user ? 1 : 0;
        thread_type_snapshot=crash_records[i].thread_type_snapshot;
        cr2=crash_records[i].frame.cr2;
        eip=crash_records[i].frame.eip;
        crash_copy_text(name,sizeof(name),crash_records[i].name);
        crash_copy_text(reason,sizeof(reason),crash_records[i].reason);
        set_eflags(flags);

        if(disp==CRASH_DISPOSITION_QUARANTINE &&
           (from_user || (thread_type_snapshot&THREAD_TYPE_APPLICATION)))
        {
            crash_alert_graos(pid,code,eip,name);
            printk("\n[CLOSE APPLICATION] PID %d (%s) closed: %s (#%d).\n",
                   pid,name[0]?name:"?",crash_exception_short_name(code),code);
            if(code==14)
                printk("[CLOSE APPLICATION] Page fault address=%x EIP=%x; %s\n",
                       cr2,eip,
                       reason[0]?reason:"faulting process quarantined");
            else
                printk("[CLOSE APPLICATION] EIP=%x; %s\n",
                       eip,
                       reason[0]?reason:"faulting process quarantined");
        }
        else
        {
            printk("\n[CLOSE PROCESS] PID %d (%s) stopped: %s (#%d, %s).\n",
                   pid,name[0]?name:"?",crash_exception_short_name(code),code,
                   crash_disposition(disp));
        }
        printk("[JTMOS] Crash snapshot queued for /logs/crash.log and emergency serial.\n");
    }
}

static const char *crash_lock_action(int a)
{
    switch(a) {
    case CRASH_LOCK_WAIT: return "WAIT";
    case CRASH_LOCK_ACQUIRE: return "ACQUIRE";
    case CRASH_LOCK_RELEASE: return "RELEASE";
    case CRASH_LOCK_TIMEOUT: return "TIMEOUT";
    case CRASH_LOCK_BAD: return "BAD";
    default: return "?";
    }
}

static const char *crash_disposition(int d)
{
    if(d==CRASH_DISPOSITION_QUARANTINE) return "QUARANTINE/REAP";
    if(d==CRASH_DISPOSITION_FATAL) return "SYSTEM_FATAL";
    return "UNKNOWN";
}

static void crash_append(char *out,int *used,int cap,const char *fmt,...)
{
    va_list ap;
    int n;
    if(!out || !used || *used>=cap-1) return;
    va_start(ap,fmt);
    n=vsnprintf(out+*used,(unsigned)(cap-*used),fmt,ap);
    va_end(ap);
    if(n<0) return;
    if(n>=cap-*used) *used=cap-1;
    else *used+=n;
}

static void crash_append_analysis(char *out,int *used,int cap,const CRASH_RECORD *r)
{
    DWORD err=r->frame.error;
    crash_append(out,used,cap,"ANALYSIS: context=%s IF=%u disposition=%s\n",
                 r->from_user?"user":"kernel",(unsigned)((r->frame.eflags>>9)&1U),
                 crash_disposition(r->disposition));
    if(!r->authoritative)
        crash_append(out,used,cap,"ANALYSIS-WARN: live frame unavailable; EIP/EFLAGS may be scheduler TSS snapshot.\n");
    if(r->code==14) {
        crash_append(out,used,cap,"PF: %s %s %s%s%s address=%08x\n",
                     (err&1U)?"protection":"not-present",(err&2U)?"write":"read",
                     (err&4U)?"user":"supervisor",(err&8U)?" reserved-bit":"",
                     (err&16U)?" instruction-fetch":"",(unsigned)r->frame.cr2);
        if(r->frame.cr2<0x1000U)
            crash_append(out,used,cap,"SUSPECT: near-NULL pointer access (CR2 < 0x1000).\n");
    }
    if(r->code==13) {
        crash_append(out,used,cap,"GP: EXT=%u IDT=%u TI=%u selector_index=%u selector=%04x\n",
                     (unsigned)(err&1U),(unsigned)((err>>1)&1U),(unsigned)((err>>2)&1U),
                     (unsigned)((err>>3)&0x1fffU),(unsigned)(((err>>3)&0x1fffU)<<3));
    }
    if(!(r->frame.eflags&0x200U))
        crash_append(out,used,cap,"SUSPECT: fault occurred with IF=0; inspect last syscall/lock and CLI critical section.\n");
    if(r->seconds_without_switch)
        crash_append(out,used,cap,"SUSPECT: PID had no task switch for about %u RTC second(s).\n",
                     (unsigned)r->seconds_without_switch);
    if(r->syscall_count)
        crash_append(out,used,cap,"SUSPECT-CONTEXT: last syscall=%u active_depth=%u.\n",
                     (unsigned)r->syscalls[r->syscall_count-1].nr,
                     (unsigned)r->scall_depth);
    crash_append(out,used,cap,"MAP-HINT: resolve EIP %08x against kernel32.map (nearest symbol <= EIP).\n",
                 (unsigned)r->frame.eip);
}

static int crash_render(const CRASH_RECORD *r,char *out,int cap)
{
    int i,used=0;
    crash_append(out,&used,cap,"\n================ JTMOS CRASH ANALYSIS V%u ================\n",
                 (unsigned)JTMOS_CRASH_ANALYSIS_VERSION);
    crash_append(out,&used,cap,"CRASH-ID=%u TICK=%u EXC=%d REASON=%s\n",
                 (unsigned)r->sequence,(unsigned)r->tick,r->code,r->reason);
    crash_append(out,&used,cap,"PID=%d MAGIC=%08x NAME=%s CMD=%s TYPE=%02x STATE=%u TERM=%u DNR=%u DB=%u\n",
                 r->pid,(unsigned)r->magic,r->name[0]?r->name:"?",r->cmdline[0]?r->cmdline:"?",
                 (unsigned)r->thread_type_snapshot,(unsigned)r->thread_state_snapshot,
                 (unsigned)r->terminal,(unsigned)r->dnr,(unsigned)r->db);
    crash_append(out,&used,cap,"LIVE authoritative=%u user=%u CS:EIP=%04x:%08x ERR=%08x EFLAGS=%08x IF=%u ENTRY_ESP=%08x USER_SS:ESP=%04x:%08x CR2=%08x\n",
                 (unsigned)r->authoritative,(unsigned)r->from_user,
                 (unsigned)r->frame.cs,(unsigned)r->frame.eip,(unsigned)r->frame.error,
                 (unsigned)r->frame.eflags,(unsigned)((r->frame.eflags>>9)&1U),
                 (unsigned)r->frame.entry_esp,(unsigned)r->frame.user_ss,
                 (unsigned)r->frame.user_esp,(unsigned)r->frame.cr2);
    crash_append(out,&used,cap,"LIVE-REGS authoritative=%u EAX=%08x EBX=%08x ECX=%08x EDX=%08x ESI=%08x EDI=%08x EBP=%08x\n",
                 (unsigned)r->frame.regs_authoritative,(unsigned)r->frame.eax,(unsigned)r->frame.ebx,
                 (unsigned)r->frame.ecx,(unsigned)r->frame.edx,(unsigned)r->frame.esi,
                 (unsigned)r->frame.edi,(unsigned)r->frame.ebp);
    crash_append(out,&used,cap,"TSS EAX=%08x EBX=%08x ECX=%08x EDX=%08x ESI=%08x EDI=%08x EBP=%08x ESP=%08x EIP=%08x CR3=%08x\n",
                 (unsigned)r->tss.eax,(unsigned)r->tss.ebx,(unsigned)r->tss.ecx,
                 (unsigned)r->tss.edx,(unsigned)r->tss.esi,(unsigned)r->tss.edi,
                 (unsigned)r->tss.ebp,(unsigned)r->tss.esp,(unsigned)r->tss.eip,
                 (unsigned)r->tss.cr3);
    crash_append(out,&used,cap,"TSS SEG CS=%04x SS=%04x DS=%04x ES=%04x FS=%04x GS=%04x EFLAGS=%08x\n",
                 r->tss.cs,r->tss.ss,r->tss.ds,r->tss.es,r->tss.fs,r->tss.gs,(unsigned)r->tss.eflags);
    crash_append(out,&used,cap,"SCHED taskSwitchNr=%u irqActive=%u timerIRQs=%u switches=%u rtc=%u lastSwitchRtc=%u noSwitchSec=%u\n",
                 (unsigned)r->task_switch_nr,(unsigned)r->irq_active,
                 (unsigned)r->sched.timer_irqs,(unsigned)r->sched.context_switches,
                 (unsigned)r->sched.rtc_heartbeat,(unsigned)r->sched.last_switch_rtc,
                 (unsigned)r->seconds_without_switch);

    crash_append(out,&used,cap,"-- RECENT SYSCALLS (oldest -> newest) --\n");
    for(i=0;i<r->syscall_count;i++) {
        const CRASH_SYSCALL_EVENT *e=&r->syscalls[i];
        crash_append(out,&used,cap,"SC seq=%u tick=%u nr=%u ebx=%08x ecx=%08x edx=%08x esi=%08x edi=%08x ebp=%08x\n",
                     (unsigned)e->seq,(unsigned)e->tick,(unsigned)e->nr,
                     (unsigned)e->ebx,(unsigned)e->ecx,(unsigned)e->edx,
                     (unsigned)e->esi,(unsigned)e->edi,(unsigned)e->ebp);
    }
    crash_append(out,&used,cap,"-- RECENT SWITCHES --\n");
    for(i=0;i<r->switch_count;i++) {
        const CRASH_SWITCH_EVENT *e=&r->switches[i];
        crash_append(out,&used,cap,"SW seq=%u tick=%u %d->%d\n",
                     (unsigned)e->seq,(unsigned)e->tick,e->old_pid,e->new_pid);
    }
    crash_append(out,&used,cap,"-- RELEVANT LOCK EVENTS --\n");
    for(i=0;i<r->lock_count;i++) {
        const CRASH_LOCK_EVENT *e=&r->locks[i];
        crash_append(out,&used,cap,"LK seq=%u tick=%u action=%s pid=%d owner=%d lock=%08x at=%s %s:%d\n",
                     (unsigned)e->seq,(unsigned)e->tick,crash_lock_action(e->action),
                     e->pid,e->owner_pid,(unsigned)e->lock_id,
                     e->function?e->function:"?",e->file?e->file:"?",e->line);
    }
    crash_append_analysis(out,&used,cap,r);
    crash_append(out,&used,cap,"================ END CRASH-ID %u ================\n",
                 (unsigned)r->sequence);
    return used;
}

void CrashAnalysisFlushPending(void)
{
    static char report[CRASH_REPORT_BYTES];
    int i,len,flags,normal_ready,normal_ok;
    CRASH_RECORD local;

    normal_ready=SystemLoggingStorageIsReady();
    if(!normal_ready && !SystemLoggingCrashFallbackIsReady()) return;
    for(i=0;i<CRASH_RECORD_SLOTS;i++) {
        flags=get_eflags();
        disable();
        if(!crash_records[i].pending) {
            set_eflags(flags);
            continue;
        }
        local=crash_records[i];
        set_eflags(flags);

        len=crash_render(&local,report,sizeof(report));
        if(len<=0) continue;
        normal_ok=0;
        if(normal_ready && WriteCrashLogRaw(report,len)==0)
            normal_ok=1;

        if(!normal_ok) {
            /* Windows-style second chance: write a self-contained slot into
             * the preallocated crash.fbk sector map. Never repeat the raw
             * write for the same record on every idle pass. */
            if(!local.fallback_persisted && SystemLoggingCrashFallbackIsReady() &&
               WriteCrashLogFallbackRaw(report,len,local.sequence)==0) {
                flags=get_eflags();
                disable();
                if(crash_records[i].pending &&
                   crash_records[i].sequence==local.sequence)
                    crash_records[i].fallback_persisted=1;
                set_eflags(flags);
            }
            /* Keep the RAM record pending. If normal JTMFS comes back, the
             * same report is still appended to readable crash.log. */
            return;
        }

        WriteSystemLogStream("CRASH","Detailed crash snapshot appended to CRASH_LOG.");
        flags=get_eflags();
        disable();
        if(crash_records[i].pending && crash_records[i].sequence==local.sequence)
            crash_records[i].pending=0;
        set_eflags(flags);
    }
}
