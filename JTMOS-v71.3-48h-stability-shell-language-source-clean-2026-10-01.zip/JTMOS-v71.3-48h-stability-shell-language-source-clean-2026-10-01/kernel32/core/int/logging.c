//================================================================
// logging.c - JTMOS persistent system logging service.
//================================================================
#include "kernel32.h"
#include "logging.h"
#include "diskspace.h"
#include "jtmfs.h"
#include "jtmfsAccess.h"
#include "jtmfat.h"
#include "scheduler.h"

/* V68.179: system messages are queued in RAM and written in batches.  The
 * preferred persistent sink is hda1:/logs when hda1 exists and is JTMFS.
 * keropt.c can disable that preference and/or select another device root,
 * for example ram:/. */
#define LOG_SUBDIR "logs"
#define SYSLOG_NAME "system.log"
#define WWWLOG_NAME "www.log"
#define CRASHLOG_NAME "crash.log"
#define CRASHFALLBACK_NAME "crash.fbk"
#define KLOGGER_PID_NAME "klogger.pid"
#define DISKSPACE_LOG_NAME "diskspace.log"
#define DISKSPACE_SAMPLE_INTERVAL 10UL
#define DISKSPACE_PERSIST_INTERVAL 60UL
#define DISKSPACE_LOG_MAX_BYTES (256*1024)
#define DISKSPACE_LOG_RESERVE_BYTES (64*1024UL)
#define SYSTEMLOG_FIFO_BYTES (256*1024)
#define SYSTEMLOG_CHUNK_BYTES 8192
#define SYSTEMLOG_PRESSURE_BYTES ((SYSTEMLOG_FIFO_BYTES*3)/4)
#define SYSTEMLOG_TARGET_RECHECK_SECONDS 30UL
#define KLOGGER_HDA1_STABLE_MS 8000UL
#define KLOGGER_QUIESCE_WAIT_MS 3000UL
#define KLOGGER_RESTART_DELAY_MS 2000UL

THREAD LoggerThread;
FBUF SystemLog;
int system_logging=FALSE;
static volatile int logging_storage_ready=0;
static volatile int logging_writer_pid=0;
static volatile int logging_quiescing=0;
static volatile DWORD logging_worker_faults=0;
static DWORD logging_hda1_candidate_since_ms=0;
static DWORD logging_worker_restart_after_ms=0;
static DWORD logging_maintenance_last_ms=0;
static volatile DWORD logging_dropped_bytes=0;
/* V69.34 fail-closed persistence gate.  KLOGGER itself must not trigger a
 * filesystem/header read while hda1 is still being discovered.  The normal
 * block-device/JTMFS bring-up path owns that work.  KLOGGER only inspects the
 * already-published hda1 DNR and cached, validated JTMFS information block. */
static volatile int logging_hda1_header_ready=0;
static int logging_hda1_header_dnr=-1;
static int logging_root_dnr=-1;
static int logging_root_db=-1;
static int logging_target_is_hda1=0;
static DWORD logging_last_diskspace_sample=0;
static DWORD logging_last_diskspace_persist=0;
static DWORD logging_last_flush=0;
static DWORD logging_last_target_probe=0;
static char logging_dir_path[512];
static char logging_syslog_path[512];
static char logging_wwwlog_path[512];
static char logging_crashlog_path[512];
static char logging_crashfallback_path[512];
static char logging_klogger_pid_path[512];
static char logging_diskspace_path[512];

static void logging_hda1_gate_reset(void)
{
    logging_hda1_header_ready=0;
    logging_hda1_header_dnr=-1;
}

/* V69.34: the only condition which opens KLOGGER persistence.
 *
 * IMPORTANT: this function intentionally does not call jtmfs_isDriveReady(),
 * jtmfat_isJTMFS(), jtmfat_getinfoblock(), jtmfat_LoadNewInfoBlock(),
 * readblock(), open(), mkdir(), syncdev(), or any other operation which can
 * cause KLOGGER to touch storage.  Device/JTMFS initialization must have
 * already loaded the hda1 information block.  We only inspect that cached
 * header after driver_getdevicenrbyname("hda1") returns a valid DNR.
 */
static int logging_hda1_header_gate_check(void)
{
    int dnr;
    JTMFAT_INFOBLOCK *inf;

    dnr=driver_getdevicenrbyname("hda1");
    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_CFAT_STRUCTURES ||
       fatsys==NULL || fatsys->bb[dnr]==NULL || !fatsys->isJTMFS[dnr])
    {
        logging_hda1_gate_reset();
        return -1;
    }

    inf=fatsys->bb[dnr];
    /* The signature check is explicit because this is the policy gate the
     * logger is allowed to trust.  validateinfoblock() performs the stronger
     * cached-header/geometry validation without loading anything from disk. */
    if(strncmp(inf->detstr,"JTMFS",5)!=0 || jtmfat_validateinfoblock(dnr,inf)!=0)
    {
        logging_hda1_gate_reset();
        return -1;
    }

    logging_hda1_header_dnr=dnr;
    logging_hda1_header_ready=1;
    return dnr;
}

/* Cheap guard for every persistence entry point after activation.  It only
 * re-resolves the hda1 name; if the DNR mapping changed, persistence closes
 * immediately and the worker returns to RAM-only mode until the cached header
 * has been validated again by logging_hda1_header_gate_check(). */
static int logging_persistence_gate_allows_io(void)
{
    int dnr;
    if(!logging_hda1_header_ready || logging_hda1_header_dnr<0)
        return 0;
    dnr=driver_getdevicenrbyname("hda1");
    if(!isValidDevice(dnr) || dnr!=logging_hda1_header_dnr)
    {
        logging_hda1_gate_reset();
        logging_storage_ready=0;
        logging_target_is_hda1=0;
        logging_root_dnr=-1;
        logging_root_db=-1;
        return 0;
    }
    return 1;
}

static int logging_writer_enter(void)
{
    int flags,pid,ok=0;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    if(logging_quiescing) {
        set_eflags(flags);
        return 0;
    }
    if(logging_writer_pid==0) {
        logging_writer_pid=pid;
        ok=1;
    }
    set_eflags(flags);
    return ok;
}

static void logging_writer_leave(void)
{
    int flags,pid;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    if(logging_writer_pid==pid) logging_writer_pid=0;
    set_eflags(flags);
}

static int logging_writer_is_current(void)
{
    return logging_writer_pid==GetCurrentThread();
}

/* V68.204 lock-order rule:
 *
 * POSIX filesystem writers acquire their function-local write()/open() lock
 * first and only then enter the per-volume JTMFS mutation lock.  KLOGGER used
 * to do the reverse: mutation_trylock -> open/write.  That creates the classic
 * ABBA cycle when UNZ owns write() while KLOGGER owns the mutation lock.
 *
 * Background logging therefore uses the mutation lock only as a nonblocking
 * availability PROBE.  Release it immediately, before any namespace or POSIX
 * file operation.  The subsequent open/write/close follows the same lock order
 * as every foreground client.  A race after the probe may delay logging, but
 * it cannot invert the lock hierarchy or deadlock install.img.nz extraction. */
static int logging_fs_try_enter(int dnr)
{
    if(!logging_persistence_gate_allows_io())
        return -1;
    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr))
        return -1;
    if(!jtmfs_mutation_trylock(dnr))
        return -1;
    jtmfs_mutation_unlock(dnr);
    return dnr;
}

static int logging_write_all(int fd,const BYTE *buf,int len)
{
    int done=0,rv;
    while(done<len) {
        rv=write(fd,(void *)(buf+done),len-done);
        if(rv<=0) return -1;
        done+=rv;
    }
    return 0;
}

static int logging_make_path(char *dst,unsigned int cap,const char *root,const char *leaf)
{
    unsigned int n;
    int rv;

    if(dst==NULL || cap<4 || root==NULL || !root[0] || leaf==NULL || !leaf[0])
        return -1;
    n=(unsigned int)strlen(root);
    if(root[n-1]=='/')
        rv=snprintf(dst,cap,"%s%s",root,leaf);
    else if(root[n-1]==':')
        rv=snprintf(dst,cap,"%s/%s",root,leaf);
    else
        rv=snprintf(dst,cap,"%s/%s",root,leaf);
    if(rv<0 || (unsigned int)rv>=cap) {
        dst[0]=0;
        return -1;
    }
    return 0;
}

static int logging_device_from_root(const char *root)
{
    char dev[32];
    const char *p;
    unsigned int n;

    if(root==NULL || !root[0]) return -1;
    p=strchr(root,':');
    if(p==NULL) p=strchr(root,'/');
    n=p ? (unsigned int)(p-root) : (unsigned int)strlen(root);
    if(n==0 || n>=sizeof(dev)) return -1;
    memcpy(dev,root,n);
    dev[n]=0;
    return driver_getdevicenrbyname(dev);
}

static int logging_build_target_paths(const char *root,
                                      char *dir,char *syslog,char *wwwlog,
                                      char *crashlog,char *pidlog,char *disklog)
{
    if(logging_make_path(dir,512,root,LOG_SUBDIR)!=0) return -1;
    if(logging_make_path(syslog,512,dir,SYSLOG_NAME)!=0) return -1;
    if(logging_make_path(wwwlog,512,dir,WWWLOG_NAME)!=0) return -1;
    if(logging_make_path(crashlog,512,dir,CRASHLOG_NAME)!=0) return -1;
    if(logging_make_path(pidlog,512,dir,KLOGGER_PID_NAME)!=0) return -1;
    if(logging_make_path(disklog,512,dir,DISKSPACE_LOG_NAME)!=0) return -1;
    return 0;
}

static void logging_publish_paths(void)
{
    /* Keep the environment in sync with the actually selected sink so shell
     * tools and userland see the same paths as KLOGGER. */
    (void)ksetglobalenv("LOG_DIR",logging_dir_path,1);
    (void)ksetglobalenv("SYSTEM_LOG",logging_syslog_path,1);
    (void)ksetglobalenv("WWW_LOG",logging_wwwlog_path,1);
    (void)ksetglobalenv("CRASH_LOG",logging_crashlog_path,1);
    if(logging_crashfallback_path[0])
        (void)ksetglobalenv("CRASH_FALLBACK",logging_crashfallback_path,1);
}

static void logging_resume_file_debug_streams(void)
{
    /* SMSH autostart may have issued d0 to quiet the serial console.  Once a
     * filesystem sink is safe, collect DEBUG/REPORT into RAM again without
     * re-enabling console-to-UART mirroring. */
    jtmos_debug=1;
    debug2=1;
    glvar.debugMsg=1;
}

/* V70.62: materialise the reserved crash dump file through normal JTMFS while
 * the filesystem is healthy.  The emergency writer later needs only its
 * cached logical-sector map, never DIRDB/FAT allocation. */
static int logging_prepare_crash_fallback_file(int dnr,int db,const char *path)
{
    static BYTE zero[512];
    int fd,end,remaining,chunk,rv=0;
    if(path==NULL || !isValidDevice(dnr)) return -1;
    fd=open(path,O_RDWR|O_CREAT|O_JTMOS_BATCH);
    if(fd<0) return -1;
    end=lseek(fd,0,SEEK_END);
    if(end<0) { close(fd); return -1; }
    memset(zero,0,sizeof(zero));
    remaining=JTMFS_CRASH_FALLBACK_BYTES-end;
    while(remaining>0) {
        chunk=remaining>512 ? 512 : remaining;
        if(logging_write_all(fd,zero,chunk)!=0) { rv=-1; break; }
        remaining-=chunk;
    }
    close(fd);
    if(rv!=0) return rv;
    /* Commit both namespace and FAT chain before publishing the raw map. */
    if(syncdev(dnr)!=0) return -1;
    return jtmfs_CrashFallbackPrepare(dnr,db,path)==0 ? 0 : -1;
}

/* Activate one device-root target.  The root is expected to look like hda1:/
 * or ram:/.  A target is accepted only when the named device exists, reports
 * JTMFS ready, has a valid JTMFS root DB and permits append-open in /logs. */
static int logging_activate_root(const char *root,int is_hda1)
{
    char dir[512],syslog[512],wwwlog[512],crashlog[512],crashfb[512],pidlog[512],disklog[512];
    int dnr,db,fd,saved_dnr,saved_db,fs_lock=-1;

    if(root==NULL || !root[0]) return -1;
    if(logging_hda1_header_gate_check()<0) return -1;
    dnr=logging_device_from_root(root);
    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr)) return -1;
    db=jtmfs_getrootdir(dnr);
    if(db<=0 || db>=getsize(dnr)) return -1;
    if(logging_build_target_paths(root,dir,syslog,wwwlog,crashlog,pidlog,disklog)!=0)
        return -1;
    if(logging_make_path(crashfb,sizeof(crashfb),dir,CRASHFALLBACK_NAME)!=0)
        return -1;
    if(!logging_writer_enter()) return -1;
    fs_lock=logging_fs_try_enter(dnr);
    if(fs_lock<0) {
        logging_writer_leave();
        return -1;
    }

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    SetThreadDNR(GetCurrentThread(),dnr);
    SetThreadDB(GetCurrentThread(),db);

    /* mkdir is intentionally idempotent here.  If /logs already exists it
     * may return an error; the append-open below is the authoritative test. */
    (void)mkdir(dir,0);
    fd=open(syslog,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd<0) {
        SetThreadDNR(GetCurrentThread(),saved_dnr);
        SetThreadDB(GetCurrentThread(),saved_db);
        logging_writer_leave();
        return -1;
    }
    close(fd);
    fd=open(wwwlog,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd>=0) close(fd);
    fd=open(crashlog,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd>=0) close(fd);
    /* Only the real hda1 target gets the block-level crash fallback.  ram:/
     * remains a normal filesystem-only logging target. */
    if(is_hda1) {
        if(logging_prepare_crash_fallback_file(dnr,db,crashfb)!=0)
            dprintk("KLOGGER: crash fallback file/map preparation failed; normal crash.log remains active.\n");
    } else {
        jtmfs_CrashFallbackReset();
    }

    logging_root_dnr=dnr;
    logging_root_db=db;
    logging_target_is_hda1=is_hda1 ? 1 : 0;
    strcpy(logging_dir_path,dir);
    strcpy(logging_syslog_path,syslog);
    strcpy(logging_wwwlog_path,wwwlog);
    strcpy(logging_crashlog_path,crashlog);
    strcpy(logging_crashfallback_path,crashfb);
    strcpy(logging_klogger_pid_path,pidlog);
    strcpy(logging_diskspace_path,disklog);
    logging_storage_ready=1;
    if(LoggerThread.pid>0) {
        SetThreadDNR(LoggerThread.pid,dnr);
        SetThreadDB(LoggerThread.pid,db);
    }

    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);

    /* V68.204: the availability probe above is released before all POSIX I/O.
     * syncdev() remains outside namespace/file operations and has its own
     * serialization and snapshot/retry discipline. */
    (void)syncdev(dnr);
    logging_writer_leave();

    logging_publish_paths();
    logging_resume_file_debug_streams();
    WriteSystemLog("============================================================");
    WriteSystemLog("JTMOS RAM-buffered system log activated.");
    if(is_hda1)
        WriteSystemLog("KLOGGER: hda1 is present and JTMFS; persistent target is hda1:/logs/system.log.");
    else
        WriteSystemLog("KLOGGER: using configured non-hda1 logging target.");
    return 0;
}

static int logging_hda1_stable_candidate(void)
{
    int dnr,db;
    DWORD now;

    /* No KLOGGER disk access is permitted until the hda1 name resolves to a
     * valid DNR and the already-cached JTMFS header passes the V69.34 gate. */
    dnr=logging_hda1_header_gate_check();
    if(dnr<0) {
        logging_hda1_candidate_since_ms=0;
        return 0;
    }
    db=jtmfs_getrootdir(dnr);
    if(db<=0 || db>=getsize(dnr)) {
        logging_hda1_candidate_since_ms=0;
        return 0;
    }

    now=(DWORD)GetTickCount();
    if(logging_hda1_candidate_since_ms==0) {
        if(now==0) return 0;
        logging_hda1_candidate_since_ms=now;
        return 0;
    }
    if((DWORD)(now-logging_hda1_candidate_since_ms)<KLOGGER_HDA1_STABLE_MS)
        return 0;
    return 1;
}

static int logging_try_activate_target(int allow_fallback)
{
    if(!SYSTEMLOGGING || logging_quiescing) return -1;

    /* Fail closed: neither hda1 nor a configured fallback target may be used
     * until hda1 has a valid DNR and its cached JTMFS header matches. */
    if(logging_hda1_header_gate_check()<0) return -1;

    if(SYSTEMLOGGING_HDA1) {
        if(logging_target_is_hda1 && logging_storage_ready) return 0;
        /* V68.216: hda1 must remain a valid JTMFS continuously for at least
         * eight seconds before KLOGGER creates /logs or writes anything.
         * This deliberately stays out of the partition -> mkfs transition. */
        if(logging_hda1_stable_candidate() && logging_activate_root("hda1:/",1)==0)
            return 0;
    }

    if(!allow_fallback) return -1;
    if(SYSTEMLOGGING_TARGET_ROOT!=NULL && SYSTEMLOGGING_TARGET_ROOT[0])
        return logging_activate_root(SYSTEMLOGGING_TARGET_ROOT,0);
    return -1;
}

void initSystemLog(void)
{
    if(system_logging || !SYSTEMLOGGING) return;
    CreateBuffer(&SystemLog,SYSTEMLOG_FIFO_BYTES);
    if(SystemLog.buf==NULL) {
        dprintk("initSystemLog: unable to allocate log FIFO.\n");
        return;
    }
    system_logging=TRUE;
}

int SystemLoggingStreamEnabled(void)
{
    return SYSTEMLOGGING && system_logging;
}

int SystemLoggingStorageIsReady(void)
{
    return logging_storage_ready ? 1 : 0;
}

/* Queue exact bytes.  This remains filesystem-independent: interrupt/debug
 * producers only touch the RAM FIFO.  KLOGGER is the sole filesystem writer. */
void WriteSystemLogRaw(const char *msg,int len)
{
    int i;
    if(!SYSTEMLOGGING || !system_logging || msg==NULL || len<=0) return;
    if(logging_writer_is_current()) return;
    for(i=0;i<len;i++) {
        if(PutBuffer(&SystemLog,(BYTE)msg[i])!=0)
            logging_dropped_bytes++;
    }
}

void WriteSystemLogStream(const char *channel,const char *msg)
{
    int l;
    if(msg==NULL || !SystemLoggingStreamEnabled()) return;
    if(channel!=NULL && channel[0]) {
        WriteSystemLogRaw("[",1);
        WriteSystemLogRaw(channel,(int)strlen(channel));
        WriteSystemLogRaw("] ",2);
    }
    l=(int)strlen(msg);
    WriteSystemLogRaw(msg,l);
    if(l<=0 || msg[l-1]!='\n') WriteSystemLogRaw("\n",1);
}

void WriteSystemLog(const char *msg)
{
    int l;
    if(msg==NULL || !SystemLoggingStreamEnabled()) return;
    l=(int)strlen(msg);
    WriteSystemLogRaw(msg,l);
    if(l<=0 || msg[l-1]!='\n') WriteSystemLogRaw("\n",1);
}

/* Drain the RAM FIFO to the selected JTMFS target. */
int SystemLogFlushNow(void)
{
    static BYTE buf[SYSTEMLOG_CHUNK_BYTES];
    char dropmsg[128];
    DWORD dropped;
    int fd,d,i,n,rv=0,fs_lock=-1;
    int saved_dnr,saved_db,flags;

    if(!SYSTEMLOGGING || !system_logging || !logging_storage_ready || logging_quiescing)
        return 0;
    if(!logging_persistence_gate_allows_io()) return 0;
    if(!logging_writer_enter())
        return 0;

    fs_lock=logging_fs_try_enter(logging_root_dnr);
    if(fs_lock<0) {
        /* Foreground I/O owns the volume.  Keep every FIFO byte queued and
         * retry later instead of entering the filesystem lock wait path. */
        logging_writer_leave();
        return -1;
    }

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }

    /* O_WRONLY is required.  O_CREAT|O_APPEND alone has O_ACCMODE==O_RDONLY
     * in JTMOS and makes write() reject the descriptor with EBADF. */
    fd=open(logging_syslog_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd<0) {
        rv=-1;
        goto out;
    }

    flags=get_eflags();
    disable();
    dropped=logging_dropped_bytes;
    logging_dropped_bytes=0;
    set_eflags(flags);
    if(dropped) {
        n=sprintf(dropmsg,"[KLOGGER] FIFO overflow: %u byte(s) were dropped before flush.\n",
                  (unsigned)dropped);
        if(n>0 && logging_write_all(fd,(BYTE *)dropmsg,n)!=0) rv=-1;
    }

    while(rv==0) {
        i=0;
        while(i<(int)sizeof(buf)) {
            d=GetBuffer(&SystemLog);
            if(d<0) break;
            if(d!=0) buf[i++]=(BYTE)d;
        }
        if(i==0) break;
        if(logging_write_all(fd,buf,i)!=0) rv=-1;
    }
    close(fd);

out:
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);

    /* O_JTMOS_BATCH keeps close() cheap.  The mutation availability probe is
     * never held across POSIX I/O or this durability barrier, so a slow/stuck
     * SATA flush cannot form a lock-order cycle with foreground writers. */
    if(rv==0 && fs_lock>=0 && syncdev(fs_lock)!=0)
        rv=-1;
    logging_writer_leave();
    return rv;
}

/* V69.29: foreground bootstrap/archive extraction can temporarily stop
 * KLOGGER filesystem persistence without disabling the RAM FIFO.  Existing
 * writers are allowed to finish before SQA enters its critical I/O phase. */
int SystemLoggingPausePersistence(void)
{
    DWORD start,now;
    int flags,pid;

    if(!SYSTEMLOGGING || !system_logging) return 0;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    logging_quiescing=1;
    set_eflags(flags);

    start=(DWORD)GetTickCount();
    for(;;) {
        flags=get_eflags();
        disable();
        if(logging_writer_pid==0 || logging_writer_pid==pid) {
            set_eflags(flags);
            return 0;
        }
        set_eflags(flags);
        now=(DWORD)GetTickCount();
        if((DWORD)(now-start)>=KLOGGER_QUIESCE_WAIT_MS) {
            /* Keep quiescing asserted: even if an old writer is unhealthy,
             * no new KLOGGER filesystem transaction may race SQA. */
            return -1;
        }
        SchedulerWaitPause(1000UL);
    }
}

void SystemLoggingResumePersistence(void)
{
    int flags;
    if(!SYSTEMLOGGING) return;
    flags=get_eflags();
    disable();
    logging_quiescing=0;
    set_eflags(flags);
}

/* Called after SMSH has a writable JTMFS root.  That root does not need to be
 * the logging target: hda1:/ is preferred independently when it exists and is
 * JTMFS.  If it is absent, SYSTEMLOGGING_TARGET_ROOT is used (ram:/ by
 * default). */
void SystemLoggingStorageReady(void)
{
    if(!SYSTEMLOGGING) { systemStarted|=2; return; }
    initSystemLog();
    if(system_logging)
        (void)logging_try_activate_target(1);
    systemStarted|=2;
}

/* V68.216: destructive storage administration (notably mkfs hda1) must
 * detach KLOGGER before the filesystem is reformatted underneath it.  This is
 * intentionally allocation/filesystem-free; new FIFO producers keep logging
 * to RAM while persistence is quiesced. */
int SystemLoggingStorageChanging(const char *device)
{
    DWORD start,now;
    int flags,had_persistence;
    if(device==NULL) return 0;
    if(strcmp(device,"hda1")!=0 && strcmp(device,"hda1:")!=0) return 0;

    flags=get_eflags();
    disable();
    had_persistence=logging_storage_ready ? 1 : 0;
    logging_quiescing=1;
    logging_hda1_candidate_since_ms=0;
    logging_hda1_gate_reset();
    logging_storage_ready=0;
    logging_target_is_hda1=0;
    set_eflags(flags);
    jtmfs_CrashFallbackReset();

    /* A crash fallback write is outside logging_writer_pid by design.  Do not
     * let mkfs/partition changes race a slot already in its direct block path. */
    start=(DWORD)GetTickCount();
    while(jtmfs_CrashFallbackBusy()) {
        now=(DWORD)GetTickCount();
        if((DWORD)(now-start)>=KLOGGER_QUIESCE_WAIT_MS) {
            flags=get_eflags();
            disable();
            logging_quiescing=0;
            set_eflags(flags);
            return -1;
        }
        SchedulerWaitPause(1000UL);
    }

    if(!had_persistence) return 0;

    /* Every persistent target depends on the hda1 header gate.  Let an
     * already-started append finish, but never change hda1 underneath it. */
    start=(DWORD)GetTickCount();
    for(;;) {
        flags=get_eflags();
        disable();
        if(logging_writer_pid==0) {
            set_eflags(flags);
            logging_root_dnr=-1;
            logging_root_db=-1;
            return 0;
        }
        set_eflags(flags);
        now=(DWORD)GetTickCount();
        if((DWORD)(now-start)>=KLOGGER_QUIESCE_WAIT_MS) {
            flags=get_eflags();
            disable();
            logging_quiescing=0;
            logging_hda1_candidate_since_ms=0;
            set_eflags(flags);
            return -1;
        }
        SchedulerWaitPause(1000UL);
    }
}

void SystemLoggingStorageChanged(const char *device)
{
    int flags;
    if(device==NULL) return;
    if(strcmp(device,"hda1")!=0 && strcmp(device,"hda1:")!=0) return;
    flags=get_eflags();
    disable();
    logging_hda1_candidate_since_ms=0;
    logging_hda1_gate_reset();
    logging_storage_ready=0;
    logging_target_is_hda1=0;
    logging_root_dnr=-1;
    logging_root_db=-1;
    logging_quiescing=0;
    set_eflags(flags);
    jtmfs_CrashFallbackReset();
}

/* Exception-context notification: no allocation, no filesystem, no printk.
 * A faulted KLOGGER loses writer ownership immediately so mkfs/foreground I/O
 * can make forward progress. CPU_IDLE will reap it and maintenance restarts a
 * fresh worker after a short backoff. */
void SystemLoggingWorkerFaulted(int pid)
{
    int flags;
    DWORD now;
    if(pid<=0 || pid!=LoggerThread.pid) return;
    now=(DWORD)GetTickCount();
    flags=get_eflags();
    disable();
    logging_worker_faults++;
    logging_writer_pid=0;
    logging_storage_ready=0;
    logging_target_is_hda1=0;
    logging_hda1_candidate_since_ms=0;
    logging_hda1_gate_reset();
    logging_root_dnr=-1;
    logging_root_db=-1;
    logging_worker_restart_after_ms=now+KLOGGER_RESTART_DELAY_MS;
    set_eflags(flags);
}

int SystemLoggingIsWorker(int pid)
{
    return pid>0 && pid==LoggerThread.pid;
}

void SystemLoggingMaintenance(void)
{
    DWORD now;
    int pid;
    if(!SYSTEMLOGGING || !system_logging || logging_quiescing) return;
    now=(DWORD)GetTickCount();
    if((DWORD)(now-logging_maintenance_last_ms)<1000UL) return;
    logging_maintenance_last_ms=now;

    pid=LoggerThread.pid;
    if(pid>0 && pid<nr_threads && pid<N_MAX_THREADS) {
        if(thread_special[pid]!=0) return;
        if(thread_states[pid]!=0) return;
    }

    if(logging_worker_restart_after_ms &&
       (DWORD)(now-logging_worker_restart_after_ms) > 0x7fffffffUL)
        return;

    /* create_thread() transferred the old stack to the dead PID and normal
     * teardown already freed it. Never free the stale pointer a second time. */
    LoggerThread.stack=NULL;
    LoggerThread.l_stack=0;
    LoggerThread.pid=0;
    logging_worker_restart_after_ms=0;
    initSystemLogging();
}


int SystemLoggingCrashFallbackIsReady(void)
{
    return jtmfs_CrashFallbackReady();
}

/* Recovery-context fallback: does not require logging_storage_ready and does
 * not enter the normal namespace/FAT/cache path.  It is called by CPU_IDLE
 * after the faulting task has already been quarantined. */
int WriteCrashLogFallbackRaw(const char *msg,int len,DWORD sequence)
{
    if(msg==NULL || len<=0 || !jtmfs_CrashFallbackReady()) return -1;
    return jtmfs_CrashFallbackWrite(msg,len,sequence)==0 ? 0 : -1;
}

/* Append a complete post-mortem report to the dedicated crash log.
 * This API is process-context only; exception handlers must use the fixed RAM
 * crash snapshot and let CPU_IDLE call this later. */
int WriteCrashLogRaw(const char *msg,int len)
{
    int fd,saved_dnr,saved_db,rv=0,fs_lock=-1;
    if(!SYSTEMLOGGING || !logging_storage_ready || logging_quiescing || msg==NULL || len<=0) return -1;
    if(!logging_persistence_gate_allows_io()) return -1;
    if(!logging_writer_enter()) return -1;
    fs_lock=logging_fs_try_enter(logging_root_dnr);
    if(fs_lock<0) { logging_writer_leave(); return -1; }

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }
    fd=open(logging_crashlog_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd<0) rv=-1;
    else {
        if(logging_write_all(fd,(const BYTE *)msg,len)!=0) rv=-1;
        close(fd);
    }
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    if(rv==0 && fs_lock>=0 && syncdev(fs_lock)!=0) rv=-1;
    logging_writer_leave();
    return rv;
}

void WriteWWWLog(const char *msg)
{
    int fd,saved_dnr,saved_db,fs_lock=-1;
    if(!SYSTEMLOGGING || !logging_storage_ready || logging_quiescing || msg==NULL) return;
    if(!logging_persistence_gate_allows_io()) return;
    if(!logging_writer_enter()) return;

    /* HTTP runs in the uIP owner thread.  Web request logging is diagnostic,
     * never a reason to block the network owner behind foreground JTMFS work. */
    fs_lock=logging_fs_try_enter(logging_root_dnr);
    if(fs_lock<0) { logging_writer_leave(); return; }
    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }
    fd=open(logging_wwwlog_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd>=0) {
        (void)logging_write_all(fd,(const BYTE *)msg,(int)strlen(msg));
        (void)logging_write_all(fd,(const BYTE *)"\n",1);
        close(fd);
    }
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    logging_writer_leave();

    /* Do not call syncdev() from uIP context.  Periodic KLOGGER/disk-space
     * syncs make the append durable without turning a web request into a disk
     * barrier on physical MCP61/SATA hardware. */
}

/* Persist the in-kernel block-device table as a compact rolling audit.
 * Keep 64 KiB of emergency headroom so diagnostics never become the writer
 * that consumes the final filesystem allocation units. */
static int SystemDiskSpacePersistNow(void)
{
    JTMOS_DISKSPACE_STATS st;
    unsigned long long free_bytes;
    int fd,end,saved_dnr,saved_db,rv=0,fs_lock=-1;

    if(!SYSTEMLOGGING || !logging_storage_ready || logging_quiescing || !isValidDevice(logging_root_dnr))
        return 0;
    if(!logging_persistence_gate_allows_io()) return 0;
    if(DiskSpaceGetStats(logging_root_dnr,&st,1)==0 &&
       (st.flags&DISKSPACE_FLAG_JTMFS))
    {
        free_bytes=(unsigned long long)st.free_units*(unsigned long long)st.unit_size;
        if(free_bytes<DISKSPACE_LOG_RESERVE_BYTES) return -ENOSPC;
    }
    if(!logging_writer_enter()) return 0;
    fs_lock=logging_fs_try_enter(logging_root_dnr);
    if(fs_lock<0) { logging_writer_leave(); return 0; }

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    SetThreadDNR(GetCurrentThread(),logging_root_dnr);
    SetThreadDB(GetCurrentThread(),logging_root_db);

    fd=open(logging_diskspace_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
    if(fd<0) { rv=-1; goto out; }
    end=lseek(fd,0,SEEK_END);
    if(end>DISKSPACE_LOG_MAX_BYTES)
    {
        close(fd);
        fd=open(logging_diskspace_path,O_WRONLY|O_CREAT|O_TRUNC|O_JTMOS_BATCH);
        if(fd<0) { rv=-1; goto out; }
    }
    if(DiskSpaceWriteSnapshot(fd)!=0) rv=-1;
    close(fd);

out:
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    if(rv==0 && fs_lock>=0 && syncdev(fs_lock)!=0) rv=-1;
    logging_writer_leave();
    return rv;
}

void initSystemLogging(void)
{
    if(!SYSTEMLOGGING) return;
    initSystemLog();
    if(!system_logging) return;
    if(LoggerThread.pid>0 && LoggerThread.pid<nr_threads &&
       thread_states[LoggerThread.pid]!=0) return;
    if(ThreadCreateStack(&LoggerThread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        printk("KLOGGER: stack allocation failed; logging worker disabled.\n");
        return;
    }
    LoggerThread.pid=create_thread(LoggerThread.stack,LoggerThread.l_stack,LoggerThreadProgram);
    if(LoggerThread.pid>0) IdentifyThread(LoggerThread.pid,"KLOGGER");
    else ThreadDestroyStack(&LoggerThread);
}

void LoggerThreadProgram(void)
{
    int saved_dnr,saved_db,fd,flush_seconds;
    DWORD now;

    initSystemLog();
    if(!SYSTEMLOGGING) ExitThread(0);

    /* Storage may become writable after KLOGGER starts.  Retry target probing
     * instead of permanently depending on the instant SystemLoggingStorageReady
     * happened to run. */
    while(!logging_storage_ready) {
        (void)logging_try_activate_target(1);
        if(!logging_storage_ready) sleep(1);
    }

    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }
    WriteSystemLog("System started.");
    WriteSystemLog("KLOGGER: RAM FIFO -> selected /logs target.");
    if(logging_worker_faults)
        WriteSystemLog("KLOGGER: worker restarted after a contained fault; RAM FIFO preserved.");

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(logging_persistence_gate_allows_io() && logging_writer_enter()) {
        int fs_lock=logging_fs_try_enter(logging_root_dnr);
        if(fs_lock>=0) {
            fd=open(logging_klogger_pid_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH);
            if(fd>=0) close(fd);
                (void)syncdev(fs_lock);
        }
        logging_writer_leave();
    }
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);

    now=(DWORD)GetSeconds();
    logging_last_flush=now;
    logging_last_target_probe=now;

    while(1) {
        now=(DWORD)GetSeconds();
        flush_seconds=SYSTEMLOGGING_FLUSH_SECONDS;
        if(flush_seconds<1) flush_seconds=1;

        /* If boot initially had only ram:/, promote future RAM-buffer flushes
         * to hda1:/logs as soon as hda1 appears as a valid JTMFS partition.
         * Likewise, if hda1 preference is disabled, honor the configured root. */
        if(now-logging_last_target_probe>=SYSTEMLOG_TARGET_RECHECK_SECONDS) {
            if(SYSTEMLOGGING_HDA1 && !logging_target_is_hda1)
                (void)logging_try_activate_target(0);
            else if(!SYSTEMLOGGING_HDA1 && logging_target_is_hda1)
                (void)logging_try_activate_target(1);
            logging_last_target_probe=now;
        }

        /* Normal persistence is a roughly 30-second batch.  Under unusually
         * heavy debug traffic flush early at 75% FIFO occupancy rather than
         * dropping diagnostics. */
        if(SystemLog.count>=SYSTEMLOG_PRESSURE_BYTES ||
           now-logging_last_flush>=(DWORD)flush_seconds) {
            if(SystemLogFlushNow()==0)
                logging_last_flush=now;
        }

        if(now-logging_last_diskspace_sample>=DISKSPACE_SAMPLE_INTERVAL) {
            DiskSpacePeriodicSample();
            logging_last_diskspace_sample=now;
        }
        if(now-logging_last_diskspace_persist>=DISKSPACE_PERSIST_INTERVAL) {
            (void)SystemDiskSpacePersistNow();
            logging_last_diskspace_persist=now;
        }
        sleep(1);
    }
}
