// ===================================================
//              GDT MANIPULATION
//      Bounded GDT entry allocation system.
//      (C) 2002-2004 by Jari Tuominen.
//      V70.67 layout/publication hardening.
// ===================================================
#include "int.h"
#include "cpu.h"
#include "sysglvar.h"
#include "kernel32.h"
#include "delay.h"
#include "threads.h"
#include "gdtmanipulation.h"

#define DEF_PRIV_LEVEL 0

GDTENTSYS *gdtentsys;
int kappCodeSeg,kappDataSeg;

static int gdt_dynamic_pair_index(DWORD selector)
{
    DWORD s;

    if(selector & ~0xffffUL) return -1;      /* Architectural selectors are 16-bit. */
    if(selector & 0x0004U) return -1;       /* LDT selector, not GDT. */
    s=selector & 0xFFF8U;                  /* Strip RPL. */
    if(s<APPSEL_OFFS) return -1;
    if(((s-APPSEL_OFFS)&0x0FU)!=0U) return -1; /* Pair must start on CS slot. */
    s=(s-APPSEL_OFFS)/0x10U;
    if(s>=N_GDTENTS) return -1;
    return (int)s;
}

static int gdt_dynamic_range_valid(DWORD which,DWORD bytes)
{
    DWORD end;

    if(!gdt_table || bytes==0U || (which&7U)!=0U) return FALSE;
    if(which<APPSEL_OFFS) return FALSE;
    if(which>0xffffffffUL-bytes) return FALSE;
    end=which+bytes;
    return end<=sizeof(GDTTAB);
}

static void gdt_compiler_barrier(void)
{
    __asm__ __volatile__("" : : : "memory");
}

void InitGDTEntryAllocationSystem(void)
{
    if(gdtentsys) return;

    gdtentsys=malloc(sizeof(GDTENTSYS));
    if(!gdtentsys)
        KERNEL_FATAL("InitGDTEntryAllocationSystem: cannot allocate metadata");
    memset(gdtentsys,0,sizeof(*gdtentsys));

    /* Kernel application/scheduler compatibility pair.  The descriptor is
     * flat, but unlike the old WORD-limit API the requested limit is explicit
     * in bytes and therefore cannot accidentally inherit limit-high bits. */
    kappCodeSeg=NewCDSegment(0,0xffffffffUL,DEF_PRIV_LEVEL);
    if(!kappCodeSeg)
        KERNEL_FATAL("InitGDTEntryAllocationSystem: cannot allocate kernel CS/DS pair");
    kappDataSeg=kappCodeSeg+8;
}

void FreeGDTEntry(int which)
{
    DWORD saved_flags,selector;
    BYTE *p;
    int idx;

    if(which<0 || !gdtentsys || !gdt_table) return;
    selector=(DWORD)which;
    idx=gdt_dynamic_pair_index(selector);
    if(idx<0) return;

    selector&=0xFFF8U;
    saved_flags=get_eflags();
    disable();

    if(!gdtentsys->gdtent[idx].isAllocated)
    {
        set_eflags(saved_flags);
        return;
    }

    /* Revoke both descriptors before clearing their remaining fields.  This
     * prevents a concurrent IRQ/task path from observing a half-cleared but
     * still-Present code/data descriptor. */
    p=(BYTE *)gdt_table+selector;
    p[5]&=(BYTE)~0x80U;
    p[13]&=(BYTE)~0x80U;
    gdt_compiler_barrier();
    memset(p,0,16);
    gdtentsys->gdtent[idx].isAllocated=FALSE;
    gdt_compiler_barrier();
    set_eflags(saved_flags);
}

int gdt_NewEntry(void)
{
    DWORD saved_flags;
    int i,entryID=-1,selector;

    if(!gdtentsys || !gdt_table) return 0;
    saved_flags=get_eflags();
    disable();

    for(i=0;i<gdtentsys->n_gdtEntries;i++)
    {
        if(!gdtentsys->gdtent[i].isAllocated)
        {
            entryID=i;
            break;
        }
    }

    if(entryID<0)
    {
        if(gdtentsys->n_gdtEntries>=N_GDTENTS)
        {
            dprintk("gdt_NewEntry: dynamic GDT exhausted (%d pairs).\n",
                    gdtentsys->n_gdtEntries);
            set_eflags(saved_flags);
            return 0;
        }
        entryID=gdtentsys->n_gdtEntries++;
    }

    selector=entryID*0x10+APPSEL_OFFS;
    if(!gdt_dynamic_range_valid((DWORD)selector,16U))
    {
        dprintk("gdt_NewEntry: layout rejected selector 0x%x.\n",selector);
        set_eflags(saved_flags);
        return 0;
    }

    /* Allocated does not mean CPU-visible: keep the pair non-Present until
     * SetCDEntryEx publishes each complete descriptor. */
    memset((BYTE *)gdt_table+selector,0,16);
    gdtentsys->gdtent[entryID].isAllocated=TRUE;
    gdt_compiler_barrier();
    set_eflags(saved_flags);
    return selector;
}

int NewCDSegment(DWORD offs,DWORD limit,int prilev)
{
    int selector;

    if(prilev<0 || prilev>3)
    {
        dprintk("NewCDSegment: invalid privilege level %d.\n",prilev);
        return 0;
    }

    selector=gdt_NewEntry();
    if(!selector) return 0;

    SetCDEntry((DWORD)selector,offs,limit,prilev);
    return selector|prilev;
}

void SetCallGate(DWORD which,DWORD offset,WORD selector,BYTE access,BYTE options)
{
    DWORD saved_flags;
    BYTE *buf,final_access;

    if(!gdt_dynamic_range_valid(which,8U))
    {
        dprintk("SetCallGate: invalid GDT offset 0x%x.\n",which);
        return;
    }

    /* A system/call gate is published with P clear until every other byte is
     * valid.  Preserve the caller's requested type/DPL bits. */
    final_access=(BYTE)(access|0x80U);
    saved_flags=get_eflags();
    disable();
    buf=(BYTE *)gdt_table+which;
    buf[5]=(BYTE)(final_access&~0x80U);
    buf[0]=(BYTE)(offset&0xffU);
    buf[1]=(BYTE)((offset>>8)&0xffU);
    buf[2]=(BYTE)(selector&0xffU);
    buf[3]=(BYTE)((selector>>8)&0xffU);
    buf[4]=options;
    buf[6]=(BYTE)((offset>>16)&0xffU);
    buf[7]=(BYTE)((offset>>24)&0xffU);
    gdt_compiler_barrier();
    buf[5]=final_access;
    set_eflags(saved_flags);
}

void SetCDEntry(DWORD which,DWORD offset,DWORD limit,int prilev)
{
    /* Access bytes 0x9A/0x92 are execute/read and data read/write.  DB=1;
     * SetCDEntryEx selects byte/page granularity from the requested limit. */
    SetCDEntryEx(which,offset,limit,0x9A,0x40,prilev);
    SetCDEntryEx(which+8U,offset,limit,0x92,0x40,prilev);
}

void SetCDEntryEx(DWORD which,DWORD offset,DWORD limit,
                  BYTE access_byte,BYTE gran_flags,int prilev)
{
    DWORD saved_flags,encoded_limit;
    BYTE *buf,final_access,limit_flags;

    if(prilev<0 || prilev>3 || !gdt_dynamic_range_valid(which,8U))
    {
        dprintk("SetCDEntryEx: invalid descriptor offset/DPL (0x%x,%d).\n",
                which,prilev);
        return;
    }

    /* IA-32 has a 20-bit limit.  For limits above 1 MiB use page granularity.
     * If the requested limit is not page-end aligned, round DOWN so the
     * descriptor never grants bytes beyond the caller's requested range. */
    limit_flags=(BYTE)(gran_flags&0x70U); /* AVL/L/DB, G decided below. */
    if(limit>0x000fffffUL)
    {
        encoded_limit=limit>>12;
        if((limit&0x0fffU)!=0x0fffU && encoded_limit) encoded_limit--;
        if(encoded_limit>0x000fffffUL) encoded_limit=0x000fffffUL;
        limit_flags|=0x80U;
    }
    else
        encoded_limit=limit;

    final_access=(BYTE)((access_byte&0x9fU)|((prilev&3)<<5)|0x80U);
    limit_flags=(BYTE)((limit_flags&0xf0U)|((encoded_limit>>16)&0x0fU));

    saved_flags=get_eflags();
    disable();
    buf=(BYTE *)gdt_table+which;

    /* Present-last publication, matching the V70.66 IDT rule. */
    buf[5]=(BYTE)(final_access&~0x80U);
    buf[0]=(BYTE)(encoded_limit&0xffU);
    buf[1]=(BYTE)((encoded_limit>>8)&0xffU);
    buf[2]=(BYTE)(offset&0xffU);
    buf[3]=(BYTE)((offset>>8)&0xffU);
    buf[4]=(BYTE)((offset>>16)&0xffU);
    buf[6]=limit_flags;
    buf[7]=(BYTE)((offset>>24)&0xffU);
    gdt_compiler_barrier();
    buf[5]=final_access;
    set_eflags(saved_flags);
}
