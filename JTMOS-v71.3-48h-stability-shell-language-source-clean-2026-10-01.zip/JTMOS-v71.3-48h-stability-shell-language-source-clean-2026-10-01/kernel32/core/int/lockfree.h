#ifndef JTMOS_LOCKFREE_H
#define JTMOS_LOCKFREE_H

#include "basdef.h"

/* Wait-free SPSC pointer ring. Capacity must be a power of two >= 2. */
typedef struct lf_spsc_queue
{
    void **slots;
    DWORD capacity;
    DWORD mask;
    volatile DWORD head;
    volatile DWORD tail;
} LF_SPSC_QUEUE;

int lf_spsc_init(LF_SPSC_QUEUE *q,void **storage,DWORD capacity);
int lf_spsc_push(LF_SPSC_QUEUE *q,void *value);
int lf_spsc_pop(LF_SPSC_QUEUE *q,void **value);
DWORD lf_spsc_count(const LF_SPSC_QUEUE *q);

/*
 * Intrusive MPSC queue. Any number of producers may push concurrently; exactly
 * one consumer may pop. A node may be reclaimed/reused after it is returned by
 * lf_mpsc_pop(). The permanent stub lives inside the queue.
 */
typedef struct lf_mpsc_node
{
    struct lf_mpsc_node * volatile next;
} LF_MPSC_NODE;

typedef struct lf_mpsc_queue
{
    LF_MPSC_NODE * volatile head;
    LF_MPSC_NODE *tail;
    LF_MPSC_NODE stub;
} LF_MPSC_QUEUE;

void lf_mpsc_init(LF_MPSC_QUEUE *q);
void lf_mpsc_push(LF_MPSC_QUEUE *q,LF_MPSC_NODE *node);
LF_MPSC_NODE *lf_mpsc_pop(LF_MPSC_QUEUE *q);
int lf_mpsc_empty(const LF_MPSC_QUEUE *q);

#endif
