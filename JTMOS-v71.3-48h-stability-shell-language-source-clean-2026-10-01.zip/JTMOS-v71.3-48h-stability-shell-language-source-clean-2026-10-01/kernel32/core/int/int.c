//--------------------------------------------------------------------------
/*
 * System Interrupt Handling Code / Highlevel Section
 *
 * int.c
 *
 * (C) 2001-2007 by Jari Tuominen(jari@vunet.org).
 *
 * This code is really nasty stuff,
 * I wonder why this crap always
 * crashes my computer... Well, I hope
 * I make it work atleast somehow
 * properly sooner or later.
 *
 * (Update: it works pretty well now, but still got somethings to work!)
 */
//--------------------------------------------------------------------------
//
// NOTE: assembly language based low level code that
// this C-language based code is dependent on,
// is located at llint.asm -assembly language file.
// (coding standard is NASM)

//
#define IRQDEBUGGER

//
#include "kernel32.h" // FATALEXCEPTION
#include "term.h"
#include "int.h"
#include "cpu.h"
#include "sysglvar.h"
#include "delay.h"
#include "threads.h"
#include "llexception.h"
#include "apic.h"

//--------------------------------------------------------------------------
// GDT table will be allocated in 0x100000 memory region.
GDTTAB *gdt_table = NULL;
TASKS *tasks = NULL;
WORD irq_mask = 0xFFFF; // All IRQs disabled initially.

/* GDT layout is an architectural ABI: selectors are byte offsets into this
 * exact structure.  Fail the build if a future field/layout edit silently
 * moves the TSS or dynamic descriptor regions. */
typedef char gdt_cdseg_must_be_8_bytes[(sizeof(CDSEG)==8) ? 1 : -1];
typedef char gdt_tss_offset_must_match_selector[
    (__builtin_offsetof(GDTTAB,tssdes)==TSSSEL_OFFS) ? 1 : -1];
typedef char gdt_dynamic_offset_must_match_selector[
    (__builtin_offsetof(GDTTAB,dynamic_cd)==APPSEL_OFFS) ? 1 : -1];
typedef char gdt_must_fit_16bit_limit[(sizeof(GDTTAB)<=0x10000UL) ? 1 : -1];
typedef char gdt_dynamic_region_must_pair[
    ((GDT_DYNAMIC_DESCRIPTOR_COUNT & 1U)==0U) ? 1 : -1];
static volatile DWORD pic_spurious_irq7 = 0;
static volatile DWORD pic_spurious_irq15 = 0;

/* V70.66: every legacy IRQ vector has a controller-neutral kernel-owned
 * fallback stub.  The same stubs are used by the userspace IRQ broker: when
 * no subscriber exists they simply acknowledge the interrupt.  This prevents
 * an unexpected/unclaimed IRQ from leaving the 8259 or LAPIC in-service bit
 * stuck forever. */
extern void userirq_stub0(void); extern void userirq_stub1(void);
extern void userirq_stub2(void); extern void userirq_stub3(void);
extern void userirq_stub4(void); extern void userirq_stub5(void);
extern void userirq_stub6(void); extern void userirq_stub7(void);
extern void userirq_stub8(void); extern void userirq_stub9(void);
extern void userirq_stub10(void); extern void userirq_stub11(void);
extern void userirq_stub12(void); extern void userirq_stub13(void);
extern void userirq_stub14(void); extern void userirq_stub15(void);

static void *const irq_default_stubs[16] = {
    userirq_stub0,userirq_stub1,userirq_stub2,userirq_stub3,
    userirq_stub4,userirq_stub5,userirq_stub6,userirq_stub7,
    userirq_stub8,userirq_stub9,userirq_stub10,userirq_stub11,
    userirq_stub12,userirq_stub13,userirq_stub14,userirq_stub15
};

static int irq_vector(unsigned short irq)
{
    if(irq >= 16U) return -1;
    if(irq < 8U) return M_VEC + (int)irq;
    return S_VEC + ((int)irq - 8);
}

void irq_install_default_gate(unsigned short irq)
{
    int vector=irq_vector(irq);
    if(vector < 0) return;
    setint(vector,irq_default_stubs[irq],SEG_CODE32,D_PRESENT + D_INT);
}

int irq_gate_is_default(unsigned short irq)
{
    int vector=irq_vector(irq);
    if(vector < 0) return 0;
    return getint(vector)==irq_default_stubs[irq];
}

static void idt_install_default_irq_gates(void)
{
    unsigned short irq;
    for(irq=0; irq<16U; ++irq) irq_install_default_gate(irq);
}

//--------------------------------------------------------------------------
// Give out pointer to the new IDT table.
// The old one is the one which the boot loader setupped.
void *GetIDTPTR(void)
{
	//
	return (void *)JTMOS_KERNEL_IDT_BASE;
	//	return OFFSET_TO_IDT_TABLE;
}

//
void init_gdt(void)
{
	WORD *gdtr;
	DWORD loaded_base;
	WORD loaded_limit;

	gdt_table = malloc(sizeof(GDTTAB));
	if(gdt_table==NULL)
		KERNEL_FATAL("init_gdt: cannot allocate GDT table");
	memset(gdt_table, 0, sizeof(GDTTAB));

	/* Selector 0 is architecturally the null selector.  Leave descriptor zero
	 * completely empty; the historical code descriptor at index zero defeated
	 * useful corruption diagnostics and violated the conventional GDT contract. */

	/* Flat Ring0 kernel descriptors. */
	set_cdseg(&gdt_table->code32, 0xFFFF,0,0,0x9A,0xCF,0);
	set_cdseg(&gdt_table->data32, 0xFFFF,0,0,0x92,0xCF,0);
	set_cdseg(&gdt_table->core32, 0xFFFF,0,0,0x92,0xCF,0);
	set_cdseg(&gdt_table->code16, 0xFFFF,0,0,0x9A,0,0);
	set_cdseg(&gdt_table->data16, 0xFFFF,0,0,0x92,0,0);

	/* V67 flat userspace descriptors.  Base=0 and 4 GiB limit; paging gives
	 * each PID its private 0x80000000..0x80ffffff address space.  These shared
	 * descriptors are immutable after LGDT; per-process isolation is paging. */
	set_cdseg(&gdt_table->appcode32, 0xFFFF,0,0,0xFA,0xCF,0);
	set_cdseg(&gdt_table->appdata32, 0xFFFF,0,0,0xF2,0xCF,0);

	/* V70.67: publish the real allocated table length, not 0xFFFF.  A 64 KiB
	 * GDTR limit over a ~6 KiB malloc buffer lets malformed/corrupt selectors
	 * make the CPU fetch descriptors from unrelated heap memory. */
	SETUPGDT(JTM_PTR_TO_DWORD(gdt_table), (WORD)(sizeof(GDTTAB)-1U));

	/* Verify the assembly-side LGDT contract immediately while boot is still
	 * single-threaded.  GETGDTOFFS returns the six-byte SGDT image. */
	gdtr=JTM_DWORD_TO_PTR(WORD,GETGDTOFFS());
	loaded_limit=gdtr[0];
	loaded_base=(DWORD)gdtr[1] | ((DWORD)gdtr[2]<<16);
	if(loaded_limit!=(WORD)(sizeof(GDTTAB)-1U) ||
	   loaded_base!=JTM_PTR_TO_DWORD(gdt_table))
		KERNEL_FATAL("init_gdt: LGDT base/limit verification failed");

	if(gdt_table->dummy.seg0_15 || gdt_table->dummy.base0_15 ||
	   gdt_table->dummy.base16_23 || gdt_table->dummy.flags ||
	   gdt_table->dummy.access || gdt_table->dummy.base24_31)
		KERNEL_FATAL("init_gdt: selector 0 is not a null descriptor");
}

void dump_gdt_info(void)
{
	//
	print("(0x00)  dummy   = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->dummy)); 	 print("(* dummy)\n");
	print("(0x08)  code32  = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->code32));  print("\n");
	print("(0x10)  data32  = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->data32));  print("\n");
	print("(0x18)  core32  = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->core32));  print("\n");
	print("(0x20)  code16  = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->code16));	 print("\n");
	print("(0x28)  data16  = 0x"); p32(JTM_PTR_TO_DWORD(&gdt_table->data16));	 print("\n");
}

/* Build the new IDT completely while the currently-loaded IDT is still live.
 * V70.66 removes the historical activation window where vectors 0..16 briefly
 * pointed at nullinterrupt2.  Error-code exceptions (#DF/#TS/#NP/#SS/#GP/#PF)
 * cannot safely return through a no-error-code stub, so the table is not
 * published with LIDT until its real exception gates are already present. */
/* Once the early safe IDT is live, runtime setup must not blank the active
 * table back to placeholder gates.  It upgrades the already-valid table
 * vector by vector instead. */
static int idt_table_initialized = 0;

static void idt_build_default_table(void)
{
    int i;
    DWORD ad,base;
    WORD *p;

    p=(WORD *)GetIDTPTR();
    base=JTM_PTR_TO_DWORD(GetIDTPTR())+6U;
    p[0]=(256U*8U)-1U;
    p[1]=(WORD)(base&0xffffU);
    p[2]=(WORD)((base>>16)&0xffffU);
    p+=3;

    ad=JTM_PTR_TO_DWORD((void *)nullinterrupt);
    for(i=0;i<256;i++)
    {
        p[i*4+0]=(WORD)(ad&0xffffU);
        p[i*4+1]=SEG_CODE32;
        p[i*4+2]=D_PRESENT + D_INT; /* DPL0 */
        p[i*4+3]=(WORD)((ad>>16)&0xffffU);
    }
    idt_table_initialized = 1;
}

static WORD idt_gate_access(unsigned vector)
{
    WORD *p=(WORD *)GetIDTPTR();
    if(vector>=256U) return 0;
    p+=3;
    return p[vector*4U+2U];
}

static int idt_validate_preload(int runtime)
{
    unsigned i;
    WORD access;

    for(i=0;i<32U;i++)
    {
        access=idt_gate_access(i);
        if(!(access&D_PRESENT) || getint((long)i)==NULL) return -1;
        if(runtime && (i==3U || i==4U))
        {
            if((access&D_DPL3)!=D_DPL3) return -2;
        }
        else if(access&D_DPL3)
            return -3;
    }
    for(i=0;i<16U;i++)
    {
        access=idt_gate_access((unsigned)irq_vector((unsigned short)i));
        if(!(access&D_PRESENT) || (access&D_DPL3) || !irq_gate_is_default((unsigned short)i))
            return -4;
    }
    return 0;
}

static void idt_activate_prepared(void)
{
    setupidt(JTM_PTR_TO_DWORD(GetIDTPTR()));
}

/* Legacy entry point: publish a self-contained safe IDT, never an incomplete
 * placeholder table. */
void int_redirectidt(void)
{
    disable();
    idt_build_default_table();
    setup_llexception_handlers();
    idt_install_default_irq_gates();
    if(idt_validate_preload(0)!=0)
        KERNEL_FATAL("int_redirectidt: safe IDT validation failed");
    idt_activate_prepared();
    /* Preserve the historical boot contract: IDT installation returns with IF=0. */
}

// Creates clean/default IDT and exception handlers.
void init_idt(void)
{
    disable();
    /* Normally int_redirectidt()/init_safe_idt() has already published a
     * complete safe table.  Preserve that live fallback while replacing the
     * runtime gates; only synthesize a table here for direct-init test paths. */
    if(!idt_table_initialized)
        idt_build_default_table();
    setup_exception_handlers();
    idt_install_default_irq_gates();
    if(idt_validate_preload(1)!=0)
        KERNEL_FATAL("init_idt: IDT validation failed");
    idt_activate_prepared();
    /* IRQ delivery remains disabled until the normal boot path enables it. */
}

// Creates safe IDT and exception handlers.
void init_safe_idt(void)
{
    disable();
    idt_build_default_table();
    setup_llexception_handlers();
    idt_install_default_irq_gates();
    if(idt_validate_preload(0)!=0)
        KERNEL_FATAL("init_safe_idt: IDT validation failed");
    idt_activate_prepared();
    /* IRQ delivery remains disabled until the normal boot path enables it. */

    /* IDT setup must not alter video state. */
    if(vga_debug_palette_effects)
    {
        outportb(0x3c8,0);
        outportb(0x3c9,0x3F);
        outportb(0x3c9,0x1F);
        outportb(0x3c9,0x0F);
    }
    else
        dprintk("init_safe_idt: VGA DAC palette side effects disabled\n");
}

/*
 * setint
 * ------
 * This routine setups interrupt handlers.
 *
 * word handler_offs0_15
 * word segment_selector
 * word access
 * word handler_offs16_31
 */
void setint( int intnum,
        void *handler,
        unsigned short int _segment,
        unsigned short int _access)
{
    WORD *p;
    DWORD ad,l,h,flags;
    unsigned idx;

    if(intnum < 0 || intnum >= 256)
    {
        printk("setint: refusing invalid vector %d.\n", intnum);
        return;
    }

    flags=get_eflags();
    disable();
    p=(WORD *)GetIDTPTR();
    p+=3;
    idx=(unsigned)intnum*4U;
    ad=JTM_PTR_TO_DWORD(handler);
    l=ad&0xffffU;
    h=(ad>>16)&0xffffU;

    /* Publish the descriptor present-bit last.  On this uniprocessor kernel
     * CLI excludes maskable IRQ readers while the four 16-bit fields change;
     * clearing P first also makes accidental software use fail closed instead
     * of jumping through a half-written offset.  Vector 2 is normally written
     * before NMI enable (or rewritten to the same fallback address). */
    p[idx+2]=(WORD)(_access & (WORD)~D_PRESENT);
    asm volatile("" ::: "memory");
    p[idx+0]=(WORD)l;
    p[idx+1]=_segment;
    p[idx+3]=(WORD)h;
    asm volatile("" ::: "memory");
    p[idx+2]=_access;
    asm volatile("" ::: "memory");
    set_eflags(flags);
}

//
void *getint(long intnum)
{
	WORD *p;
	DWORD ad,l,h;

	if(intnum < 0 || intnum >= 256)
		return NULL;

	/* GetIDTPTR() points to the six-byte pseudo descriptor; gates begin
	 * immediately after it.  The old implementation accidentally read the
	 * IVT/null page at linear address zero, making handler ownership tests
	 * unusable in protected mode. */
	p=(WORD *)GetIDTPTR();
	p+=3;
	l=p[(intnum<<2)+0];
	h=((DWORD)p[(intnum<<2)+3])<<16;
	ad=l|h;
	return (void *)ad;
}

//
static void pic_io_wait(void)
{
    /* Port 0x80 is the traditional ISA POST delay.  The read has no device
     * side effect in JTMOS and gives old southbridges/MCP61 time between ICWs. */
    (void)inportb(0x80);
}

void Init8259(void)
{
    DWORD flags=get_eflags();

    /* Reprogramming a live 8259 while IF=1 can deliver an IRQ using a mixture
     * of the old/new vector bases.  Keep the full ICW sequence atomic. */
    disable();
    outportb(M_PIC, ICW1); pic_io_wait();
    outportb(S_PIC, ICW1); pic_io_wait();

    outportb(M_PIC+1, M_VEC); pic_io_wait();
    outportb(S_PIC+1, S_VEC); pic_io_wait();

    outportb(M_PIC+1, 1<<2); pic_io_wait();
    outportb(S_PIC+1, 2); pic_io_wait();

    outportb(M_PIC+1, ICW4); pic_io_wait();
    outportb(S_PIC+1, ICW4); pic_io_wait();

    irq_mask = 0xFFFFU;
    outportb(M_IMR, 0xFF); pic_io_wait();
    outportb(S_IMR, 0xFF); pic_io_wait();

    outportb(M_PIC, OCW3_IRR);
    outportb(S_PIC, OCW3_IRR);
    set_eflags(flags);
}

/* Read one of the cascaded 8259A status registers selected by OCW3.
 * The operation is atomic with respect to interrupt handlers because OCW3 is
 * sticky: an interrupt-time status read must not change which register a
 * concurrent diagnostic read receives. */
static WORD pic_read_reg(BYTE ocw3)
{
	DWORD flags;
	WORD value;

	flags = get_eflags();
	disable();
	outportb(M_PIC, ocw3);
	outportb(S_PIC, ocw3);
	value = (WORD)inportb(M_PIC);
	value |= (WORD)((WORD)inportb(S_PIC) << 8);
	set_eflags(flags);
	return value;
}

WORD pic_read_irr(void)
{
	/* Historical name retained for ABI compatibility: in APIC mode return the
	 * LAPIC IRR bits corresponding to JTMOS legacy IRQ vectors 0x68..0x77. */
	if(apic_active()) return apic_legacy_irr();
	return pic_read_reg(OCW3_IRR);
}

WORD pic_read_isr(void)
{
	if(apic_active()) return apic_legacy_isr();
	return pic_read_reg(OCW3_ISR);
}

WORD pic_get_mask(void)
{
	DWORD flags;
	WORD value;
	flags = get_eflags();
	disable();
	value = irq_mask;
	set_eflags(flags);
	return value;
}

int pic_irq_pending(unsigned short irq_no)
{
	if(irq_no >= 16) return 0;
	if(apic_active()) return apic_irq_pending(irq_no);
	return (pic_read_irr() & (WORD)(1U << irq_no)) ? 1 : 0;
}

int pic_irq_in_service(unsigned short irq_no)
{
	if(irq_no >= 16) return 0;
	if(apic_active()) return apic_irq_in_service(irq_no);
	return (pic_read_isr() & (WORD)(1U << irq_no)) ? 1 : 0;
}

DWORD pic_get_spurious_count(unsigned short irq_no)
{
	if(irq_no == 7) return pic_spurious_irq7;
	if(irq_no == 15) return pic_spurious_irq15;
	return 0;
}

/* enables irq irq_no */
void enable_irq(unsigned short irq_no)
{
	DWORD flags;

	if(irq_no >= 16)
	{
		dprintk("enable_irq: invalid IRQ %u rejected.\n", (unsigned)irq_no);
		return;
	}

	/* irq_mask plus the two 8259 IMRs are one logical update. */
	flags = get_eflags();
	disable();
	if(apic_active())
	{
		if(apic_set_legacy_irq_mask(irq_no,0)!=0)
		{
			dprintk("enable_irq: APIC has no route for IRQ %u.\n",(unsigned)irq_no);
			set_eflags(flags);
			return;
		}
		irq_mask &= (WORD)~(1U << irq_no);
		set_eflags(flags);
		return;
	}
	irq_mask &= (WORD)~(1U << irq_no);
	if(irq_no >= 8)
		irq_mask &= (WORD)~(1U << 2);
	outportb(M_PIC+1, irq_mask & 0xFF);
	outportb(S_PIC+1, (irq_mask >> 8) & 0xFF);
	set_eflags(flags);
}

/* disables irq irq_no */
void disable_irq(unsigned short irq_no)
{
	DWORD flags;

	if(irq_no >= 16)
	{
		dprintk("disable_irq: invalid IRQ %u rejected.\n", (unsigned)irq_no);
		return;
	}

	flags = get_eflags();
	disable();
	if(apic_active())
	{
		if(apic_set_legacy_irq_mask(irq_no,1)!=0)
		{
			dprintk("disable_irq: APIC has no route for IRQ %u.\n",(unsigned)irq_no);
			set_eflags(flags);
			return;
		}
		irq_mask |= (WORD)(1U << irq_no);
		set_eflags(flags);
		return;
	}
	irq_mask |= (WORD)(1U << irq_no);
	if((irq_mask & 0xFF00)==0xFF00)
		irq_mask |= (WORD)(1U << 2);
	outportb(M_PIC+1, irq_mask & 0xFF);
	outportb(S_PIC+1, (irq_mask >> 8) & 0xFF);
	set_eflags(flags);
}

void pic_send_eoi(unsigned short irq_no)
{
	WORD isr;

	if(irq_no >= 16)
		return;
	if(apic_active())
	{
		apic_send_eoi();
		return;
	}

	/* 8259A can synthesize IRQ7/IRQ15 when the request vanishes between INTR
	 * and INTA.  A spurious IRQ7 has no ISR bit and must receive no EOI.  For
	 * spurious IRQ15 the slave receives no EOI, but the master cascade IRQ2
	 * was real and must still be acknowledged. */
	if(irq_no == 7)
	{
		isr = pic_read_isr();
		if(!(isr & (1U << 7)))
		{
			pic_spurious_irq7++;
			return;
		}
	}
	else if(irq_no == 15)
	{
		isr = pic_read_isr();
		if(!(isr & (1U << 15)))
		{
			pic_spurious_irq15++;
			outportb(M_PIC, EOI);
			return;
		}
	}

	if(irq_no >= 8)
		outportb(S_PIC, EOI);
	outportb(M_PIC, EOI);
}

// Dumps critical information.
// (GDT/IDT tables)
void dump_critical(void)
{
	WORD *gdt,*gdtt, *idt,*idtt;
	int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	//
	gdt=JTM_DWORD_TO_PTR(WORD,GETGDTOFFS());
	idt=JTM_DWORD_TO_PTR(WORD,GETIDTOFFS());

	//
	print("> Doing IDT & GDT dump\n");

	// --- DUMP OF IDT ---
	// beginning
	print("Using IDT, which resides at the memory location 0x");
	p32(JTM_PTR_TO_DWORD(idt)); print("\n");
	//
	print("IDT size =   0x");
	p16( idt[0] );
	print("\n");
	//
	print("IDT table's offset = 0x");
	p32( (idt[1]+(idt[2]<<16)) );
	print("\n");

	//
	idtt=JTM_DWORD_TO_PTR(WORD,(DWORD)idt[1]+((DWORD)idt[2]<<16));

	//
	print("Now dumping IDT table's contents :\n");

	//
	for(i=0; i<8; i++)
	{
		//
		p32( ((unsigned long int) (idtt))+(i*8) ); print("> ");
		// PRINT INTERRUPT #
		print("IDT entry #"); printhex8(&screens[0],i); print(": ");
		// PRINT OFFSET
		print("handler=0x");
		printhex32( &screens[0], idtt[0+i*4]+(idtt[3+i*4]<<16) );
		// PRINT SEGMENT
		print(", segment=0x"); printhex16( &screens[0], idtt[1+i*4] );
		// PRINT ACCESS
		print(", access=0x"); printhex16( &screens[0], idtt[2+i*4] );
		// new line !
		print("\n");
	}
	print("End of IDT dump.\n");
	/* Do not call waitpesc(): it polls shared i8042 port 0x60 directly. */

	//
	gdtt=(unsigned short int*)gdt_table;

	// --- DUMP OF GDT ---
	// beginning
	print("Using GDT, which resides at the memory location 0x");
	p32(JTM_PTR_TO_DWORD(gdt)); print("\n");
	//
	print("GDT size =   0x");
	p16( gdt[0]);
	print("\n");
	//
	print("GDT table's offset = 0x");
	p32( (unsigned long int)gdtt );
	print("\n");

	//
	print("Now dumping GDT table's contents :\n");

	// print # entries out of GDT table (gdtt)
	for(i=0; i<8; i++)
	{
		//
		p32( ((unsigned long int) (gdtt))+(i*8) ); print("> ");
		// PRINT GDT ENTRY #
		print("GDT entry #"); p8(i); print(": ");
  
		// PRINT SEGMENT
		print("length=0x"); p16(gdtt[i*4+0]); print(", ");
  
		// PRINT BASE(32bit, 24bit used) .. consists of one word, and two bytes.
		print("base=0x"); p16( gdtt[i*4+1] + ((gdtt[i*4+3]&0xff) << 16) + \
	                              ((gdtt[i*4+2]>>8) << 24) ); print(", ");
                              
		// PRINT FLAGS(8bit)
		print("flags=0x"); p8( gdtt[i*4+1]>>8 ); print(", ");
  
		// PRINT ACCESS
		print("access=0x"); p8( gdtt[i*4+3]&0xff );
  
		// Fin./Next
		print("\n");
	}
	print("End of GDT dump.\n");
	/* Do not call waitpesc(): it polls shared i8042 port 0x60 directly. */
}

//
void irqdebugger(void)
{
#ifdef IRQDEBUGGER
	DWORD saved_flags;
	//
	saved_flags = get_eflags();
	disable();

	//
	if( GetThreadBase(GetCurrentThread()) )
	{
		//
		printk("\n[Caught Application Thread Switch]\n");
		printk("PID %d/%d(%s), DS=%x ES=%x FS=%x GS=%x SS=%x, tick=%d, state=%d\n",
				GetCurrentThread(),nr_threads,
				thread_name[GetCurrentThread()],
			        thread_ds[GetCurrentThread()],
			        thread_es[GetCurrentThread()],
			        thread_fs[GetCurrentThread()],
			        thread_gs[GetCurrentThread()],
			        thread_ss[GetCurrentThread()],
				thread_tick[GetCurrentThread()],
				thread_states[GetCurrentThread()]
			);

		//
		printk("CODE SEG DESCRIPTOR: %x %x %x %x  %x %x %x %x\n",
			thread_codedescs[GetCurrentThread()*8+0],
			thread_codedescs[GetCurrentThread()*8+1],
			thread_codedescs[GetCurrentThread()*8+2],
			thread_codedescs[GetCurrentThread()*8+3],
			thread_codedescs[GetCurrentThread()*8+4],
			thread_codedescs[GetCurrentThread()*8+5],
			thread_codedescs[GetCurrentThread()*8+6],
 			thread_codedescs[GetCurrentThread()*8+7]);
		//
		printk("DATA SEG DESCRIPTOR: %x %x %x %x  %x %x %x %x\n",
			thread_datadescs[GetCurrentThread()*8+0],
			thread_datadescs[GetCurrentThread()*8+1],
			thread_datadescs[GetCurrentThread()*8+2],
			thread_datadescs[GetCurrentThread()*8+3],
			thread_datadescs[GetCurrentThread()*8+4],
			thread_datadescs[GetCurrentThread()*8+5],
			thread_datadescs[GetCurrentThread()*8+6],
			thread_datadescs[GetCurrentThread()*8+7]);

		//	
		//showappgdt();

		//
		printk("Execution freezed - Press [ESC] to unfreeze\n");

		//
		ESCLOCK();
	}

	//
	set_eflags(saved_flags);

	//
	return;
#endif
}

//
void set_cdseg(CDSEG *t,
	 	WORD	seg0_15,
 		WORD	base0_15,
		BYTE	base16_23,
		BYTE	flags,
		BYTE	access,
		BYTE	base24_31)
{
	//
	t->seg0_15=	seg0_15;
	t->base0_15=	base0_15;
	t->base16_23=	base16_23;
	t->flags=	flags;
	t->access=	access;
	t->base24_31=	base24_31;
}

//
