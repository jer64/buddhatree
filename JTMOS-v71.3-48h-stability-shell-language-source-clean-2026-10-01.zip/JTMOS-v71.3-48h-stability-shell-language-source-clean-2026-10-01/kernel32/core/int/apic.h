#ifndef JTMOS_APIC_H
#define JTMOS_APIC_H

#include "basdef.h"

#define JTMOS_APIC_MAX_IOAPICS 8
#define JTMOS_APIC_LEGACY_IRQS 16

typedef struct JTMOS_APIC_INFO {
    int active;
    int madt_found;
    int ioapic_count;
    DWORD madt_phys;
    DWORD lapic_phys;
    BYTE lapic_id;
    BYTE lapic_version;
    WORD reserved;
    DWORD legacy_gsi[JTMOS_APIC_LEGACY_IRQS];
    WORD legacy_flags[JTMOS_APIC_LEGACY_IRQS];
    DWORD ioapic_phys[JTMOS_APIC_MAX_IOAPICS];
    DWORD ioapic_gsi_base[JTMOS_APIC_MAX_IOAPICS];
    DWORD ioapic_redir_count[JTMOS_APIC_MAX_IOAPICS];
} JTMOS_APIC_INFO;

/* Initialize xAPIC + I/O APIC routing.  The 8259 must already be initialized
 * and fully masked, and the normal IDT must already be installed.  Returns 1
 * when APIC mode owns external IRQ delivery, zero when JTMOS must keep using
 * the legacy 8259 path. */
int InitAPIC(void);
int apic_active(void);
int apic_set_nmi_enabled(int enabled);
int apic_nmi_enabled(void);
const char *apic_status(void);
int apic_platform_quirk_active(void);
const char *apic_platform_quirk_name(void);

/* V70 rapid LAPIC scheduler timer.  PIT remains the wall-clock/timekeeping
 * source; when xAPIC is active the local APIC can provide a higher-rate
 * preemption clock without changing GetTickCount() semantics. */
int apic_start_rapid_scheduler(DWORD target_hz);
void apic_stop_rapid_scheduler(void);
int apic_rapid_scheduler_active(void);
DWORD apic_rapid_scheduler_hz(void);

/* Legacy ISA IRQ compatibility layer used by int.c.  Existing JTMOS drivers
 * keep IRQ numbers 0..15 while ACPI MADT maps those IRQs to GSIs. */
int apic_set_legacy_irq_mask(unsigned short irq, int masked);
void apic_send_eoi(void);
int apic_irq_pending(unsigned short irq);
int apic_irq_in_service(unsigned short irq);
WORD apic_legacy_irr(void);
WORD apic_legacy_isr(void);
int apic_get_legacy_redir(unsigned short irq,DWORD *low,DWORD *high);

int apic_get_info(JTMOS_APIC_INFO *out);

#endif
