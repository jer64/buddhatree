/*
 * V69.18 autonomous x86 NMI watchdog sources.
 *
 * Intel SDM rules matter here: an NMI is independent of EFLAGS.IF, and a
 * performance-monitoring interrupt delivered through LVTPC automatically
 * masks the LVTPC entry.  The handler MUST explicitly clear that mask before
 * another PMI can arrive.  V69.17 missed the latter rule and therefore got at
 * most one Intel PMU NMI.
 *
 * Sources, in priority order:
 *   - QEMU/KVM IB700 external watchdog -> QEMU inject-nmi (hard stall proof);
 *   - Intel architectural PMU -> LAPIC LVTPC delivery=NMI;
 *   - Intel P6/i686 legacy 40-bit PMC0 -> LVTPC NMI;
 *   - AMD Family 10h legacy PMC0 -> LVTPC NMI.
 *
 * Conservative policy: never steal an active LVTPC or PMU. Original register
 * state is retained for shutdown/rollback.
 */
#include "kernel32.h"
#include "cpu.h"
#include "paging.h"
#include "nmi_source.h"
#include "cmos.h"
#include "threads.h"

#define MSR_IA32_APIC_BASE          0x0000001bUL
#define APIC_BASE_ENABLE            0x00000800UL
#define APIC_BASE_X2APIC            0x00000400UL
#define LAPIC_VERSION               0x030U
#define LAPIC_SVR                   0x0f0U
#define LAPIC_LVTPC                 0x340U
#define LAPIC_SVR_ENABLE            0x00000100UL
#define LAPIC_LVT_MASKED            0x00010000UL
#define LAPIC_LVT_NMI               0x00000400UL

#define MSR_IA32_PMC0               0x000000c1UL
#define MSR_IA32_PERFEVTSEL0        0x00000186UL
#define MSR_IA32_PERF_GLOBAL_STATUS 0x0000038eUL
#define MSR_IA32_PERF_GLOBAL_CTRL   0x0000038fUL
#define MSR_IA32_PERF_GLOBAL_OVF    0x00000390UL
#define INTEL_EVT_UNHALTED_CYCLES   0x0053003cUL /* USR|OS|INT|EN + architectural event 3c */
#define INTEL_P6_EVT_UNHALTED_CYCLES 0x00530079UL /* USR|OS|INT|EN + P6 event 79h */

#define MSR_AMD_PERFEVTSEL0         0xc0010000UL
#define MSR_AMD_PMC0                0xc0010004UL
#define AMD_EVT_CPU_CLOCKS          0x00530076UL /* USR|OS|INT|EN + event 76 */

#define NMI_SRC_NONE       0
#define NMI_SRC_INTEL_ARCH 1
#define NMI_SRC_AMD10      2
#define NMI_SRC_INTEL_P6   3
#define NMI_SRC_QEMU_IB700 4
#define NMI_SRC_INTEL_ARCH1 5

#define IB700_WDT_STOP      0x441U
#define IB700_WDT_START     0x443U
/* IB700 selector 0xD = 4 seconds (+/- hardware tolerance). */
#define IB700_WDT_4SEC      0x0dU

/* PC/AT port 70h bit 7 is the external NMI gate.  boot32/dosboot keep it
 * masked across the real/protected-mode transition.  A software INT 2 test
 * bypasses this gate, so source initialization must explicitly re-open it
 * only after vector 2 and the autonomous source are ready. */

static volatile int src_kind=NMI_SRC_NONE;
static volatile int src_active=0;
static volatile DWORD *lapic=NULL;
static DWORD lapic_map=0;
static DWORD saved_lvtpc=0;
static DWORD saved_evt_lo=0,saved_evt_hi=0;
static DWORD saved_pmc_lo=0,saved_pmc_hi=0;
static DWORD saved_global_lo=0,saved_global_hi=0;
static BYTE intel_width=0;
static const char *src_status="NMI source disabled";
/* IB700 is kicked for scheduler progress, not merely for a live PIT.  The
 * second flag records whether IRQ0 ran during the previous hardware interval:
 * an NMI caused by a CPU-bound process must not reopen IF in an IRQ handler. */
static volatile BYTE ib700_pit_seen=0;
static volatile BYTE ib700_expiry_pit_progress=0;

static void nmi_open_pc_gate(void)
{
    /* V69.38: share the single shadowed port-70h owner with the CMOS driver.
     * Never open-code the NMI mask bit here or an RTC access could later
     * restore the wrong gate state. */
    cmos_set_nmi_masked(0);
    __sync_synchronize();
}

static void nmi_cpuid(DWORD leaf,DWORD sub,DWORD *a,DWORD *b,DWORD *c,DWORD *d)
{
    DWORD ra,rb,rc,rd;
    __asm__ volatile("cpuid":"=a"(ra),"=b"(rb),"=c"(rc),"=d"(rd):"a"(leaf),"c"(sub):"memory");
    if(a) *a=ra;
    if(b) *b=rb;
    if(c) *c=rc;
    if(d) *d=rd;
}

static int nmi_is_qemu_hypervisor(void)
{
    DWORD a,b,c,d;
    char hv[13];
    if(!cpuHasFeature(JTMOS_CPUF_CPUID) || jtmos_cpu_info.max_basic_leaf<1U) return 0;
    nmi_cpuid(1,0,&a,&b,&c,&d);
    if(!(c&(1UL<<31))) return 0;
    nmi_cpuid(0x40000000UL,0,&a,&b,&c,&d);
    ((DWORD *)hv)[0]=b; ((DWORD *)hv)[1]=c; ((DWORD *)hv)[2]=d; hv[12]=0;
    /* TCG and KVM are the two QEMU execution modes used by the JTMOS runner. */
    if(!strncmp(hv,"TCGTCGTCG",9)) return 1;
    if(!strncmp(hv,"KVMKVMKVM",9)) return 1;
    return 0;
}

static void nmi_rdmsr(DWORD msr,DWORD *lo,DWORD *hi)
{
    DWORD a,d;
    __asm__ volatile("rdmsr":"=a"(a),"=d"(d):"c"(msr):"memory");
    if(lo) *lo=a;
    if(hi) *hi=d;
}

static void nmi_wrmsr(DWORD msr,DWORD lo,DWORD hi)
{
    __asm__ volatile("wrmsr"::"c"(msr),"a"(lo),"d"(hi):"memory");
}

static void nmi_counter_preload(BYTE width,DWORD *lo,DWORD *hi)
{
    DWORD hmask;
    /* Overflow every 2^28 counted cycles.  V69.38 never samples RTC from NMI;
     * the handler judges repeated PMU samples by scheduler/PIT progress. */
    *lo=0xf0000000UL;
    if(width<=32U) { *hi=0; return; }
    hmask=(1UL<<(width-32U))-1UL; /* width is capped at 48 */
    *hi=hmask;
}

static int nmi_map_lapic(void)
{
    DWORD lo,hi,phys,map;
    if(!cpuHasFeature(JTMOS_CPUF_CPUID)) { src_status="external NMI only: no CPUID"; return -1; }
    nmi_rdmsr(MSR_IA32_APIC_BASE,&lo,&hi);
    if(hi!=0U || !(lo&APIC_BASE_ENABLE)) { src_status="external NMI only: LAPIC disabled"; return -1; }
    if(lo&APIC_BASE_X2APIC) { src_status="external NMI only: x2APIC unsupported"; return -1; }
    phys=lo&0xfffff000UL;
    map=pg_mapio((int)(phys/4096UL),1);
    if(!map) { src_status="external NMI only: LAPIC map failed"; return -1; }
    lapic_map=map;
    lapic=(volatile DWORD *)map;
    if(!(lapic[LAPIC_SVR/4U]&LAPIC_SVR_ENABLE))
    {
        pg_unmapmemory(lapic_map,1); lapic_map=0; lapic=NULL;
        src_status="external NMI only: LAPIC software-disabled";
        return -1;
    }
    /* P6 introduced the performance-counter LVT.  Max-LVT < 4 means that
     * the 0x340 slot is not a usable performance-counter entry. */
    if(((lapic[LAPIC_VERSION/4U]>>16)&0xffU)<4U)
    {
        pg_unmapmemory(lapic_map,1); lapic_map=0; lapic=NULL;
        src_status="external NMI only: LAPIC has no LVTPC";
        return -1;
    }
    saved_lvtpc=lapic[LAPIC_LVTPC/4U];
    if(!(saved_lvtpc&LAPIC_LVT_MASKED))
    {
        pg_unmapmemory(lapic_map,1); lapic_map=0; lapic=NULL;
        src_status="external NMI only: LVTPC already in use";
        return -1;
    }
    /* Reserve the entry in a masked NMI state until the PMU is armed. */
    lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_MASKED|LAPIC_LVT_NMI;
    (void)lapic[LAPIC_LVTPC/4U]; /* flush/serialize posted MMIO write */
    return 0;
}

static void nmi_unmap_lapic(void)
{
    if(lapic && lapic_map)
    {
        lapic[LAPIC_LVTPC/4U]=saved_lvtpc;
        (void)lapic[LAPIC_LVTPC/4U];
        pg_unmapmemory(lapic_map,1);
    }
    lapic=NULL; lapic_map=0;
}

static int nmi_setup_intel(void)
{
    DWORD a,b,c,d,lo,hi;
    BYTE version,counters,width;
    if(jtmos_cpu_info.max_basic_leaf<0x0aU || strcmp(jtmos_cpu_info.vendor,"GenuineIntel")) return -1;
    nmi_cpuid(0x0aU,0,&a,&b,&c,&d);
    version=(BYTE)(a&0xffU); counters=(BYTE)((a>>8)&0xffU); width=(BYTE)((a>>16)&0xffU);
    if(version<2U || counters<1U || width<32U || width>48U || (b&1U)) return -1;
    intel_width=width;
    nmi_rdmsr(MSR_IA32_PERFEVTSEL0,&saved_evt_lo,&saved_evt_hi);
    if(saved_evt_lo&0x00400000UL) { src_status="external NMI only: Intel PMC0 already enabled"; return -1; }
    nmi_rdmsr(MSR_IA32_PMC0,&saved_pmc_lo,&saved_pmc_hi);
    nmi_rdmsr(MSR_IA32_PERF_GLOBAL_CTRL,&saved_global_lo,&saved_global_hi);
    nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,saved_global_lo&~1UL,saved_global_hi);
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
    nmi_wrmsr(MSR_IA32_PERF_GLOBAL_OVF,1U,0);
    nmi_counter_preload(width,&lo,&hi);
    nmi_wrmsr(MSR_IA32_PMC0,lo,hi);
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_EVT_UNHALTED_CYCLES,0);
    nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,saved_global_lo|1UL,saved_global_hi);
    return 0;
}

static int nmi_setup_intel_arch1(void)
{
    DWORD a,b,c,d,lo,hi;
    BYTE version,counters,width;

    /* Core Solo/Core Duo introduced architectural PMU version 1.  It has the
     * architectural IA32_PERFEVTSELx/PMC pair and APIC INT bit, but not the
     * version-2 GLOBAL_STATUS/GLOBAL_CTRL machinery.  Intel specifies that a
     * PMC write sign-extends bit 31 into the implemented high counter bits, so
     * writing 0xF0000000 still gives the desired -2^28 preload on a >32-bit
     * counter.  Ownership/ack is therefore proven by the LVTPC auto-mask bit. */
    if(jtmos_cpu_info.max_basic_leaf<0x0aU || strcmp(jtmos_cpu_info.vendor,"GenuineIntel")) return -1;
    nmi_cpuid(0x0aU,0,&a,&b,&c,&d);
    version=(BYTE)(a&0xffU); counters=(BYTE)((a>>8)&0xffU); width=(BYTE)((a>>16)&0xffU);
    if(version!=1U || counters<1U || width<32U || width>48U || (b&1U)) return -1;
    intel_width=width;
    nmi_rdmsr(MSR_IA32_PERFEVTSEL0,&saved_evt_lo,&saved_evt_hi);
    if(saved_evt_lo&0x00400000UL) { src_status="external NMI only: Intel arch-v1 PMC0 already enabled"; return -1; }
    nmi_rdmsr(MSR_IA32_PMC0,&saved_pmc_lo,&saved_pmc_hi);
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
    nmi_counter_preload(width,&lo,&hi);
    nmi_wrmsr(MSR_IA32_PMC0,lo,hi);
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_EVT_UNHALTED_CYCLES,0);
    return 0;
}

static int nmi_setup_intel_p6(void)
{
    DWORD lo,hi;
    /* P6 family (the i686 baseline: Pentium Pro/II/III and descendants before
     * architectural CPUID.0AH PMU enumeration) has two 40-bit counters at the
     * classic IA32_PMCx/PERFEVTSELx MSRs. Pentium 4/NetBurst is family 0Fh and
     * deliberately does not use this P6 event encoding. */
    if(strcmp(jtmos_cpu_info.vendor,"GenuineIntel") || jtmos_cpu_info.family!=6U) return -1;
    if(jtmos_cpu_info.max_basic_leaf>=0x0aU)
    {
        DWORD a,b,c,d;
        nmi_cpuid(0x0aU,0,&a,&b,&c,&d);
        if((a&0xffU)!=0U) return -1; /* use architectural PMU when enumerated */
    }
    nmi_rdmsr(MSR_IA32_PERFEVTSEL0,&saved_evt_lo,&saved_evt_hi);
    if(saved_evt_lo&0x00400000UL) { src_status="external NMI only: Intel P6 PMC0 already enabled"; return -1; }
    nmi_rdmsr(MSR_IA32_PMC0,&saved_pmc_lo,&saved_pmc_hi);
    intel_width=40U;
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
    nmi_counter_preload(intel_width,&lo,&hi);
    nmi_wrmsr(MSR_IA32_PMC0,lo,hi);
    nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_P6_EVT_UNHALTED_CYCLES,0);
    return 0;
}

static int nmi_setup_amd10(void)
{
    DWORD lo,hi;
    if(strcmp(jtmos_cpu_info.vendor,"AuthenticAMD") || jtmos_cpu_info.family!=0x10U) return -1;
    nmi_rdmsr(MSR_AMD_PERFEVTSEL0,&saved_evt_lo,&saved_evt_hi);
    if(saved_evt_lo&0x00400000UL) { src_status="external NMI only: AMD PMC0 already enabled"; return -1; }
    nmi_rdmsr(MSR_AMD_PMC0,&saved_pmc_lo,&saved_pmc_hi);
    nmi_counter_preload(48U,&lo,&hi);
    nmi_wrmsr(MSR_AMD_PMC0,lo,hi);
    nmi_wrmsr(MSR_AMD_PERFEVTSEL0,AMD_EVT_CPU_CLOCKS,0);
    return 0;
}

static int nmi_periodic_source_init(int allow_baremetal_pmu)
{
    DWORD a,b,c,d,flags;
    if(src_active) return 0;
    src_kind=NMI_SRC_NONE; src_status="external NMI only";
    if(!cpuHasFeature(JTMOS_CPUF_CPUID))
    {
        nmi_open_pc_gate();
        return -1;
    }

    /* The official JTMOS QEMU launcher installs an IB700 watchdog and selects
     * -watchdog-action inject-nmi.  Prefer that external source in a VM: unlike
     * a PMU counter, it is driven by host time and still fires when the guest
     * has disabled ordinary interrupts or wedged its scheduler completely. */
    if(nmi_is_qemu_hypervisor())
    {
        flags=get_eflags(); disable();
        ib700_pit_seen=0;
        ib700_expiry_pit_progress=0;
        outportb(IB700_WDT_START,IB700_WDT_4SEC);
        src_kind=NMI_SRC_QEMU_IB700;
        src_active=1;
        __sync_synchronize();
        src_status="QEMU/KVM IB700 4s watchdog -> injected NMI";
        nmi_open_pc_gate();
        set_eflags(flags);
        return 0;
    }

    /* V70.1 buildfix3: do not program architectural/legacy PMU counters as a
     * side effect of `nmi on` / ordinary watchdog enable on physical machines.
     * Several older chipsets/CPUs (notably the eMachines MCP61/Athlon II test
     * host) can lock up before a useful exception is reported.  External NMI
     * delivery remains enabled.  V70.4 reaches the PMU code below only through
     * the explicit force API / nmi=pmu boot option. */
    if(!allow_baremetal_pmu)
    {
        src_status="external NMI only: bare-metal PMU auto-source disabled";
        nmi_open_pc_gate();
        return -1;
    }

    nmi_cpuid(1,0,&a,&b,&c,&d);
    if(!(d&(1UL<<5)))
    {
        src_status="external NMI only: no MSR";
        nmi_open_pc_gate();
        return -1;
    }
    if(!(d&(1UL<<9)))
    {
        src_status="external NMI only: no local APIC";
        nmi_open_pc_gate();
        return -1;
    }
    flags=get_eflags(); disable();
    if(nmi_map_lapic()!=0)
    {
        nmi_open_pc_gate();
        set_eflags(flags);
        return -1;
    }
    if(nmi_setup_intel()==0) src_kind=NMI_SRC_INTEL_ARCH;
    else if(nmi_setup_intel_arch1()==0) src_kind=NMI_SRC_INTEL_ARCH1;
    else if(nmi_setup_intel_p6()==0) src_kind=NMI_SRC_INTEL_P6;
    else if(nmi_setup_amd10()==0) src_kind=NMI_SRC_AMD10;
    else
    {
        nmi_unmap_lapic();
        if(src_status[0]=='e' && !strcmp(src_status,"external NMI only"))
            src_status="external NMI only: unsupported/reserved PMU";
        nmi_open_pc_gate();
        set_eflags(flags); return -1;
    }
    src_active=1;
    __sync_synchronize();
    lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;
    (void)lapic[LAPIC_LVTPC/4U];
    if(src_kind==NMI_SRC_INTEL_ARCH)
        src_status="Intel architectural PMU v2+ -> LAPIC NMI";
    else if(src_kind==NMI_SRC_INTEL_ARCH1)
        src_status="Intel architectural PMU v1 -> LAPIC NMI";
    else if(src_kind==NMI_SRC_INTEL_P6)
        src_status="Intel P6/i686 40-bit PMC0 -> LAPIC NMI";
    else
        src_status="AMD Family 10h PMU -> LAPIC NMI";

    /* Last initialization step: undo the boot loader's port-70h NMI mask.
     * From here onward an asynchronous vector-2 entry is fully serviceable. */
    nmi_open_pc_gate();
    set_eflags(flags);
    return 0;
}

int NmiPeriodicSourceInit(void)
{
    return nmi_periodic_source_init(0);
}

int NmiPeriodicSourceForcePmu(void)
{
    return nmi_periodic_source_init(1);
}

void NmiPeriodicSourceShutdown(void)
{
    DWORD flags=get_eflags(); disable();

    if(src_kind==NMI_SRC_QEMU_IB700)
    {
        src_active=0;
        __sync_synchronize();
        outportb(IB700_WDT_STOP,0);
        ib700_pit_seen=0;
        ib700_expiry_pit_progress=0;
        src_kind=NMI_SRC_NONE;
        src_status="NMI source disabled";
        cmos_set_nmi_masked(1);
        set_eflags(flags);
        return;
    }

    /* CLI does not block NMI. Stop new LVTPC deliveries first and flush the
     * MMIO write before touching PMU ownership or src_active. */
    if(lapic && lapic_map)
    {
        lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_MASKED|LAPIC_LVT_NMI;
        (void)lapic[LAPIC_LVTPC/4U];
    }
    src_active=0;
    __sync_synchronize();

    if(src_kind==NMI_SRC_INTEL_ARCH)
    {
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,saved_global_lo&~1UL,saved_global_hi);
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_OVF,1U,0);
        nmi_wrmsr(MSR_IA32_PMC0,saved_pmc_lo,saved_pmc_hi);
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,saved_evt_lo,saved_evt_hi);
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,saved_global_lo,saved_global_hi);
    }
    else if(src_kind==NMI_SRC_INTEL_ARCH1)
    {
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
        nmi_wrmsr(MSR_IA32_PMC0,saved_pmc_lo,saved_pmc_hi);
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,saved_evt_lo,saved_evt_hi);
    }
    else if(src_kind==NMI_SRC_INTEL_P6)
    {
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,0,0);
        nmi_wrmsr(MSR_IA32_PMC0,saved_pmc_lo,saved_pmc_hi);
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,saved_evt_lo,saved_evt_hi);
    }
    else if(src_kind==NMI_SRC_AMD10)
    {
        nmi_wrmsr(MSR_AMD_PERFEVTSEL0,0,0);
        nmi_wrmsr(MSR_AMD_PMC0,saved_pmc_lo,saved_pmc_hi);
        nmi_wrmsr(MSR_AMD_PERFEVTSEL0,saved_evt_lo,saved_evt_hi);
    }
    src_kind=NMI_SRC_NONE;
    nmi_unmap_lapic();
    src_status="NMI source disabled";
    cmos_set_nmi_masked(1);
    set_eflags(flags);
}

int NmiPeriodicSourceAcknowledge(void)
{
    DWORD lo,hi,pl,ph,glo,ghi;
    if(!src_active) return 0;

    if(src_kind==NMI_SRC_QEMU_IB700)
    {
        /* IB700 exposes no readable expiry-status register. In QEMU this source
         * is installed only with watchdog-action=inject-nmi, so a source-less
         * vector 2 while it is armed is the watchdog event. Snapshot whether
         * PIT ran since the previous arm before rearming. */
        ib700_expiry_pit_progress=ib700_pit_seen;
        ib700_pit_seen=0;
        outportb(IB700_WDT_START,IB700_WDT_4SEC);
        return 1;
    }

    if(src_kind==NMI_SRC_INTEL_ARCH)
    {
        nmi_rdmsr(MSR_IA32_PERF_GLOBAL_STATUS,&lo,&hi);
        if(!(lo&1U)) return 0;

        /* Intel SDM: LAPIC automatically sets LVTPC.mask when it accepts a PMI.
         * V69.17 cleared overflow/reloaded PMC0 but never cleared that mask,
         * so the first PMI was also the last. Stop -> clear -> reload ->
         * UNMASK LVTPC -> restart, in that order. */
        nmi_rdmsr(MSR_IA32_PERF_GLOBAL_CTRL,&glo,&ghi);
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,glo&~1UL,ghi);
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_OVF,1U,0);
        nmi_counter_preload(intel_width,&pl,&ph);
        nmi_wrmsr(MSR_IA32_PMC0,pl,ph);
        if(lapic)
        {
            lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;
            (void)lapic[LAPIC_LVTPC/4U];
        }
        nmi_wrmsr(MSR_IA32_PERF_GLOBAL_CTRL,glo|1UL,ghi);
        return 1;
    }

    if(src_kind==NMI_SRC_INTEL_ARCH1)
    {
        /* Architectural PMU v1 predates GLOBAL_STATUS.  Like P6, use the
         * Intel-defined LVTPC auto-mask as the ownership/ack indication. */
        if(!lapic || !(lapic[LAPIC_LVTPC/4U]&LAPIC_LVT_MASKED)) return 0;
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_EVT_UNHALTED_CYCLES&~0x00400000UL,0);
        nmi_counter_preload(intel_width,&pl,&ph);
        nmi_wrmsr(MSR_IA32_PMC0,pl,ph);
        lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;
        (void)lapic[LAPIC_LVTPC/4U];
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_EVT_UNHALTED_CYCLES,0);
        return 1;
    }

    if(src_kind==NMI_SRC_INTEL_P6)
    {
        /* P6 has no IA32_PERF_GLOBAL_STATUS. The auto-masked LVTPC bit is our
         * ownership proof: the entry was unmasked when armed and only the PMI
         * path sets it. Stop the event while PMC0 is reloaded, then unmask. */
        if(!lapic || !(lapic[LAPIC_LVTPC/4U]&LAPIC_LVT_MASKED)) return 0;
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_P6_EVT_UNHALTED_CYCLES&~0x00400000UL,0);
        nmi_counter_preload(40U,&pl,&ph);
        nmi_wrmsr(MSR_IA32_PMC0,pl,ph);
        lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;
        (void)lapic[LAPIC_LVTPC/4U];
        nmi_wrmsr(MSR_IA32_PERFEVTSEL0,INTEL_P6_EVT_UNHALTED_CYCLES,0);
        return 1;
    }

    if(src_kind==NMI_SRC_AMD10)
    {
        nmi_rdmsr(MSR_AMD_PMC0,&lo,&hi);
        if(hi&0x00008000UL) return 0;
        nmi_wrmsr(MSR_AMD_PERFEVTSEL0,AMD_EVT_CPU_CLOCKS&~0x00400000UL,0);
        nmi_counter_preload(48U,&pl,&ph);
        nmi_wrmsr(MSR_AMD_PMC0,pl,ph);
        if(lapic)
        {
            lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;
            (void)lapic[LAPIC_LVTPC/4U];
        }
        nmi_wrmsr(MSR_AMD_PERFEVTSEL0,AMD_EVT_CPU_CLOCKS,0);
        return 1;
    }
    return 0;
}

int NmiPeriodicSourceHardExpiry(void)
{
    return (src_active && src_kind==NMI_SRC_QEMU_IB700) ? 1 : 0;
}

int NmiPeriodicSourcePITProgress(void)
{
    return ib700_expiry_pit_progress ? 1 : 0;
}

void NmiPeriodicSourceHeartbeat(void)
{
    static unsigned int divider=0;
    if(!src_active || src_kind!=NMI_SRC_QEMU_IB700) return;
    ib700_pit_seen=1;
    /* Keep the idle CPU quiet; a live IRQ0 from a non-idle task is not
     * scheduler progress and must never suppress its watchdog timeout. */
    if(nr_curthread==IdleThread.pid && (divider&0xffU)==0U)
    {
        outportb(IB700_WDT_START,IB700_WDT_4SEC);
        ib700_pit_seen=0;
    }
    divider++;
}

void NmiPeriodicSourceTaskSwitchHeartbeat(void)
{
    if(!src_active || src_kind!=NMI_SRC_QEMU_IB700) return;
    /* Kick at the real switch, not on the next PIT IRQ.  A newly scheduled
     * task can disable IF before another timer tick, and must still get the
     * full hardware interval before IB700 is allowed to intervene. */
    outportb(IB700_WDT_START,IB700_WDT_4SEC);
    ib700_pit_seen=0;
}

int NmiPeriodicSourceActive(void) { return src_active ? 1 : 0; }
const char *NmiPeriodicSourceName(void)
{
    if(src_kind==NMI_SRC_QEMU_IB700) return "qemu-ib700";
    if(src_kind==NMI_SRC_INTEL_ARCH) return "intel-arch-pmu-v2+";
    if(src_kind==NMI_SRC_INTEL_ARCH1) return "intel-arch-pmu-v1";
    if(src_kind==NMI_SRC_INTEL_P6) return "intel-p6-pmu";
    if(src_kind==NMI_SRC_AMD10) return "amd10h-pmu";
    return "external";
}
const char *NmiPeriodicSourceStatus(void) { return src_status; }
