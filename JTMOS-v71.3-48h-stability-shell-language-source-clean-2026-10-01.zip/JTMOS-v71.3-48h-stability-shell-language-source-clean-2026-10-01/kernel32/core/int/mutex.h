#ifndef JTMOS_THREAD_MUTEX_H
#define JTMOS_THREAD_MUTEX_H

/*
 * Sleeping thread mutexes for JTMOS.
 *
 * The public API deliberately follows Linux' ordinary mutex API:
 *
 *     static DEFINE_MUTEX(lock);
 *     mutex_lock(&lock);
 *     ...
 *     mutex_unlock(&lock);
 *
 * A mutex is non-recursive and belongs to a thread, not to an IRQ-disabled
 * region.  Contended process-context callers are placed on a FIFO wait queue
 * and removed from the scheduler's runnable set.  IRQ/exception code must use
 * mutex_trylock(); mutex_lock() is not legal in atomic context.
 *
 * JTMOS is currently a uniprocessor kernel.  Queue and ownership publication
 * are therefore made atomic with a short IRQ-save section.  The protected
 * operation itself always runs with the caller's original IF state.
 */

#include "basdef.h"

struct mutex_waiter;

struct mutex
{
    volatile int owner_pid;
    DWORD owner_magic;
    struct mutex_waiter *wait_head;
    struct mutex_waiter *wait_tail;
    volatile unsigned int waiters;
    const char *name;
    const char *owner_function;
    const char *owner_file;
    int owner_line;
    DWORD acquired_ms;
    struct mutex *registry_next;
    BYTE registered;
};

#define __MUTEX_INITIALIZER(lockname) \
    { -1, 0, 0, 0, 0, #lockname, 0, 0, 0, 0, 0, 0 }

#define DEFINE_MUTEX(lockname) \
    struct mutex lockname = __MUTEX_INITIALIZER(lockname)

void mutex_init(struct mutex *lock);
int mutex_destroy(struct mutex *lock);

void mutex_lock_at(struct mutex *lock,
                   const char *function,const char *file,int line);
int mutex_trylock_at(struct mutex *lock,
                     const char *function,const char *file,int line);
void mutex_unlock_at(struct mutex *lock,
                     const char *function,const char *file,int line);
int mutex_is_locked(const struct mutex *lock);
int mutex_owner(const struct mutex *lock);

#ifndef JTMOS_MUTEX_IMPLEMENTATION
#define mutex_lock(lock) \
    mutex_lock_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define mutex_trylock(lock) \
    mutex_trylock_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define mutex_unlock(lock) \
    mutex_unlock_at((lock),__FUNCTION__,__FILE__,__LINE__)
#endif

/* Scheduler/thread-lifecycle hooks.  These are allocation-free and safe from
 * the asynchronous quarantine path while interrupts are already disabled. */
int JtMutexThreadBlocked(int pid);
const char *JtMutexThreadWaitName(int pid);
void JtMutexThreadInit(int pid);
void JtMutexThreadCleanup(int pid);
void JtMutexThreadCleanupExcept(int pid,struct mutex *keep_owned_lock);

#endif
