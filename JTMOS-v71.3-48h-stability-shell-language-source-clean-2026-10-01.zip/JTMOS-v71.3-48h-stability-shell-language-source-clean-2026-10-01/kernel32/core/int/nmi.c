/*
 * nmi.c - Linux-inspired x86 NMI + autonomous progress watchdog for JTMOS.
 * V69.39 IA-32 task-gate NMI + guarded watchdog revision.
 *
 * NMI-entry rules remain stricter than an ordinary IRQ handler:
 *   - no malloc, filesystem, terminal, printf or ordinary kernel locks;
 *   - no scheduler/task switch from NMI context;
 *   - no PIC EOI;
 *   - diagnostics are emergency-serial only;
 *   - interactive rescue may restore EFLAGS.IF for explicitly recoverable
 *     threads; V70.4 may also reopen IF for a normal non-zero thread after an
 *     autonomous source proves a hard no-IRQ stall;
 *   - fail-stop Guard Dog targets keep IF unchanged and arm TF/#DB;
 *   - all quarantine/resource teardown runs outside NMI context.
 */
#include "kernel32.h"
#include "io.h"
#include "nmi.h"
#include "threads.h"
#include "scheduler.h"
#include "crash_analysis.h"
#include "threadpriorities.h"
#include "nmi_source.h"
#include "nmi_watchdog_policy.h"
#include "tss.h"
#include "apic.h"
#include "cmos.h"
#include "keropt.h"

static volatile DWORD nmi_total=0;
static volatile DWORD nmi_unknown=0;
static volatile DWORD nmi_parity=0;
static volatile DWORD nmi_io_check=0;
static volatile DWORD nmi_software_tests=0;
static volatile DWORD nmi_nested=0;
static volatile DWORD nmi_depth=0;
static volatile DWORD nmi_max_depth=0;
static volatile DWORD nmi_last_reason=0;
static volatile DWORD nmi_last_eip=0;
static volatile DWORD nmi_last_cs=0;
static volatile DWORD nmi_last_eflags=0;
static volatile DWORD nmi_last_cr2=0;
static volatile DWORD nmi_last_pid=(DWORD)-1;
static volatile int nmi_panic_on_unknown=0;

/* V69.39: after multitasking has loaded a valid TR, vector 2 uses a hardware
 * IA-32 task gate.  The CPU saves the interrupted register image in that
 * task's TSS before loading the dedicated NMI TSS/stack. */
static volatile DWORD nmi_task_gate_entries=0;
static volatile DWORD nmi_task_gate_bad_backlink=0;
volatile DWORD nmi_task_gate_active=0;

/* V68.208: scheduler-visible, but semantically distinct from thread_states[]. */
volatile BYTE nmi_thread_suspended[N_MAX_THREADS];
volatile DWORD thread_rtc_seconds_without_task_switch[N_MAX_THREADS];
volatile DWORD thread_lastsec=0;

static volatile DWORD nmi_watchdog_threshold=JTMOS_NMI_WATCHDOG_DEFAULT_SECONDS;
static volatile DWORD nmi_watchdog_events=0;
static volatile DWORD nmi_rescue_forced_irq_count=0;
static volatile DWORD nmi_rescue_sequence=0;
static volatile DWORD nmi_watchdog_samples=0;
static volatile DWORD nmi_watchdog_unowned_skipped=0;
static volatile DWORD nmi_watchdog_kernel_context_skipped=0;
static volatile DWORD nmi_watchdog_force_if_repairs=0;
static volatile DWORD nmi_watchdog_last_force_if_pid=(DWORD)-1;
static volatile DWORD nmi_watchdog_last_force_if_eip=0;
static volatile DWORD nmi_rescue_publish_conflicts=0;
static volatile DWORD nmi_watchdog_autokills=0;
static volatile DWORD nmi_watchdog_kill_traps=0;
static volatile DWORD nmi_watchdog_guarddog_reaps=0;
/* PMU NMIs have no trustworthy wall-clock duration without touching CMOS from
 * NMI context.  Count repeated owned samples with no PIT progress instead. */
static volatile DWORD nmi_watchdog_last_timer_irqs=0;
static volatile DWORD nmi_watchdog_last_context_switches=0;
static volatile DWORD nmi_watchdog_pmu_stall_samples=0;
static volatile BYTE nmi_watchdog_pmu_baseline_valid=0;
static volatile int nmi_watchdog_enabled=0;
static volatile int nmi_system_enabled=0;
/* V70.4 last-resort liveness policy.  This never kills, suspends or frees a
 * thread; it only lets normal IRQ0/preemption resume after a proven stall. */
static volatile int nmi_watchdog_force_if=1;
/* Recovery is opt-in per thread.  NMI may only force IF when a thread has
 * explicitly promised that the interrupted region is rollback/restart safe. */
volatile BYTE nmi_thread_recoverable[N_MAX_THREADS];
/* V69.17: ordinary applications are fail-stop watchdog targets.  NMI sets
 * this bit before arming TF in the interrupted frame.  The resulting #DB is
 * handled by the normal exception containment path, which performs deferred
 * process teardown outside NMI context. */
volatile BYTE nmi_thread_watchdog_kill_pending[N_MAX_THREADS];
/* Explicit fail-stop eligibility for isolated Ring0 workers.  Never set this
 * on SMSH itself, PID0, IdleThread or long-lived kernel services. */
volatile BYTE nmi_thread_watchdog_autokill[N_MAX_THREADS];
static volatile DWORD nmi_rescue_prompt_claimed[N_MAX_THREADS];
static volatile JTMOS_NMI_RESCUE_INFO nmi_rescue_slots[N_MAX_THREADS];

extern void NmiSoftwareTrigger(void);
extern void NmiSoftwareTriggerReturn(void);

static void nmi_serial_field(const char *name,DWORD value)
{
    DebugSerialNmiWrite(name);
    DebugSerialNmiWriteHex32(value);
}

static int nmi_log_this_event(DWORD count,DWORD source)
{
    if(source & (JTMOS_NMI_REASON_PARITY|JTMOS_NMI_REASON_IOCHECK)) return 1;
    if(count<=4U) return 1;
    return (count & (count-1U))==0U;
}


static int nmi_rescue_state_visible(DWORD state)
{
    return state==JTMOS_NMI_RESCUE_PENDING || state==JTMOS_NMI_RESCUE_HELD ||
           state==JTMOS_NMI_RESCUE_AUTOKILL;
}

static int nmi_watchdog_common_eligible(DWORD pid,JTMOS_NMI_FRAME *frame,DWORD depth)
{
    if(!nmi_watchdog_enabled || !frame || depth!=1U) return 0;
    if(pid==0U || pid>=(DWORD)nr_threads || pid>=N_MAX_THREADS) return 0;
    if(!thread_states[pid] || nmi_thread_suspended[pid]) return 0;
    if((int)pid==IdleThread.pid) return 0;
    if(thread_type[pid]&(THREAD_TYPE_IMMORTAL|THREAD_TYPE_RESOURCE_OWNER)) return 0;
    if(nmi_rescue_slots[pid].active!=JTMOS_NMI_RESCUE_FREE) return 0;
    return 1;
}

/* V69.17: a normal external application is always a watchdog target.  It no
 * longer has to opt in with NmiWatchdogSetThreadRecoverable().  Kernel/service
 * threads retain the conservative opt-in rescue policy below. */
static int nmi_watchdog_autokill_eligible(DWORD pid,JTMOS_NMI_FRAME *frame,DWORD depth)
{
    if(!nmi_watchdog_common_eligible(pid,frame,depth)) return 0;

    /* V69.18: a short-lived Ring0 worker may explicitly opt into fail-stop
     * containment.  This is intentionally a separate side-band bit instead of
     * lying about THREAD_TYPE_APPLICATION; scheduler/TSS validation must still
     * know that the worker really runs at CPL0. */
    if(nmi_thread_watchdog_autokill[pid]) return 1;

    if(!(thread_type[pid]&THREAD_TYPE_APPLICATION)) return 0;
    if(thread_type[pid]&THREAD_TYPE_KERNEL) return 0;
    /* A normal Ring3 process is fail-stop eligible only while the interrupted
     * CPU context is actually Ring3.  If NMI lands while that process is in a
     * syscall, page fault, scheduler or other kernel critical path, forcing TF
     * would single-step kernel code and can strand locks.  Diagnose only. */
    if((frame->cs&3U)!=3U) return 0;
    return 1;
}

static int nmi_rescue_eligible(DWORD pid,JTMOS_NMI_FRAME *frame,DWORD depth)
{
    if(!nmi_watchdog_common_eligible(pid,frame,depth)) return 0;
    if(frame->eflags&0x200U) return 0;
    if(!nmi_thread_recoverable[pid]) return 0;
    return 1;
}

static int nmi_watchdog_force_if_eligible(DWORD pid,JTMOS_NMI_FRAME *frame,
                                          DWORD depth)
{
    if(!nmi_watchdog_force_if) return 0;
    if(!nmi_watchdog_common_eligible(pid,frame,depth)) return 0;
    if(frame->eflags&0x200U) return 0;
    return 1;
}

static void nmi_watchdog_observe(JTMOS_NMI_FRAME *frame,DWORD pid,DWORD reason,
                                 DWORD depth)
{
    JTMOS_SCHED_WATCHDOG sw;
    DWORD no_switch=0,stall=0,current_time,elapsed_time;
    DWORD required_samples=0;
    int hard_expiry;

    if(!nmi_watchdog_enabled || !frame) return;
    __sync_add_and_fetch(&nmi_watchdog_samples,1U);
    hard_expiry=NmiPeriodicSourceHardExpiry();
    if(SchedulerGetWatchdogSnapshot(&sw)!=0) return;
    current_time=SchedulerWatchdogSeconds();
    /* Uptime wraps after about 49 days.  An ambiguous wrap cannot sentence a
     * process; the next task switch establishes a fresh origin. */
    elapsed_time=NmiWatchdogElapsedSeconds(current_time,thread_lastsec,0);

    /* V69.38 NMI rule: NEVER touch CMOS/RTC ports here.  Port 70h is a shared
     * selector plus the external NMI gate; an NMI that interrupts a CMOS
     * selector/data pair must not change that selector.
     *
     * The host-clocked IB700 source reports four seconds with no task switch
     * or idle feed, whether PIT ran or not.  PMU-only machines use a
     * conservative sequence of owned PMU samples with zero PIT progress.  That
     * is intentionally approximate rather than risking CMOS I/O from NMI. */
    if(pid<(DWORD)N_MAX_THREADS)
        no_switch=NmiWatchdogElapsedSeconds(current_time,thread_lastsec,hard_expiry);

    if(hard_expiry)
    {
        /* IB700 expires four seconds after the last scheduler progress kick.
         * PIT may still run; NmiPeriodicSourcePITProgress distinguishes this
         * from an IF=0 hard stop when deciding whether IF can be reopened. */
        stall=4U;
    }
    else
    {
        if(nmi_watchdog_pmu_baseline_valid &&
           sw.timer_irqs==nmi_watchdog_last_timer_irqs &&
           sw.context_switches==nmi_watchdog_last_context_switches)
        {
            if(nmi_watchdog_pmu_stall_samples<0xffffffffUL)
                nmi_watchdog_pmu_stall_samples++;
        }
        else
            nmi_watchdog_pmu_stall_samples=0;
        nmi_watchdog_last_timer_irqs=sw.timer_irqs;
        nmi_watchdog_last_context_switches=sw.context_switches;
        nmi_watchdog_pmu_baseline_valid=1;

        /* The PMU preload is 2^28 unhalted cycles.  Its wall-clock rate varies
         * by CPU, so require several consecutive samples per configured second
         * and treat this only as a conservative progress watchdog. */
        required_samples=nmi_watchdog_threshold*8U;
        if(required_samples<8U) required_samples=8U;
        if(nmi_watchdog_pmu_stall_samples>=required_samples)
            stall=nmi_watchdog_threshold;
    }

    /* PMU sample counts have no stable wall-clock rate.  Only a monotonic
     * timestamp older than three seconds or the host-clocked IB700 expiry may
     * authorize automatic termination.  Samples alone may reopen IF below. */
    if(!hard_expiry && elapsed_time>nmi_watchdog_threshold)
        stall=elapsed_time;

    {
        int auto_kill=nmi_watchdog_autokill_eligible(pid,frame,depth);
        int interactive=nmi_rescue_eligible(pid,frame,depth);
        volatile JTMOS_NMI_RESCUE_INFO *r;

        if(stall<nmi_watchdog_threshold) return;
        if(!NmiWatchdogMayTerminate(elapsed_time,nmi_watchdog_threshold,hard_expiry))
        {
            auto_kill=0;
            interactive=0;
        }
        if(!auto_kill && !interactive)
        {
            /* V70.4 generic CLI/disable escape hatch.  A kernel/service thread
             * may be holding an unknown lock, so NMI must not kill, suspend,
             * reap or publish it as recoverable.  Reopening IF alone permits
             * the ordinary IRQ0 scheduler to preempt the wedged context and
             * restores machine-wide progress.  The offending thread remains
             * visible/runnable for diagnostics and an explicit later action. */
            if(NmiWatchdogMayRepairIf(hard_expiry,
                                     NmiPeriodicSourcePITProgress(),
                                     nmi_watchdog_pmu_stall_samples,
                                     required_samples) &&
               nmi_watchdog_force_if_eligible(pid,frame,depth))
            {
                DWORD before=frame->eflags;
                frame->eflags|=0x200U;
                nmi_watchdog_last_force_if_pid=pid;
                nmi_watchdog_last_force_if_eip=frame->eip;
                __sync_add_and_fetch(&nmi_watchdog_force_if_repairs,1U);
                __sync_add_and_fetch(&nmi_watchdog_events,1U);

                DebugSerialNmiWrite("\n[NMI/WATCHDOG] hard IF=0 stall; IRQ delivery reopened\n");
                nmi_serial_field("  pid=",pid);
                nmi_serial_field(" no-switch-sec=",no_switch);
                nmi_serial_field(" rtc-irq-stall=",stall);
                DebugSerialNmiWrite("\n");
                nmi_serial_field("  EIP=",frame->eip);
                nmi_serial_field(" EFLAGS(before)=",before);
                DebugSerialNmiWrite(" IF will be ON after IRETD; thread was not killed or suspended\n");
                return;
            }
            if(pid<(DWORD)N_MAX_THREADS &&
               (thread_type[pid]&THREAD_TYPE_APPLICATION) &&
               !(thread_type[pid]&THREAD_TYPE_KERNEL) &&
               ((frame->cs&3U)!=3U))
                __sync_add_and_fetch(&nmi_watchdog_kernel_context_skipped,1U);
            return;
        }
        r=&nmi_rescue_slots[pid];

        /* CLI is not an NMI lock. Reserve the slot with an atomic state
         * transition before publishing any fields, so a nested/re-entrant NMI
         * can never publish a second rescue into the same PID slot. */
        if(!__sync_bool_compare_and_swap(&r->active,
                                        JTMOS_NMI_RESCUE_FREE,
                                        JTMOS_NMI_RESCUE_WRITING))
        {
            __sync_add_and_fetch(&nmi_rescue_publish_conflicts,1U);
            return;
        }

        nmi_thread_suspended[pid]=1;
        r->sequence=__sync_add_and_fetch(&nmi_rescue_sequence,1U);
        r->pid=pid;
        r->thread_magic=(DWORD)thread_magic[pid];
        r->terminal=(DWORD)GetThreadTerminal((int)pid);
        r->no_switch_seconds=no_switch; r->stall_seconds=stall;
        r->eip=frame->eip; r->cs=frame->cs; r->eflags=frame->eflags;
        r->reason61=reason;
        r->scheduler_timer_irqs=sw.timer_irqs;
        r->scheduler_context_switches=sw.context_switches;
        nmi_rescue_prompt_claimed[pid]=0;

        if(auto_kill)
        {
            /* Do NOT free a process, take locks, switch tasks or enable IRQs
             * from NMI context.  TF is independent of IF: after IRETD the CPU
             * executes at most one instruction and raises #DB.  JTMOS's normal
             * exception containment then quarantines/reaps this non-immortal
             * application in ordinary kernel context.  This also escapes a
             * userspace process stuck behind CLI/IF=0 without relying on PIT. */
            nmi_thread_watchdog_kill_pending[pid]=1;
            r->forced_irqs_on=0U;
            __sync_synchronize();
            r->active=JTMOS_NMI_RESCUE_AUTOKILL;
            __sync_add_and_fetch(&nmi_watchdog_autokills,1U);
            __sync_add_and_fetch(&nmi_watchdog_kill_traps,1U);
            /* Stage 1: TF guarantees a #DB after at most one instruction and
             * works even when the wedged target had IF=0.  Do not force IF here:
             * the NMI may have interrupted an application inside a kernel
             * critical section.  Stage 2 runs only after ordinary scheduling is
             * safe again and reaps any AUTOKILL slot left by containment. */
            frame->eflags|=0x100U; /* TF: deterministic post-NMI kill trap */

            DebugSerialNmiWrite("\n[NMI/GUARD-DOG] hard hang: fail-stop containment armed\n");
            nmi_serial_field("  pid=",pid);
                nmi_serial_field(" no-switch-sec=",no_switch);
            nmi_serial_field(" rtc-irq-stall=",stall);
            DebugSerialNmiWrite("\n");
            nmi_serial_field("  EIP=",frame->eip);
            nmi_serial_field(" EFLAGS(before)=",r->eflags);
            DebugSerialNmiWrite(" TF will raise #DB after IRETD; process-context Guard Dog will finish teardown\n");
        }
        else
        {
            r->forced_irqs_on=1U;
            __sync_synchronize();
            r->active=JTMOS_NMI_RESCUE_PENDING;
            __sync_add_and_fetch(&nmi_rescue_forced_irq_count,1U);

            /* Explicitly recoverable kernel/service probes keep the old
             * interactive policy.  Only those callers permit IF mutation. */
            frame->eflags|=0x200U;
            DebugSerialNmiWrite("\n[NMI/WATCHDOG] CLI hang detected; process quarantined\n");
            nmi_serial_field("  pid=",pid);
            nmi_serial_field(" no-switch-sec=",no_switch);
            nmi_serial_field(" rtc-irq-stall=",stall);
            DebugSerialNmiWrite("\n");
            nmi_serial_field("  EIP=",frame->eip);
            nmi_serial_field(" EFLAGS(before)=",r->eflags);
            DebugSerialNmiWrite(" IF will be forced ON after IRETD\n");
            DebugSerialNmiWrite("  decision: Continue / Kill / keep Suspended in rescue worker or `nmi rescue`\n");
        }
    }
    __sync_add_and_fetch(&nmi_watchdog_events,1U);
}

static TSSEG *nmi_task_from_selector(WORD selector)
{
    CDSEG *d;
    DWORD off,base,type;
    DWORD lo,hi;

    if(!tasks || !gdt_table) return NULL;
    if(selector&0x0004U) return NULL; /* LDT selector: JTMOS task TSSes are GDT. */
    off=(DWORD)(selector&0xfff8U);
    if(off==0U || off+sizeof(CDSEG)>sizeof(GDTTAB)) return NULL;

    d=(CDSEG *)((BYTE *)gdt_table+off);
    if(!(d->flags&0x80U)) return NULL;
    type=(DWORD)(d->flags&0x0fU);
    if(type!=9U && type!=11U) return NULL;
    base=(DWORD)d->base0_15 | ((DWORD)d->base16_23<<16) |
         ((DWORD)d->base24_31<<24);

    /* Never trust an arbitrary descriptor base in NMI context: accepting only
     * the two fixed JTMOS task arrays guarantees the snapshot itself cannot
     * chase a corrupted pointer into unmapped memory. */
    lo=JTM_PTR_TO_DWORD(&tasks->tss[0]);
    hi=JTM_PTR_TO_DWORD(&tasks->tss[N_MAX_TSS_TASKS]);
    if(base>=lo && base<hi && ((base-lo)%sizeof(TSSEG))==0U)
        return JTM_DWORD_TO_PTR(TSSEG,base);

    lo=JTM_PTR_TO_DWORD(&tasks->kertss[0]);
    hi=JTM_PTR_TO_DWORD(&tasks->kertss[24]);
    if(base>=lo && base<hi && ((base-lo)%sizeof(TSSEG))==0U)
        return JTM_DWORD_TO_PTR(TSSEG,base);
    return NULL;
}

void NmiTaskDispatch(void)
{
    TSSEG *old;
    JTMOS_NMI_FRAME frame;
    WORD backlink;

    /* ASMnmi_task publishes active=1 before any C work so a fault in this
     * adapter is recognized as NMI-nested by the exception path. */
    nmi_task_gate_active=1U;
    __sync_add_and_fetch(&nmi_task_gate_entries,1U);

    /* For an INT/NMI task-gate switch the processor writes the selector of the
     * interrupted task into the new TSS backlink before ASMnmi_task runs. */
    if(!tasks)
    {
        __sync_add_and_fetch(&nmi_task_gate_bad_backlink,1U);
        nmi_task_gate_active=0U;
        return;
    }
    backlink=tasks->kertss[6].link;
    old=nmi_task_from_selector(backlink);
    if(!old)
    {
        __sync_add_and_fetch(&nmi_task_gate_bad_backlink,1U);
        DebugSerialNmiWrite("\n[NMI] invalid task-gate backlink; returning without policy work\n");
        nmi_task_gate_active=0U;
        return;
    }

    /* Build the same logical frame used by the early interrupt-gate fallback.
     * The hardware TSS image is authoritative here: the CPU completed this save
     * before executing the first instruction on the private NMI stack. */
    frame.cr2=GETCR2();
    frame.gs=(DWORD)old->gs; frame.fs=(DWORD)old->fs;
    frame.es=(DWORD)old->es; frame.ds=(DWORD)old->ds;
    frame.edi=old->edi; frame.esi=old->esi; frame.ebp=old->ebp;
    frame.entry_esp=old->esp;
    frame.ebx=old->ebx; frame.edx=old->edx; frame.ecx=old->ecx; frame.eax=old->eax;
    frame.eip=old->eip; frame.cs=(DWORD)old->cs; frame.eflags=old->eflags;
    if((old->cs&3U)!=0U)
    {
        frame.user_esp=old->esp;
        frame.user_ss=(DWORD)old->ss;
    }
    else
    {
        frame.user_esp=0U;
        frame.user_ss=0U;
    }

    NmiDispatch(&frame);

    /* Watchdog recovery deliberately edits only IF/TF in EFLAGS.  Do not copy
     * general registers or segment state back from the diagnostic frame. */
    old->eflags=frame.eflags;
    __sync_synchronize();
    nmi_task_gate_active=0U;
}

int NmiTaskGateInProgress(void)
{
    return nmi_task_gate_active?1:0;
}

void NmiDispatch(JTMOS_NMI_FRAME *frame)
{
    DWORD depth,count,reason,source,pid=(DWORD)-1;
    int software_test,periodic_event=0;

    /* V69.40: when disabled, vector 2 is intentionally inert. */
    if(!nmi_system_enabled) return;

    depth=(DWORD)__sync_add_and_fetch(&nmi_depth,1U);
    count=(DWORD)__sync_add_and_fetch(&nmi_total,1U);
    if(depth>nmi_max_depth) nmi_max_depth=depth;
    if(depth>1U) __sync_add_and_fetch(&nmi_nested,1U);

    software_test=(frame && frame->eip==JTM_PTR_TO_DWORD((void *)NmiSoftwareTriggerReturn));
    if(software_test)
    {
        reason=0;
        source=0;
        __sync_add_and_fetch(&nmi_software_tests,1U);
    }
    else
    {
        reason=(DWORD)inportb(0x61);
        source=reason & (JTMOS_NMI_REASON_PARITY|JTMOS_NMI_REASON_IOCHECK);
        if(source & JTMOS_NMI_REASON_PARITY) __sync_add_and_fetch(&nmi_parity,1U);
        if(source & JTMOS_NMI_REASON_IOCHECK) __sync_add_and_fetch(&nmi_io_check,1U);
        if(source==0U)
        {
            periodic_event=NmiPeriodicSourceAcknowledge();
            if(!periodic_event) __sync_add_and_fetch(&nmi_unknown,1U);
        }
    }

    if(tasks!=NULL && nr_curthread>=0 && nr_curthread<N_MAX_THREADS)
        pid=(DWORD)nr_curthread;

    nmi_last_reason=reason;
    nmi_last_pid=pid;
    if(frame)
    {
        nmi_last_eip=frame->eip;
        nmi_last_cs=frame->cs;
        nmi_last_eflags=frame->eflags;
        nmi_last_cr2=frame->cr2;
    }

    if(nmi_log_this_event(count,source) || software_test)
    {
        DebugSerialNmiWrite("\n[NMI] vector=2 ");
        if(software_test) DebugSerialNmiWrite("software-test");
        else if(source & JTMOS_NMI_REASON_PARITY) DebugSerialNmiWrite("parity-error");
        else if(source & JTMOS_NMI_REASON_IOCHECK) DebugSerialNmiWrite("io-channel-check");
        else if(periodic_event) DebugSerialNmiWrite("pmu-watchdog");
        else DebugSerialNmiWrite("external/unknown");
        DebugSerialNmiWrite("\n");
        nmi_serial_field("  count=",count);
        nmi_serial_field(" depth=",depth);
        nmi_serial_field(" pid=",pid);
        nmi_serial_field(" reason61=",reason);
        DebugSerialNmiWrite("\n");
        if(frame)
        {
            nmi_serial_field("  EIP=",frame->eip);
            nmi_serial_field(" CS=",frame->cs);
            nmi_serial_field(" EFLAGS=",frame->eflags);
            nmi_serial_field(" CR2=",frame->cr2);
            DebugSerialNmiWrite("\n");
            nmi_serial_field("  EAX=",frame->eax);
            nmi_serial_field(" EBX=",frame->ebx);
            nmi_serial_field(" ECX=",frame->ecx);
            nmi_serial_field(" EDX=",frame->edx);
            DebugSerialNmiWrite("\n");
            nmi_serial_field("  ESI=",frame->esi);
            nmi_serial_field(" EDI=",frame->edi);
            nmi_serial_field(" EBP=",frame->ebp);
            nmi_serial_field(" ESP0=",frame->entry_esp);
            DebugSerialNmiWrite("\n");
            if((frame->cs & 3U)!=0U)
            {
                nmi_serial_field("  USER_ESP=",frame->user_esp);
                nmi_serial_field(" USER_SS=",frame->user_ss);
                DebugSerialNmiWrite("\n");
            }
        }
    }

    /* Only an event positively owned/acknowledged by the autonomous PMU
     * source is allowed to drive watchdog rescue.  An unrelated external NMI
     * must never quarantine a process merely because the scheduler heartbeat
     * happens to be stale at that instant. */
    if(!software_test && source==0U && periodic_event)
        nmi_watchdog_observe(frame,pid,reason,depth);
    else if(!software_test && source==0U && !periodic_event)
        __sync_add_and_fetch(&nmi_watchdog_unowned_skipped,1U);

    if(!software_test && source!=0U)
        KernelFatalAt("NMI hardware error", "core/int/nmi.c", "NmiDispatch", 0);

    if(!software_test && source==0U && !periodic_event && nmi_panic_on_unknown)
        KernelFatalAt("unknown NMI (strict policy)", "core/int/nmi.c", "NmiDispatch", 0);

    __sync_sub_and_fetch(&nmi_depth,1U);
}

static void nmi_copy_rescue(JTMOS_NMI_RESCUE_INFO *out,
                            const volatile JTMOS_NMI_RESCUE_INFO *in)
{
    if(!out || !in) return;
    out->sequence=in->sequence; out->pid=in->pid; out->thread_magic=in->thread_magic;
    out->terminal=in->terminal; out->no_switch_seconds=in->no_switch_seconds;
    out->stall_seconds=in->stall_seconds; out->eip=in->eip; out->cs=in->cs;
    out->eflags=in->eflags; out->reason61=in->reason61;
    out->scheduler_timer_irqs=in->scheduler_timer_irqs;
    out->scheduler_context_switches=in->scheduler_context_switches;
    out->forced_irqs_on=in->forced_irqs_on; out->active=in->active;
}

static int nmi_first_rescue(void)
{
    int i;
    for(i=1;i<nr_threads && i<N_MAX_THREADS;i++)
        if(nmi_rescue_state_visible(nmi_rescue_slots[i].active)) return i;
    return -1;
}

static DWORD nmi_rescue_count(void)
{
    int i; DWORD n=0;
    for(i=1;i<nr_threads && i<N_MAX_THREADS;i++)
        if(nmi_rescue_state_visible(nmi_rescue_slots[i].active)) n++;
    return n;
}

void NmiGetStats(JTMOS_NMI_STATS *out)
{
    DWORD flags; int rp;
    if(!out) return;
    flags=get_eflags(); disable();
    rp=nmi_first_rescue();
    out->total=nmi_total; out->unknown=nmi_unknown; out->parity=nmi_parity;
    out->io_check=nmi_io_check; out->software_tests=nmi_software_tests;
    out->nested=nmi_nested; out->last_reason=nmi_last_reason; out->last_eip=nmi_last_eip;
    out->last_cs=nmi_last_cs; out->last_eflags=nmi_last_eflags; out->last_cr2=nmi_last_cr2;
    out->last_pid=nmi_last_pid;
    out->max_depth=nmi_max_depth; out->watchdog_events=nmi_watchdog_events;
    out->watchdog_threshold_seconds=nmi_watchdog_threshold;
    out->rescue_pending=nmi_rescue_count();
    out->rescue_pid=(rp>=0)?nmi_rescue_slots[rp].pid:(DWORD)-1;
    out->rescue_no_switch_seconds=(rp>=0)?nmi_rescue_slots[rp].no_switch_seconds:0;
    out->rescue_stall_seconds=(rp>=0)?nmi_rescue_slots[rp].stall_seconds:0;
    out->rescue_forced_irq_count=nmi_rescue_forced_irq_count;
    out->watchdog_enabled=nmi_watchdog_enabled?1U:0U;
    out->watchdog_samples=nmi_watchdog_samples;
    out->watchdog_unowned_skipped=nmi_watchdog_unowned_skipped;
    out->watchdog_kernel_context_skipped=nmi_watchdog_kernel_context_skipped;
    out->watchdog_force_if_enabled=nmi_watchdog_force_if?1U:0U;
    out->watchdog_force_if_repairs=nmi_watchdog_force_if_repairs;
    out->watchdog_last_force_if_pid=nmi_watchdog_last_force_if_pid;
    out->watchdog_last_force_if_eip=nmi_watchdog_last_force_if_eip;
    out->rescue_publish_conflicts=nmi_rescue_publish_conflicts;
    out->watchdog_autokills=nmi_watchdog_autokills;
    out->watchdog_kill_traps=nmi_watchdog_kill_traps;
    out->watchdog_guarddog_reaps=nmi_watchdog_guarddog_reaps;
    out->task_gate_entries=nmi_task_gate_entries;
    out->task_gate_bad_backlink=nmi_task_gate_bad_backlink;
    out->task_gate_active=nmi_task_gate_active;
    set_eflags(flags);
}

int NmiSystemGetEnabled(void)
{
    return nmi_system_enabled?1:0;
}

int NmiSystemSetEnabled(int enabled)
{
    if(enabled)
    {
        if(nmi_system_enabled) return 1;

        /* Real-hardware safe default: enabling vector 2 must not immediately
         * start a PMU NMI storm or perform an IA-32 hardware task switch.
         * Keep the proven IRETD interrupt-gate entry and leave the autonomous
         * watchdog source disabled until explicitly requested. */
        cmos_set_nmi_masked(1);
        (void)apic_set_nmi_enabled(0);
        InstallNmiInterruptGateFallback();
        nmi_system_enabled=1;
        nmi_watchdog_enabled=0;
        __sync_synchronize();

        (void)apic_set_nmi_enabled(1);
        cmos_set_nmi_masked(0);
        NmiRescueInit();
        dprintk("NMI: safe interrupt-gate mode enabled; autonomous watchdog source remains off.\n");
        return 1;
    }

    nmi_watchdog_enabled=0;
    cmos_set_nmi_masked(1);
    (void)apic_set_nmi_enabled(0);
    NmiPeriodicSourceShutdown();
    InstallNmiInterruptGateFallback();
    __sync_synchronize();
    nmi_system_enabled=0;
    return 0;
}

int NmiSystemBootInit(void)
{
#if JTMOS_NMI_DEFAULT_ENABLED
    if(BOOTOPT_NMI_ENABLED)
    {
        int enabled=NmiSystemSetEnabled(1);
        if(!enabled) return 0;

        /* Boot auto-arms only the host-clocked/safe source.  Bare-metal PMU
         * setup requires the explicit nmi=pmu option because older MCP61 /
         * Athlon II systems have shown pre-diagnostic lockups. */
        if(BOOTOPT_NMI_FORCE_PMU)
        {
            if(!NmiWatchdogSetPmuEnabled(1))
                dprintk("NMI: explicit bare-metal PMU watchdog could not be armed (%s).\n",
                        NmiPeriodicSourceStatus());
        }
        else if(!NmiWatchdogSetEnabled(1))
            dprintk("NMI: core enabled; no safe autonomous source (%s).\n",
                    NmiPeriodicSourceStatus());
        return 1;
    }
#else
    (void)BOOTOPT_NMI_ENABLED;
#endif
    nmi_system_enabled=0;
    nmi_watchdog_enabled=0;
    cmos_set_nmi_masked(1);
    (void)apic_set_nmi_enabled(0);
    InstallNmiInterruptGateFallback();
    return 0;
}

int NmiSoftwareSelfTest(void)
{
    DWORD before;
    if(!nmi_system_enabled) return -2;
    before=nmi_software_tests;
    NmiSoftwareTrigger();
    return nmi_software_tests==before+1U ? 0 : -1;
}
int NmiSetUnknownPanic(int enabled) { nmi_panic_on_unknown=enabled?1:0; return nmi_panic_on_unknown; }
int NmiGetUnknownPanic(void) { return nmi_panic_on_unknown; }
int NmiWatchdogSetEnabled(int enabled)
{
    if(enabled && !nmi_system_enabled) return 0;
    if(!enabled)
    {
        nmi_watchdog_enabled=0;
        NmiPeriodicSourceShutdown();
        /* Keep external vector-2 delivery available while the NMI subsystem
         * itself remains enabled. */
        if(nmi_system_enabled)
        {
            (void)apic_set_nmi_enabled(1);
            cmos_set_nmi_masked(0);
        }
        return 0;
    }

    /* NmiPeriodicSourceInit() is conservative on bare metal in buildfix3: it
     * will use the QEMU IB700 source when present, otherwise remain external-
     * NMI-only instead of programming a PMU automatically. */
    if(NmiPeriodicSourceInit()!=0)
    {
        nmi_watchdog_enabled=0;
        return 0;
    }
    nmi_watchdog_enabled=1;
    return 1;
}
int NmiWatchdogSetPmuEnabled(int enabled)
{
    if(!enabled) return NmiWatchdogSetEnabled(0);
    if(!nmi_system_enabled) return 0;
    if(NmiPeriodicSourceForcePmu()!=0)
    {
        nmi_watchdog_enabled=0;
        return 0;
    }
    nmi_watchdog_enabled=1;
    return 1;
}
int NmiWatchdogGetEnabled(void) { return nmi_watchdog_enabled; }
int NmiWatchdogSetForceIf(int enabled)
{
    nmi_watchdog_force_if=enabled?1:0;
    return nmi_watchdog_force_if;
}
int NmiWatchdogGetForceIf(void) { return nmi_watchdog_force_if?1:0; }
int NmiWatchdogSetThreshold(DWORD seconds)
{
    if(seconds<1U || seconds>JTMOS_NMI_WATCHDOG_MAX_SECONDS) return -1;
    nmi_watchdog_threshold=seconds; return 0;
}
DWORD NmiWatchdogGetThreshold(void) { return nmi_watchdog_threshold; }

int NmiWatchdogSetThreadRecoverable(int pid,int enabled)
{
    DWORD flags;
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return -1;
    flags=get_eflags(); disable();
    nmi_thread_recoverable[pid]=enabled?1:0;
    set_eflags(flags); return nmi_thread_recoverable[pid]?1:0;
}
int NmiWatchdogThreadRecoverable(int pid)
{
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    return nmi_thread_recoverable[pid]?1:0;
}
int NmiWatchdogKillTrapPending(int pid)
{
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    return nmi_thread_watchdog_kill_pending[pid]?1:0;
}
void NmiWatchdogKillTrapObserved(int pid)
{
    if(pid<=0 || pid>=N_MAX_THREADS) return;
    /* Leave the slot/suspension intact until ordinary quarantine teardown.
     * Clearing only the one-shot marker avoids mislabeling a later exception. */
    nmi_thread_watchdog_kill_pending[pid]=0;
}

int NmiWatchdogSetThreadAutokill(int pid,int enabled)
{
    DWORD flags;
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    if((int)pid==IdleThread.pid ||
       (thread_type[pid]&(THREAD_TYPE_IMMORTAL|THREAD_TYPE_RESOURCE_OWNER))) return 0;
    flags=get_eflags(); disable();
    nmi_thread_watchdog_autokill[pid]=enabled?1:0;
    set_eflags(flags);
    return nmi_thread_watchdog_autokill[pid]?1:0;
}

int NmiWatchdogThreadAutokill(int pid)
{
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    return nmi_thread_watchdog_autokill[pid]?1:0;
}

void NmiWatchdogResetThread(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;

    /* Do not use CLI as synchronization against NMI. Mark the slot internal
     * while its side-band state is reset, then publish FREE last. */
    __sync_lock_test_and_set(&nmi_rescue_slots[pid].active,JTMOS_NMI_RESCUE_WRITING);
    __sync_synchronize();
    nmi_thread_suspended[pid]=0;
    nmi_thread_recoverable[pid]=0;
    nmi_thread_watchdog_kill_pending[pid]=0;
    nmi_thread_watchdog_autokill[pid]=0;
    thread_rtc_seconds_without_task_switch[pid]=0;
    nmi_rescue_prompt_claimed[pid]=0;
    __sync_synchronize();
    nmi_rescue_slots[pid].active=JTMOS_NMI_RESCUE_FREE;
}

int NmiRescueGetInfo(JTMOS_NMI_RESCUE_INFO *out)
{
    int pid;
    if(!out) return -1;
    pid=nmi_first_rescue();
    if(pid<0) { memset(out,0,sizeof(*out)); return 0; }
    nmi_copy_rescue(out,&nmi_rescue_slots[pid]);
    return 1;
}

int NmiRescueClaimPrompt(JTMOS_NMI_RESCUE_INFO *out)
{
    DWORD flags; int i;
    if(!out) return -1;
    flags=get_eflags(); disable();
    for(i=1;i<nr_threads && i<N_MAX_THREADS;i++)
        if(nmi_rescue_slots[i].active==JTMOS_NMI_RESCUE_PENDING &&
           __sync_bool_compare_and_swap(&nmi_rescue_prompt_claimed[i],0U,1U))
        {
            __sync_synchronize();
            if(nmi_rescue_slots[i].active!=JTMOS_NMI_RESCUE_PENDING)
            {
                nmi_rescue_prompt_claimed[i]=0;
                continue;
            }
            nmi_copy_rescue(out,&nmi_rescue_slots[i]);
            set_eflags(flags); return 1;
        }
    set_eflags(flags); return 0;
}

/* V69.24 NMI Guard Dog stage 2.  This function is deliberately process-context
 * only: the NMI handler merely publishes AUTOKILL + TF/IF.  If #DB already
 * quarantined the target, this completes teardown; if scheduling resumed by
 * the forced IF fallback first, it quarantines the suspended target before
 * freeing anything.  The PID generation token prevents killing a reused slot. */
int NmiGuardDogReapOne(JTMOS_NMI_RESCUE_INFO *out)
{
    int i,me=GetCurrentThread();

    for(i=1;i<nr_threads && i<N_MAX_THREADS;i++)
    {
        volatile JTMOS_NMI_RESCUE_INFO *r=&nmi_rescue_slots[i];
        DWORD magic;

        if(r->active!=JTMOS_NMI_RESCUE_AUTOKILL) continue;
        if(!__sync_bool_compare_and_swap(&r->active,
                                         JTMOS_NMI_RESCUE_AUTOKILL,
                                         JTMOS_NMI_RESCUE_WRITING))
            continue;
        __sync_synchronize();

        magic=r->thread_magic;
        if(i==me)
        {
            __sync_synchronize();
            r->active=JTMOS_NMI_RESCUE_AUTOKILL;
            continue;
        }
        if(r->pid!=(DWORD)i || magic!=(DWORD)thread_magic[i])
        {
            /* A reused/dead PID must never inherit an old watchdog sentence. */
            __sync_synchronize();
            r->active=JTMOS_NMI_RESCUE_FREE;
            continue;
        }
        if(thread_type[i]&(THREAD_TYPE_IMMORTAL|THREAD_TYPE_RESOURCE_OWNER))
        {
            nmi_thread_watchdog_kill_pending[i]=0;
            nmi_thread_suspended[i]=0;
            __sync_synchronize();
            r->active=JTMOS_NMI_RESCUE_FREE;
            continue;
        }

        if(out)
        {
            nmi_copy_rescue(out,r);
            out->active=JTMOS_NMI_RESCUE_AUTOKILL;
        }

        /* The target cannot become runnable again between quarantine and kill:
         * AUTOKILL made it scheduler-suspended, then quarantine clears its
         * runnable state before any resource teardown occurs. */
        if(thread_states[i])
        {
            JTMOS_CRASH_FRAME crash;
            memset(&crash,0,sizeof(crash));
            crash.eip=r->eip; crash.cs=r->cs; crash.eflags=r->eflags;
            crash.authoritative=1;
            crash.from_user=(r->cs&3U)==3U;
            CrashAnalysisCaptureException("(NMI watchdog) process reaped by rescue worker",
                                          1,i,&crash,&tasks->tss[i]);
            CrashAnalysisSetDisposition(i,CRASH_DISPOSITION_QUARANTINE);
        }
        nmi_thread_watchdog_kill_pending[i]=0;
        ThreadQuarantineFromException(i);
        __sync_add_and_fetch(&nmi_watchdog_guarddog_reaps,1U);
        KillThreadEx((DWORD)i,KT_NO_THREAD_SWITCH);
        return 1;
    }
    return 0;
}

static int nmi_rescue_matches(int pid)
{
    volatile JTMOS_NMI_RESCUE_INFO *r;
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    r=&nmi_rescue_slots[pid];
    return nmi_rescue_state_visible(r->active) && r->pid==(DWORD)pid &&
           r->thread_magic==(DWORD)thread_magic[pid];
}

static void nmi_rescue_clear(int pid)
{
    __sync_lock_test_and_set(&nmi_rescue_slots[pid].active,JTMOS_NMI_RESCUE_WRITING);
    __sync_synchronize();
    nmi_thread_suspended[pid]=0;
    thread_rtc_seconds_without_task_switch[pid]=0;
    nmi_rescue_prompt_claimed[pid]=0;
    __sync_synchronize();
    nmi_rescue_slots[pid].active=JTMOS_NMI_RESCUE_FREE;
}

int NmiRescueContinue(int pid)
{
    DWORD flags=get_eflags(); disable();
    if(!nmi_rescue_matches(pid) || !thread_states[pid] ||
       nmi_rescue_slots[pid].active==JTMOS_NMI_RESCUE_AUTOKILL)
    { set_eflags(flags); return -1; }
    nmi_rescue_clear(pid);
    set_eflags(flags); return 0;
}

int NmiRescueKeepSuspended(int pid)
{
    DWORD flags=get_eflags(); disable();
    if(!nmi_rescue_matches(pid)) { set_eflags(flags); return -1; }
    nmi_thread_suspended[pid]=1;
    nmi_rescue_slots[pid].active=JTMOS_NMI_RESCUE_HELD;
    nmi_rescue_prompt_claimed[pid]=0;
    set_eflags(flags); return 0;
}

int NmiRescueKill(int pid)
{
    if(!nmi_rescue_matches(pid)) return -1;
    if(pid==0 ||
       (thread_type[pid]&(THREAD_TYPE_IMMORTAL|THREAD_TYPE_RESOURCE_OWNER))) return -1;
    KillThreadEx((DWORD)pid,KT_NO_THREAD_SWITCH);
    /* KillThreadEx() owns NMI side-band reset while the PID lifecycle lock is
     * held; do not clear again after the slot could have been reused. */
    return 0;
}
