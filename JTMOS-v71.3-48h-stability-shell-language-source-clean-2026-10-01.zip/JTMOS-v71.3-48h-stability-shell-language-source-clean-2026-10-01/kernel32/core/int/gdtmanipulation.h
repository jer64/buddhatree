#ifndef __INCLUDED_GDTMANIPULATION_H__
#define __INCLUDED_GDTMANIPULATION_H__

/* One allocation is two adjacent descriptors (code + data).  Capacity is
 * derived from GDTTAB's actual dynamic tail in int.h. */
#define N_GDTENTS GDT_DYNAMIC_PAIR_COUNT

typedef struct
{
    char isAllocated;
} GDTENT;

typedef struct
{
    int n_gdtEntries;
    GDTENT gdtent[N_GDTENTS];
} GDTENTSYS;

void SetCDEntryEx(DWORD which,DWORD offset,DWORD limit,
                  BYTE access_byte,BYTE gran_flags,int prilev);
void SetCDEntry(DWORD which,DWORD offset,DWORD limit,int prilev);
int NewCDSegment(DWORD offs,DWORD limit,int prilev);
void InitGDTEntryAllocationSystem(void);
void FreeGDTEntry(int which);
int gdt_NewEntry(void);
void SetCallGate(DWORD which,DWORD offset,WORD selector,
                 BYTE access,BYTE options);

extern int kappCodeSeg,kappDataSeg;

#endif
