/* Scheduler-aware shared/exclusive locks for JTMOS V68.219. */
#define JTMOS_RWSEM_IMPLEMENTATION 1
#include "kernel32.h"
#include "rwsem.h"
#include "lock.h"
#include "sync.h"
#include "scheduler.h"
#include "io.h"

typedef struct rwsem_waiter
{
    struct rwsem_waiter *next;
    struct rwsem *lock;
    int pid;
    DWORD magic;
    BYTE write;
    volatile BYTE granted;
    const char *function;
    const char *file;
    int line;
} RWSEM_WAITER;

static RWSEM_WAITER *rwsem_thread_waiter[N_MAX_THREADS];
static volatile BYTE rwsem_thread_blocked[N_MAX_THREADS];
static struct rwsem *rwsem_registry;

#define JTMOS_RWSEM_REGISTRY_LIMIT 1024U

static DWORD rwsem_thread_magic(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return thread_magic[pid];
}

static int rwsem_pid_live(int pid,DWORD magic)
{
    if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    if(!thread_states[pid]) return 0;
    return thread_magic[pid]==magic;
}

static unsigned int rwsem_word(int pid) { return ((unsigned int)pid)>>5; }
static DWORD rwsem_mask(int pid) { return ((DWORD)1)<<(((unsigned int)pid)&31); }

static int rwsem_reader_held_locked(const struct rwsem *lock,int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return (lock->reader_bits[rwsem_word(pid)] & rwsem_mask(pid))!=0;
}

static void rwsem_reader_add_locked(struct rwsem *lock,int pid)
{
    DWORD mask=rwsem_mask(pid);
    unsigned int word=rwsem_word(pid);
    if((lock->reader_bits[word]&mask)==0)
    {
        lock->reader_bits[word]|=mask;
        lock->readers++;
    }
}

static void rwsem_reader_del_locked(struct rwsem *lock,int pid)
{
    DWORD mask=rwsem_mask(pid);
    unsigned int word=rwsem_word(pid);
    if(lock->reader_bits[word]&mask)
    {
        lock->reader_bits[word]&=~mask;
        if(lock->readers) lock->readers--;
    }
}

static int rwsem_registry_find_locked(struct rwsem *wanted,
                                      struct rwsem **previous_out)
{
    struct rwsem *lock,*previous=0;
    unsigned int scanned;
    for(lock=rwsem_registry,scanned=0;
        lock && scanned<JTMOS_RWSEM_REGISTRY_LIMIT;
        lock=lock->registry_next,scanned++)
    {
        if(lock==wanted)
        {
            if(previous_out) *previous_out=previous;
            return 1;
        }
        if(lock->registry_next==lock) return -1;
        previous=lock;
    }
    if(lock) return -1;
    if(previous_out) *previous_out=0;
    return 0;
}

static int rwsem_registry_remove_locked(struct rwsem *lock)
{
    struct rwsem *previous,*next;
    int found=rwsem_registry_find_locked(lock,&previous);
    if(found<=0) return found;
    next=lock->registry_next;
    if(next==lock) next=0;
    if(previous) previous->registry_next=next;
    else rwsem_registry=next;
    lock->registry_next=0;
    lock->registered=0;
    return 1;
}

static int rwsem_register_locked(struct rwsem *lock)
{
    int found=rwsem_registry_find_locked(lock,0);
    if(found<0) return -1;
    if(found>0)
    {
        lock->registered=1;
        return 0;
    }
    lock->registry_next=rwsem_registry;
    rwsem_registry=lock;
    lock->registered=1;
    return 0;
}

static void rwsem_clear_writer_locked(struct rwsem *lock)
{
    lock->writer_pid=-1;
    lock->writer_magic=0;
    lock->writer_function=0;
    lock->writer_file=0;
    lock->writer_line=0;
    lock->acquired_ms=0;
}

static int rwsem_waiter_live_locked(RWSEM_WAITER *waiter,struct rwsem *lock)
{
    int pid;
    if(!waiter || waiter->lock!=lock) return 0;
    pid=waiter->pid;
    if(!rwsem_pid_live(pid,waiter->magic)) return 0;
    if(!rwsem_thread_blocked[pid] || rwsem_thread_waiter[pid]!=waiter) return 0;
    return 1;
}

static int rwsem_remove_waiter_locked(struct rwsem *lock,RWSEM_WAITER *wanted)
{
    RWSEM_WAITER *w,*previous=0;
    for(w=(RWSEM_WAITER *)lock->wait_head;w;w=w->next)
    {
        if(w==wanted)
        {
            if(previous) previous->next=w->next;
            else lock->wait_head=w->next;
            if(lock->wait_tail==w) lock->wait_tail=previous;
            if(lock->waiters) lock->waiters--;
            if(w->write && lock->waiting_writers) lock->waiting_writers--;
            w->next=0;
            return 1;
        }
        previous=w;
    }
    return 0;
}

static RWSEM_WAITER *rwsem_pop_live_locked(struct rwsem *lock)
{
    RWSEM_WAITER *w;
    int pid;
    while((w=(RWSEM_WAITER *)lock->wait_head)!=0)
    {
        lock->wait_head=w->next;
        if(lock->wait_tail==w) lock->wait_tail=0;
        if(lock->waiters) lock->waiters--;
        if(w->write && lock->waiting_writers) lock->waiting_writers--;
        w->next=0;
        if(rwsem_waiter_live_locked(w,lock)) return w;
        pid=w->pid;
        if(pid>=0 && pid<N_MAX_THREADS && rwsem_thread_waiter[pid]==w)
        {
            rwsem_thread_waiter[pid]=0;
            rwsem_thread_blocked[pid]=0;
        }
    }
    return 0;
}

/* Strict FIFO at writer boundaries; consecutive readers at the queue head are
 * granted as one shared batch. Caller holds the IRQ-save critical section. */
static int rwsem_grant_locked(struct rwsem *lock)
{
    RWSEM_WAITER *w;
    int granted=0,pid;

    if(lock->writer_pid!=-1 || lock->readers!=0) return 0;
    w=rwsem_pop_live_locked(lock);
    if(!w) return 0;

    if(w->write)
    {
        pid=w->pid;
        lock->writer_pid=pid;
        lock->writer_magic=w->magic;
        lock->writer_function=w->function;
        lock->writer_file=w->file;
        lock->writer_line=w->line;
        lock->acquired_ms=GetTickCount();
        rwsem_thread_waiter[pid]=0;
        rwsem_thread_blocked[pid]=0;
        io_memory_barrier();
        w->granted=1;
        SchedulerWakeThread(pid);
        return 1;
    }

    for(;;)
    {
        pid=w->pid;
        rwsem_reader_add_locked(lock,pid);
        rwsem_thread_waiter[pid]=0;
        rwsem_thread_blocked[pid]=0;
        io_memory_barrier();
        w->granted=1;
        SchedulerWakeThread(pid);
        granted++;

        w=(RWSEM_WAITER *)lock->wait_head;
        if(!w || w->write) break;
        w=rwsem_pop_live_locked(lock);
        if(!w) break;
        if(w->write)
        {
            /* Should be unreachable because the head was checked above. */
            w->next=(RWSEM_WAITER *)lock->wait_head;
            lock->wait_head=w;
            if(!lock->wait_tail) lock->wait_tail=w;
            lock->waiters++;
            lock->waiting_writers++;
            break;
        }
    }
    return granted;
}

void rwsem_init(struct rwsem *lock)
{
    int flags,i,found,busy;
    if(!lock) return;
    flags=get_eflags(); disable();
    found=rwsem_registry_find_locked(lock,0);
    busy=found>0 && (lock->writer_pid!=-1 || lock->readers ||
                     lock->wait_head || lock->wait_tail || lock->waiters ||
                     lock->waiting_writers);
    if(found<0 || busy)
    {
        set_eflags(flags);
        dprintk("[RWSEM] init rejected lock=%x reason=%s\n",
                (unsigned long)lock,found<0 ? "registry-corrupt" : "busy");
        return;
    }
    if(found>0) (void)rwsem_registry_remove_locked(lock);
    lock->writer_pid=-1;
    lock->writer_magic=0;
    lock->readers=0;
    for(i=0;i<JTMOS_RWSEM_READER_WORDS;i++) lock->reader_bits[i]=0;
    lock->wait_head=0; lock->wait_tail=0; lock->waiters=0; lock->waiting_writers=0;
    lock->name="<dynamic>";
    lock->writer_function=0; lock->writer_file=0; lock->writer_line=0; lock->acquired_ms=0;
    lock->registry_next=0; lock->registered=0;
    set_eflags(flags);
}

int rwsem_destroy(struct rwsem *lock)
{
    int flags,removed;
    if(!lock) return -1;
    flags=get_eflags(); disable();
    if(lock->writer_pid!=-1 || lock->readers || lock->wait_head ||
       lock->wait_tail || lock->waiters || lock->waiting_writers)
    { set_eflags(flags); return -1; }
    removed=rwsem_registry_remove_locked(lock);
    if(removed<0) { set_eflags(flags); return -1; }
    lock->registry_next=0; lock->registered=0;
    set_eflags(flags);
    return 0;
}

static void rwsem_queue_and_sleep(struct rwsem *lock,BYTE write,
                                  const char *function,const char *file,int line,
                                  int flags,int pid)
{
    RWSEM_WAITER waiter;
    int waitcheck=JtSyncBlockingWaitCheck(pid,flags);
    if(waitcheck!=JTMOS_SYNC_WAIT_OK)
    {
        set_eflags(flags);
        dprintk("[RWSEM] cannot-block lock=%x name=%s pid=%d mode=%s reason=%s IF=%d\n",
                (unsigned long)lock,lock->name ? lock->name : "?",pid,
                write ? "write" : "read",JtSyncBlockingWaitReason(waitcheck),
                (flags&0x200)?1:0);
        if(waitcheck==JTMOS_SYNC_WAIT_ATOMIC)
            KERNEL_FATAL(write ? "rwsem: write contention in atomic context" :
                                 "rwsem: read contention in atomic context");
        KERNEL_FATAL("rwsem: thread already has a blocking wait");
    }
    memset(&waiter,0,sizeof(waiter));
    waiter.lock=lock; waiter.pid=pid; waiter.magic=rwsem_thread_magic(pid);
    waiter.write=write; waiter.function=function; waiter.file=file; waiter.line=line;
    if(lock->wait_tail) ((RWSEM_WAITER *)lock->wait_tail)->next=&waiter;
    else lock->wait_head=&waiter;
    lock->wait_tail=&waiter;
    lock->waiters++;
    if(write) lock->waiting_writers++;
    rwsem_thread_waiter[pid]=&waiter;
    rwsem_thread_blocked[pid]=1;
    set_eflags(flags);
    while(!waiter.granted) SwitchToThread();
    io_memory_barrier();
}

void rwsem_down_read_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid;
    if(!lock) KERNEL_FATAL("rwsem_down_read: NULL");
    pid=GetCurrentThread();
    if(pid<0 || pid>=N_MAX_THREADS) KERNEL_FATAL("rwsem_down_read: invalid PID");
    flags=get_eflags(); disable();
    if(rwsem_register_locked(lock)!=0)
    { set_eflags(flags); KERNEL_FATAL("rwsem_down_read: registry corrupt"); }
    if(rwsem_reader_held_locked(lock,pid) ||
       (lock->writer_pid==pid && lock->writer_magic==rwsem_thread_magic(pid)))
    { set_eflags(flags); KERNEL_FATAL("rwsem_down_read: recursive/owner acquisition"); }
    if(lock->writer_pid==-1 && lock->wait_head==0)
    {
        rwsem_reader_add_locked(lock,pid);
        set_eflags(flags);
        return;
    }
    rwsem_queue_and_sleep(lock,0,function,file,line,flags,pid);
}

int rwsem_down_read_trylock_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid,ok=0;
    (void)function; (void)file; (void)line;
    if(!lock) return 0;
    pid=GetCurrentThread(); if(pid<0 || pid>=N_MAX_THREADS) return 0;
    flags=get_eflags(); disable();
    if(rwsem_register_locked(lock)!=0) { set_eflags(flags); return 0; }
    if(!rwsem_reader_held_locked(lock,pid) && lock->writer_pid==-1 && lock->wait_head==0)
    { rwsem_reader_add_locked(lock,pid); ok=1; }
    set_eflags(flags); return ok;
}

void rwsem_up_read_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid;
    (void)function; (void)file; (void)line;
    if(!lock) return;
    pid=GetCurrentThread();
    flags=get_eflags(); disable();
    if(pid<0 || pid>=N_MAX_THREADS || !rwsem_reader_held_locked(lock,pid))
    { set_eflags(flags); dprintk("[RWSEM] bad read unlock lock=%x pid=%d\n",(unsigned long)lock,pid); return; }
    rwsem_reader_del_locked(lock,pid);
    if(lock->readers==0) (void)rwsem_grant_locked(lock);
    set_eflags(flags);
}

void rwsem_down_write_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid;
    if(!lock) KERNEL_FATAL("rwsem_down_write: NULL");
    pid=GetCurrentThread();
    if(pid<0 || pid>=N_MAX_THREADS) KERNEL_FATAL("rwsem_down_write: invalid PID");
    flags=get_eflags(); disable();
    if(rwsem_register_locked(lock)!=0)
    { set_eflags(flags); KERNEL_FATAL("rwsem_down_write: registry corrupt"); }
    if(rwsem_reader_held_locked(lock,pid) ||
       (lock->writer_pid==pid && lock->writer_magic==rwsem_thread_magic(pid)))
    { set_eflags(flags); KERNEL_FATAL("rwsem_down_write: recursive/upgrade acquisition"); }
    if(lock->writer_pid==-1 && lock->readers==0 && lock->wait_head==0)
    {
        lock->writer_pid=pid; lock->writer_magic=rwsem_thread_magic(pid);
        lock->writer_function=function; lock->writer_file=file; lock->writer_line=line;
        lock->acquired_ms=GetTickCount();
        set_eflags(flags); return;
    }
    rwsem_queue_and_sleep(lock,1,function,file,line,flags,pid);
}

int rwsem_down_write_trylock_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid,ok=0;
    if(!lock) return 0;
    pid=GetCurrentThread(); if(pid<0 || pid>=N_MAX_THREADS) return 0;
    flags=get_eflags(); disable();
    if(rwsem_register_locked(lock)!=0) { set_eflags(flags); return 0; }
    if(!rwsem_reader_held_locked(lock,pid) && lock->writer_pid==-1 &&
       lock->readers==0 && lock->wait_head==0)
    {
        lock->writer_pid=pid; lock->writer_magic=rwsem_thread_magic(pid);
        lock->writer_function=function; lock->writer_file=file; lock->writer_line=line;
        lock->acquired_ms=GetTickCount(); ok=1;
    }
    set_eflags(flags); return ok;
}

void rwsem_up_write_at(struct rwsem *lock,const char *function,const char *file,int line)
{
    int flags,pid;
    (void)function; (void)file; (void)line;
    if(!lock) return;
    pid=GetCurrentThread(); flags=get_eflags(); disable();
    if(lock->writer_pid!=pid || lock->writer_magic!=rwsem_thread_magic(pid))
    { set_eflags(flags); dprintk("[RWSEM] bad write unlock lock=%x pid=%d owner=%d\n",(unsigned long)lock,pid,lock->writer_pid); return; }
    rwsem_clear_writer_locked(lock);
    (void)rwsem_grant_locked(lock);
    set_eflags(flags);
}

unsigned int rwsem_reader_count(const struct rwsem *lock)
{
    int flags; unsigned int n;
    if(!lock) return 0;
    flags=get_eflags(); disable(); n=lock->readers; set_eflags(flags); return n;
}

int rwsem_writer(const struct rwsem *lock)
{
    int flags,pid;
    if(!lock) return -1;
    flags=get_eflags(); disable(); pid=lock->writer_pid; set_eflags(flags); return pid;
}

int JtRwsemThreadBlocked(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return rwsem_thread_blocked[pid] ? 1 : 0;
}

const char *JtRwsemThreadWaitName(int pid)
{
    RWSEM_WAITER *w;
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    w=rwsem_thread_waiter[pid];
    return (w && w->lock && w->lock->name) ? w->lock->name : 0;
}

void JtRwsemThreadCleanup(int pid)
{
    struct rwsem *lock;
    RWSEM_WAITER *w;
    int flags,registry_corrupt=0;
    unsigned int scanned;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags(); disable();
    w=rwsem_thread_waiter[pid];
    if(w)
    {
        lock=w->lock;
        if(lock) (void)rwsem_remove_waiter_locked(lock,w);
        rwsem_thread_waiter[pid]=0; rwsem_thread_blocked[pid]=0;
    }
    for(lock=rwsem_registry,scanned=0;
        lock && scanned<JTMOS_RWSEM_REGISTRY_LIMIT;
        lock=lock->registry_next,scanned++)
    {
        if(lock->writer_pid==pid)
        {
            rwsem_clear_writer_locked(lock);
            (void)rwsem_grant_locked(lock);
        }
        if(rwsem_reader_held_locked(lock,pid))
        {
            rwsem_reader_del_locked(lock,pid);
            if(lock->readers==0) (void)rwsem_grant_locked(lock);
        }
    }
    if(lock) registry_corrupt=1;
    set_eflags(flags);
    if(registry_corrupt)
        dprintk("[RWSEM] cleanup stopped at corrupt registry pid=%d\n",pid);
}

void JtRwsemThreadInit(int pid)
{
    JtRwsemThreadCleanup(pid);
}
