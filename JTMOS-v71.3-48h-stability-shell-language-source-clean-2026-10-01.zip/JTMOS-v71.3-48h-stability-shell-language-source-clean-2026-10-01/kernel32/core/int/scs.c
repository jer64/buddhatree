// ======================================================================
// scs.c - JTMOS system call services.
// (C) 2002-2021 by Jari Tuominen
// (jari.t.tuominen@gmail.com).
//
// Note: all system calls implement it's callers stack,
// therefore all pointer references to the local variables,
// that are stored in the present stack are either invalid
// or must be specifically converted from USER memory space
// addressing to the KERNEL memory space addressing.
//
// This is a major bug that have been raging the system
// for a very long time.
// ======================================================================
#include "kernel32.h"
#include "systemcalls.h" // aka scs.h
#include "scconf.h" // contains only defines, works with nasm
#include "ega.h" // N_VIRTUAL_TERMINALS
#include "threads.h" // SwitchToThreadEx
#include "scs.h"
#include "scs2.h"
#include "scs_devices.h" // sys_readblock, etc.
#include "mouse.h"
#include "ps2mouse.h"
#include "msgbox.h"
#include "driver_diskchange.h"
#include "jtmfat.h"
#include "jtmfsAccess.h"
#include "jtmfsPath.h"
#include "directfileaccess.h"
#include "serial.h"
#include "scheduler.h"
#include "audio.h"
#include "userhw.h"
#include "sysgfx.h"
#include "vga.h"
#include "int.h"
#include "linuxabi.h"
#include "sys/mman.h"
#include "process_vm_lock.h"
#include "bootutilsram.h"
#include "sh.h"
#include "jt_usersock.h"
#include "jnet.h"
#include "jtmos/fsusage.h"
#include "diskspace.h"
#include "fsdos.h" /* canonical SYS_findfirst/findnext FFBLK ABI */
#include "term.h"
#include "fs/api.h"
#include "_stat.h"
#include "rtc.h"

int scall_dprintk(SYSCALLPAR);
int scall_freeterminal(SYSCALLPAR);

/* Last physical PS/2 packet observed by each raw-mouse syscall consumer.
 * Merely polling SYS_inputmouse does not count as activity; a process is
 * rewarded only when a new packet has actually arrived since its last read. */
static DWORD scall_mouse_seen_packets[N_MAX_THREADS];

/* SYS_fsusage (156): read-only JTMFS capacity information for df(1). */
int scall_fsusage(SYSCALLPAR)
{
    JTMOS_FSUSAGE *u;
    JTMOS_FSUSAGE out;
    JTMOS_DISKSPACE_STATS st;
    int dnr=(int)scall_ebx;

    if(!isValidDevice(dnr) || !jtmfat_isJTMFS(dnr)) return -ENODEV;
    if(DiskSpaceGetStats(dnr,&st,1)!=0 || !(st.flags&DISKSPACE_FLAG_JTMFS) ||
       st.total_units==0 || st.unit_size==0 || st.free_units>st.total_units)
        return -EIO;
    u=(JTMOS_FSUSAGE *)A2KRange(scall_ecx,sizeof(JTMOS_FSUSAGE));
    if(u==NULL) return -EFAULT;
    out.total_units=st.total_units;
    out.free_units=st.free_units;
    out.unit_size=st.unit_size;
    out.flags=JTMOS_FSUSAGE_JTMFS;
    memcpy(u,&out,sizeof(out));
    return 0;
}

/* SYS_smsh_builtin (153): execute one explicitly whitelisted SMSH builtin.
 * EBX points to a userspace command line.  This is deliberately not a generic
 * ring0 shell escape; smsh_execute_builtin_text() enforces the command list. */
int scall_smsh_builtin(SYSCALLPAR)
{
    const char *src=(const char *)A2K(scall_ebx);
    char line[1024];
    unsigned int i;
    int rc;
    if(src==NULL) return -1;
    for(i=0;i<sizeof(line)-1U;i++) {
        char c=src[i];
        line[i]=c;
        if(c=='\0') break;
    }
    if(i==sizeof(line)-1U) return -2;
    line[sizeof(line)-1U]='\0';

    /* V68.166: SYS_smsh_builtin is SCALL_IRQ_ON in the central dispatcher
     * policy.  By the time this service is entered, normal application callers
     * therefore have IRQ0/IRQ1/device interrupts live.  Do not issue a second
     * unconditional STI here: a kernel caller that entered INT 0x7F with IF=0
     * must retain that atomic contract. */
    rc=smsh_execute_builtin_text(line);
    return rc;
}


/* SYS_env (154): POSIX process environment + JTMOS system-global environment.
 * EBX=operation; remaining registers are operation-specific.  Query calls may
 * pass output capacity 0 to obtain the required string length without copy. */
#define SCALL_ENV_NAME_MAX 256U
#define SCALL_ENV_VALUE_MAX 16384U

static int scall_env_copyin(DWORD address,char *out,DWORD capacity)
{
    DWORD i;
    char *p;
    if(!address || !out || capacity<2) return -EFAULT;
    for(i=0;i<capacity;i++) {
        p=(char *)A2KRange(address+i,1);
        if(p==NULL) return -EFAULT;
        out[i]=*p;
        if(out[i]==0) return (int)i;
    }
    out[capacity-1]=0;
    return -ENAMETOOLONG;
}

static int scall_env_copyout(const char *src,DWORD address,DWORD capacity)
{
    DWORD len;
    void *dst;
    if(src==NULL) return -ENOENT;
    len=(DWORD)strlen(src);
    if(capacity==0) return (int)len;
    if(len+1U>capacity) return -ERANGE;
    dst=(void *)A2KRange(address,capacity);
    if(dst==NULL) return -EFAULT;
    memcpy(dst,src,len+1U);
    return (int)len;
}

int scall_env(SYSCALLPAR)
{
    int op=(int)scall_ebx;
    int pid=GetCurrentThread();
    char name[SCALL_ENV_NAME_MAX];
    char *value;
    const char *entry;
    int rc;
    DWORD cap;

    switch(op) {
    case JTMOS_ENV_COUNT_LOCAL:
        return ProcessEnvCount(pid);
    case JTMOS_ENV_COUNT_GLOBAL:
        return kenv ? envdb_Count(kenv) : 0;
    case JTMOS_ENV_ENTRY_LOCAL:
        entry=ProcessEnvEntry(pid,(int)scall_ecx);
        return scall_env_copyout(entry,scall_edx,scall_esi);
    case JTMOS_ENV_ENTRY_GLOBAL:
        entry=kenv ? envdb_EntryAt(kenv,(int)scall_ecx) : NULL;
        return scall_env_copyout(entry,scall_edx,scall_esi);
    default:
        break;
    }

    rc=scall_env_copyin(scall_ecx,name,sizeof(name));
    if(rc<0) return rc;
    if(!envdb_ValidName(name)) return -EINVAL;

    if(op==JTMOS_ENV_UNSET_LOCAL) return ProcessEnvUnset(pid,name);
    if(op==JTMOS_ENV_UNSET_GLOBAL) return kunsetglobalenv(name);

    if(op==JTMOS_ENV_GET_LOCAL || op==JTMOS_ENV_GET_GLOBAL) {
        const char *v;
        if(op==JTMOS_ENV_GET_LOCAL) {
            ENVDB *e=ProcessEnvGetDB(pid,1);
            v=envdb_GetValuePtr(e,name);
        } else v=kgetglobalenv_ptr(name);
        return scall_env_copyout(v,scall_edx,scall_esi);
    }

    if(op==JTMOS_ENV_SET_LOCAL || op==JTMOS_ENV_SET_GLOBAL) {
        /* Value strings are dynamically stored; this syscall cap only bounds
         * one untrusted userspace copy operation. */
        cap=SCALL_ENV_VALUE_MAX;
        value=(char *)malloc(cap);
        if(value==NULL) return -ENOMEM;
        rc=scall_env_copyin(scall_edx,value,cap);
        if(rc>=0) {
            if(op==JTMOS_ENV_SET_LOCAL)
                rc=ProcessEnvSet(pid,name,value,scall_esi?1:0);
            else
                rc=ksetglobalenv(name,value,scall_esi?1:0);
        }
        free(value);
        return rc;
    }
    return -EINVAL;
}


/* SYS_resolvehost4 (155): resolve one IPv4 A record through the JNet owner.
 * EBX=userspace hostname, ECX=userspace DWORD output, EDX=timeout ms. */
int scall_resolvehost4(SYSCALLPAR)
{
#if JTMOS_MOD_NETWORK
    char name[254];
    JNET_HOST_RESULT hr;
    BYTE *dst;
    DWORD i,timeout=scall_edx?scall_edx:3000UL;
    int rv;
    if(!scall_ebx || !scall_ecx) return -EINVAL;
    for(i=0;i<sizeof(name);i++) {
        char *p=(char *)A2KRange(scall_ebx+i,1);
        if(!p) return -EFAULT;
        name[i]=*p;
        if(name[i]==0) break;
    }
    if(i==0 || i>=sizeof(name)-1U) return -EINVAL;
    rv=jnet_host_request(name,timeout,&hr);
    if(rv<0) return rv;
    if(hr.count<1) return -2;
    dst=(BYTE *)A2KRange(scall_ecx,4);
    if(!dst) return -EFAULT;
    memcpy(dst,hr.addr[0],4);
    return 0;
#else
    return -ENOSYS;
#endif
}

//
/* V69.37 diagnostics: when the dispatcher deliberately enabled IRQs for a
 * syscall body, the handler is expected to return with IF still set.  The
 * assembly exit path records violations before forcing CLI for frame restore. */
volatile DWORD scall_irq_unexpected_off_count=0;
volatile DWORD scall_irq_unexpected_off_last=0xffffffffUL;

/*
 * INT 0x7F is an interrupt gate, therefore IF is clear when a syscall
 * reaches scall_handler.  V69.37 audits every public syscall slot through
 * SYS_hdbench (168).  For normal Ring3 callers the dispatcher reenables IF
 * only for the handler body, then forces CLI for the common return path.
 *
 * The assembly dispatcher applies STI only after the target function has
 * been resolved and all seven C arguments have been pushed on the current
 * task stack.  This ordering is mandatory because scall_eax/.../scall_tmp1
 * are legacy global dispatch scratch and must not be exposed to another
 * task before dispatch state is private.  STI has a one-instruction shadow,
 * so the following CALL executes before an IRQ can be accepted.
 *
 * ON is the normal policy: pure queries plus blocking I/O, filesystem, network,
 * sleep, audio, memory-management and process-wait services keep IRQ0/IRQ1/
 * device IRQs live.  Shared metadata updates use local irq_save()/irq_restore().
 * Subsystems protect their own short hardware/data critical sections with
 * irq_save()/irq_restore().  OFF is reserved for the few operations whose
 * current implementation still needs the whole syscall dispatch atomically.
 * IRET restores the userspace EFLAGS in either case.
 */
#define SCALL_IRQ_OFF 0
#define SCALL_IRQ_ON  1
const unsigned char scall_irq_policy[N_MAX_SCALLS] = {
    /*   0 scall_dummy                        - dummy/unimplemented */ SCALL_IRQ_OFF,
    /*   1 idle_moment                        */ SCALL_IRQ_ON,
    /*   2 scall_remove                       */ SCALL_IRQ_ON,
    /*   3 scall_mkfs                         */ SCALL_IRQ_ON,
    /*   4 scall_rename                       */ SCALL_IRQ_ON,
    /*   5 scall_dummy                        - dummy/unimplemented */ SCALL_IRQ_OFF,
    /*   6 scall_puts                         */ SCALL_IRQ_ON,
    /*   7 scall_putchar                      */ SCALL_IRQ_ON,
    /*   8 scall_exit                         - current-task teardown and scheduler handoff */ SCALL_IRQ_OFF,
    /*   9 scall_clrscr                       */ SCALL_IRQ_ON,
    /*  10 scall_getch                        */ SCALL_IRQ_ON,
    /*  11 scall_postcmd                      */ SCALL_IRQ_ON,
    /*  12 scall_getcurdev                    */ SCALL_IRQ_ON,
    /*  13 scall_gotoxy                       */ SCALL_IRQ_ON,
    /*  14 scall_gettickcount                 */ SCALL_IRQ_ON,
    /*  15 scall_getamemsize                  */ SCALL_IRQ_ON,
    /*  16 scall_getcurrentthread             */ SCALL_IRQ_ON,
    /*  17 scall_getargc                      */ SCALL_IRQ_ON,
    /*  18 scall_getargv                      */ SCALL_IRQ_ON,
    /*  19 scall_open                         */ SCALL_IRQ_ON,
    /*  20 scall_close                        */ SCALL_IRQ_ON,
    /*  21 scall_read                         */ SCALL_IRQ_ON,
    /*  22 scall_write                        */ SCALL_IRQ_ON,
    /*  23 scall_lseek                        */ SCALL_IRQ_ON,
    /*  24 scall_cexec                        */ SCALL_IRQ_ON,
    /*  25 scall_getdevnrbyname               */ SCALL_IRQ_ON,
    /*  26 scall_readblock                    */ SCALL_IRQ_ON,
    /*  27 scall_writeblock                   */ SCALL_IRQ_ON,
    /*  28 scall_waitprocterm                 */ SCALL_IRQ_ON,
    /*  29 scall_findfirst                    */ SCALL_IRQ_ON,
    /*  30 scall_findnext                     */ SCALL_IRQ_ON,
    /*  31 scall_textcolor                    */ SCALL_IRQ_ON,
    /*  32 scall_textbackground               */ SCALL_IRQ_ON,
    /*  33 scall_inputmouse                   */ SCALL_IRQ_ON,
    /*  34 scall_setmouserect                 */ SCALL_IRQ_ON,
    /*  35 scall_vgadrawframe                 */ SCALL_IRQ_ON,
    /*  36 scall_getcurdb                     */ SCALL_IRQ_ON,
    /*  37 scall_vgawaitretrace               */ SCALL_IRQ_ON,
    /*  38 scall_chdir                        */ SCALL_IRQ_ON,
    /*  39 scall_getdevicename                */ SCALL_IRQ_ON,
    /*  40 scall_getdate                      */ SCALL_IRQ_ON,
    /*  41 scall_wherex                       */ SCALL_IRQ_ON,
    /*  42 scall_wherey                       */ SCALL_IRQ_ON,
    /*  43 scall_vgaselectplane               */ SCALL_IRQ_ON,
    /*  44 scall_getdevicenrbyname            */ SCALL_IRQ_ON,
    /*  45 scall_getthreadpriority            */ SCALL_IRQ_ON,
    /*  46 scall_getthreadspending            */ SCALL_IRQ_ON,
    /*  47 scall_getthreadname                */ SCALL_IRQ_ON,
    /*  48 scall_getthreadmemoryusage         */ SCALL_IRQ_ON,
    /*  49 scall_getthreadcount               */ SCALL_IRQ_ON,
    /*  50 scall_getctrl                      */ SCALL_IRQ_ON,
    /*  51 scall_getalt                       */ SCALL_IRQ_ON,
    /*  52 scall_activatemsgbox               */ SCALL_IRQ_ON,
    /*  53 scall_sendmessage                  */ SCALL_IRQ_ON,
    /*  54 scall_receivemessage               */ SCALL_IRQ_ON,
    /*  55 scall_getthreadpid                 */ SCALL_IRQ_ON,
    /*  56 scall_identifythread               */ SCALL_IRQ_ON,
    /*  57 scall_getseconds                   */ SCALL_IRQ_ON,
    /*  58 scall_globalcopy                   */ SCALL_IRQ_ON,
    /*  59 scall_getthreadterminal            */ SCALL_IRQ_ON,
    /*  60 scall_setthreadterminal            */ SCALL_IRQ_ON,
    /*  61 scall_newterminal                  */ SCALL_IRQ_ON,
    /*  62 scall_outputterminalkeyboardbuffer */ SCALL_IRQ_ON,
    /*  63 scall_inputterminalkeyboardbuffer  */ SCALL_IRQ_ON,
    /*  64 scall_copyterminal                 */ SCALL_IRQ_ON,
    /*  65 scall_killthread                   - task teardown mutates scheduler/process tables */ SCALL_IRQ_OFF,
    /*  66 scall_getcursorlocation            */ SCALL_IRQ_ON,
    /*  67 scall_setint                       - legacy direct interrupt-database mutation has no internal lock */ SCALL_IRQ_OFF,
    /*  68 scall_enableirq                    - legacy direct PIC-mask mutation */ SCALL_IRQ_OFF,
    /*  69 scall_diskchange                   */ SCALL_IRQ_ON,
    /*  70 scall_getthreaduniquepid           */ SCALL_IRQ_ON,
    /*  71 scall_registernewdevice            - device-registry publication has no internal lock */ SCALL_IRQ_OFF,
    /*  72 scall_switchtothreadex             - explicit hardware task switch */ SCALL_IRQ_OFF,
    /*  73 scall_createterminal               */ SCALL_IRQ_ON,
    /*  74 scall_setterminalowner             */ SCALL_IRQ_ON,
    /*  75 scall_getterminalowner             */ SCALL_IRQ_ON,
    /*  76 scall_serialget                    */ SCALL_IRQ_ON,
    /*  77 scall_serialput                    */ SCALL_IRQ_ON,
    /*  78 scall_setserialportspeed           */ SCALL_IRQ_ON,
    /*  79 scall_receiverawpacket             */ SCALL_IRQ_ON,
    /*  80 scall_transmitrawpacket            */ SCALL_IRQ_ON,
    /*  81 scall_devicecall                   */ SCALL_IRQ_ON,
    /*  82 scall_milsleep                     */ SCALL_IRQ_ON,
    /*  83 scall_opensocket                   */ SCALL_IRQ_ON,
    /*  84 scall_closesocket                  */ SCALL_IRQ_ON,
    /*  85 scall_readsocket                   */ SCALL_IRQ_ON,
    /*  86 scall_writesocket                  */ SCALL_IRQ_ON,
    /*  87 scall_switchtothread               - explicit hardware task switch */ SCALL_IRQ_OFF,
    /*  88 scall_getcwd                       */ SCALL_IRQ_ON,
    /*  89 scall_stat                         */ SCALL_IRQ_ON,
    /*  90 scall_fstat                        */ SCALL_IRQ_ON,
    /*  91 scall_wgetch                       */ SCALL_IRQ_ON,
    /*  92 scall_mkdir                        */ SCALL_IRQ_ON,
    /*  93 scall_kmalloc                      */ SCALL_IRQ_ON,
    /*  94 scall_kfree                        */ SCALL_IRQ_ON,
    /*  95 scall_fexist1                      */ SCALL_IRQ_ON,
    /*  96 scall_getfiledatablock             */ SCALL_IRQ_ON,
    /*  97 scall_isdriveready                 */ SCALL_IRQ_ON,
    /*  98 scall_diskchange                   */ SCALL_IRQ_ON,
    /*  99 scall_getfilesize                  */ SCALL_IRQ_ON,
    /* 100 scall_read1                        */ SCALL_IRQ_ON,
    /* 101 scall_write1                       */ SCALL_IRQ_ON,
    /* 102 scall_creat1                       */ SCALL_IRQ_ON,
    /* 103 scall_unlink1                      */ SCALL_IRQ_ON,
    /* 104 scall_setsize                      */ SCALL_IRQ_ON,
    /* 105 scall_getcpustats                  */ SCALL_IRQ_ON,
    /* 106 scall_usleep                       */ SCALL_IRQ_ON,
    /* 107 scall_audioinit                    */ SCALL_IRQ_ON,
    /* 108 scall_audiowrite                   */ SCALL_IRQ_ON,
    /* 109 scall_audioposition                */ SCALL_IRQ_ON,
    /* 110 scall_audiostop                    */ SCALL_IRQ_ON,
    /* 111 scall_audioinfo                    */ SCALL_IRQ_ON,
    /* 112 scall_audioselect                  */ SCALL_IRQ_ON,
    /* 113 scall_window                       */ SCALL_IRQ_ON,
    /* 114 scall_copyfromthread               */ SCALL_IRQ_ON,
    /* 115 scall_irqsubscribe                 */ SCALL_IRQ_ON,
    /* 116 scall_irqunsubscribe               */ SCALL_IRQ_ON,
    /* 117 scall_irqwait                      */ SCALL_IRQ_ON,
    /* 118 scall_dmaalloc                     */ SCALL_IRQ_ON,
    /* 119 scall_dmafree                      */ SCALL_IRQ_ON,
    /* 120 scall_dmaprogram                   */ SCALL_IRQ_ON,
    /* 121 scall_dmastop                      */ SCALL_IRQ_ON,
    /* 122 scall_vgasetpalette                */ SCALL_IRQ_ON,
    /* 123 scall_getcpufeatures               */ SCALL_IRQ_ON,
    /* 124 scall_graosgraphics                - long physical display transition; internal lock protects handoff */ SCALL_IRQ_ON,
    /* 125 scall_readblocks                   */ SCALL_IRQ_ON,
    /* 126 scall_writeblocks                  */ SCALL_IRQ_ON,
    /* 127 scall_fork                         */ SCALL_IRQ_ON,
    /* 128 scall_getppid                      */ SCALL_IRQ_ON,
    /* 129 scall_waitpid                      */ SCALL_IRQ_ON,
    /* 130 scall_kill_posix                   - POSIX kill may tear down another task synchronously */ SCALL_IRQ_OFF,
    /* 131 scall_sigdisp                      */ SCALL_IRQ_ON,
    /* 132 scall_pipe                         - V69.37 FDDB publication is locally atomic */ SCALL_IRQ_ON,
    /* 133 scall_poll                         */ SCALL_IRQ_ON,
    /* 134 scall_nice                         - V69.37 priority RMW has a local IRQ transaction */ SCALL_IRQ_ON,
    /* 135 scall_getpriority_posix            */ SCALL_IRQ_ON,
    /* 136 scall_setpriority_posix            - V69.37 priority update has a local IRQ transaction */ SCALL_IRQ_ON,
    /* 137 scall_uname                        */ SCALL_IRQ_ON,
    /* 138 scall_sysinfo                      */ SCALL_IRQ_ON,
    /* 139 scall_filebuf_read                 */ SCALL_IRQ_ON,
    /* 140 scall_filebuf_write                */ SCALL_IRQ_ON,
    /* 141 scall_filebuf_flush                */ SCALL_IRQ_ON,
    /* 142 scall_filebuf_set                  */ SCALL_IRQ_ON,
    /* 143 scall_filebuf_seek                 */ SCALL_IRQ_ON,
    /* 144 scall_filebuf_tell                 */ SCALL_IRQ_ON,
    /* 145 scall_dup2                         - V69.37 FD/stdin-out routing is locally atomic */ SCALL_IRQ_ON,
    /* 146 scall_cexec_stdio                  */ SCALL_IRQ_ON,
    /* 147 scall_mmap                         */ SCALL_IRQ_ON,
    /* 148 scall_munmap                       */ SCALL_IRQ_ON,
    /* 149 scall_mem_grow                     */ SCALL_IRQ_ON,
    /* 150 scall_setcursortype                */ SCALL_IRQ_ON,
    /* 151 scall_bootutils                    */ SCALL_IRQ_ON,
    /* 152 scall_keystate                     */ SCALL_IRQ_ON,
    /* 153 scall_smsh_builtin                 */ SCALL_IRQ_ON,
    /* 154 scall_env                          */ SCALL_IRQ_ON,
    /* 155 scall_resolvehost4                 */ SCALL_IRQ_ON,
    /* 156 scall_fsusage                      */ SCALL_IRQ_ON,
    /* 157 scall_dprintk                      - bounded userspace debug-string copy */ SCALL_IRQ_ON,
    /* 158 scall_freeterminal                 - owner-checked terminal teardown */ SCALL_IRQ_ON,
    /* 159 scall_rmdir                        */ SCALL_IRQ_ON,
    /* 160 scall_fsync                        */ SCALL_IRQ_ON,
    /* 161 scall_sync                         */ SCALL_IRQ_ON,
    /* 162 scall_truncate                     */ SCALL_IRQ_ON,
    /* 163 scall_ftruncate                    */ SCALL_IRQ_ON,
    /* 164 scall_access                       */ SCALL_IRQ_ON,
    /* 165 scall_gettimeofday                 */ SCALL_IRQ_ON,
    /* 166 scall_nanosleep                    */ SCALL_IRQ_ON,
    /* 167 scall_sched_yield                  */ SCALL_IRQ_ON,
    /* 168 scall_hdbench                      - kernel-buffered read-only hda benchmark */ SCALL_IRQ_ON,
    /* 169 scall_graosstartup                  - publish GraOS startup stage */ SCALL_IRQ_ON,
};
#undef SCALL_IRQ_OFF
#undef SCALL_IRQ_ON

/* V69.6 privilege policy.  The assembly gate checks the interrupted CS, not
 * a mutable process flag, so a CPL3 caller cannot reach old compatibility
 * services that directly control kernel/device state.  Zero means Ring3-safe;
 * one means CPL0 only.  Keep user-driver IRQ/DMA APIs available because those
 * are capability/ownership checked in userhw.c. */
const unsigned char scall_ring0_only[N_MAX_SCALLS] = {
    [SYS_mkfs] = 1,
    [SYS_POSTCMD] = 1,
    [SYS_readblock] = 1,
    [SYS_writeblock] = 1,
    [SYS_killthread] = 1,
    [SYS_setint] = 1,
    [SYS_enableirq] = 1,
    [SYS_diskchange] = 1,
    [SYS_registernewdevice] = 1,
    [SYS_switchtothreadex] = 1,
    [SYS_devicecall] = 1,
    [SYS_switchtothread] = 1,
    [SYS_kmalloc] = 1,
    [SYS_kfree] = 1,
    [SYS_diskchange_compat] = 1,
    [SYS_readblocks] = 1,
    [SYS_writeblocks] = 1
};

void *scall_functions[N_MAX_SCALLS]={
	// 0
	// dummy entry, never ought to be called
	scall_dummy,
	// 1 SYS_IDLE
	idle_moment,
	// 2 SYS_remove
	scall_remove,
	// 3 SYS_mkfs
	scall_mkfs,
	// 4 SYS_rename
	scall_rename,
	// 5
	scall_dummy,
	// 6 SYS_PUTS
	scall_puts,
	// 7 SYS_PUTCH
	scall_putchar,
	// 8 SYS_EXIT
	scall_exit,
	// 9 SYS_CLRSCR
	scall_clrscr,
	// 10 SYS_GETCH
	scall_getch,
	// 11 postcmd
	scall_postcmd,
	// 12 SYS_GETCURDEV
	scall_getcurdev,
	// 13 SYS_GOTOXY
	scall_gotoxy,
	// 14 SYS_GETTICKCOUNT
	scall_gettickcount,
	// 15 SYS_GETAMEMSIZE
	scall_getamemsize,
	// 16 SYS_GETCURRENTTHREAD
	scall_getcurrentthread,
	// 17 SYS_GETARGC
	scall_getargc,
	// 18 SYS_GETARGV
	scall_getargv,
	// 19 SYS_open
	scall_open,
	// 20 SYS_close
	scall_close,
	// 21 SYS_read
	scall_read,
	// 22 SYS_write
	scall_write,
	// 23 SYS_lseek
	scall_lseek,
	// 24 SYS_cexec
	scall_cexec,
	// 25 SYS_getdevnrbyname
	scall_getdevnrbyname,
	// 26 SYS_readblock
	scall_readblock,
	// 27 SYS_writeblock
	scall_writeblock,
	// 28 SYS_waitprocterm
	scall_waitprocterm,
	// 29 SYS_findfirst
	scall_findfirst,
	// 30 SYS_findnext
	scall_findnext,
	// 31 SYS_textcolor
	scall_textcolor,
	// 32 SYS_textbackground
	scall_textbackground,
	// 33 SYS_inputmouse
	scall_inputmouse,
	// 34 SYS_setmouserect
	scall_setmouserect,
	// 35 SYS_vgadrawframe
	scall_vgadrawframe,
	// 36 SYS_GETCURDB
	scall_getcurdb,
	// 37 SYS_vgawaitretrace
	scall_vgawaitretrace,
	// 38 SYS_chdir
	scall_chdir,
	// 39 SYS_getdevicename
	scall_getdevicename,
	// 40 SYS_getdate
	scall_getdate,
	// 41 SYS_WHEREX
	scall_wherex,
	// 42 SYS_WHEREY
	scall_wherey,
	// 43 SYS_vgaselectplane
	scall_vgaselectplane,
	// 44 getdevicenrbyname
	scall_getdevicenrbyname,
	// 45 
	scall_getthreadpriority,
	// 46
	scall_getthreadspending,
	// 47
	scall_getthreadname,
	// 48
	scall_getthreadmemoryusage,
	// 49
	scall_getthreadcount,
	// 50
	scall_getctrl,
	// 51
	scall_getalt,
	// 52 Activate thread's MSGBOX
	scall_activatemsgbox,
	// 53 Send message to a PID
	scall_sendmessage,
	// 54 Receive message
	scall_receivemessage,
	// 55 getthreadpid
	scall_getthreadpid,
	// 56 identifythread
	scall_identifythread,
	// 57 getseconds
	scall_getseconds,
	// 58 globalcopy
	scall_globalcopy,
	// 59 getthreadterminal
	scall_getthreadterminal,
	// 60 setthreadterminal
	scall_setthreadterminal,
	// 61 NewTerminal
	scall_newterminal,
	// 62 outputterminalkeyboardbuffer
	scall_outputterminalkeyboardbuffer,
	// 63 inputterminalkeyboardbuffer
	scall_inputterminalkeyboardbuffer,
	// 64 copyterminal
	scall_copyterminal,
	// 65 killthread
	scall_killthread,
	// 66 getcursorlocation
	scall_getcursorlocation,
	// 67 setint
	scall_setint,
	// 68 enableirq
	scall_enableirq,
	// 69 diskchange
	scall_diskchange,
	// 70 legacy PID identity (former getthreaduniquepid)
	scall_getthreaduniquepid,
	// 71 registernewdevice
	scall_registernewdevice,
	// 72 switchtothreadex
	scall_switchtothreadex,
	// 73 createterminal
	scall_createterminal,
	// 74 setterminalowner
	scall_setterminalowner,
	// 75 getterminalowner
	scall_getterminalowner,
	// 76 serialget
	scall_serialget,
	// 77 serialput
	scall_serialput,
	// 78 setserialportspeed
	scall_setserialportspeed,
	// 79 receiverawpacket
	scall_receiverawpacket,
	// 80 transmitrawpacket
	scall_transmitrawpacket,
	// 81 devicecall
	scall_devicecall,
	// 82 milsleep
	scall_milsleep,
	// 83 opensocket
	scall_opensocket,
	// 84 closesocket
	scall_closesocket,
	// 85 readsocket
	scall_readsocket,
	// 86 writesocket
	scall_writesocket,
	// 87 switchtothread
	scall_switchtothread,
	// 88 getcwd
	scall_getcwd,
	// 89 stat
	scall_stat,
	// 90 fstat
	scall_fstat,
	// 91 SYS_wgetch
	scall_wgetch,
	// 92 SYS_mkdir
	scall_mkdir,
	// 93 kmalloc
	scall_kmalloc,
	// 94 kfree
	scall_kfree,
	// 95 SYS_fexist
	scall_fexist1,
	// 96 SYS_getfiledatablock
	scall_getfiledatablock,
	// 97 SYS_isdriveready
	scall_isdriveready,
	// 98 SYS_diskchange_compat (legacy duplicate of syscall 69)
	scall_diskchange,
	// 99 SYS_getfilesize
	scall_getfilesize,
	// 100 SYS_read1
	scall_read1,
	// 101 SYS_write1
	scall_write1,
	// 102 SYS_creat1
	scall_creat1,
	// 103 SYS_unlink1
	scall_unlink1,
	// 104 SYS_setsize1
	scall_setsize,
	// 105 SYS_getcpustats
	scall_getcpustats,
	// 106 SYS_usleep
	scall_usleep,
	// 107 SYS_audioinit
	scall_audioinit,
	// 108 SYS_audiowrite
	scall_audiowrite,
	// 109 SYS_audioposition
	scall_audioposition,
	// 110 SYS_audiostop
	scall_audiostop,
	// 111 SYS_audioinfo
	scall_audioinfo,
	// 112 SYS_audioselect
	scall_audioselect,
	// 113 SYS_window (Turbo C 1-based inclusive coordinates)
	scall_window,
	// 114 SYS_copyfromthread (kernel-assisted GUI framebuffer copy)
	scall_copyfromthread,
	// 115 SYS_irqsubscribe
	scall_irqsubscribe,
	// 116 SYS_irqunsubscribe
	scall_irqunsubscribe,
	// 117 SYS_irqwait
	scall_irqwait,
	// 118 SYS_dmaalloc
	scall_dmaalloc,
	// 119 SYS_dmafree
	scall_dmafree,
	// 120 SYS_dmaprogram
	scall_dmaprogram,
	// 121 SYS_dmastop
	scall_dmastop,
	// 122 SYS_vgasetpalette
	scall_vgasetpalette,
	// 123 SYS_getcpufeatures
	scall_getcpufeatures,
	// 124 SYS_graosgraphics
	scall_graosgraphics,
	// 125 SYS_readblocks
	scall_readblocks,
	// 126 SYS_writeblocks
	scall_writeblocks,
	// 127 SYS_fork
	scall_fork,
	// 128 SYS_getppid
	scall_getppid,
	// 129 SYS_waitpid
	scall_waitpid,
	// 130 SYS_kill
	scall_kill_posix,
	// 131 SYS_sigdisp
	scall_sigdisp,
	// 132 SYS_pipe
	scall_pipe,
	// 133 SYS_poll
	scall_poll,
	// 134 SYS_nice
	scall_nice,
	// 135 SYS_getpriority
	scall_getpriority_posix,
	// 136 SYS_setpriority
	scall_setpriority_posix,
	// 137 SYS_uname
	scall_uname,
	// 138 SYS_sysinfo
	scall_sysinfo,
	// 139..144 kernel-owned stdio/file buffering
	scall_filebuf_read,
	scall_filebuf_write,
	scall_filebuf_flush,
	scall_filebuf_set,
	scall_filebuf_seek,
	scall_filebuf_tell,
	// 145 POSIX-style stdio dup2 routing
	scall_dup2,
	// 146 process launch with explicit stdin/stdout/stderr routes
	scall_cexec_stdio,
	// 147..149 process virtual memory
	scall_mmap,
	scall_munmap,
	scall_mem_grow,
	// 150 terminal cursor visibility/type
	scall_setcursortype,
    // 151 DOSBOOT persistent UTILS.ISO RAM bank
    scall_bootutils,
    // 152 raw physical key state for GraOS navigation
    scall_keystate,
    // 153 restricted SMSH builtin bridge for SQSH
    scall_smsh_builtin,
    // 154 POSIX per-process + system-global environment
    scall_env,
    // 155 IPv4 DNS resolver for Ring3 network clients
    scall_resolvehost4,
    // 156 read-only filesystem usage for df(1)
    scall_fsusage,
    // 157 userspace -> kernel dprintk debug bridge
    scall_dprintk,
    // 158 release a dynamic terminal owned by the calling process
    scall_freeterminal,
    // 159..167 V69.7 mediated Ring3 POSIX/service API
    scall_rmdir,
    scall_fsync,
    scall_sync,
    scall_truncate,
    scall_ftruncate,
    scall_access,
    scall_gettimeofday,
    scall_nanosleep,
    scall_sched_yield,
    // 168 V69.14 read-only hda benchmark; raw bytes remain in Ring 0
    scall_hdbench,
    // 169 V70.19 GraOS startup-stage diagnostics
    scall_graosstartup
};

// Number of system calls registered
DWORD nr_scall_func = 170;


//--------------------------------------------------------------------------
//
// A2K.
// Application to Kernel memory space address conversion function.
//
void *A2K(DWORD appoffs)
{
    return _A2KRange(appoffs,1,GetCurrentThread());
}

// PID specific.
void *_A2K(DWORD appoffs, int pid)
{
    return _A2KRange(appoffs,1,pid);
}

void *A2KRange(DWORD appoffs, DWORD length)
{
    return _A2KRange(appoffs,length,GetCurrentThread());
}

void *_A2KRange(DWORD appoffs, DWORD length, int pid)
{
	DWORD tb;
	DWORD dma_address;
	DWORD user_bytes;
	int type;

	if(length == 0)
		return 0;
	type = GetThreadType(pid);
	if(!(type & (THREAD_TYPE_APPLICATION|THREAD_TYPE_KERNEL)))
		return 0;

	/* V65 DMA mappings live outside the historical contiguous application
	 * backing image. Resolve those first so normal read/write/device syscalls
	 * can safely accept a DMA buffer pointer too. */
	dma_address = userhw_dma_translate_range(pid, appoffs, length);
	if(dma_address)
		return JTM_DWORD_TO_VOID(dma_address);

	/* All V69.6 application processes, ELF and legacy raw, execute in the
	 * flat Ring-3 window.  An application carrying any other CS is a broken
	 * or stale task: fail closed instead of treating its value as a native
	 * kernel pointer. */
	if(type & THREAD_TYPE_APPLICATION)
	{
		if(thread_selector[pid] != USER_CS)
			return 0;
		DWORD mapped;
		if(appoffs < MM_USER_BASE || !(tb=GetThreadBase(pid)))
			return 0;
		user_bytes=(DWORD)thread_memkb[pid]*1024UL;
		if(user_bytes>MM_USER_SIZE)
			user_bytes=MM_USER_SIZE;
		if(appoffs-MM_USER_BASE<user_bytes &&
		   length<=user_bytes-(appoffs-MM_USER_BASE))
			return JTM_DWORD_TO_VOID((appoffs-MM_USER_BASE)+tb);

		/* mmap/mem_grow regions are intentionally outside the original
		 * SYSMEMREQ backing window. Translate them through the process VM
		 * registry rather than pretending thread_base[] is one 16 MiB slab. */
		mapped=mm_translate_process_mapping(pid,appoffs,length);
		return JTM_DWORD_TO_VOID(mapped);
	}

	/* Only native kernel/service threads use native kernel addresses. */
	return JTM_DWORD_TO_VOID(appoffs);
}

/* Copy a NUL-terminated userspace string without ever reading beyond the
 * caller's validated mapping.  A missing terminator is an error. */
static int scall_copyin_string(DWORD address, char *out, DWORD capacity)
{
	DWORD i;
	char *p;

	if(!address || !out || capacity < 2)
		return -1;
	for(i=0; i<capacity; ++i)
	{
		if(address>0xffffffffUL-i)
			return -1;
		p=(char *)A2KRange(address+i,1);
		if(!p || !mm_prepare_kernel_copy_range(p,1))
			return -1;
		out[i]=*p;
		if(out[i]==0)
			return (int)i;
	}
	out[capacity-1]=0;
	return -1;
}

/* SYS_dprintk (157): bounded Ring3 debug bridge.  Applications format their
 * message in userspace and this syscall only copies one NUL-terminated line
 * into kernel storage before handing it to the existing serial/system-log
 * dprintk() path.  It never treats userspace bytes as a format string. */
int scall_dprintk(SYSCALLPAR)
{
    char text[768];
    int n;
    n=scall_copyin_string(scall_ebx,text,sizeof(text));
    if(n<0) return -EFAULT;
    dprintk("%s",text);
    return n;
}

//--------------------------------------------------------------------------
//
static void LogThisSystemCall(SYSCALLPAR)
{
	char str[256];

	//
	if(scall_eax!=SYS_PUTCH && scall_eax!=SYS_IDLE)
	{
		sprintf(str, "SYSCALL%d: ebx=%x, ecx=%x, edx=%x, esi=%x, edi=%x, ebp=%x\n",
			scall_eax,
			scall_ebx, scall_ecx, scall_edx,
			scall_esi, scall_edi, scall_ebp);
		WriteSystemLog(str);
	}
}

// Called by scall_handler before jumping to
// the service function.
void scallActive(SYSCALLPAR)
{
	int pid=GetCurrentThread();

	/* The gate may be installed before init_threads() has created a valid
	 * task slot. Never index per-thread arrays with an unvalidated PID. */
	if(!valid_pid(pid))
		return;

	/* The scheduler may save this application on its Ring0 syscall stack.
	 * Publish the depth before tracing or accounting can call other kernel
	 * code; those helpers are not part of the syscall service body. */
	if(thread_scall_active[pid] != 0xFF)
		thread_scall_active[pid]++;

	/* V68.210 forensic history is captured before the service body can
	 * block, fault or yield. Arguments are raw register values only. */
	CrashAnalysisTraceSyscall(pid,scall_eax,scall_ebx,scall_ecx,scall_edx,
	                          scall_esi,scall_edi,scall_ebp);

	/* V68.154: account the syscall before the service body can block/yield.
	 * The scheduler uses only the syscall number and recent per-PID history;
	 * no userspace pointer is dereferenced here. */
	SchedulerAccountSyscall(pid,(int)scall_eax);

	if(GetThreadType(pid)&THREAD_TYPE_SYSCALL_TRACE)
		LogThisSystemCall(MYSYSCALLPAR);
}

//--------------------------------------------------------------------------
// This function is called by scall_handler
// after the system call has been served.
void scallDeactive(void)
{
	int pid=GetCurrentThread();

	if(!valid_pid(pid))
		return;
	if(thread_scall_active[pid])
		thread_scall_active[pid]--;
}

//--------------------------------------------------------------------------
//
// Nothing doer.
//
DWORD scall_nothing(SYSCALLPAR)
{
	//
	return 0;
}

//--------------------------------------------------------------------------
//
// scall_puts(scall #6).
//
// Note: base address is needed because
// we need to translate the application's
// own virtual memory address space to
// memory space that is visible to kernel.
// f.e.:
// - Kernel can see everything.
// (supervising)
//
// - Application can see only itself.
// (restricted)
//
//
DWORD scall_puts(SYSCALLPAR)
{
	char text[1024];
	int i,l;

	l=scall_copyin_string(scall_ebx,text,sizeof(text));
	if(l<0)
		return -1;
	for(i=0; i<l; i++)
		putch(text[i]);
	return 0;
}

//--------------------------------------------------------------------------
// Wait until key is hit and return the key code.
int scall_wgetch(SYSCALLPAR)
{
    /* SCALL_IRQ_ON: the dispatcher enables IRQ1 for normal application
     * callers before entering this blocking service. */
    return getch();
}

//--------------------------------------------------------------------------
// Input key from current terminal's keyboard buffer
DWORD scall_getch(SYSCALLPAR)
{
	//
	return getch1();
}

//--------------------------------------------------------------------------
//
// scall_putchar(scall #7).
// BL = character to print on screen.
//
// New: Modified for visible_terminal.
//
DWORD scall_putchar(SYSCALLPAR)
{
	int i JTM_UNUSED;
	char *scr JTM_UNUSED;
	char str[10] JTM_UNUSED;

	// Print char
	sputch(&screens[thread_terminal[GetCurrentThread()]], scall_ebx&255);

	//
	return 0;
}

//--------------------------------------------------------------------------
// This system call is used to exit a thread.
// F.e. an application can be ended with this
// function very well.
//
DWORD scall_exit(SYSCALLPAR)
{
	/* Preserve the userspace exit code for waitpid(). */
	ExitThread((int)scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
//
// Clears screen.
//
DWORD scall_clrscr(SYSCALLPAR)
{
	//
	_clrscr();
	return 0;
}

//--------------------------------------------------------------------------
// scall_getcurdev - get current device
//
// Returns the caller process current device number (DNR).
//
DWORD scall_getcurdev(SYSCALLPAR)
{
	int devnr;

	//
	devnr = GetCurrentDNR();
	return devnr;
}

//--------------------------------------------------------------------------
DWORD scall_getcurdb(SYSCALLPAR)
{
	int db;

	//
	db = GetCurrentDB();
	return db;
}

//--------------------------------------------------------------------------
//
void scall_relaxthread(SYSCALLPAR)
{
	//
	SwitchToThread();
}

//--------------------------------------------------------------------------
//
int scall_gotoxy(SYSCALLPAR)
{
	gotoxy(scall_ebx,scall_ecx);
	return 0;
}

int scall_setcursortype(SYSCALLPAR)
{
	SCREEN *s=&screens[MYTER];
	unsigned long irq_flags;
	/* Native text mode may touch the shared VGA CRTC cursor registers. */
	irq_flags=irq_save();
	CursorState(s, scall_ebx==0 ? FALSE : TRUE);
	irq_restore(irq_flags);
	return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_gettickcount(SYSCALLPAR)
{
	return GetTickCount();
}

//--------------------------------------------------------------------------
// scall_getamemsize
//
// This function returns the size of the memory
// allocated for the process use.
// This is only for application processes,
// does not apply to kernel processes.
DWORD scall_getamemsize(SYSCALLPAR)
{
	return thread_memkb[GetCurrentThread()]*1024;
}

//--------------------------------------------------------------------------
//
DWORD scall_getcurrentthread(SYSCALLPAR)
{
	return GetCurrentThread();
}

//--------------------------------------------------------------------------
//
DWORD scall_getargc(SYSCALLPAR)
{
	int i JTM_UNUSED;
	char *s;

	s=thread_cmdline[GetCurrentThread()];
	if( !s )return 0;
	if( !isValidString(s) )return 0;

	//
	return CountWords(s);
}

//--------------------------------------------------------------------------
// scall_ebx = which argument
// scall_ecx = pointer to string where to store the answer
int scall_getargv(SYSCALLPAR)
{
    char *s;
    int which;
    DWORD argc;

    which = (int)scall_ebx;
    s = (char *)A2KRange(scall_ecx,256);
    if(s == NULL)
        return -1;

    argc = scall_getargc(MYSYSCALLPAR);
    if(which < 0 || (DWORD)which >= argc)
    {
        strcpy(s, "");
        return -1;
    }

    strcpy(s, "");
    strcpyarg(s, thread_cmdline[GetCurrentThread()], which);
    return 0;
}

//--------------------------------------------------------------------------
// Order init -process to create new task.
DWORD scall_cexec(SYSCALLPAR)
{
	char *s,*s2;
	DWORD pid;
	char fname[256],cmdline[256],workdir[256],cwd_dir[256] JTM_UNUSED;
	int i,*spid,caller_dnr,caller_db;
	unsigned int exec_flags=(unsigned int)scall_ebp;

	//	scall_ebx	(char *)	file name + arguments 
	//	scall_ecx	int		wait until process exits [TRUE/FALSE]
	//	scall_edx	(char *)	work directory
	//	scall_esi	(int *)		pointer to address where to store PID
	//		(if equals to NULL, then ignored)
	//	scall_edi	(int)		terminal ID
	//	scall_ebp	(unsigned)	exec flags (JTMOS_EXEC_F_*)

	if(exec_flags & ~JTMOS_EXEC_F_VALID_MASK) return -EINVAL;

	// Snapshot CWD before any exec/path work.  DNR/DB is the authoritative
	// caller directory and must survive even if a textual path cache is stale.
	pid = 0;
	caller_dnr=GetCurrentDNR();
	caller_db=GetCurrentDB();
	if(scall_copyin_string(scall_ebx,cmdline,sizeof(cmdline))<0)
		return -2;
	if(!scall_edx)
		workdir[0]=0;
	else if(scall_copyin_string(scall_edx,workdir,sizeof(workdir))<0)
		return -2;
	s = cmdline; // string: exe fname&args
	//	scall_ecx = 0 background (return after creation), 1 foreground (wait for exit)
	
	/* Preserve the syscall workDir contract.  An empty string means exact
	 * caller DNR/DB inheritance in centralprocess_exec(); do not round-trip
	 * it through a textual CWD here. */
	s2 = workdir;
	spid =	scall_esi ? (int *)A2KRange(scall_esi,sizeof(int)) : NULL;
	if(scall_esi && !spid)
		return -2;
	if(spid)
		*spid = 0;

	//
	if(isValidString(s) && strlen(s))
	{
		// Cut file name.
		strcpy(fname, s);
		for(i=0; i<strlen(fname); i++)
			if(fname[i]==' ')fname[i]=0;

		// #1 argument =	file name(ends at the first space)
		// #2 argument = 	whole command line
		// s2 =			running path(where the program will run at)
#if JTMOS_MOD_APP_LOADER
		pid = centralprocess_exec_flags(fname, s, caller_dnr, caller_db,
					s2,
					scall_edi,exec_flags); // terID + capability flags

		// Store PID
		if(spid)
			*spid = pid;
#else
		printk("cexec: application loader module is disabled.\n");
		if(spid)
			*spid = 0;
		return -1;
#endif
	}
	else
		// Invalid parameter string(s) detected
		return -2;

	// Creation/load(not found) failed if pid equals zero
	// Return value -1 means error
	if(!pid)
		// No process created
		return -1;

	/* Historical ABI: ECX=0 means background; ECX=1 means foreground.
	 * Do not invert this in libc -- GraOS depends on bgexec() returning as
	 * soon as the child has been created. */
	if(!scall_ecx)
		return 0;

	WaitProcessTerminationInterruptible(pid);
	// Return value 0 means that
	// program terminated like it used to
	return 0;
}


//--------------------------------------------------------------------------
// SYS_cexec_stdio: SYS_cexec plus EBP -> int stdio_routes[3].
DWORD scall_cexec_stdio(SYSCALLPAR)
{
    char cmdline[256],workdir[256],fname[256];
    int *spid,*routes_user;
    int routes[3],pid,i,caller_dnr,caller_db;
    caller_dnr=GetCurrentDNR();
    caller_db=GetCurrentDB();
    if(scall_copyin_string(scall_ebx,cmdline,sizeof(cmdline))<0) return -EFAULT;
    if(!scall_edx) workdir[0]=0;
    else if(scall_copyin_string(scall_edx,workdir,sizeof(workdir))<0) return -EFAULT;
    spid=scall_esi ? (int *)A2KRange(scall_esi,sizeof(int)) : NULL;
    if(scall_esi && !spid) return -EFAULT;
    routes[0]=routes[1]=routes[2]=-1;
    if(scall_ebp)
    {
        routes_user=(int *)A2KRange(scall_ebp,sizeof(routes));
        if(!routes_user) return -EFAULT;
        routes[0]=routes_user[0]; routes[1]=routes_user[1]; routes[2]=routes_user[2];
    }
    if(spid) *spid=0;
    if(!cmdline[0]) return -EINVAL;
    strcpy(fname,cmdline);
    for(i=0;fname[i];i++) if(fname[i]==' ' || fname[i]=='\t') { fname[i]=0; break; }
#if JTMOS_MOD_APP_LOADER
    pid=centralprocess_exec_stdio(fname,cmdline,caller_dnr,caller_db,
            workdir,(int)scall_edi,routes[0],routes[1],routes[2]);
#else
    return -ENOSYS;
#endif
    if(pid<=0) return -ENOENT;
    if(spid) *spid=pid;
    if(scall_ecx) WaitProcessTerminationInterruptible(pid);
    return 0;
}

//--------------------------------------------------------------------------
// V67.8.57.8: real process virtual-memory mappings. The syscall ABI returns
// Linux-style pointer values in EAX; only 0xfffff001..0xffffffff are errors,
// so valid JTMOS user pointers at 0x80000000 are unambiguous.
DWORD scall_mmap(SYSCALLPAR)
{
    int pid;
    DWORD low;
    void *p;
    if(scall_ecx==0 || (scall_edx & ~(PROT_READ|PROT_WRITE|PROT_EXEC)))
        return (DWORD)-EINVAL;
    if((scall_esi & MAP_ANONYMOUS)==0)
        return (DWORD)-ENOSYS;
    if((scall_esi & MAP_PRIVATE)==0 || (scall_esi & MAP_SHARED))
        return (DWORD)-EINVAL;
    if((int)scall_edi!=-1 || scall_ebp!=0)
        return (DWORD)-EINVAL;
    pid=GetCurrentThread();
    if(thread_selector[pid]!=USER_CS)
        return (DWORD)-EPERM;
    if(ProcessVmLock()!=0)
        return (DWORD)-EAGAIN;
    low=MM_USER_BASE+(DWORD)thread_memkb[pid]*1024UL;
    p=mm_process_mmap_anon(pid,scall_ebx,scall_ecx,(int)scall_edx,
                           (int)scall_esi,low);
    ProcessVmUnlock();
    return p ? (DWORD)p : (DWORD)-ENOMEM;
}

int scall_munmap(SYSCALLPAR)
{
    int pid=GetCurrentThread();
    int rv;
    if(thread_selector[pid]!=USER_CS)
        return -EPERM;
    if(ProcessVmLock()!=0)
        return -EAGAIN;
    rv=mm_process_munmap(pid,scall_ebx,scall_ecx);
    ProcessVmUnlock();
    return rv==0 ? 0 : -EINVAL;
}

DWORD scall_mem_grow(SYSCALLPAR)
{
    DWORD bytes;
    DWORD low;
    void *p;
    int pid=GetCurrentThread();
    if(thread_selector[pid]!=USER_CS || scall_ebx==0)
        return (DWORD)-EINVAL;
    bytes=scall_ebx;
    if(bytes<64UL*1024UL) bytes=64UL*1024UL;
    bytes=mm_page_align_up(bytes);
    if(bytes==0 || bytes>MM_USER_SIZE)
        return (DWORD)-ENOMEM;
    if(ProcessVmLock()!=0)
        return (DWORD)-EAGAIN;
    low=MM_USER_BASE+(DWORD)thread_memkb[pid]*1024UL;
    p=mm_process_mmap_anon(pid,0,bytes,PROT_READ|PROT_WRITE,
                           MAP_PRIVATE|MAP_ANONYMOUS,low);
    ProcessVmUnlock();
    return p ? (DWORD)p : (DWORD)-ENOMEM;
}

//--------------------------------------------------------------------------
// Kernel-owned buffered stdio/file operations. User buffers are translated
// here; the persistent buffer itself always lives in kernel memory.
int scall_filebuf_read(SYSCALLPAR)
{
    BYTE *p; int count=(int)scall_edx;
    if(count<0) return -EINVAL;
    if(count==0) return 0;
    p=(BYTE *)A2KRange(scall_ecx,(DWORD)count); if(!p) return -EFAULT;
    return KernelFileBufRead(GetCurrentThread(),(int)scall_ebx,p,count);
}
int scall_filebuf_write(SYSCALLPAR)
{
    BYTE *p; int count=(int)scall_edx;
    if(count<0) return -EINVAL;
    if(count==0) return 0;
    p=(BYTE *)A2KRange(scall_ecx,(DWORD)count); if(!p) return -EFAULT;
    return KernelFileBufWrite(GetCurrentThread(),(int)scall_ebx,p,count);
}
int scall_filebuf_flush(SYSCALLPAR)
{
    return KernelFileBufFlush(GetCurrentThread(),(int)scall_ebx);
}
int scall_filebuf_set(SYSCALLPAR)
{
    return KernelFileBufSet(GetCurrentThread(),(int)scall_ebx,(int)scall_ecx,(int)scall_edx);
}
int scall_filebuf_seek(SYSCALLPAR)
{
    return KernelFileBufSeek(GetCurrentThread(),(int)scall_ebx,(int)scall_ecx,(int)scall_edx);
}
int scall_filebuf_tell(SYSCALLPAR)
{
    return KernelFileBufTell(GetCurrentThread(),(int)scall_ebx);
}

//--------------------------------------------------------------------------
// scall_ebx = PID
DWORD scall_waitprocterm(SYSCALLPAR)
{
	/* SCALL_IRQ_ON: scheduler/timer IRQs remain live while waiting. */
	WaitProcessTerminationInterruptible(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_ebx = fname.
// scall_ecx = FFBLK typedef structure.
#define SCALL_FIND_PATH_MAX 512U

static int scall_find_abi_size_ok(DWORD declared)
{
    /* EDX==0 is the historical ABI.  New libc passes sizeof(FFBLK), making
     * future structure changes detectable without breaking old binaries. */
    return declared==0U || declared==(DWORD)sizeof(FFBLK);
}

DWORD scall_findfirst(SYSCALLPAR)
{
    char path[SCALL_FIND_PATH_MAX];
    FFBLK kff;
    void *user_ff;
    int rc;

    if(!scall_find_abi_size_ok(scall_edx))
        return (DWORD)-EINVAL;
    rc=scall_copyin_string(scall_ebx,path,sizeof(path));
    if(rc<0)
        return (DWORD)-EFAULT;
    user_ff=(void *)A2KRange(scall_ecx,(DWORD)sizeof(kff));
    if(user_ff==NULL)
        return (DWORD)-EFAULT;

    memset(&kff,0,sizeof(kff));
    rc=findfirst(path,&kff);
    if(rc>0)
        memcpy(user_ff,&kff,sizeof(kff));
    return (DWORD)rc;
}

//--------------------------------------------------------------------------
// scall_ebx = fd.
// scall_ecx = FFBLK typedef structure.
// scall_edx = sizeof(FFBLK) for the versioned ABI, or 0 for legacy callers.
DWORD scall_findnext(SYSCALLPAR)
{
    FFBLK kff;
    void *user_ff;
    int rc;

    if(!scall_find_abi_size_ok(scall_edx))
        return (DWORD)-EINVAL;
    user_ff=(void *)A2KRange(scall_ecx,(DWORD)sizeof(kff));
    if(user_ff==NULL)
        return (DWORD)-EFAULT;

    /* _ff_reserved[0] carries the exact-match/single-entry state, so preserve
     * the caller's previous FFBLK state before asking JTMFS for the next item. */
    memcpy(&kff,user_ff,sizeof(kff));
    rc=findnext((int)scall_ebx,&kff);
    if(rc==0)
        memcpy(user_ff,&kff,sizeof(kff));
    return (DWORD)rc;
}

//--------------------------------------------------------------------------
int scall_textcolor(SYSCALLPAR)
{
	textcolor(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
int scall_textbackground(SYSCALLPAR)
{
	textbackground(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_inputmouse(SYSCALLPAR)
{
    int pid=GetCurrentThread();
	/* Keep the IRQ-driven path, but opportunistically drain queued PS/2 AUX
	 * bytes as a non-blocking fallback.  This is especially useful under
	 * QEMU/VirtualBox while the slave PIC is transitioning between masks. */
	mouse_poll();

    if(pid>0 && pid<N_MAX_THREADS &&
       scall_mouse_seen_packets[pid]!=ps2mouse_packet_count) {
        DWORD delta=ps2mouse_packet_count-scall_mouse_seen_packets[pid];
        scall_mouse_seen_packets[pid]=ps2mouse_packet_count;
        SchedulerNoteActivity(pid,SCHED_ACTIVITY_MOUSE,(int)(delta>8U?8U:delta));
    }

	switch(scall_ebx)
	{
		//
		case 0:
		return mouse.x;
		case 1:
		return mouse.y;
		case 2:
		return (DWORD)mouse_getbuttons();
		case 3:
		return ps2mouse_irq_count;
		case 4:
		return ps2mouse_byte_count;
		case 5:
		return ps2mouse_packet_count;
		case 6:
		return (DWORD)ps2mouse_stream_status;

		//
		default:
		return 0;
	}
}

//--------------------------------------------------------------------------
int scall_setmouserect(SYSCALLPAR)
{
	long x1=scall_ebx,y1=scall_ecx,x2=scall_edx,y2=scall_esi;

	/* SetMouseRect() describes the coordinate range; it must not leave a
	 * newly-started GUI cursor clipped into the top-left corner.  The old
	 * syscall always teleported the pointer to (x1,y1).  Start at the centre
	 * of the requested rectangle instead; subsequent PS/2 packets update it. */
	mouse_setframe(x1,y1,x2,y2);
	mouse_setposition(x1+(x2-x1)/2,y1+(y2-y1)/2);
	return 0;
}

//--------------------------------------------------------------------------
extern volatile int graos_startup_diag_pid;
extern volatile DWORD graos_startup_diag_magic;
extern volatile int graos_startup_diag_row;

DWORD scall_vgadrawframe(SYSCALLPAR)
{
    const void *src;
    DWORD row_bytes=GRAOS_VESA_WIDTH*GRAOS_VESA_BYTES_PER_PIXEL;
    DWORD offset=scall_ecx;
    DWORD bytes=scall_edx;
    DWORD first_column=scall_esi;
    DWORD column_count=scall_edi;
    int first_row,row_count;

    /* Offset and length describe complete packed source scanlines. ESI/EDI
     * optionally restrict conversion to an X region inside those rows.  Zero
     * width preserves the old full-row/full-frame ABI. */
    if(bytes==0 || (scall_ebx&3UL)!=0 ||
       (offset%row_bytes)!=0 || (bytes%row_bytes)!=0 ||
       offset>=GRAOS_VESA_FRAME_BYTES || bytes>GRAOS_VESA_FRAME_BYTES-offset ||
       scall_ebx>0xffffffffUL-(offset+bytes))
        return 0;
    if(column_count==0) {
        first_column=0;
        column_count=GRAOS_VESA_WIDTH;
    }
    if(first_column>=GRAOS_VESA_WIDTH ||
       column_count>GRAOS_VESA_WIDTH-first_column)
        return 0;
    if(!VesaGraOSReady() && !VesaStartGraOSGraphics())
        return 0;

    first_row=(int)(offset/row_bytes);
    row_count=(int)(bytes/row_bytes);

    /* A 4096-byte scanline can start at any malloc alignment and thus cross
     * two independently backed sparse pages. Translate at user-page boundaries
     * before reading any pixel. Span conversion takes the pointer to the first
     * pixel in that span, without assuming its alias covers the whole row. */
    {
        int r,pixel;
        DWORD user_row=scall_ebx+offset;
        for(r=0;r<row_count;r++,user_row+=row_bytes)
        {
            if(graos_startup_diag_pid==GetCurrentThread() &&
               graos_startup_diag_magic==thread_magic[graos_startup_diag_pid])
                graos_startup_diag_row=first_row+r;
            pixel=(int)first_column;
            while(pixel<(int)(first_column+column_count))
            {
                DWORD user_pixel=user_row+(DWORD)pixel*4UL;
                DWORD span=(PAGESIZE-(user_pixel&(PAGESIZE-1UL)))/4UL;
                DWORD remaining=first_column+column_count-(DWORD)pixel;
                if(span>remaining) span=remaining;
                src=(const void *)A2KRange(user_pixel,span*4UL);
                if(src==NULL) return 0;
                if(!VesaDrawFrameSpan(src,first_row+r,pixel,(int)span))
                    return 0;
                pixel+=(int)span;
            }
        }
    }
    return 1;
}

//--------------------------------------------------------------------------
DWORD scall_vgawaitretrace(SYSCALLPAR)
{
	//
	vga_waitretrace();
	return 0;
}

//--------------------------------------------------------------------------
// chdir [path]
// EAX   EBX
DWORD scall_chdir(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    int rv;
    if(scall_copyin_string(scall_ebx,path,sizeof(path))<0) return (DWORD)-EFAULT;
    rv=_chdir(path);
    return rv==0 ? 0 : (DWORD)-rv;
}

//--------------------------------------------------------------------------
// SYS_mkfs [path]
DWORD scall_mkfs(SYSCALLPAR)
{
    /* libc historically passed either a device number or a device/path string. */
    if((int)scall_ebx >= 0 && (int)scall_ebx < 256 && isValidDevice((int)scall_ebx))
        return (DWORD)formatdrive((int)scall_ebx);
    {
        const char *path = (const char *)A2K(scall_ebx);
        if(path == NULL || !isValidString(path) || !strlen(path))
            return (DWORD)-1;
        return (DWORD)mkfs(path);
    }
}

//--------------------------------------------------------------------------
// Rename a file in the caller's current JTMFS device/database context.
// scall_rename: old file name, new file name
DWORD scall_rename(SYSCALLPAR)
{
    char oldname[JTMFS_PATH_MAX],newname[JTMFS_PATH_MAX];
    if(scall_copyin_string(scall_ebx,oldname,sizeof(oldname))<0 ||
       scall_copyin_string(scall_ecx,newname,sizeof(newname))<0 ||
       !oldname[0] || !newname[0]) return (DWORD)-EFAULT;
    return (DWORD)jtmfs_RenameFile(GetCurrentDNR(),oldname,newname,GetCurrentDB());
}



//--------------------------------------------------------------------------
// scall_mkdir: directory name, type
DWORD scall_mkdir(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    int rv;
    if(scall_copyin_string(scall_ebx,path,sizeof(path))<0 || !path[0])
        return (DWORD)-EFAULT;
    errno=0;
    rv=mkdir(path,scall_ecx);
    if(rv<0) return (DWORD)-(errno ? errno : EIO);
    return (DWORD)rv;
}

//--------------------------------------------------------------------------
// SYS_remove
// remove [path]
// EAX    EBX
DWORD scall_remove(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    if(scall_copyin_string(scall_ebx,path,sizeof(path))<0 || !path[0])
        return (DWORD)-EFAULT;
    return (DWORD)unlink(path);
}


//--------------------------------------------------------------------------
// dnr, strbuf*
int scall_getdevicenrbyname(SYSCALLPAR)
{
    char name[128];
    if(scall_copyin_string(scall_ebx,name,sizeof(name))<0) return -EFAULT;
    return driver_getdevicenrbyname(name);
}

//--------------------------------------------------------------------------
// dnr, strbuf*
DWORD scall_getdevicename(SYSCALLPAR)
{
    const char *name=driver_getdevicename((int)scall_ebx,NULL);
    char *out;
    DWORD len;
    if(!name) return (DWORD)-ENODEV;
    len=(DWORD)strlen(name)+1U;
    out=(char *)A2KRange(scall_ecx,len);
    if(!out) return (DWORD)-EFAULT;
    memcpy(out,name,len);
    return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_getdate(SYSCALLPAR)
{
    DATE *p=(DATE *)A2KRange(scall_ebx,sizeof(DATE));
    if(!p) return (DWORD)-EFAULT;
    rtc_getdate(p);
    return 0;
}

//--------------------------------------------------------------------------
DWORD scall_wherex(SYSCALLPAR)
{
	//
	return wherex();
}

//--------------------------------------------------------------------------
DWORD scall_wherey(SYSCALLPAR)
{
	//
	return wherey();
}

//--------------------------------------------------------------------------
// VGA select plane where to draw and write.
DWORD scall_vgaselectplane(SYSCALLPAR)
{
	unsigned long irq_flags;
	/* Sequencer/graphics-controller index+data pairs are global VGA state.
	 * Keep only the register transaction atomic; the syscall itself may run
	 * with normal IRQs enabled under the V69.37 dispatcher policy. */
	irq_flags=irq_save();
	setwplane(scall_ebx & 3);
	setrplane(scall_ebx & 3);
	irq_restore(irq_flags);
	return 0;
}

//--------------------------------------------------------------------------
// Get thread priority: pid.
int scall_getthreadpriority(SYSCALLPAR)
{
	//
	return GetThreadPriority(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread spending: pid.
int scall_getthreadspending(SYSCALLPAR)
{
	//
	return GetThreadSpending(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread name: pid, name.
int scall_getthreadname(SYSCALLPAR)
{
	char *p;

	//
	p = A2KRange(scall_ecx,39);
	if(!p) return -1;
	return GetThreadName(scall_ebx, p);
}

//--------------------------------------------------------------------------
// Get thread memory usage: pid
int scall_getthreadmemoryusage(SYSCALLPAR)
{
	//
	return GetThreadMemoryUsage(scall_ebx);
}

//--------------------------------------------------------------------------
// Get number of threads
int scall_getthreadcount(SYSCALLPAR)
{
	//
	return GetThreadCount();
}

//--------------------------------------------------------------------------
// Get scheduler CPU/load statistics. EBX=user struct pointer, ECX=struct size.
int scall_getcpustats(SYSCALLPAR)
{
	JTMOS_CPU_STATS *p;

	if(scall_ecx < sizeof(JTMOS_CPU_STATS)) return -1;
	p = (JTMOS_CPU_STATS *)A2KRange(scall_ebx,sizeof(JTMOS_CPU_STATS));
	if(!p) return -1;
	return SchedulerGetCpuStats(p, scall_ecx);
}

//--------------------------------------------------------------------------
// DOSBOOT persistent UTILS.ISO RAM bank.
// EBX=0: return exact byte size (0 means unavailable).
// EBX=1: ECX=offset, EDX=user destination, ESI=length; returns copied bytes.
// EBX=2: return BOOTUTILS_STATUS_* diagnostic code.
int scall_bootutils(SYSCALLPAR)
{
    DWORD size,len;
    void *dst;

    if(scall_ebx==0)
        return (int)BootUtilsRamSize();
    if(scall_ebx==2)
        return BootUtilsRamStatus();
    if(scall_ebx!=1)
        return -1;

    size=BootUtilsRamSize();
    if(size==0 || scall_ecx>size)
        return -1;
    len=scall_esi;
    if(len>size-scall_ecx)
        len=size-scall_ecx;
    if(len==0)
        return 0;
    dst=(void *)A2KRange(scall_edx,len);
    if(!dst)
        return -1;
    return BootUtilsRamRead(scall_ecx,dst,len);
}

//--------------------------------------------------------------------------
/*
 * Return the physical make/break state for one normalized set-1 scan code.
 * This is deliberately a state query rather than another translated key
 * stream: GraOS uses it for desktop navigation edges (Tab, Alt+Tab and
 * cursor keys), while printable text continues through SYS_GETCH.
 */
int scall_keystate(SYSCALLPAR)
{
    int sc=(int)scall_ebx;
    if(sc<0 || sc>=1024)
        return 0;
    /* This is a state-only query: no terminal FIFO contents are exposed.
     * Keeping it independent of terminal ownership is intentional so the
     * desktop can recover navigation even while dynamic GraOS terminals are
     * being created or focus is being transferred. */
    if(kbstr.ktab==NULL)
        return 0;
    return kbstr.ktab[sc] ? 1 : 0;
}

//--------------------------------------------------------------------------
int scall_getctrl(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[GetCurrentThread()]==GetInputTerminal() )
		return GetCTRL();
	else
		return 0;
}

//--------------------------------------------------------------------------
int scall_getalt(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[GetCurrentThread()]==GetInputTerminal() )
		return GetALT();
	else
		return 0;
}

//--------------------------------------------------------------------------
// Enables the caller thread to
// receive messages from other processes.
// (automatically activated nowadays, but still can be manually used...)
int scall_activatemsgbox(SYSCALLPAR)
{
	//
	return ActivateThreadMessageBox(GetCurrentThread());
}

//--------------------------------------------------------------------------
// Send message to a process.
int scall_sendmessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2KRange(scall_ebx,sizeof(MSG));
	if(!p || !mm_prepare_kernel_copy_range(p,sizeof(MSG))) return 1;

	// Send message
	return sendMessage(p, scall_ecx);
}

//--------------------------------------------------------------------------
// Receive message.
int scall_receivemessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2KRange(scall_ebx,sizeof(MSG));
	if(!p || !mm_prepare_kernel_copy_range(p,sizeof(MSG))) return 0;

	// Receive message
	return receiveMessage(p);
}

//--------------------------------------------------------------------------
// Resolve thread name to a PID.
int scall_getthreadpid(SYSCALLPAR)
{
	char name[39];

	// Get PTR
	if(scall_copyin_string(scall_ebx,name,sizeof(name))<0) return -1;
	return GetThreadPID(name);
}

//--------------------------------------------------------------------------
// Give thread a name
// (ONLY allows to identify itself,
//  future modifications will be made,
//  to allow system processes to do
//  identifying itself.)
int scall_identifythread(SYSCALLPAR)
{
	char name[39];

	// Get PTR
	if(scall_copyin_string(scall_ecx,name,sizeof(name))<0) return 1;

	// Only allow to modify itself
	if(scall_ebx==(DWORD)GetCurrentThread())
	{
		// Identify
		IdentifyThread(scall_ebx, name);
	}
	else
	{
		//
		printk("%s: Sorry PID%d, I cannot allow you to identify PID%d..\n",
			__FUNCTION__, GetCurrentThread(), scall_ebx);
		// Error
		return 1;
	}

	// Return OK
	return 0;
}

//--------------------------------------------------------------------------
// Return second count
int scall_getseconds(SYSCALLPAR)
{
	//
	return GetSeconds();
}

//--------------------------------------------------------------------------
// Copy a global memory region.
//
//	globalcopy(srcPID,srcPTR, dstPID,dstPTR, length);
//
//	scall_ebx	source PID
//	scall_ecx	source offset
//	scall_edx	destination PID
//	scall_esi	destination offset
//	scall_edi	copy length in bytes
//
int scall_globalcopy(SYSCALLPAR)
{
	BYTE *src,*dst;
	int srcPID,dstPID,len,caller,type;

	// Get PIDs
	srcPID = scall_ebx;
	dstPID = scall_edx;

	// Get copy length
	len = scall_edi;
	if(len < 0 || len > (16*1024*1024)) return -1;
	if(len == 0) return 0;
	caller=GetCurrentThread();
	type=GetThreadType(caller);
	if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE) &&
	   (srcPID!=caller || dstPID!=caller))
		return -1;

	// Get PTRs
	src = (BYTE *)_A2KRange(scall_ecx,(DWORD)len,srcPID);
	dst = (BYTE *)_A2KRange(scall_esi,(DWORD)len,dstPID);

	//
	if(dst == NULL || src == NULL || illegal(dst) || illegal(src))
	{
		dprintk("Illegal globalcopy(%x,%x,%d).\n", dst,src,len);
		return -1;
	}

	// Perform copy
	memcpy(dst, src, len);

	//
	return 0;
}

//--------------------------------------------------------------------------
//
int scall_getthreadterminal(SYSCALLPAR)
{
	//
	return GetThreadTerminal(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_setthreadterminal(SYSCALLPAR)
{
	//
	SetThreadTerminal(scall_ebx, scall_ecx);
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_newterminal(SYSCALLPAR)
{
	// Returns terminal ID
	return NewTerminal();
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer.
int scall_outputterminalkeyboardbuffer(SYSCALLPAR)
{
	if((int)scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return OutputTerminalKeyboardBuffer(&screens[scall_ebx], scall_ecx);
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer
int scall_inputterminalkeyboardbuffer(SYSCALLPAR)
{
	if((int)scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return InputTerminalKeyboardBuffer(&screens[scall_ebx]);
}

//--------------------------------------------------------------------------
// Copy specified terminal to a buffer.
int scall_copyterminal(SYSCALLPAR)
{
	BYTE *p;
	int ter;

	// Get parameters
	ter = scall_ebx;
	if(ter<0 || ter>=N_MAX_SCREENS || scall_ecx==0) return -1;
	if(screens[ter].isFree || screens[ter].buf==NULL) return -1;
	p = A2K(scall_ecx);
	if(p==NULL) return -1;

        /* SYS_copyterminal is a fixed 80x25 ABI used by GraOS/tm.bin.
         * Refuse a corrupted SCREEN geometry instead of trusting it as a
         * userspace copy length.  JTMOS is single-CPU; IF=0 prevents the PIT
         * scheduler from producing a torn character/attribute snapshot. */
        if(screens[ter].width!=TERMINAL_TEXT_COLS ||
           screens[ter].height!=TERMINAL_TEXT_ROWS) return -1;
        {
                unsigned long flags=irq_save();
                memcpy(p, screens[ter].buf, TERMINAL_TEXT_BYTES);
                irq_restore(flags);
        }

	return 0;
}

//--------------------------------------------------------------------------
// Terminate a process
int scall_killthread(SYSCALLPAR)
{
	//
	KillThread(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Get cursor location in specified terminal.
int scall_getcursorlocation(SYSCALLPAR)
{
	int ter=scall_ebx;
	int caller=GetCurrentThread();
	int type;
	if(ter<0 || ter>=N_MAX_SCREENS || screens[ter].isFree) return -1;
	if(!screens[ter].updcur) return -1;

	/* Physical-console applications may query only the terminal that owns
	   keyboard focus.  GraOS is different: it is a trusted compositor
	   service and renders dynamic terminal windows without making each one
	   the kernel-wide GetInputTerminal().  Let KERNEL/SERVICE callers read
	   cursor metadata for those terminals; ordinary Ring3 callers retain
	   the old focus restriction. */
	type=GetThreadType(caller);
	if(ter!=GetInputTerminal() &&
	   !(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE))
		return -1;
	return GetCursorLocation(ter);
}

//--------------------------------------------------------------------------
// Set interrupt handler.
int scall_setint(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    /* Direct IDT/IRQ installation is a privileged kernel operation.  Ring3
     * drivers must use SYS_irqsubscribe, whose ISR remains kernel-owned. */
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE))
        return -1;
    return addInterruptHandler(scall_ebx,(void*)scall_ecx,scall_edx,scall_esi);
}

//--------------------------------------------------------------------------
// Enable IRQ #.
int scall_enableirq(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE))
        return -1;
    /* The legacy ABI is retained for trusted kernel/service code, but garbage
     * IRQ values must never reach the PIC. Ring3 uses SYS_irqsubscribe. */
    if((int)scall_ebx < 0 || scall_ebx > 15) return -1;
    enable_irq((unsigned short)scall_ebx);
    return 0;
}

//--------------------------------------------------------------------------
//
int scall_diskchange(SYSCALLPAR)
{
	//
	diskchangednr(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Legacy syscall number 70. UNIPID is retired; return the PID unchanged so
// older applications remain ABI-compatible without generation-bit semantics.
int scall_getthreaduniquepid(SYSCALLPAR)
{
    return scall_ebx;
}

//--------------------------------------------------------------------------
// Register a new device.
int scall_registernewdevice(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE)) return -EPERM;
	return driver_register_new_deviceEx((const char *)A2K(scall_ebx),
			JTM_DWORD_TO_VOID(scall_ecx), scall_edx,
			scall_esi,
			scall_edi,
			scall_ebp);
	// int driver_register_new_deviceEx(const char *device_name,
	//                                void *device_call, int CS,
	//                                int pid,
	//                                WORD type,
	//                                int Alias)
}

//--------------------------------------------------------------------------
// Switch to specified thread.
int scall_switchtothreadex(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE)) return -EPERM;
	SwitchToThreadEx(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_createterminal(SYSCALLPAR)
{
	int terID;

	terID = NewTerminal();
	if(terID < 0)
		return -1;
	if(SetTerminalOwner(terID, GetCurrentThread()) < 0)
	{
		FreeTerminal(terID);
		return -1;
	}
	return terID;
}

//--------------------------------------------------------------------------
// Release a dynamic terminal owned by the calling process.
int scall_freeterminal(SYSCALLPAR)
{
	unsigned long irq_flags;
	int id=(int)scall_ebx;
	int owner;
	int rv;

	/* Fixed VT indexes 0..N_VIRTUAL_TERMINALS-1 are never releasable. Keep the ownership check and
	 * the release in one single-CPU critical section so a concurrent owner
	 * transfer cannot turn a valid check into a use-after-free. */
	if(id<FIRST_DYNAMIC_TERMINAL || id>=N_MAX_SCREENS)
		return -EINVAL;
	irq_flags=irq_save();
	owner=GetTerminalOwner(id);
	if(owner<=0 || owner!=GetCurrentThread())
	{
		irq_restore(irq_flags);
		return -EPERM;
	}
	rv=FreeTerminal(id);
	irq_restore(irq_flags);
	return rv==0 ? 0 : -EINVAL;
}

//--------------------------------------------------------------------------
// Set terminal owner.
int scall_setterminalowner(SYSCALLPAR)
{
	unsigned long flags;
	int caller=GetCurrentThread();
	int id=(int)scall_ebx;
	int target=(int)scall_ecx;
	int owner,type;

	if(id<0 || id>=N_MAX_SCREENS) return -EINVAL;
	type=GetThreadType(caller);
	if((type&THREAD_TYPE_KERNEL) || (type&THREAD_TYPE_SERVICE))
		return SetTerminalOwner(id,target);

	/* Ring3 cannot steal a live terminal or assign it to an unrelated PID. */
	if(target<0 || target>=N_MAX_THREADS) return -EINVAL;
	if(target>0 && (!valid_pid(target) || !thread_states[target] ||
	                LinuxGetPPid(target)!=caller || GetThreadTerminal(target)!=id))
		return -EPERM;

	flags=irq_save();
	owner=GetTerminalOwner(id);
	if(owner!=caller && owner>0 && valid_pid(owner) && thread_states[owner])
	{
		irq_restore(flags);
		return -EPERM;
	}
	if(target==0 && owner!=caller)
	{
		irq_restore(flags);
		return -EPERM;
	}
	owner=SetTerminalOwner(id,target);
	irq_restore(flags);
	return owner==0 ? 0 : -EINVAL;
}

//--------------------------------------------------------------------------
// Createa a new terminal.
int scall_getterminalowner(SYSCALLPAR)
{
	//
	return GetTerminalOwner(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialget(SYSCALLPAR)
{
	//
	return serial_get(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialput(SYSCALLPAR)
{
	//
	return serial_put(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
//
int scall_setserialportspeed(SYSCALLPAR)
{
	//
	return SetSerialPortSpeedOwned(scall_ebx, scall_ecx, SERIAL_OWNER_NONE);
}

//
/*int device_call(long device_nr,
                long n_function,
                long v1,long v2,long v3,long v4,
                void *p1,void *p2)
*/

//--------------------------------------------------------------------------
// Receive raw packet.
int scall_receiverawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_RECEIVERAWPACKET, // receive raw packet
		0,0,0,0,
		A2K(scall_ecx),NULL); // PTR to packet buffer.
}

//--------------------------------------------------------------------------
// Transmit raw packet
int scall_transmitrawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer
	// scall_edx	packet length in bytes

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_TRANSMITRAWPACKET, // receive raw packet
		scall_edx,0,0,0, // packet length
		A2K(scall_ecx),NULL); // PTR to packet buffer
		
		
}

//--------------------------------------------------------------------------
// Generic device call compatibility syscall.
int scall_devicecall(SYSCALLPAR)
{
    DCPACKET *userp;
    DCPACKET p;
    int dnr;

    dnr = (int)scall_ebx;
    userp = (DCPACKET *)A2K(scall_ecx);
    if(userp == NULL || illegal(userp))
        return -1;
    if(!isValidDevice(dnr))
        return -1;

    /* Copy the packet first, then translate its nested application pointers.
     * Passing raw p1/p2 values to a kernel driver was unsafe for ring-3 apps. */
    memcpy(&p, userp, sizeof(p));
    if(p.n_function <= 0)
        return -1;
    if(p.p1) p.p1 = (void *)A2K((DWORD)p.p1);
    if(p.p2) p.p2 = (void *)A2K((DWORD)p.p2);
    if(p.done) p.done = (int *)A2K((DWORD)p.done);
    if(p.rval) p.rval = (int *)A2K((DWORD)p.rval);

    return device_call(dnr, p.n_function,
                       p.par1,p.par2,p.par3,p.par4,
                       p.p1,p.p2);
}

//--------------------------------------------------------------------------
// Sleep specified amount of 1/100 seconds
int scall_milsleep(SYSCALLPAR)
{
	//
	MilSleep(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// POSIX-style microsecond sleep.  EBX = useconds_t duration.
int scall_usleep(SYSCALLPAR)
{
	return UsecSleep(scall_ebx);
}

//--------------------------------------------------------------------------
// Generic audio syscall API.  User buffers are translated to kernel space;
// hardware I/O and DMA addresses never leave the kernel.
#if JTMOS_MOD_AUDIO_DRIVERS
int scall_audioinit(SYSCALLPAR)
{
    audio_init();
    return audio_ensure_backend((int)scall_ebx);
}

int scall_audiowrite(SYSCALLPAR)
{
    BYTE *buf;
    if(scall_ebx == 0 || scall_ecx == 0) return 0;
    if(scall_ecx > (1024UL * 1024UL)) return -1;
    buf = (BYTE *)A2KRange(scall_ebx,scall_ecx);
    if(!buf) return -1;
    return audio_write(buf, (int)scall_ecx, (int)scall_edx, (int)scall_esi);
}

int scall_audioposition(SYSCALLPAR)
{
    return (int)audio_pending_bytes();
}

int scall_audiostop(SYSCALLPAR)
{
    return audio_stop();
}

int scall_audioinfo(SYSCALLPAR)
{
    JTMOS_AUDIO_INFO *info;
    if(scall_ebx == 0 || scall_ecx < sizeof(JTMOS_AUDIO_INFO)) return -1;
    info = (JTMOS_AUDIO_INFO *)A2KRange(scall_ebx,sizeof(JTMOS_AUDIO_INFO));
    if(!info) return -1;
    return audio_get_info(info);
}

int scall_audioselect(SYSCALLPAR)
{
    return audio_select_backend((int)scall_ebx);
}

#else
int scall_audioinit(SYSCALLPAR) { return -1; }
int scall_audiowrite(SYSCALLPAR) { return -1; }
int scall_audioposition(SYSCALLPAR) { return 0; }
int scall_audiostop(SYSCALLPAR) { return -1; }
int scall_audioinfo(SYSCALLPAR) { return -1; }
int scall_audioselect(SYSCALLPAR) { return -1; }
#endif

//--------------------------------------------------------------------------
//
int GetTCPIPStackDNR(void)
{
	int dnr;

	//
	dnr = driver_getdevicenrbyname("network");
	return dnr;
}

//--------------------------------------------------------------------------
// Open socket.
int scall_opensocket(SYSCALLPAR)
{
#if JTMOS_MOD_NETWORK && !JTMOS_MOD_LEGACY_TCP
	return JtUserSocketOpen((DWORD)scall_ebx,(int)scall_ecx,GetCurrentThread());
#else
	return device_call(GetTCPIPStackDNR(), DEVICE_CMD_OPENSOCKET,
		scall_ebx,scall_ecx,0,0,NULL,NULL);
#endif
}

//--------------------------------------------------------------------------
// Close socket.
int scall_closesocket(SYSCALLPAR)
{
#if JTMOS_MOD_NETWORK && !JTMOS_MOD_LEGACY_TCP
	return JtUserSocketClose((int)scall_ebx,GetCurrentThread());
#else
	return device_call(GetTCPIPStackDNR(), DEVICE_CMD_CLOSESOCKET,
		scall_ebx,0,0,0,NULL,NULL);
#endif
}

//--------------------------------------------------------------------------
// Read socket.
int scall_readsocket(SYSCALLPAR)
{
#if JTMOS_MOD_NETWORK && !JTMOS_MOD_LEGACY_TCP
	void *dst;
	if((int)scall_edx<=0) return -EINVAL;
	dst=(void *)A2KRange(scall_ecx,scall_edx);
	if(!dst) return -EFAULT;
	return JtUserSocketRead((int)scall_ebx,dst,(int)scall_edx,GetCurrentThread());
#else
	return device_call(GetTCPIPStackDNR(), DEVICE_CMD_READSOCKET,
		scall_ebx,JTM_PTR_TO_DWORD(A2K(scall_ecx)),0,0,NULL,NULL);
#endif
}

//--------------------------------------------------------------------------
// Write socket.
int scall_writesocket(SYSCALLPAR)
{
	void *src;
	if((int)scall_edx<=0) return -EINVAL;
	src=(void *)A2KRange(scall_ecx,scall_edx);
	if(!src) return -EFAULT;
#if JTMOS_MOD_NETWORK && !JTMOS_MOD_LEGACY_TCP
	return JtUserSocketWrite((int)scall_ebx,src,(int)scall_edx,GetCurrentThread());
#else
	return device_call(GetTCPIPStackDNR(), DEVICE_CMD_WRITESOCKET,
		scall_ebx,scall_edx,0,0,src,NULL);
#endif
}

//--------------------------------------------------------------------------
// Schedule.
int scall_switchtothread(SYSCALLPAR)
{
	SwitchToThread();
	return 0;
}

//--------------------------------------------------------------------------
// Get current work directory path.
// Arguments: [getcwd] [string]
int scall_getcwd(SYSCALLPAR)
{
    char *buf;
    int max_len;
    int rv;

    max_len = (int)scall_ecx;
    if(max_len <= 0 || max_len > 4096)
        return -1;
    buf = (char *)A2KRange(scall_ebx,(DWORD)max_len);
    if(buf == NULL)
        return -1;

    rv = getcwd(buf, max_len);
    return rv == 0 ? 0 : -rv;
}

//--------------------------------------------------------------------------
void *scall_kmalloc(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE)) return NULL;
	if(scall_ebx==0 || scall_ebx>(16UL*1024UL*1024UL))
		return NULL;
	return malloc(scall_ebx);
}

//--------------------------------------------------------------------------
int scall_kfree(SYSCALLPAR)
{
    int type=GetThreadType(GetCurrentThread());
    if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE)) return -EPERM;
	if(scall_ebx) {
		if(GetChunkOwner((void *)scall_ebx)!=GetCurrentThread())
			return -1;
		free((void *)scall_ebx);
	}
	return 0;
}


//--------------------------------------------------------------------------
// scall_postcmd
//
// New: Modified to transfer execution immediatly
// to postman process so no CPU time is spent
// elsewhere, which might lead into a markable
// inefficiency.
//
int scall_postcmd(SYSCALLPAR)
{
    POSTMANCMD *userp;
    POSTMANCMD p;
    int *ackp = NULL;
    int *rvp = NULL;
    int rv = -1;

    userp = (POSTMANCMD *)A2K(scall_ebx);
    if(userp == NULL || illegal(userp))
        return -1;

    /* Work on a kernel copy: never dereference nested application pointers
     * before translating them from the caller's virtual address space. */
    memcpy(&p, userp, sizeof(p));
    if(p.par1) p.par1 = (char *)A2K((DWORD)p.par1);
    if(p.par2) p.par2 = (char *)A2K((DWORD)p.par2);
    if(p.par3) p.par3 = (char *)A2K((DWORD)p.par3);
    if(p.par4) p.par4 = (char *)A2K((DWORD)p.par4);
    if(p.par5) p.par5 = (char *)A2K((DWORD)p.par5);
    if(p.par6) p.par6 = (char *)A2K((DWORD)p.par6);
    if(p.par7) p.par7 = (char *)A2K((DWORD)p.par7);
    if(p.par8) p.par8 = (char *)A2K((DWORD)p.par8);
    if(p.acknowledged) ackp = (int *)A2K((DWORD)p.acknowledged);
    if(p.rv) rvp = (int *)A2K((DWORD)p.rv);

    /* The old Postman filled these from the sender before dispatching. */
    p.magic = POSTMAN_MAGIC;
    p.pid = GetCurrentThread();
    p.dnr = GetCurrentDNR();
    p.db = GetCurrentDB();

    switch(p.id)
    {
        case PCMD_CREATE_FILE:
            rv = createfile(p.par1);
            break;
        case PCMD_DELETE_FILE:
            rv = unlink(p.par1);
            break;
        case PCMD_WRITE_FILE:
            rv = writefile(p.par1, p.par2, p.v2, p.v1);
            break;
        case PCMD_READ_FILE:
            rv = readfile(p.par1, p.par2, p.v2, p.v1);
            break;
        case PCMD_GET_FILE_SIZE:
            rv = getfilesize(p.par1);
            break;
        case PCMD_ADD_BLOCKS:
            rv = addfileblocks(p.par1, p.v1);
            break;
        case PCMD_EXIST:
            rv = exist(p.par1);
            break;
        case PCMD_READBLOCK:
            rv = readblock(p.v1, p.v2, (BYTE *)p.par1);
            break;
        case PCMD_WRITEBLOCK:
            rv = writeblock(p.v1, p.v2, (BYTE *)p.par1);
            break;
        case PCMD_FINDFIRST:
            rv = findfirst(p.par1, p.par2);
            break;
        case PCMD_FINDNEXT:
            rv = findnext(p.v1, p.par1);
            break;
        case PCMD_RENAME_FILE:
            if(!p.par1 || !p.par2) rv = -1;
            else rv = jtmfs_RenameFile(GetCurrentDNR(), p.par1, p.par2, GetCurrentDB());
            break;
        case PCMD_SETSIZE:
            rv = setsize(p.par1, p.v1);
            break;
        case PCMD_GETFILEDATABLOCK:
            if(!p.par1) rv = -1;
            else rv = jtmfs_GetFileDataBlock(GetCurrentDNR(), GetCurrentDB(), p.par1);
            break;
        case PCMD_CREATEDIRECTORY:
            rv = mkdir(p.par1, 0);
            break;
        case PCMD_FORMATDRIVE:
            rv = formatdrive(p.v1);
            break;
        case PCMD_CLOSE:
            rv = close(p.v1);
            break;
        case PCMD_CHDIR:
            rv = chdir(p.par1);
            break;
        case PCMD_IS_DRIVE_READY:
            rv = isValidDevice(p.v1) && jtmfs_isDriveReady(p.v1) ? 1 : 0;
            break;
        case PCMD_GETCWD:
            rv = getcwd(p.par1, p.v1);
            break;

        /* Legacy multimedia Postman ABI now forwards to the same kernel
         * backends as the modern dedicated syscalls. */
        case PCMD_SETMODE:
            setvmode(p.v1);
            rv = 0;
            break;
        case PCMD_DRAWFRAME:
            if(!p.par1 || p.v2 <= 0) {
                rv = -1;
            } else if(p.v1 == 0 && p.v2 == GRAOS_VESA_FRAME_BYTES) {
                rv = VesaDrawFrame(p.par1, GRAOS_VESA_FRAME_BYTES) ? 0 : -1;
            } else if(p.v1 >= 0 && p.v2 > 0 && p.v1 + p.v2 <= 0x10000) {
                memcpy((BYTE *)0xA0000 + p.v1, p.par1, p.v2);
                rv = 0;
            } else {
                rv = -1;
            }
            break;
        case PCMD_SETPALETTE:
            if(p.v1 < 0 || p.v1 > 255 || p.v2 < 0 || p.v2 > 63 ||
               p.v3 < 0 || p.v3 > 63 || p.v4 < 0 || p.v4 > 63) {
                rv = -1;
            } else {
                setpaletteEx(p.v1, p.v2, p.v3, p.v4);
                rv = 0;
            }
            break;
        case PCMD_SETPALETTEMAP:
            if(!p.par1 || p.v1 < 0 || p.v1 > 255 || p.v2 <= 0 ||
               p.v2 > 256 || p.v1 + p.v2 > 256) {
                rv = -1;
            } else {
                setpalettemap(p.v1, p.v2, (BYTE *)p.par1);
                rv = 0;
            }
            break;
#if JTMOS_MOD_AUDIO_DRIVERS
        case PCMD_INITAUDIO:
            audio_init();
            rv = audio_ensure_backend(0);
            break;
        case PCMD_SENDAUDIO:
            if(!p.par1 || p.v1 <= 0 || p.v3 <= 0) rv = -1;
            else rv = audio_write((BYTE *)p.par1, p.v1, p.v3, p.v2);
            break;
        case PCMD_GETAUDIOPOSITION:
            rv = (int)audio_pending_bytes();
            break;
#endif
        default:
            rv = -1;
            break;
    }

    /* Preserve the synchronous Postman ABI for old callers that supplied
     * acknowledgement / return-value cells, while also returning rv in EAX. */
    if(rvp && !illegal(rvp)) *rvp = rv;
    if(ackp && !illegal(ackp)) *ackp = (rv < 0) ? 2 : 1;
    userp->magic = POSTMAN_MAGIC;
    userp->pid = p.pid;
    userp->dnr = p.dnr;
    userp->db = p.db;
    userp->id = 0;
    return rv;
}

/* V69.7: the FDDB is kernel-global, so every Ring3 descriptor operation must
 * prove that the current process owns the slot.  Otherwise guessing another
 * process' small integer fd would cross the Ring3 process boundary. */
static int scall_owned_fd(int fd)
{
    int pid=GetCurrentThread();
    if(fd<3 || !isValidFD(fd)) return 0;
    return fd_has_owner(fd,pid);
}

//--------------------------------------------------------------------------
// scall_open
//
int scall_open(SYSCALLPAR)
{
    char pathname[JTMFS_PATH_MAX];
    int rv;

    /* Never hand a raw Ring3 string pointer to the VFS.  A2K() validates only
     * the first byte; copyin_string validates every mapped byte through NUL. */
    if(scall_copyin_string(scall_ebx,pathname,sizeof(pathname))<0)
        return -EFAULT;
    errno=0;
    rv=open(pathname, scall_ecx);
    if(rv<0) return -(errno ? errno : EIO);
    return rv;
}

//--------------------------------------------------------------------------
// Turbo C compatible text window: all public coordinates are 1-based.
int scall_window(SYSCALLPAR)
{
    return window((long)scall_ebx, (long)scall_ecx,
                  (long)scall_edx, (long)scall_esi);
}

//--------------------------------------------------------------------------
// Copy bytes from another thread's user virtual address into the caller.
// Used by the GraOS server to make a private copy of client framebuffers.
int scall_copyfromthread(SYSCALLPAR)
{
    BYTE *src;
    BYTE *dst;
    DWORD len = scall_edx;
    int srcpid = (int)scall_ebx;
    int caller = GetCurrentThread();
    int type = GetThreadType(caller);

    if(srcpid <= 0 || scall_ecx == 0 || scall_esi == 0 || len == 0)
        return -1;
    if(len > (4UL * 1024UL * 1024UL))
    {
        return -1;
    }
	if(srcpid!=caller && !(type&THREAD_TYPE_KERNEL) &&
	   !(type&THREAD_TYPE_SERVICE)) {
		printk("SYS_copyfromthread: caller PID%d type=%x lacks SERVICE for source PID%d len=%d.\n",
		       caller,type,srcpid,(int)len);
		return -1;
	}

    src = (BYTE *)_A2KRange(scall_ecx,len,srcpid);
    dst = (BYTE *)A2KRange(scall_esi,len);
    if(!src || !dst)
        return -EFAULT;
    if(!mm_prepare_kernel_copy_range(src,len) ||
       !mm_prepare_kernel_copy_range(dst,len) ||
       !memcpy(dst,src,len))
        return -EFAULT;
    return (int)len;
}

//--------------------------------------------------------------------------
// scall_close
//
int scall_close(SYSCALLPAR)
{
    /* fd 0/1/2 are permanent ABI numbers, but a process may have redirected
     * one of them to a pipe endpoint.  Closing a redirected standard stream
     * must release that endpoint so readers can observe EOF/HUP. */
    if((int)scall_ebx >= 0 && (int)scall_ebx <= 2)
        return LinuxCloseStdioFd(GetCurrentThread(),(int)scall_ebx);
    if(!scall_owned_fd((int)scall_ebx)) return -EBADF;
    return close(scall_ebx);
}

//
int scall_read(SYSCALLPAR)
{
    BYTE *buf;
    int count;

    count = (int)scall_edx;
    if(count < 0) return -1;
    if(count == 0) return 0;
    buf = (BYTE *)A2KRange(scall_ecx,(DWORD)count);
    if(buf == NULL) return -1;

    /* Resolve process-local stdio first.  An unredirected fd 0 still reads
     * the terminal; redirected stdin uses the normal VFS/pipe read path. */
    {
        int realfd=LinuxResolveStdioFd(GetCurrentThread(),(int)scall_ebx);
        if((int)scall_ebx == 0 && realfd == 0)
            return KernelNativeStdinRead(GetCurrentThread(),buf,count);
        if(realfd != (int)scall_ebx) {
            if(realfd>=3 && !scall_owned_fd(realfd)) return -EBADF;
            return read(realfd,buf,count);
        }
    }

    if((int)scall_ebx == 1 || (int)scall_ebx == 2)
        return -EBADF;
    if(!scall_owned_fd((int)scall_ebx)) return -EBADF;

    return read(scall_ebx, buf, count);
}

//--------------------------------------------------------------------------
// scall_write
//
int scall_write(SYSCALLPAR)
{
    BYTE *buf;
    int i, count;

    count = (int)scall_edx;
    if(count < 0) return -1;
    if(count == 0) return 0;
    buf = (BYTE *)A2KRange(scall_ecx,(DWORD)count);
    if(buf == NULL) return -1;

    /* stdout/stderr normally target the terminal, but a pipeline may route
     * either stream to a process-owned pipe endpoint. */
    {
        int realfd=LinuxResolveStdioFd(GetCurrentThread(),(int)scall_ebx);
        if(realfd != (int)scall_ebx) {
            int rv;
            if(realfd>=3 && !scall_owned_fd(realfd)) return -EBADF;
            errno=0;
            rv=write(realfd,buf,count);
            if(rv<0) return -(errno ? errno : EIO);
            return rv;
        }
    }
    if((int)scall_ebx == 1 || (int)scall_ebx == 2)
    {
        for(i=0; i<count; ++i)
            putch(buf[i]);
        return count;
    }
    if((int)scall_ebx == 0)
        return -EBADF;
    if(!scall_owned_fd((int)scall_ebx)) return -EBADF;

    {
        int rv;
        errno=0;
        rv=write(scall_ebx, buf, count);
        if(rv<0) return -(errno ? errno : EIO);
        return rv;
    }
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_fnctl(SYSCALLPAR)
{
	// file descriptor
	//return fnctl(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_lseek(SYSCALLPAR)
{
    if((int)scall_ebx<3 || !scall_owned_fd((int)scall_ebx)) return -EBADF;
    return lseek(scall_ebx,scall_ecx,scall_edx);
}

//--------------------------------------------------------------------------
// scall_stat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_stat(SYSCALLPAR)
{
    char pathname[JTMFS_PATH_MAX];
    void *buf=(void *)A2KRange(scall_ecx,sizeof(struct stat));
    if(!buf) return -EFAULT;
    if(scall_copyin_string(scall_ebx,pathname,sizeof(pathname))<0) return -EFAULT;
    return stat(pathname,buf);
}

//--------------------------------------------------------------------------
// scall_fstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_fstat(SYSCALLPAR)
{
    void *buf = (void *)A2KRange(scall_ecx,sizeof(struct stat));
    if(buf == NULL) return -EFAULT;
    if((int)scall_ebx<3 || !scall_owned_fd((int)scall_ebx)) return -EBADF;
    return fstat(scall_ebx, buf);
}

//--------------------------------------------------------------------------
// scall_lstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_lstat(SYSCALLPAR)
{
    char pathname[JTMFS_PATH_MAX];
    void *buf=(void *)A2KRange(scall_ecx,sizeof(struct stat));
    if(!buf) return -EFAULT;
    if(scall_copyin_string(scall_ebx,pathname,sizeof(pathname))<0) return -EFAULT;
    return lstat(pathname,buf);
}


//--------------------------------------------------------------------------
// V69.7 mediated Ring3 filesystem, time and scheduling services.
typedef struct { long tv_sec; long tv_usec; } JTMOS_TIMEVAL_K;
typedef struct { long tv_sec; long tv_nsec; } JTMOS_TIMESPEC_K;

static int scall_is_leap_year(int year)
{
    return ((year%4)==0 && ((year%100)!=0 || (year%400)==0));
}

static long scall_epoch_seconds(const DATE *d)
{
    static const int month_days[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    long days=0;
    int y,m,year;
    if(!d) return -1;
    year=(d->year<70)?(2000+d->year):(1900+d->year);
    if(year<1970 || d->month<1 || d->month>12 || d->day<1 || d->day>31 ||
       d->hour<0 || d->hour>23 || d->minute<0 || d->minute>59 ||
       d->second<0 || d->second>60) return -1;
    for(y=1970;y<year;y++) days+=scall_is_leap_year(y)?366L:365L;
    for(m=1;m<d->month;m++) {
        days+=month_days[m-1];
        if(m==2 && scall_is_leap_year(year)) days++;
    }
    days+=(long)(d->day-1);
    return days*86400L+(long)d->hour*3600L+(long)d->minute*60L+(long)d->second;
}

int scall_rmdir(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    int n,rv;
    n=scall_copyin_string(scall_ebx,path,sizeof(path));
    if(n<0) return -EFAULT;
    errno=0;
    rv=rmdir(path);
    if(rv<0) return -(errno?errno:EIO);
    return 0;
}

int scall_fsync(SYSCALLPAR)
{
    FILEDES *f;
    int fd=(int)scall_ebx;
    if(fd<3 || !scall_owned_fd(fd)) return -EBADF;
    f=get_filedesptr(fd);
    if(!f) return -EBADF;
    return syncdev(f->dnr)==0 ? 0 : -EIO;
}

int scall_sync(SYSCALLPAR)
{
    return sync()==0 ? 0 : -EIO;
}

int scall_truncate(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    int n;
    if((int)scall_ecx<0) return -EINVAL;
    n=scall_copyin_string(scall_ebx,path,sizeof(path));
    if(n<0) return -EFAULT;
    return setsize(path,(int)scall_ecx)==0 ? 0 : -EIO;
}

int scall_ftruncate(SYSCALLPAR)
{
    FILEDES *f;
    int fd=(int)scall_ebx;
    int length=(int)scall_ecx;
    int rv;
    if(length<0) return -EINVAL;
    if(fd<3 || !scall_owned_fd(fd)) return -EBADF;
    f=get_filedesptr(fd);
    if(!f) return -EBADF;
    if((f->flags&O_ACCMODE)==O_RDONLY) return -EINVAL;
    rv=jtmfs_SetSize(f->dnr,f->name,length,f->db);
    if(rv!=0) return -EIO;
    if(f->max_offset_peek>length) f->max_offset_peek=length;
    return 0;
}

int scall_access(SYSCALLPAR)
{
    char path[JTMFS_PATH_MAX];
    int mode=(int)scall_ecx;
    int n,kind,fd,flags;
    if(mode & ~7) return -EINVAL;
    n=scall_copyin_string(scall_ebx,path,sizeof(path));
    if(n<0) return -EFAULT;
    kind=exist(path);
    if(kind<=0) return -ENOENT;
    if(kind==2) return 0; /* searchable JTMFS directory; no Unix mode bits yet */
    if(mode==0 || (mode&1)) { /* F_OK/X_OK: JTMFS has no executable ACL yet. */ }
    flags=(mode&2)?O_WRONLY:O_RDONLY;
    if((mode&(4|2))!=0) {
        errno=0;
        fd=open(path,flags);
        if(fd<0) return -(errno?errno:EACCES);
        close(fd);
    }
    return 0;
}

int scall_gettimeofday(SYSCALLPAR)
{
    JTMOS_TIMEVAL_K *tv;
    DATE d;
    long sec;
    if(!scall_ebx) return 0;
    tv=(JTMOS_TIMEVAL_K *)A2KRange(scall_ebx,sizeof(*tv));
    if(!tv) return -EFAULT;
    rtc_getdate(&d);
    sec=scall_epoch_seconds(&d);
    if(sec<0) return -EIO;
    tv->tv_sec=sec;
    tv->tv_usec=(long)(GetTickCount()%1000UL)*1000L;
    return 0;
}

int scall_nanosleep(SYSCALLPAR)
{
    JTMOS_TIMESPEC_K req,*in,*rem;
    long seconds,nsec;
    if(!scall_ebx) return -EFAULT;
    in=(JTMOS_TIMESPEC_K *)A2KRange(scall_ebx,sizeof(*in));
    if(!in) return -EFAULT;
    memcpy(&req,in,sizeof(req));
    seconds=req.tv_sec; nsec=req.tv_nsec;
    if(seconds<0 || nsec<0 || nsec>=1000000000L) return -EINVAL;
    /* Sleep in bounded pieces so no 32-bit microsecond conversion can wrap. */
    while(seconds>0) { MilSleep(1000); seconds--; }
    if(nsec>0) UsecSleep((DWORD)((nsec+999L)/1000L));
    if(scall_ecx) {
        rem=(JTMOS_TIMESPEC_K *)A2KRange(scall_ecx,sizeof(*rem));
        if(!rem) return -EFAULT;
        rem->tv_sec=0; rem->tv_nsec=0;
    }
    return 0;
}

int scall_sched_yield(SYSCALLPAR)
{
    SwitchToThread();
    return 0;
}

//--------------------------------------------------------------------------
// V65 safe userspace IRQ / ISA DMA mediation.
int scall_irqsubscribe(SYSCALLPAR)
{
    return userhw_irq_subscribe(GetCurrentThread(), (int)scall_ebx, scall_ecx);
}

int scall_irqunsubscribe(SYSCALLPAR)
{
    return userhw_irq_unsubscribe(GetCurrentThread(), scall_ebx);
}

int scall_irqwait(SYSCALLPAR)
{
    return userhw_irq_wait(GetCurrentThread(), scall_ebx, scall_ecx);
}

int scall_dmaalloc(SYSCALLPAR)
{
    JTMOS_DMA_BUFFER_K *out;
    out = (JTMOS_DMA_BUFFER_K *)A2KRange(scall_edx,sizeof(*out));
    if(out == NULL)
        return -14;
    return userhw_dma_alloc(GetCurrentThread(), scall_ebx, scall_ecx, out);
}

int scall_dmafree(SYSCALLPAR)
{
    return userhw_dma_free(GetCurrentThread(), scall_ebx);
}

int scall_dmaprogram(SYSCALLPAR)
{
    return userhw_dma_program(GetCurrentThread(), scall_ebx,
        (int)scall_ecx, scall_edx, (int)scall_esi);
}

int scall_dmastop(SYSCALLPAR)
{
    return userhw_dma_stop(GetCurrentThread(), scall_ebx, (int)scall_ecx);
}


// V67.6: controlled VGA/VESA 8-bit DAC palette update for Ring3 GraOS clients.
int scall_vgasetpalette(SYSCALLPAR)
{
    int index=(int)scall_ebx;
    int r=(int)scall_ecx,g=(int)scall_edx,b=(int)scall_esi;

    /* index -1 is a backwards-compatible control operation: restore the
     * complete system MCGA/VGA palette without consuming another syscall
     * number.  Normal 0..255 entry updates retain the V67.6 ABI. */
    if(index==-1)
    {
        setpalette256();
        return 0;
    }
    if(index<0 || index>255 || r<0 || r>63 || g<0 || g>63 || b<0 || b>63)
        return -1;
    setpaletteEx(index,r,g,b);
    return 0;
}


// V67.8.12: return kernel-validated CPU/OS feature mask.
int scall_getcpufeatures(SYSCALLPAR)
{
    return (int)cpuFeatureMask();
}


// V70.19: retain the last userspace GraOS startup stage even if the task exits
// before publishing the guiserver ready name. The launcher validates PID+magic.
volatile int graos_startup_diag_pid=0;
volatile DWORD graos_startup_diag_magic=0;
volatile int graos_startup_diag_stage=0;
volatile int graos_startup_diag_row=-1;

int scall_graosstartup(SYSCALLPAR)
{
    int pid=GetCurrentThread();
    int stage=(int)scall_ebx;
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS || stage<0 || stage>255)
        return 0;
    graos_startup_diag_pid=pid;
    graos_startup_diag_magic=thread_magic[pid];
    graos_startup_diag_stage=stage;
    graos_startup_diag_row=-1;
    return 1;
}

// V68.202: GraOS graphics transition runs with IRQs enabled; VESA owns a narrow transition lock.
int scall_graosgraphics(SYSCALLPAR)
{
    (void)scall_ebx; (void)scall_ecx; (void)scall_edx;
    (void)scall_esi; (void)scall_edi; (void)scall_ebp;

    /* A manually launched/older GraOS must not depend on the SMSH adapter to
     * have attached the pointing device.  This is intentionally idempotent. */
    if(PS2MOUSE_ENABLED)
        (void)ps2mouse_prepare_graos();

    return VesaStartGraOSGraphics() ? 1 : 0;
}
