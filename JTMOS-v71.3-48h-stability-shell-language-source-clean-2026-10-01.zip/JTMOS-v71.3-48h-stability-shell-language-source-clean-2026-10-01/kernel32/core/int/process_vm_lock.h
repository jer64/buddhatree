#ifndef JTMOS_PROCESS_VM_LOCK_H
#define JTMOS_PROCESS_VM_LOCK_H

/*
 * Process-context serializer for compound virtual-memory operations.
 *
 * Blocking lock order (outermost first):
 *   process VM mutex -> thread lifecycle mutex -> IRQ-save/MM critical region
 *
 * Page faults, the scheduler and raw MM allocators must never take this
 * sleeping mutex.  They retain their bounded IRQ-safe synchronization.  An
 * existing IF=0 publication window may only trylock and unwind on contention.
 */
int ProcessVmLockAt(const char *function,const char *file,int line);
void ProcessVmUnlockAt(const char *function,const char *file,int line);

#define ProcessVmLock() \
    ProcessVmLockAt(__FUNCTION__,__FILE__,__LINE__)
#define ProcessVmUnlock() \
    ProcessVmUnlockAt(__FUNCTION__,__FILE__,__LINE__)

#endif
