//===================================================================
// intgdt.c
// llint.asm multithreading system
// (C) 2001-2008 by Jari Tuominen.
//===================================================================
#include "kernel32.h"
#include "int.h"
#include "intgdt.h"

//
void randomscreen(void)
{
	char *p;
	int i;

	//
	p=JTM_DWORD_TO_PTR(char,0xB8000);
	for(i=0; i<(80*25*2); i++) p[i]=i;
}

//
void OnAppThread(void)
{
	/* Historical debugger trap removed: a valid application descriptor must
	 * never stop the scheduler.  Keep the symbol for source compatibility. */
	dprintk("OnAppThread: legacy debug hook ignored.\n");
}

//
void update_gdt_for_appthread(void)
{
	/* V70.67: the shared Ring-3 selectors 0x30/0x38 are immutable flat
	 * descriptors.  Older JTMOS revisions copied per-thread descriptor bytes
	 * into these global slots during switches; those cached descriptors were
	 * DPL0 in several legacy paths and could turn a valid USER_CS/USER_DS task
	 * into #TS/#GP on its next hardware resume.
	 *
	 * Per-process isolation and address translation are paging-owned now.
	 * Keep this compatibility hook as an intentional no-op so old assembly or
	 * out-of-tree modules cannot mutate the live shared user GDT entries. */
	if(!gdt_table)
		dprintk("update_gdt_for_appthread: GDT unavailable.\n");
}

//



