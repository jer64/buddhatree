#ifndef JTMOS_NMI_H
#define JTMOS_NMI_H

#include "basdef.h"

/*
 * Common logical IA-32 NMI snapshot.
 *
 * During early boot ASMexception_2 / ASMllexception_2 build this directly from
 * the interrupt-gate frame.  After TR is valid, V69.39 switches vector 2 to a
 * 386 task gate; NmiTaskDispatch then builds the same structure from the
 * hardware-saved interrupted TSS on the dedicated NMI task stack.
 */
typedef struct JTMOS_NMI_FRAME {
    /* V69.38: CR2 is explicitly preserved across the NMI C body.  The NMI
     * itself must never steal the page-fault address from an interrupted #PF. */
    DWORD cr2;
    DWORD gs,fs,es,ds;
    DWORD edi,esi,ebp,entry_esp,ebx,edx,ecx,eax;
    DWORD eip,cs,eflags;
    DWORD user_esp,user_ss;
} JTMOS_NMI_FRAME;

#define JTMOS_NMI_REASON_PARITY   0x80U
#define JTMOS_NMI_REASON_IOCHECK  0x40U
/* V70.4: the frame-preserving NMI core is enabled by default.  Safe boot and
 * `nmi=off` can still mask it, while bare-metal PMU programming remains an
 * explicit opt-in (`nmi=pmu` / `nmi watchdog pmu on`). */
#define JTMOS_NMI_DEFAULT_ENABLED           1U
#define JTMOS_NMI_WATCHDOG_DEFAULT_SECONDS 3U
#define JTMOS_NMI_WATCHDOG_MAX_SECONDS     300U
#define JTMOS_NMI_RESCUE_FREE    0U
#define JTMOS_NMI_RESCUE_PENDING 1U
#define JTMOS_NMI_RESCUE_HELD    2U
#define JTMOS_NMI_RESCUE_WRITING 3U /* internal: slot is being published/cleared */
#define JTMOS_NMI_RESCUE_AUTOKILL 4U /* watchdog has armed a #DB kill trap */

typedef struct JTMOS_NMI_STATS {
    DWORD total;
    DWORD unknown;
    DWORD parity;
    DWORD io_check;
    DWORD software_tests;
    DWORD nested;
    DWORD last_reason;
    DWORD last_eip;
    DWORD last_cs;
    DWORD last_eflags;
    DWORD last_cr2;
    DWORD last_pid;
    DWORD max_depth;
    DWORD watchdog_events;
    DWORD watchdog_threshold_seconds;
    DWORD rescue_pending;
    DWORD rescue_pid;
    DWORD rescue_no_switch_seconds;
    DWORD rescue_stall_seconds;
    DWORD rescue_forced_irq_count;
    DWORD watchdog_enabled;
    DWORD watchdog_samples;
    DWORD watchdog_unowned_skipped;
    DWORD watchdog_kernel_context_skipped;
    DWORD watchdog_force_if_enabled;
    DWORD watchdog_force_if_repairs;
    DWORD watchdog_last_force_if_pid;
    DWORD watchdog_last_force_if_eip;
    DWORD rescue_publish_conflicts;
    DWORD watchdog_autokills;
    DWORD watchdog_kill_traps;
    DWORD watchdog_guarddog_reaps;
    DWORD task_gate_entries;
    DWORD task_gate_bad_backlink;
    DWORD task_gate_active;
} JTMOS_NMI_STATS;

typedef struct JTMOS_NMI_RESCUE_INFO {
    DWORD sequence;
    DWORD pid;
    DWORD thread_magic;
    DWORD terminal;
    DWORD no_switch_seconds;
    DWORD stall_seconds;
    DWORD eip;
    DWORD cs;
    DWORD eflags;
    DWORD reason61;
    DWORD scheduler_timer_irqs;
    DWORD scheduler_context_switches;
    DWORD forced_irqs_on;
    DWORD active;
} JTMOS_NMI_RESCUE_INFO;

/*
 * Scheduler-visible quarantine.  A watchdog rescue never sets thread_states[]
 * to zero: the process is alive, but the scheduler skips it until the user
 * chooses Continue or Kill.  The second array is the requested coarse RTC
 * counter: seconds the current thread has remained active without a real task
 * switch, updated whenever the NMI watchdog samples the machine.
 */
extern volatile BYTE nmi_thread_suspended[];
extern volatile BYTE nmi_thread_recoverable[];
extern volatile BYTE nmi_thread_watchdog_kill_pending[];
extern volatile BYTE nmi_thread_watchdog_autokill[];
extern volatile DWORD thread_rtc_seconds_without_task_switch[];
/* Monotonic uptime second recorded on each real task switch.  NMI reads this
 * published scalar; it never accesses the shared CMOS selector/data ports. */
extern volatile DWORD thread_lastsec;

/* Called only by the vector-2 assembly entry.  It is deliberately NMI-safe:
 * no allocation, scheduler switch, filesystem, terminal, printf or ordinary
 * kernel lock. */
void NmiDispatch(JTMOS_NMI_FRAME *frame);
/* V69.39 runtime task-gate entry.  ASMnmi_task calls this on the dedicated
 * NMI TSS stack; it snapshots the hardware-saved interrupted TSS into the
 * common JTMOS_NMI_FRAME format and writes back only intentional EFLAGS edits. */
extern volatile DWORD nmi_task_gate_active;
void NmiTaskDispatch(void);
int NmiTaskGateInProgress(void);

/* Whole NMI subsystem control. */
int NmiSystemBootInit(void);
int NmiSystemSetEnabled(int enabled);
int NmiSystemGetEnabled(void);

/* Read-only diagnostics for SMSH and watchdog tools. */
void NmiGetStats(JTMOS_NMI_STATS *out);
int NmiSoftwareSelfTest(void);
int NmiSetUnknownPanic(int enabled);
int NmiGetUnknownPanic(void);

/* V68.208 watchdog policy. */
int NmiWatchdogSetEnabled(int enabled);
/* Explicit bare-metal PMU source control.  Ordinary enable never programs a
 * physical PMU; QEMU's host-clocked IB700 remains the preferred safe source. */
int NmiWatchdogSetPmuEnabled(int enabled);
int NmiWatchdogGetEnabled(void);
/* Last-resort liveness policy: after a proven watchdog stall, reopen IF for a
 * normal non-zero/non-immortal thread without killing or quarantining it. */
int NmiWatchdogSetForceIf(int enabled);
int NmiWatchdogGetForceIf(void);
int NmiWatchdogSetThreshold(DWORD seconds);
DWORD NmiWatchdogGetThreshold(void);
void NmiWatchdogResetThread(int pid);
int NmiWatchdogSetThreadRecoverable(int pid,int enabled);
int NmiWatchdogThreadRecoverable(int pid);
int NmiWatchdogKillTrapPending(int pid);
void NmiWatchdogKillTrapObserved(int pid);
/* Trusted kernel workers can opt into the same fail-stop policy as Ring3 apps.
 * This is used for dangerous SMSH builtins that are isolated from the shell. */
int NmiWatchdogSetThreadAutokill(int pid,int enabled);
int NmiWatchdogThreadAutokill(int pid);

/* Process-context rescue controls.  None of these are called by NmiDispatch. */
int NmiRescueGetInfo(JTMOS_NMI_RESCUE_INFO *out);
int NmiRescueClaimPrompt(JTMOS_NMI_RESCUE_INFO *out);
/* Process-context fallback for AUTOKILL slots.  It never runs from NMI. */
int NmiGuardDogReapOne(JTMOS_NMI_RESCUE_INFO *out);
int NmiRescueContinue(int pid);
int NmiRescueKeepSuspended(int pid);
int NmiRescueKill(int pid);
void NmiRescueInit(void);

#endif
