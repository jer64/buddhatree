#ifndef JTMOS_SYNC_H
#define JTMOS_SYNC_H

/* Common scheduler/lifecycle view of sleeping synchronization primitives. */
#define JTMOS_SYNC_WAIT_OK       0
#define JTMOS_SYNC_WAIT_ATOMIC  -1
#define JTMOS_SYNC_WAIT_NESTED  -2
#define JTMOS_SYNC_WAIT_BAD_PID -3

struct mutex;

int JtSyncThreadBlocked(int pid);
const char *JtSyncThreadWaitName(int pid);
int JtSyncBlockingWaitCheck(int pid,int saved_eflags);
const char *JtSyncBlockingWaitReason(int result);
void JtSyncThreadInit(int pid);
void JtSyncThreadCleanup(int pid);
void JtSyncThreadCleanupExceptMutex(int pid,struct mutex *keep_owned_lock);

#endif
