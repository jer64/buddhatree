/*
 * nmi_rescue.c - process-context companion for the V68.208 NMI watchdog.
 *
 * NmiDispatch never calls terminal, scheduler-switch or teardown code.  This
 * permanent low-priority worker runs only after the NMI has returned and IRQ0
 * has switched away from the quarantined process.
 */
#include <stdio.h>
#include "kernel32.h"
#include "nmi.h"
#include "threads.h"
#include "scheduler.h"
#include "term.h"
#include "keyb.h"
#include "threadpriorities.h"

static THREAD nmi_rescue_thread;
static int nmi_rescue_worker_pid=0;
static int nmi_rescue_started=0;

static void nmi_rescue_print(const JTMOS_NMI_RESCUE_INFO *r)
{
    char name[100];
    if(!r) return;
    name[0]=0;
    if((int)r->pid>=0 && (int)r->pid<nr_threads)
        GetThreadName((int)r->pid,name);
    if(!name[0]) strcpy(name,"UNKNOWN");

    printf("\n*** JTMOS NMI WATCHDOG RESCUE ***\n");
    printf("PID %u (%s), terminal %u\n",(unsigned)r->pid,name,(unsigned)r->terminal);
    printf("No task switch: at least %u s; watchdog evidence %u s\n",
           (unsigned)r->no_switch_seconds,(unsigned)r->stall_seconds);
    printf("CS:EIP=%x:%x EFLAGS=%x (IF was %s)\n",
           (unsigned)r->cs,(unsigned)r->eip,(unsigned)r->eflags,
           (r->eflags&0x200U)?"ON":"OFF");
    printf("The process is temporarily SUSPENDED; IRQ0/IRQ1 were forced back on.\n");
    printf("[C] Continue with IRQs enabled  [K] Kill process  [S] Keep suspended\n");
}

static void nmi_rescue_worker(void)
{
    int me=GetCurrentThread();

    IdentifyThread(me,"KNMI-RESCUE");
    SetThreadPriority(me,THREAD_PRIORITY_BELOW_NORMAL);
    SetThreadType(me,GetThreadType(me)|THREAD_TYPE_KERNEL|THREAD_TYPE_SERVICE|
                     THREAD_TYPE_IMMORTAL);

    for(;;)
    {
        JTMOS_NMI_RESCUE_INFO r;
        int claim;
        int prompt_terminal,old_terminal,saved_foreground,key,action=0;

        /* Fail-stop targets never require console input.  Drain them first so
         * a jammed application cannot leave an AUTOKILL slot/resources behind
         * if the TF/#DB stage did not finish teardown. */
        if(NmiGuardDogReapOne(&r)>0)
        {
            printf("NMI Guard Dog: PID %u terminated after watchdog stall at CS:EIP=%x:%x.\n",
                   (unsigned)r.pid,(unsigned)r.cs,(unsigned)r.eip);
            continue;
        }

        claim=NmiRescueClaimPrompt(&r);
        if(claim<=0)
        {
            SchedulerWaitPause(10000UL);
            continue;
        }

        prompt_terminal=GetInputTerminal();
        if(prompt_terminal<0 || prompt_terminal>=N_MAX_SCREENS)
            prompt_terminal=(r.terminal<N_MAX_SCREENS)?(int)r.terminal:0;

        old_terminal=GetThreadTerminal(me);
        SetThreadTerminal(me,prompt_terminal);
        saved_foreground=GetTerminalForegroundProcess(prompt_terminal);
        (void)SetTerminalForegroundProcess(prompt_terminal,me);

        nmi_rescue_print(&r);
        for(;;)
        {
            key=getch();
            if(key=='c' || key=='C')
            {
                if(NmiRescueContinue((int)r.pid)==0)
                {
                    printf("NMI rescue: PID %u continued; watchdog will ask again if it wedges again.\n",
                           (unsigned)r.pid);
                    action=1;
                }
                else
                    printf("NMI rescue: PID %u is no longer resumable.\n",(unsigned)r.pid);
                break;
            }
            if(key=='s' || key=='S')
            {
                (void)NmiRescueKeepSuspended((int)r.pid);
                printf("NMI rescue: PID %u remains suspended. Use `nmi rescue continue` or `nmi rescue kill`.\n",
                       (unsigned)r.pid);
                action=2;
                break;
            }
            if(key=='k' || key=='K')
            {
                printf("Kill PID %u? This cannot safely release an arbitrary lock it may hold. [Y/N] ",
                       (unsigned)r.pid);
                key=getch();
                printf("%c\n",key);
                if(key=='y' || key=='Y')
                {
                    if(NmiRescueKill((int)r.pid)==0)
                    {
                        printf("NMI rescue: PID %u terminated.\n",(unsigned)r.pid);
                        action=3;
                    }
                    else
                        printf("NMI rescue: PID %u could not be terminated.\n",(unsigned)r.pid);
                    break;
                }
                printf("Kill cancelled. [C] Continue  [K] Kill  [S] Suspend\n");
            }
        }

        /* Do not restore a foreground PID that was killed or deliberately left
         * quarantined.  Continue restores the terminal's previous job-control
         * owner when it still exists. */
        if(action==1 && saved_foreground>0 && saved_foreground<nr_threads &&
           thread_states[saved_foreground])
            (void)SetTerminalForegroundProcess(prompt_terminal,saved_foreground);
        else
            (void)SetTerminalForegroundProcess(prompt_terminal,0);
        SetThreadTerminal(me,old_terminal);
    }
}

void NmiRescueInit(void)
{
    DWORD flags;
    if(nmi_rescue_started) return;

    flags=get_eflags();
    disable();
    if(nmi_rescue_started)
    {
        set_eflags(flags);
        return;
    }

    if(ThreadCreateStack(&nmi_rescue_thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        set_eflags(flags);
        printk("NMI rescue worker: stack allocation failed.\n");
        return;
    }
    nmi_rescue_thread.pid=create_thread(nmi_rescue_thread.stack,
                                        nmi_rescue_thread.l_stack,
                                        nmi_rescue_worker);
    if(nmi_rescue_thread.pid>0)
    {
        nmi_rescue_worker_pid=nmi_rescue_thread.pid;
        nmi_rescue_started=1;
        NmiWatchdogResetThread(nmi_rescue_worker_pid);
    }
    else ThreadDestroyStack(&nmi_rescue_thread);
    set_eflags(flags);

    if(nmi_rescue_started)
        printk("NMI watchdog: rescue worker PID=%d, threshold=%u seconds/progress units.\n",
               nmi_rescue_worker_pid,(unsigned)NmiWatchdogGetThreshold());
    else
        printk("NMI watchdog: failed to create rescue worker.\n");
}
