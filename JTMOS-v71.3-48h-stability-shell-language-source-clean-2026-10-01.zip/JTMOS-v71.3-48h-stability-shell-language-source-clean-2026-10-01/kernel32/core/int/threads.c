//--------------------------------------------------------------
/* Private lazy CWD-cache lifecycle; definition is near cwd helpers. */
static void ReleaseThreadCWDCache(int pid);

// JTMOS THREADS - JTMOS THREAD MANAGEMENT SYSTEM
//
// This is the actual thread management code, this code still
// does not do any low level multitasking, it just manipulates
// the multithread engine(llint.asm).
//
// New: Added support for deallocation of all memory allocated
//      with malloc -function by a specific process.
//      From now on, on a malloc call, the malloc also
//      registers PID. Function void malloc_freeprocmem(int pid)
//      from malloc.h will be used in the deallocation process.
//
// (C) 2001-2005 by Jari Tuominen(jari@vunet.org).
//
// For more information, see README.
//--------------------------------------------------------------
//
// Some new functions:
// create_app_thread, RunApplication
//
#include "kernel32.h"
#include "userhw.h"
#include "rtc.h"
#include "int.h"
#include "threads.h" // Much of system threads, contains also thread_shell_ptr array.
#include "scheduler.h"
#include "sync.h"
#include "mutex.h"
#include "lock.h"
#include "dezombie.h"
#include "hexdump.h"
#include "vmware.h"
#include "tss.h" // LOW LEVEL TASK SEGMENTATION
#include "mm.h"  // V67 per-PID userspace page-table cleanup
#include "linuxabi.h" // V67.8.57 Linux/POSIX process lifecycle
#include "stack.h"

//
extern DWORD thread_shell_pointer[N_MAX_THREADS];

//---------------------------------------------------
// Multitasking enabled yet?
int Multitasking=0;
int threadMagic=0xFCE2E37B;
// Unique PID generation walking number
static int uniwalk JTM_UNUSED=0;

/* Serialize allocation, publication and teardown of thread-table slots.
 * The mutex is outside every long IRQ-disabled transaction.  A supported
 * syscall may cooperatively wait; an actual IRQ/exception/early-boot caller
 * can only take the uncontended fast path. */
static DEFINE_MUTEX(thread_lifecycle_mutex);

static int thread_lifecycle_lock(void)
{
	int flags=get_eflags();
	/* Some loader/fork publication windows deliberately arrive with IF=0.
	 * They may take the fast path, but must never sleep while IRQs are off. */
	if((flags&0x200) && LockWaitCanYield(flags))
	{
		mutex_lock(&thread_lifecycle_mutex);
		return 0;
	}
	return mutex_trylock(&thread_lifecycle_mutex) ? 0 : -1;
}

static void thread_lifecycle_unlock(void)
{
	mutex_unlock(&thread_lifecycle_mutex);
}

//
int kill(pid_t pid, int sig)
{
	(void)sig;
	KillThread(pid);
	return 0;
}

//
void abort(void)
{
	//
	ExitThread(0);
}

// Get process memory load
// (total number of kilobytes allocated by the process).
int GetThreadML(int pid)
{
	//
	return thread_ml[pid];
}

//
void SetThreadML(int pid, int load)
{
	//
	thread_ml[pid] = load;
}

// Track or untrack thread system calls.
void TrackThread(int pid, char val)
{
	if(val)
		SetThreadType(pid,
			GetThreadType(pid) | THREAD_TYPE_SYSCALL_TRACE);
	else
		SetThreadType(pid,
			GetThreadType(pid) & (~THREAD_TYPE_SYSCALL_TRACE));
}

// Get the count of task switches occured since start of the threads engine
int GetSwitchCount(void)
{
	return taskSwitchNr;
}

//---------------------------------------------------
// Legacy PID compatibility helpers.
//
// UNIPID generation is retired in V65.  Process identifiers are the plain
// thread-table PID (0..nr_threads-1).  Keep valid_pid() temporarily because some
// legacy source compatibility still exposes unif(), but active code uses valid_pid().
int valid_pid(int pid)
{
    return pid >= 0 && pid < nr_threads && pid < N_MAX_THREADS;
}

/* Legacy source-compatibility shim. New V65 code uses valid_pid(). */
int unif(int pid)
{
    return valid_pid(pid);
}

//---------------------------------------------------
// Find a process named by PTR name
//
int GetThreadPID(const char *name)
{
	int i;

	/* Process names survive until a PID slot is reused, while teardown marks
	 * the slot non-runnable first.  Returning such a stale name made service
	 * launchers (notably GraOS' "guiserver") believe a crashed instance was
	 * still alive.  It also made strcmp() unsafe for a not-yet-named slot.
	 * A name lookup is a live-process lookup, so ignore unpublished/dead slots. */
	if(name==NULL || name[0]=='\0') return -1;
	for(i=0; i<nr_threads; i++)
	{
		if(thread_states[i] && thread_name[i]!=NULL &&
		   !strcmp(thread_name[i], name))
		{
			// Found
			return i;
		}
	}

	// Not found
	return -1;
}

// Get thread TSS segment structure PTR.
TSSEG *GetThreadTSS(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return NULL;

	//
	return &tasks->tss[pid];
}

// Set current thread to sleep for X number of turns.
void SetToSleep(int x)
{
	/* Compatibility delay is PIT-aged by the scheduler.  Do not rely on
	 * future runnable scans to make this task eligible again. */
	SchedulerSetLegacyDelay(nr_curthread,x);
}

// Skip over a process that wants to sleep abit now.
void schedSleepSwitch(void)
{
	//
	if(Multitasking)
	{
		//
		SetToSleep(4);

		// Switch to next thread
		forceSwitch();
	}
}

// Called by PIT timer handler when a thread has
// exceeded it's run-time.
void ThreadTimeOut(void)
{
	// Increase spending for this thread
	thread_CPUspending[nr_curthread]++;
}

// Called on task switch by
// PIT handler / schedule switch (SwitchToThread).
void scheduleNextThread(void)
{
	// Switch to next thread
	forceSwitch();
}

// Used for sleeping
void Schedule(void)
{
	//
	SwitchToThread();
}

/* V70.2 buildfix1: foreground process-exit waiters.
 *
 * Store target_pid+1 so zero remains the static "not waiting" value.  The
 * direct wake is an optimization and, more importantly, closes the long wait
 * seen on VirtualBox after a child has already printed its output and exited.
 * Timed scheduler-clock sleep remains the race-safe fallback. */
static volatile DWORD thread_wait_target_plus1[N_MAX_THREADS];

static void thread_wait_target_set(int waiter,int target)
{
    if(waiter<0 || waiter>=N_MAX_THREADS) return;
    if(target<0 || target>=N_MAX_THREADS) { thread_wait_target_plus1[waiter]=0; return; }
    thread_wait_target_plus1[waiter]=(DWORD)target+1U;
}

static void thread_wait_target_clear(int waiter)
{
    if(waiter<0 || waiter>=N_MAX_THREADS) return;
    thread_wait_target_plus1[waiter]=0;
}

static void thread_wake_process_waiters(int target)
{
    int i;
    DWORD key;
    if(target<0 || target>=N_MAX_THREADS) return;
    key=(DWORD)target+1U;
    for(i=0;i<nr_threads && i<N_MAX_THREADS;i++)
    {
        if(thread_wait_target_plus1[i]==key)
        {
            thread_wait_target_plus1[i]=0;
            SchedulerWakeThread(i);
        }
    }
}

// Tick on!
int ThreadGiveMagic(void)
{
	threadMagic++;
	return threadMagic;
}

//---------------------------------------------------------------
// Waits until specified process exists.
void WaitProcessTermination(int pid)
{
    int waiter;

    if(!valid_pid(pid)) return;
    waiter=GetCurrentThread();
    while(valid_pid(pid) && GetThreadPriority(pid)!=0)
    {
        thread_wait_target_set(waiter,pid);
        /* Close the publish-vs-exit race before sleeping.  If the child has
         * already died, do not arm another wait interval. */
        if(!valid_pid(pid) || GetThreadPriority(pid)==0) break;
        SchedulerWaitPause(1000UL);
    }
    thread_wait_target_clear(waiter);
}

/* Wait for a foreground child while honoring Ctrl+C from the same
 * terminal.  Return 1 when Ctrl+C killed the child, 0 on normal exit. */
int WaitProcessTerminationInterruptible(int pid)
{
    int terminal;
    int waiter;

    if(!valid_pid(pid)) return 0;
    waiter=GetCurrentThread();
    terminal=GetCurrentTerminal();
    if(GetThreadTerminal(pid)==terminal)
        SetTerminalForegroundProcess(terminal,pid);
    while(valid_pid(pid) && GetThreadPriority(pid)!=0)
    {
        thread_wait_target_set(waiter,pid);
        if(!valid_pid(pid) || GetThreadPriority(pid)==0) break;
        if(GetThreadTerminal(pid)==terminal && ConsumeTerminalInterrupt(terminal))
        {
            int spins;
            printf("^C\n");

            /* Deliver POSIX-style SIGINT first.  Default SIGINT disposition
             * tears the task down synchronously.  JTMOS can also record a
             * userspace disposition, but full signal-frame delivery is not
             * implemented yet; in that case merely setting linux_pending[]
             * would leave the shell blocked forever.  Give the normal signal
             * path a few scheduler turns, then enforce the historical JTMOS
             * Ctrl+C contract: the foreground child is terminated. */
            (void)LinuxSignalSend(GetCurrentThread(),pid,JTMOS_SIGINT);
            for(spins=0; spins<4 && valid_pid(pid) &&
                         GetThreadPriority(pid)!=0; ++spins)
                SchedulerWaitPause(1000UL);

            if(valid_pid(pid) && GetThreadPriority(pid)!=0)
            {
                LinuxProcessExit(pid,0,JTMOS_SIGINT);
                KillThreadEx((DWORD)pid,KT_NO_THREAD_SWITCH);
            }

            while(valid_pid(pid) && GetThreadPriority(pid)!=0)
                SchedulerWaitPause(1000UL);
            thread_wait_target_clear(waiter);
            ClearTerminalForegroundProcess(pid);
            return 1;
        }
        SchedulerWaitPause(1000UL);
    }
    thread_wait_target_clear(waiter);
    ClearTerminalForegroundProcess(pid);
    return 0;
}

// Cause immediate task switch.
int SwitchToThread(void)
{
	/* A yield must not secretly sleep for two complete scheduler rounds.
	 * Timed sleeping belongs to MilSleep()/UsecSleep(); this function simply
	 * gives another runnable thread an immediate chance to execute. */
	if(Multitasking)
	{
		idle_moment();
	}
	return 0;
}

// SwitchToThreadEx
// Wakes up specified process and transfers
// CPU to it immediatly.
int SwitchToThreadEx(int pid)
{
	DWORD flags;

	if(!valid_pid(pid)) return 1;

	/* Keep target publication + INT 0x7E atomic against IRQ0. Otherwise a
	 * timer tick can consume the one-shot target before the explicit yield. */
	flags=get_eflags();
	disable();
	SchedulerWakeThread(pid);
	thread_tick[pid]=0;
	force_switch_thread_nr = pid;
	if(Multitasking) idle_moment();
	set_eflags(flags);
	return 0;
}

// Set thread command line
int SetThreadCmdLine(int pid, const char *CmdLine)
{
	// Check that the process really exists.
	if(!valid_pid(pid) || CmdLine==NULL) return 1;

	// Allocate command line if neccessary.
	if( thread_cmdline[pid]==NULL )
	{
		thread_cmdline[pid] = malloc(256);
		if(thread_cmdline[pid]==NULL) return 1;
		ChangeChunkOwner(thread_cmdline[pid], mm_kernel_persistent_owner());
		SetMemoryName(thread_cmdline[pid], "ThreadCmdLine");
	}

	// Store command line string.
	strncpy(thread_cmdline[pid], CmdLine, 255);
	thread_cmdline[pid][255]=0;
	return 0;
}

// Get currently being used terminal
int GetCurrentTerminal(void)
{
	/* Before init_threads() there is no process-local terminal yet.  Follow the
	 * explicitly selected visible console so early boot can be routed to VT2
	 * without special-casing printk/putch. */
	if(Multitasking!=TRUE)
	{
		if(visible_terminal>=0 && visible_terminal<N_VIRTUAL_TERMINALS &&
		   !screens[visible_terminal].isFree)
			return visible_terminal;
		return JTMOS_VT_STATUS;
	}

	return GetThreadTerminal(GetCurrentThread());
}

//
int GetThreadTerminal(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return thread_terminal[pid];
}

//
void SetThreadTerminal(int pid, int ter)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return;

	/* A process must never carry an invalid terminal index.  Exec resolves
	 * the -1 inheritance sentinel before this point; this clamp is the final
	 * defence for old/internal callers. */
	if(ter < 0 || ter >= N_MAX_SCREENS) ter=0;
	thread_terminal[pid] = ter;
}

// Get oointer to thread's shell structure.
void *GetThreadShellPTR(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return NULL;

	// Stored as a 32-bit kernel ABI address on IA-32.
	return (void *)thread_shell_pointer[pid];
}

// Set oointer to thread's shell structure.
void SetThreadShellPTR(int pid JTM_UNUSED, void *_syssh JTM_UNUSED)
{
}


//
BYTE GetThreadPriority(DWORD pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return get_prio(pid);
}

//
void SetThreadPriority(DWORD pid, BYTE prio)
{
	if(!valid_pid(pid)) return;
	set_prio(pid, prio);
}

/* Return the x86 Current Privilege Level (CPL).
 *
 * IA-32 stores the current privilege level in the two low bits of CS.
 * Reading CS is unprivileged, so this helper is safe in both ring 0 and
 * ring 3.  This is a JTMOS/x86 extension; POSIX itself does not define
 * processor privilege rings. */
int getringlevel(void)
{
	unsigned short cs;

	__asm__ volatile("movw %%cs,%0" : "=rm"(cs));
	return (int)(cs & 3U);
}

// Get current thread PID(wrapper)
int getpid(void)
{
	//
	return GetCurrentThread();
}

// Get current thread PID
int GetCurrentThread(void)
{
	//
	if(Multitasking!=TRUE) { return 0; }

	//
	return nr_curthread;
}

// Get thread count
int GetThreadCount(void)
{
	//
	return nr_threads;
}

// Give thread a name
void IdentifyThread(DWORD pid, const char *_ident)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return;

	//
	_IdentifyThread(pid, _ident);
}

// --
void _IdentifyThread(DWORD pid, const char *_ident)
{
	//
	if(_ident==NULL || strlen(_ident)>38)return;

	//
	if(thread_name[pid]==NULL)
	{
		thread_name[pid] = malloc(256);
		if(thread_name[pid]==NULL) return;
		ChangeChunkOwner(thread_name[pid], mm_kernel_persistent_owner());
		SetMemoryName(thread_name[pid], "ThreadName");
	}

	//
	strcpy(thread_name[pid], _ident);
}

//---------------------------------------------------------------------
//
int ThreadCreateStack(THREAD *t ,int _stacksize)
{
	if(t==NULL) return -1;
	t->stack=NULL;
	t->l_stack=0;
	t->pid=0;
	if(_stacksize < JTMOS_MIN_DYNAMIC_STACK)
		_stacksize = JTMOS_MIN_DYNAMIC_STACK;
	t->stack = malloc(_stacksize);
	if(t->stack==NULL) return -1;
	SetMemoryName(t->stack, "ThreadStack");
	t->l_stack =_stacksize;
	return 0;
}

//
void ThreadDestroyStack(THREAD *t)
{
	if(t->stack)	free(t->stack);
	t->stack=NULL;
	t->l_stack=0;
}

// Loop & spare CPU time to others
void infLoop(void)
{
	while(1)
	{
	//	printk("HELLO WORLD - THIS TSS THREAD WORKS !\N");
		SwitchToThread();
	}
}

// Make process immortal.
void Immortal(int pid)
{
	//
	SetThreadType(pid, GetThreadType(pid) | THREAD_TYPE_IMMORTAL);
}

// Initialize multitasking scheduler system
void init_threads(void)
{
	int i;
	static int flags JTM_UNUSED;
	char *name,*p;

	//
	disable();
	printk("Initializing threads ...\n");

	//
	Multitasking=FALSE;

	//
	nr_threads=1;
	nr_curthread=0;

	//
	name = malloc(N_MAX_THREADS*100);
	if(name==NULL)
		KERNEL_FATAL("init_threads: cannot allocate thread name table");

	//
	for(i=0,p=name; i<N_MAX_THREADS; i++,p+=100)
	{
		//
		thread_special[i]=0; // 0 = non-zombie
		thread_states[i]=0;
		thread_ds[i]=0x10; // default => kernel data segment
		thread_es[i]=0x10;
		thread_fs[i]=0x10;
		thread_gs[i]=0x10;
		thread_ss[i]=0x10;
		thread_type[i]=0;
		thread_esps[i]=0;
		thread_tick[i]=0;
		thread_base[i]=0;
		thread_selector[i]=0;
		thread_banks[i]=0;
		thread_terminal[i]=0;
		thread_cmdline[i]=NULL;
		thread_name[i] = p;
		strcpy(thread_name[i], "UNKNOWN");
		thread_shell_pointer[i]=0;

		// Default name
	//	thread_name[i]=malloc(100);
	//	_IdentifyThread(i, "[NONE]");
	}

	// Init thread descriptors:
	memset(thread_codedescs, 0, N_MAX_THREADS*8);
	memset(thread_datadescs, 0, N_MAX_THREADS*8);

	// Enable first thread(init) and classify it before any syscall inspects it.
	thread_states[0]=1;
	thread_type[0]=THREAD_TYPE_KERNEL;
	SchedulerThreadInit(0);

	// This function creates entries inside the GDT which are
	// tasks, each task contain own registers such as
	// a real processor would have(i386),
	// that includes f.e. : eax,ebx,ecx,edx,esp,eip and so on:
	// Initialize TSS system.
	printk("  - TSS init\n");
	InitTSS();

	// Create and publish TSS for first thread:
	printk("  PASS 1\n");
	if(NewTSS(&tasks->tss[0], (DWORD)infLoop, SEG_NO_TSS, GetCurrentThread())!=0 ||
	   PublishThreadTSSDescriptor(0)!=0)
		KERNEL_FATAL("init_threads: cannot publish PID0 TSS");

	// We are at the 0x100:
	printk("  PASS 2\n");
	LOADTR(TSSSEL_OFFS);
	nr_curthread=0;
	/* V69.40: NMI remains disabled after TR becomes valid.  `nmi on` installs
	 * the task gate later from normal process context. */

	// Make process 0 (init process) immortal.
	printk("  PASS 3\n");
	Immortal(0);

	//
	printk("  - Done.\n");

	//
	printk("  - IdleThread init\n");
	init_IdleThread();
	//
	printk("  - Done.\n");

	//
//	if(vmware)
//	{
		printk("  - Enabling ACPI sleep support...\n");
		vmware_sleep_enabled = TRUE;
		vmware = TRUE;
		printk("  - Done.\n");
//	}

	//
	printk("Multitasking=TRUE :\n");
	/* V70.11: the historical one-second pause served no synchronization
	 * purpose and only delayed every boot. */
	Multitasking=TRUE;
	//
	printk("OK.\n");
}

// set_thread pid esp ss cs ds pc
//
// set_thread for KERNEL MODE THREADS
// which can access all memory available,
// aka non-application threads
//
// Renders threads so that it is runnable
//
// Special note:
// even 16-bit segment registers are stored
// at the 32-bit DWORD sized variables
// because of logicallity and sympathy
// for the assembly programs.
//
// KERNEL THREAD:
// set_thread(key, _pr_stack+(_stacksize-1),
//                GIMMIE_DS(),GIMMIE_CS(),GIMMIE_DS(),
//                _pr_pc);
//
// APPLICATION THREAD:
// set_thread(key, _real_esp,
//                0x38,0x30,0x38,
//                _pr_pc);
//
void set_thread(
	DWORD pid, DWORD _esp,
	DWORD _ss,DWORD _cs,
	DWORD _ds,DWORD _pc)
{
	// Memory based variable
	static int prid;
	DWORD *eip JTM_UNUSED,*eflags JTM_UNUSED;
	WORD *cs JTM_UNUSED;
	char *ren JTM_UNUSED;

	// copy to safety
	prid = pid;

	//
	if(prid<0 || prid>=nr_threads || prid>=N_MAX_THREADS)
	{
		dprintk("set_thread: illegal PID %d rejected.\n",prid);
		return;
	}

	//
	thread_ds[prid]=	_ds;
	thread_es[prid]=	_ds;
	thread_fs[prid]=	_ds;
	thread_gs[prid]=	_ds;
	//
	thread_ss[prid]=	_ss;
	thread_esps[prid]=	_esp;

	// reset tick, so that execution
	// priority gets right
	thread_tick[prid]=0;

	// And as a last thing we do the renderation:
	//
	thread_esps[prid] = JTM_PTR_TO_DWORD(RenderStack(
					JTM_DWORD_TO_PTR(char,_esp+GetThreadBase(pid)),
					_pc,pid,_ss,_cs,_ds)) - GetThreadBase(pid);
}

/* Abort a not-yet-published process slot.  This path is used only while
 * interrupts are disabled and before SetThreadPriority() makes the PID
 * runnable, so no other task can observe a half-built TSS. */
static void thread_create_abort(int pid,int parent,void *main_stack,int stack_owned)
{
	if(pid<=0 || pid>=N_MAX_THREADS) return;
	FpuForgetThread(pid);
	ProcessEnvRelease(pid);
	LinuxProcessDiscard(pid);
	if(stack_owned && main_stack!=NULL && parent>=0)
		(void)ChangeChunkOwner(main_stack,parent);
	if(tasks!=NULL) memset(&tasks->tss[pid],0,sizeof(tasks->tss[pid]));
	thread_states[pid]=0;
	thread_special[pid]=0;
	thread_base[pid]=0;
	thread_magic[pid]=0;
	thread_CPUspending[pid]=0;
	thread_type[pid]=0;
	SchedulerPriorityChanged(pid,0);
}

// create_thread
// -------------
//
// Creates a thread that can be executed.
// note: stack must be pre-allocated before
// the function call, this function will
// not allocate the stack, the stack size
// must be also reported properly, otherwise
// the thread will not run correctly.
//
// Thread running is set to default priority.
// 
// NEW NOTE:
// The stack must be allocated with kernel malloc,
// or else memory corruption will occur.
// System relies on dynamical memory allocation.
//
// New:
// Now stack is automatically placed in ownership
// of the thread. And is deallocated on thread termination.
//
// example:
// create_thread(stack_offs,1024*16,_my_thread_program);
//
DWORD create_thread(void *_pr_stack, DWORD _stacksize, void *_pr_pc)
{
	// IA-32 kernel ABI stores stack/entry addresses in 32-bit TSS fields.
	return create_threadEx((DWORD)_pr_stack, _stacksize, (DWORD)_pr_pc,
		0x08, 0x10); // code & data segment
}

//
DWORD CreateThreadA(void *_pr_stack, DWORD _stacksize, void *_pr_pc)
{

	// IA-32 kernel ABI stores stack/entry addresses in 32-bit TSS fields.
	return create_threadEx((DWORD)_pr_stack, _stacksize, (DWORD)_pr_pc,
		kappCodeSeg, kappDataSeg); // code & data segment
		// |1 = privilege level 1(0-2)
}

//	return create_threadEx(_pr_stack, _stacksize, _pr_pc,
//		kappCodeSeg, kappDataSeg); // code & data segment

// The real create thread function.
// Returns a plain PID.
DWORD create_threadEx(DWORD _pr_stack, DWORD _stacksize, DWORD _pr_pc,
	WORD codeSeg JTM_UNUSED, WORD dataSeg JTM_UNUSED)
{
	DWORD flags;
	int dnr,db,pid,parent,stack_owned=0;
	char str[256];
	TSSEG *ts;

	if(tasks==NULL || _pr_stack==0U || _pr_pc==0U ||
	   _stacksize<JTMOS_MIN_DYNAMIC_STACK ||
	   _stacksize>(0xffffffffUL-_pr_stack))
	{
		printk("create_threadEx: invalid stack/entry/TSS arguments.\n");
		return 0;
	}
	if(thread_lifecycle_lock()!=0)
	{
		dprintk("create_threadEx: lifecycle mutex busy in atomic context.\n");
		return 0;
	}

	flags=get_eflags();
	disable();
	parent=GetCurrentThread();
	pid=new_thread();
	if(pid<=0)
	{
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}

	FpuForgetThread(pid);
	LinuxProcessCreated(pid,parent);
	if(ProcessEnvInherit(pid,parent)<0)
	{
		printk("create_threadEx: warning: environment inheritance failed for PID%d; continuing.\n",pid);
		ProcessEnvRelease(pid);
	}

	if(ChangeChunkOwner((void *)_pr_stack,pid)!=pid)
	{
		thread_create_abort(pid,parent,(void *)_pr_stack,0);
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}
	stack_owned=1;

	thread_CPUspending[pid]=0;
	SchedulerThreadInit(pid);
	ts=&tasks->tss[pid];
	if(NewTSS(ts,_pr_pc,SEG_NO_TSS,pid)!=0)
	{
		thread_create_abort(pid,parent,(void *)_pr_stack,stack_owned);
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}
	ts->esp=_pr_stack+(_stacksize-16U);
	if(PublishThreadTSSDescriptor(pid)!=0)
	{
		thread_create_abort(pid,parent,(void *)_pr_stack,stack_owned);
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}

	thread_base[pid]=0;
	thread_special[pid]=0;
	thread_magic[pid]=ThreadGiveMagic();

	/* All failure-prone state is complete before this PID becomes runnable. */
	dnr=GetCurrentDNR(); db=GetCurrentDB(); (void)dnr; (void)db;
	CopyThreadCWDContext(pid,parent);
	sprintf(str,"process%d",pid);
	IdentifyThread(pid,str);
	SetThreadType(pid,THREAD_TYPE_KERNEL);
	SetThreadPriority(pid,THREAD_PRIORITY_NORMAL);

	thread_lifecycle_unlock();
	set_eflags(flags);
	return pid;
}

// This function is used by LaunchApp.c...
DWORD _createAppThread(int CODESEG, int DATASEG,
    void *base, DWORD pc, DWORD stackoffs)
{
	DWORD flags;
	int pid,parent;
	char str[256];
	TSSEG *ts;

	if(tasks==NULL || base==NULL || pc==0U || stackoffs==0U) return 0;
	/* _createAppThread is an application-only constructor.  Do not let a
	 * future loader accidentally publish an application TSS with DPL0
	 * selectors; trusted kernel work must use create_thread(). */
	if(CODESEG!=USER_CS || DATASEG!=USER_DS)
	{
		dprintk("_createAppThread: refusing non-Ring3 selectors CS=%x DS=%x.\n",
		        CODESEG,DATASEG);
		return 0;
	}
	if(thread_lifecycle_lock()!=0)
	{
		dprintk("_createAppThread: lifecycle mutex busy in atomic context.\n");
		return 0;
	}
	flags=get_eflags();
	disable();
	parent=GetCurrentThread();
	pid=new_thread();
	if(pid<=0)
	{
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}

	FpuForgetThread(pid);
	LinuxProcessCreated(pid,parent);
	if(ProcessEnvInherit(pid,parent)<0)
	{
		printk("_createAppThread: warning: environment inheritance failed for PID%d; continuing.\n",pid);
		ProcessEnvRelease(pid);
	}

	thread_base[pid]=JTM_PTR_TO_DWORD(base);
	thread_special[pid]=0;
	thread_magic[pid]=ThreadGiveMagic();
	thread_CPUspending[pid]=0;
	SchedulerThreadInit(pid);

	ts=&tasks->tss[pid];
	if(NewTSS(ts,pc,0x48,pid)!=0)
	{
		thread_create_abort(pid,parent,NULL,0);
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}
	ts->ds=DATASEG; ts->es=DATASEG; ts->fs=DATASEG; ts->gs=DATASEG;
	ts->ss=DATASEG; ts->esp=stackoffs;
	ts->cs=CODESEG; ts->eip=pc;
	if(PublishThreadTSSDescriptor(pid)!=0)
	{
		thread_create_abort(pid,parent,NULL,0);
		thread_lifecycle_unlock();
		set_eflags(flags);
		return 0;
	}

	CopyThreadCWDContext(pid,parent);
	sprintf(str,"process%d",pid);
	IdentifyThread(pid,str);
	/* Do not publish the application here.  The loader/fork caller must first
	 * finish page tables, selector/accounting metadata and THREAD_TYPE_APPLICATION,
	 * then call SetThreadPriority() as the final runnable-state publication. */

	thread_lifecycle_unlock();
	set_eflags(flags);
	return pid;
}

// Returns PID. Caller holds thread_lifecycle_mutex and has interrupts disabled.
// note: doesn't actually make the thread working,
// use create_thread for actual creation.
// NEW: now avoids zombies.
DWORD new_thread(void)
{
	int i,key,flags JTM_UNUSED,tm;

	//
	tm=0;
repeat:
	// Find free entry
	/* PID 0 is the permanent bootstrap/init task and also the historical
	 * error return value from this function.  Never recycle slot zero even if
	 * its state byte is accidentally observed clear. */
	for(i=1; i<nr_threads; i++)
	{
		if( !thread_states[i]
			&&
		thread_special[i]!=ISZOMBIE
			&&
		thread_special[i]!=ISDEZOMBIE
			&&
		thread_special[i]!=ISQUARANTINED
			&&
		thread_special[i]!=ISQUARANTINE_REAP
			&&
		LinuxProcessPidReusable(i) )
			// Return key
			return i;
	}

	// Already got too many threads?
	if(nr_threads>=(N_MAX_THREADS-4))
	{
		// Free all dezombies
		for(i=0; i<nr_threads; i++)
			if(thread_special[i]==ISDEZOMBIE)
				thread_special[i] = 0;

		// Repeat search
		tm++;
		if(tm>=10)
			// Out of threads!
			return 0;
		goto repeat;
	}

	// Allocate a new entry
	if(nr_threads < 1)
		nr_threads = 1;
	key=nr_threads; nr_threads++;

	// Return key
	return key;
}

// set_thread_memory_space
// -----------------------
//
// This function is needed to give applications
// own code/data segments.
// Though this function is not needed when
// a kernel thread is being created,
// because a kernel thread is created as default.
// So f.e. a systemcall which creates a thread,
// always creates an application thread,
// but a direct call to thread mgt. create_thread
// function creates a kernel mode thread.
//
void set_thread_memory_space(DWORD pid,
			DWORD offset,
			WORD limit)
{
	// RENDER CODE SEGMENT DESCRIPTOR
	// ------------------------------
	// Segment limit       (0-15 - 16 bits)
	thread_codedescs[0 + pid*8] = limit&255;
	thread_codedescs[1 + pid*8] = (limit>>8)&255;
	// Base                (0-15 - 16 bits)
	thread_codedescs[2 + pid*8] = (offset)&255;
	thread_codedescs[3 + pid*8] = (offset>>8)&255;
	// Base II             (16-23 - 8 bits)
	thread_codedescs[4 + pid*8] = (offset>>16)&255;
	// Flags
	thread_codedescs[5 + pid*8] = 0x9a;
	// Access
	thread_codedescs[6 + pid*8] = 0xcf;
	// Base III            (24-31 - 8 bits)
	thread_codedescs[7 + pid*8] = (offset>>24)&255;

	// RENDER DATA SEGMENT DESCRIPTOR
	// ------------------------------
	// Segment limit       (0-15 - 16 bits)
	thread_datadescs[0 + pid*8] = limit&255;
	thread_datadescs[1 + pid*8] = (limit>>8)&255;
	// Base                (0-15 - 16 bits)
	thread_datadescs[2 + pid*8] = offset&255;
	thread_datadescs[3 + pid*8] = (offset>>8)&255;
	// Base II             (16-23 - 8 bits)
	thread_datadescs[4 + pid*8] = (offset>>16)&255;
	// Flags
	thread_datadescs[5 + pid*8] = 0x92;
	// Access
	thread_datadescs[6 + pid*8] = 0xcf;
	// Base III            (24-31 - 8 bits)
	thread_datadescs[7 + pid*8] = (offset>>24)&255;
}

// This function sets a state fo a thread
// see thread.h for example priorities
// (e.g. THREAD_PRIORITY_NORMAL)
//
void set_prio(DWORD pid, BYTE prio)
{
	if(!valid_pid(pid)) return;
	thread_states[pid]=prio;
	SchedulerPriorityChanged((int)pid, prio);
}

// This function gets a state of a thread
// See set_prio too.
//
BYTE get_prio(DWORD pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return thread_states[pid];
}

/* Asynchronous containment only: remove a corrupt task from runnable
 * scheduling, but never free process resources from IRQ/exception context.
 * CPU_IDLE later performs the ordinary process-context teardown. */
static void thread_quarantine_async(int pid)
{
	if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) return;
	if(thread_special[pid]==ISQUARANTINE_REAP) return;
	/* A quarantined task can be either a mutex owner or a queued waiter.
	 * Remove it atomically before taking it out of the runnable set; otherwise
	 * one contained process fault could strand unrelated kernel threads. */
	JtSyncThreadCleanup(pid);
	thread_special[pid]=ISQUARANTINED;
	thread_states[pid]=0;
	SchedulerPriorityChanged(pid,0);
}

void ThreadQuarantineFromIRQ(int pid)
{
	thread_quarantine_async(pid);
}

void ThreadQuarantineFromException(int pid)
{
	thread_quarantine_async(pid);
}

/* Ordinary process-context teardown for quarantined tasks. */
void ThreadReapQuarantined(void)
{
	int i,me=GetCurrentThread();
	for(i=1;i<nr_threads && i<N_MAX_THREADS;i++)
	{
		if(i==me || thread_special[i]!=ISQUARANTINED) continue;
		if(thread_type[i]&THREAD_TYPE_IMMORTAL)
			KERNEL_FATAL("ThreadReapQuarantined: corrupt immortal task");
		thread_special[i]=ISQUARANTINE_REAP;
		KillThreadEx((DWORD)i,KT_NO_THREAD_SWITCH);
	}
}

// KillThread - terminates a process.
//
// This function kills a thread.
// A special method is used to kill a thread.
// In this method we do set the state of
// the specified thread to 255, which means
// in human language "waiting to be terminated".
// This method is only made to prevent a conflict
// being happending which would be something
// like following:
//
// - Thread is being killed.
// - Thread's entry is reused by some coincidence
//   at about the same time, causing an allocation
//   on the thread that is actually currently
//   still running.
//
// Special note:
// This method is still being unimplented since
// it only related to the cases where the thread
// terminates itself.
//
// 02.09.2003:
// - Added some rights management.
// - Immortal processes now cannot be terminated.
// 12.05.2002:
// - Dead process file descriptor deallocation.
// 25.04.2002(obsolete):
// - Dead process memory deallocation.
// (x.x.2003: now done at KZOMBIE)
// 24.04.2002:
// - Added thread GDT entry deallocation.
// - Added thread memory space deallocation.
//
void KillThread(DWORD pid)
{
	//
	KillThreadEx(pid, 0);
}

// The real kill thread function.
void KillThreadEx(DWORD pid, DWORD options)
{
	void *threadBasement;
	int flags,self;

	//---------------------------------------------------
	// Verify that the process really exists.
	//
	if(!valid_pid(pid)) return;
	if(pid==0)
	{
		/* Killing PID0 is an invalid request, not a reason to destroy the OS. */
		dprintk("KillThreadEx: refusing request to kill PID0.\n");
		return;
	}
	if(thread_lifecycle_lock()!=0)
	{
		dprintk("KillThreadEx: lifecycle mutex busy in atomic context for PID%d.\n",
			(int)pid);
		return;
	}
	/* The PID may have changed state while a process-context caller waited. */
	if(!valid_pid(pid))
	{
		thread_lifecycle_unlock();
		return;
	}


	//---------------------------------------------------
	// Apply thread type rule.
	//
	if( (GetThreadType(pid)&THREAD_TYPE_IMMORTAL) && (DWORD)GetCurrentThread()!=pid )
	{
		// Refuse to kill an immortal process.
		printk("\nProcess %d attempted terminate an immortal process.\n",
			GetCurrentThread());
		thread_lifecycle_unlock();
		ExitThread(0);
	}

	/* V70.63: KRESOURCE is an ownership anchor, not an immortal fault domain.
	 * Reject ordinary remote kill requests, but let CPU_IDLE reap it after an
	 * exception quarantine.  Before any teardown, orphan its persistent heap to
	 * owner -1 so malloc_freeprocmem() can never destroy global kernel state. */
	if((GetThreadType(pid)&THREAD_TYPE_RESOURCE_OWNER) &&
	   (DWORD)GetCurrentThread()!=pid && thread_special[pid]!=ISQUARANTINE_REAP)
	{
		dprintk("KillThreadEx: refusing ordinary kill of kernel resource owner PID%d.\n",
		        (int)pid);
		thread_lifecycle_unlock();
		return;
	}
	if(GetThreadType(pid)&THREAD_TYPE_RESOURCE_OWNER)
	{
		int moved;
		(void)mm_set_kernel_persistent_owner(MM_OWNER_KERNEL_GLOBAL);
		moved=mm_transfer_allocation_owner((int)pid,MM_OWNER_KERNEL_GLOBAL);
		dprintk("KRESOURCE: failover moved %d allocations from PID%d to owner -1.\n",
		        moved<0?0:moved,(int)pid);
	}

	// Already dead? Quarantined tasks still own resources and need teardown.
	if(thread_states[pid]==0 &&
	   thread_special[pid]!=ISQUARANTINED &&
	   thread_special[pid]!=ISQUARANTINE_REAP)
	{
		thread_lifecycle_unlock();
		return;
	}
	self=pid==(DWORD)GetCurrentThread();

	/* Direct kernel termination is represented as SIGKILL unless ExitThread()
	 * or a POSIX signal path already recorded a more specific wait status. */
	LinuxProcessExit((int)pid, 0, JTMOS_SIGKILL);

	//----------------------------------------------
	// We have to do this safely
	flags = get_eflags();
	disable();

	/* Detach a blocked waiter and hand owned sleeping mutexes to their next
	 * FIFO waiter before any stack or per-process memory can be reclaimed. */
	JtSyncThreadCleanupExceptMutex((int)pid,&thread_lifecycle_mutex);

	//----------------------------------------------
	/* V68.187: invalidate lazy FPU/SSE ownership BEFORE malloc_freeprocmem()
	 * can free thread_fpuregs[pid].  Otherwise the next #NM may FXSAVE into
	 * freed memory or a recycled PID may observe the old owner's context. */
	FpuForgetThread((int)pid);

	//----------------------------------------------
	// V65: release userspace IRQ subscriptions and ISA DMA mappings before
	// the process page table/backing memory is dismantled.
	userhw_release_pid(pid);

	//----------------------------------------------
	// Deallocate all PID devices.
	DevRemPID(pid);

	//----------------------------------------------
	// Release the process-private environment before this PID can be reused.
	ProcessEnvRelease((int)pid);

	//----------------------------------------------
	// Set thread state to non-running.
	thread_states[pid]=0;
	/* Publish termination to foreground waiters immediately.  The actual
	 * teardown continues in this dying task, but a waiter no longer depends on
	 * a PIT-based polling timeout before it can become runnable. */
	thread_wake_process_waiters((int)pid);

	//----------------------------------------------
	// We need to dellocate name?
	if(!illegal(thread_name[pid]) && thread_name[pid])
	{
	//// ** Not dellocated nowadays **:
	//	free(thread_name[pid]);
	//	thread_name[pid]=NULL;
	}

	// Free all terminals which this process owned
	FreePIDTerminals(pid);

	//
/*	//----------------------------------------------
	// We need to deallocate terminal?
	// Terminals 0-8 are static EGA terminals.
	if(thread_terminal[pid]>8)
	{
		// Deallocate the terminal
		FreeScreen(&screens[pid]);
	}*/

	//----------------------------------------------
	// We need to deallocate memory space?
	threadBasement = JTM_DWORD_TO_VOID(thread_base[pid]);
	if(threadBasement)
	{
		// ___ THIS IS NOW DONE IN DEZOMBIE PROCESS ___
		// It is rather hard to deallocate itself
		// without getting a page fault.

		// Deallocate base
//		free(threadBasement);
	}

	/* V67.8.57.8: dynamic mmap/grow regions own separate sparse backing.
	 * Release those aliases before clearing the page table and before the
	 * generic per-PID allocator sweep runs. */
	mm_release_process_mappings(pid);
	mm_clear_process_space(pid);

	/* Mailboxes are kernel-owned and may have been created by another sender.
	 * Detach and free explicitly; DestroyThreadMessageBox() synchronizes with
	 * send/receive publication so the pointer cannot become a use-after-free. */
	DestroyThreadMessageBox(pid);

	// We have a selector to free?
	if(thread_selector[pid]>=0x100)
	{
		FreeGDTEntry(thread_selector[pid]);
		thread_selector[pid]=0;
	}

	//
	deallocate_proc_filedes(pid);

	// Bugfix: First states[..] must be set to zero.
	// Before callinf freeprocmem.
	thread_states[pid]=0;
 
	// Bugfix: This must be done before endless wait loop.
	// Dellocate all kernel malloc -allocated memory.
	if(!XON_DEZOMBIE)	malloc_freeprocmem(pid);

	// ===========================================================
	// Finally clear all the preferences of the thread.
	//

	// Make scall not active for this thread.
	thread_scall_active[pid]=0;
	//
	thread_ds[pid]=0x10; // default => kernel data segment
	thread_es[pid]=0x10;
	thread_fs[pid]=0x10;
	thread_gs[pid]=0x10;
	thread_ss[pid]=0x10;
	thread_esps[pid]=0;
	if(thread_name[pid])
		strcpy(thread_name[pid], "zombie");
//	thread_cmdline[pid]=NULL;
	thread_tick[pid]=0;
	thread_base[pid]=0;
	thread_selector[pid]=0;
	thread_banks[pid]=0;
	thread_terminal[pid]=0;
	thread_type[pid]=0;
	thread_wait_target_plus1[pid]=0;
	/* A self-killing thread must keep its identity until it releases the
	 * lifecycle mutex.  Remote targets can be invalidated before publication. */
	if(!self) thread_magic[pid]=0;
	NmiWatchdogResetThread((int)pid);
	// DNR & DB
	thread_dnr[pid]=0;
	thread_db[pid]=0;
	ReleaseThreadCWDCache(pid);
	//
	if(!XON_DEZOMBIE)
		thread_special[pid]=0;
	else
		// For garbage collector thread:
		thread_special[pid]=ISZOMBIE;

	// !!!! FIXED HERE !!!!
	// We are the same thread?
	// YES => We conduct an immediate
	// switch to prevent conflicts.
	/* Release while the old task identity and IF=0 are still intact.  No woken
	 * lifecycle waiter can run before the final state is fully published. */
	thread_lifecycle_unlock();
	if(self) thread_magic[pid]=0;

	if(self && !(options&KT_NO_THREAD_SWITCH) )
	{
		// Disable interrupts to secure schedule
		disable();
		while(1) { SwitchToThread(); }
	}

	// Restore flags
	set_eflags(flags);

	// Return back...
	return;
}

// Waits until specified thread exits
void wait_thread(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return;

	//
	while( get_prio(pid) ) { SchedulerWaitPause(1000UL); }

	//
	return;
}

// Exit thread, exists current thread
//
void ExitThread(int rval)
{
	LinuxProcessExit(GetCurrentThread(), rval, 0);
	KillThread(GetCurrentThread());
	while(1) { SwitchToThread(); }
}

#define CHECKSEG(x) \
	do { \
		/* Selectors are 16-bit and JTMOS uses a large dynamic GDT.  The old \
		 * 0x1ff ceiling was obsolete and could panic on valid selectors. */ \
		if(((WORD)(x) & 0x0004U)!=0) { \
			dprintk("CHECKSEG: LDT selector 0x%x rejected; using kernel data selector.\n",(WORD)(x)); \
			(x)=SEG_DATA32; \
		} \
	} while(0)

//
void copysregstothread(void)
{
	CHECKSEG(tmpds); thread_ds[nr_curthread]=tmpds;
	CHECKSEG(tmpes); thread_es[nr_curthread]=tmpes;
	CHECKSEG(tmpfs); thread_fs[nr_curthread]=tmpfs;
	CHECKSEG(tmpgs); thread_gs[nr_curthread]=tmpgs;
	CHECKSEG(tmpss); thread_ss[nr_curthread]=tmpss;
}

//
void copysregsfromthread(void)
{
	tmpds = thread_ds[nr_curthread]; CHECKSEG(tmpds);
	tmpes = thread_es[nr_curthread]; CHECKSEG(tmpes);
	tmpfs = thread_fs[nr_curthread]; CHECKSEG(tmpfs);
	tmpgs = thread_gs[nr_curthread]; CHECKSEG(tmpgs);
	tmpss = thread_ss[nr_curthread]; CHECKSEG(tmpss);
}

//
void SetThreadStack(THREAD *t, BYTE *buf, int length)
{
	// set stack params
	t->stack =	buf;
	t->l_stack =	length;

	// wipe the stack (0xbd = C64 action replay filling code)
	memset(t->stack, 0xbd, t->l_stack);
}

// Returns current thread base offset
DWORD GetCurrentThreadBase(void)
{
	// Get base offset
	return GetThreadBase(GetCurrentThread());
}

// Returns thread limit
DWORD GetThreadLimit(int pid)
{
	DWORD i;
	int flags;

	// V65 uses the raw process table index as the PID.
	if(!valid_pid(pid)) return 0;


	//
	flags = get_eflags();
	disable();

	//
	i=0;
	//
	// Base                (0-15 - 16 bits)
	i |= thread_datadescs[0 + pid*8];
	i |= (thread_datadescs[1 + pid*8]<<8);

	//
	set_eflags(flags);

	//
	return i;
}

// Get a thread base
DWORD GetThreadBase(int pid)
{
	DWORD base;
	DWORD flags;

	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	flags = get_eflags();
	disable();

	// New code added
	base = thread_base[pid];

	//
	set_eflags(flags);

	//
	/* Keep the snapshot and saved IF state on this task's stack.  With
	 * interrupts enabled, a second task can enter this getter immediately
	 * after set_eflags() and before the return reads the snapshot. */
	return base;
}

/*
 * Creates a proper memory space for an application
 * to run at. It is needed when preparing to run
 * a program at a private memory space.
 * Naturally, the binary code(appbin) is copied within
 * the memory space.
 */
int MakeAppMemoryMap(APPLICATION *app,
                BYTE *appbin,int l_code,DWORD runsize)
{
	static int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	//
	if(!appbin || !app ||
		!l_code || !runsize)
	{
		// If invalid parameters entered,
		// return an error value.
		return 1;
	}

	//
	// Thoughts about the allocation
	// of the application memory space:
	//
	// It's actually quite funny since the allocation of
	// another application's virtual memory space is
	// actually made by using the kernel's malloc.
	// It isn't very low level, but I like it.
	//

	// Allocate space for the program
	app->buf =     malloc( ((runsize/65536)+1)*65536 );
	app->l_buf =   ((runsize/65536)+1)*65536;

	// Specify each of the sections seperately:
	app->stackarea =       app->buf;
	app->comarea =         (app->buf + (1024*8 * 1));
	app->codearea =        (app->buf + (1024*8 * 2));

	//
	dprintk("Caught binary copying: stk %x, com %x, cod %x, %d\n",
		app->stackarea,
		app->comarea,
		app->codearea,
		l_code);
//	ESCLOCK();

	// Copy the binary inside the application's virtual
	// memory space
	for(i=0; i<l_code; i++) { app->codearea[i]=appbin[i]; }

	//
	return 0;
}

//
void MapThreadGDT(APPLICATION *app)
{
	//
	dprintk("MapThreadGDT function call:\n");
	dprintk("<This is debug note> suggestion as base = 0x%x, pid=%d, length=%d banks\n",
		app->buf,app->thread->pid,
		app->l_buf/65536);

	// Specify memory area
	set_thread_memory_space(app->thread->pid, JTM_PTR_TO_DWORD(app->buf), app->l_buf/65536);
}

// This function terminates an application,
// it does also do the neccesary memory
// deallocation(freeing).
//
int TerminateApplication(APPLICATION *app)
{
	int flags;

	//
	if(!app)return 1;

	// - - - - - - - - - - - - - - - - - - - - - - - -
	// Disable interrupts(push flags too)
	flags = get_eflags();
	disable();

	//
	app->stackarea =	NULL;
	app->comarea =		NULL;
	app->codearea =	NULL;

	//
	app->l_buf =		0;

	// If something allocated, deallocate it.
	if(app->buf)
		free(app->buf);
	app->buf =		NULL;

	//
	KillThread(app->thread->pid);

	//
	app->thread->pid=0;

	// - - - - - - - - - - - - - - - - - - - - - - - -
	// Restore flags
	set_eflags(flags);

	//
	return 0;
}

// Legacy ABI helper: UNIPID is retired; return the plain PID unchanged.
DWORD GetThreadUniquePID(int pid)
{
    return pid;
}

//
DWORD GetRunningThreadsCount(void)
{
	int i,count;

	//
	for(i=0,count=0; i<nr_threads; i++)
	{
		if(GetThreadPriority(i)) count++;
	}

	//
	return count;
}

// The GetTickCount function retrieves the number of milliseconds that have elapsed since JTMOS was started. 
DWORD GetTickCount(void)
{
	return glvar.timer[10];
}

// Get tick count #2
DWORD GetTickCount2(void)
{
	return glvar.timer[11];
}

// Set thread type
void SetThreadType(int pid, int which)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return;

	// Set thread type
	thread_type[pid] = which;
}

// Get thread type
int GetThreadType(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	// Get type
	return thread_type[pid];
}

/* V68.129: keep printable CWD strings out of the fixed 0x200000..0x2dffff
 * kernel BSS window.  Only the pointer/valid/generation metadata is static.
 * A 256-byte cache buffer is allocated lazily from normal kernel memory when
 * a canonical string is actually available.  DNR/DB remain authoritative, so
 * allocation failure only disables the optimization; it never breaks cwd. */
static char *thread_cwd_cache[N_MAX_THREADS];
static BYTE thread_cwd_cache_valid[N_MAX_THREADS];
static DWORD thread_cwd_cache_generation[N_MAX_THREADS];

static char *ThreadEnsureCWDCache(int pid)
{
    char *p;
    DWORD flags;

    if(pid<0 || pid>=N_MAX_THREADS) return NULL;
    if(thread_cwd_cache[pid]!=NULL) return thread_cwd_cache[pid];

    /* Persistent kernel ownership keeps this cache independent from the target
     * process generic allocator sweep; ReleaseThreadCWDCache() frees it explicitly. */
    p=(char *)procmalloc(THREAD_CWD_CACHE_MAX,mm_kernel_persistent_owner(),"ThreadCWDCache");
    if(p==NULL) return NULL;
    p[0]=0;

    flags=get_eflags();
    disable();
    if(thread_cwd_cache[pid]==NULL)
    {
        thread_cwd_cache[pid]=p;
        p=NULL;
    }
    set_eflags(flags);

    if(p!=NULL) kfree(p);
    return thread_cwd_cache[pid];
}

static void ReleaseThreadCWDCache(int pid)
{
    char *p;
    DWORD flags;

    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags();
    disable();
    p=thread_cwd_cache[pid];
    thread_cwd_cache[pid]=NULL;
    thread_cwd_cache_valid[pid]=0;
    thread_cwd_cache_generation[pid]=0;
    set_eflags(flags);
    if(p!=NULL) kfree(p);
}

// Thread DNR
int GetThreadDNR(int pid)
{
	if(!valid_pid(pid)) return 0;
	return thread_dnr[pid];
}

void InvalidateThreadCWDCache(int pid)
{
    DWORD flags;

    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags();
    disable();
    thread_cwd_cache_valid[pid]=0;
    thread_cwd_cache_generation[pid]=0;
    if(thread_cwd_cache[pid]!=NULL) thread_cwd_cache[pid][0]=0;
    set_eflags(flags);
}

int SetThreadCWDCache(int pid, const char *path, DWORD generation)
{
    int len;
    char *cache;
    DWORD flags;

    if(!valid_pid(pid) || path==NULL) return 1;
    len=(int)strlen(path);
    if(len<0 || len>=THREAD_CWD_CACHE_MAX) return 1;
    cache=ThreadEnsureCWDCache(pid);
    if(cache==NULL) return 1;

    flags=get_eflags();
    disable();
    memcpy(cache,path,(unsigned int)len+1U);
    thread_cwd_cache_generation[pid]=generation;
    thread_cwd_cache_valid[pid]=1;
    set_eflags(flags);
    return 0;
}

int GetThreadCWDCache(int pid, DWORD generation, char *path, int max_len)
{
    int len;
    int rv=1;
    char *cache;
    DWORD flags;

    if(!valid_pid(pid) || path==NULL || max_len<=0) return 1;
    flags=get_eflags();
    disable();
    if(thread_cwd_cache_valid[pid] &&
       thread_cwd_cache_generation[pid]==generation)
    {
        cache=thread_cwd_cache[pid];
        if(cache!=NULL)
        {
            len=(int)strlen(cache);
            if(len+1<=max_len)
            {
                memcpy(path,cache,(unsigned int)len+1U);
                rv=0;
            }
        }
    }
    set_eflags(flags);
    return rv;
}

int SetThreadCWDContext(int pid, int dnr, int db)
{
    DWORD flags;

    if(!valid_pid(pid)) return 1;
    flags=get_eflags();
    disable();
    thread_dnr[pid]=dnr;
    thread_db[pid]=db;
    InvalidateThreadCWDCache(pid);
    set_eflags(flags);
    return 0;
}

int CopyThreadCWDContext(int dst_pid, int src_pid)
{
    DWORD flags;

    if(!valid_pid(dst_pid) || !valid_pid(src_pid)) return 1;
    flags=get_eflags();
    disable();
    thread_dnr[dst_pid]=thread_dnr[src_pid];
    thread_db[dst_pid]=thread_db[src_pid];
    /* Copy only the authoritative identity here.  A child can lazily rebuild
     * the printable path on its first getcwd(); this keeps thread creation free
     * of allocator calls while interrupts are disabled. */
    InvalidateThreadCWDCache(dst_pid);
    set_eflags(flags);
    return 0;
}

// Set thread DNR.  Legacy callers remain supported, but invalidate the path
// cache because DNR/DB together define cwd identity.
int SetThreadDNR(int pid, int what)
{
	if(!valid_pid(pid)) return 0;
	thread_dnr[pid] = what;
    InvalidateThreadCWDCache(pid);
	return 0;
}

int GetThreadDB(int pid)
{
	if(!valid_pid(pid)) return 0;
	return thread_db[pid];
}

int SetThreadDB(int pid, int what)
{
	if(!valid_pid(pid)) return 0;
	thread_db[pid] = what;
    InvalidateThreadCWDCache(pid);
	return 0;
}

int GetCurrentDNR(void)
{
	return GetThreadDNR(GetCurrentThread());
}

//
int GetCurrentDB(void)
{
	return GetThreadDB(GetCurrentThread());
}

//
void SleepSecond(void)
{
	DATE d,od;
	DWORD start_ticks,polls=0;

	/* RTC may be absent/stuck during early boot.  PIT time bounds the normal
	 * case and the poll counter bounds the pre-PIT case, so warning paths can
	 * never stop boot forever waiting for CMOS seconds to advance. */
	rtc_getdate(&od);
	start_ticks=GetTickCount();
	while(1)
	{
		rtc_getdate(&d);
		if(d.second!=od.second) break;
		if((DWORD)(GetTickCount()-start_ticks)>=2000U) break;
		if(++polls>=2000000U) break;
		if(Multitasking) SchedulerWaitPause(10000UL);
	}
}

// Sleeps specified duration of seconds
int sleep(int seconds)
{
	int i;

	if(seconds<=0) return 0;
	for(i=0; i<seconds; i++) SleepSecond();
	return 0;
}

// Get thread CPU spending
int GetThreadSpending(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return thread_CPUspending[pid];
}

// Get thread memory usage
// Returns amount of bytes thread uses.
// 0 for kernel mode.
int GetThreadMemoryUsage(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return thread_banks[pid] * 1024*64;
}

// Get thread name
int GetThreadName(int pid, char *s)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	if(thread_name[pid]==NULL)
		strcpy(s, "[NULL]");
		else
		strcpy(s, thread_name[pid]);
	return 0;
}

// Returns the beginning of memory region that
// is visible to the specified thread
DWORD GetThreadMemoryStart(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return GetThreadBase(pid);
}

// Returns the end of memory region that
// the specified thread can access.
DWORD GetThreadMemoryEnd(int pid)
{
	// Check that the process really exists.
	if(!valid_pid(pid)) return 0;

	//
	return GetThreadBase(pid) + GetThreadMemoryUsage(pid);
}

//
