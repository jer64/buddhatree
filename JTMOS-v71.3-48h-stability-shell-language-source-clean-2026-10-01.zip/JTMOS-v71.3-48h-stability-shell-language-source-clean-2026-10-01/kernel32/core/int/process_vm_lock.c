/*
 * Global process-VM transaction mutex.
 *
 * JTMOS currently schedules one CPU, but mmap/munmap/grow and fork are
 * multi-step operations over shared process/MM metadata.  This sleeping lock
 * gives those process-context paths one transaction boundary without putting
 * a sleeping primitive in page-fault, allocator, scheduler or IRQ code.
 */
#include "kernel32.h"
#include "mutex.h"
#include "lock.h"
#include "process_vm_lock.h"

static DEFINE_MUTEX(process_vm_mutex);

int ProcessVmLockAt(const char *function,const char *file,int line)
{
    int flags=get_eflags();

    /* A blocking acquisition starts only with hardware IRQs enabled.  The
     * syscall dispatcher marks these VM calls SCALL_IRQ_ON. */
    if((flags&0x200) && LockWaitCanYield(flags))
    {
        mutex_lock_at(&process_vm_mutex,function,file,line);
        return 0;
    }

    /* Early boot and atomic callers may use an uncontended transaction but
     * must never enqueue a stack waiter or enter the scheduler. */
    if(mutex_trylock_at(&process_vm_mutex,function,file,line))
        return 0;

    dprintk("[MM] process VM mutex busy in atomic context at=%s %s:%d\n",
            function ? function : "?",file ? file : "?",line);
    return -1;
}

void ProcessVmUnlockAt(const char *function,const char *file,int line)
{
    mutex_unlock_at(&process_vm_mutex,function,file,line);
}
