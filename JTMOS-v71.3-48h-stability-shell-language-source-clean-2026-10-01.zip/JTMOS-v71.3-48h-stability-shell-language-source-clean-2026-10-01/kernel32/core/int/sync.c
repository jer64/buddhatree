/* Unified scheduler/lifecycle bridge for sleeping synchronization objects. */
#include "kernel32.h"
#include "sync.h"
#include "mutex.h"
#include "rwsem.h"
#include "ksem.h"
#include "lock.h"

int JtSyncThreadBlocked(int pid)
{
    return JtMutexThreadBlocked(pid) ||
           JtRwsemThreadBlocked(pid) ||
           JtSemaphoreThreadBlocked(pid);
}

const char *JtSyncThreadWaitName(int pid)
{
    const char *name;
    name=JtRwsemThreadWaitName(pid); if(name) return name;
    name=JtSemaphoreThreadWaitName(pid); if(name) return name;
    name=JtMutexThreadWaitName(pid); if(name) return name;
    return 0;
}

/* One blocking-context policy for every sleeping synchronization primitive.
 * This is deliberately separate from acquisition semantics: uncontended
 * mutex/rwsem/semaphore operations are still legal with IF=0, but a caller
 * may not enqueue and sleep from a true IRQ/exception/early-boot context.
 * LockWaitCanYield() already knows about the supported INT 0x7f syscall case.
 *
 * The cross-primitive check is equally important.  Each primitive keeps a
 * stack waiter, so publishing a second blocking wait for the same PID would
 * make scheduler/lifecycle cleanup ambiguous and can leave a stale stack
 * pointer in one of the queues. */
int JtSyncBlockingWaitCheck(int pid,int saved_eflags)
{
    if(pid<0 || pid>=N_MAX_THREADS)
        return JTMOS_SYNC_WAIT_BAD_PID;
    if(!LockWaitCanYield(saved_eflags))
        return JTMOS_SYNC_WAIT_ATOMIC;
    if(JtSyncThreadBlocked(pid))
        return JTMOS_SYNC_WAIT_NESTED;
    return JTMOS_SYNC_WAIT_OK;
}

const char *JtSyncBlockingWaitReason(int result)
{
    switch(result)
    {
        case JTMOS_SYNC_WAIT_OK: return "ok";
        case JTMOS_SYNC_WAIT_ATOMIC: return "atomic-context";
        case JTMOS_SYNC_WAIT_NESTED: return "nested-blocking-wait";
        case JTMOS_SYNC_WAIT_BAD_PID: return "invalid-pid";
    }
    return "unknown";
}

void JtSyncThreadCleanup(int pid)
{
    JtSyncThreadCleanupExceptMutex(pid,0);
}

void JtSyncThreadCleanupExceptMutex(int pid,struct mutex *keep_owned_lock)
{
    JtSemaphoreThreadCleanup(pid);
    JtRwsemThreadCleanup(pid);
    JtMutexThreadCleanupExcept(pid,keep_owned_lock);
    JtLegacyLockThreadCleanup(pid);
}

void JtSyncThreadInit(int pid)
{
    JtSemaphoreThreadInit(pid);
    JtRwsemThreadInit(pid);
    JtMutexThreadInit(pid);
}
