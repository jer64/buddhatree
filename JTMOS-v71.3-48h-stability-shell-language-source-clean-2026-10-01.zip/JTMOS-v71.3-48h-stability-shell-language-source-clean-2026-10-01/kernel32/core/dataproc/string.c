/*
 * JTMOS STRING FUNCTIONS
 * ----------------------
 *
 * (C) 2001-2005 by Jari Tuominen(jari@vunet.org).
 *
 * Comes with useful string manipulation functions.
 * Aims to emulate STL's standard STRING module.
 *
 * NOTE: CONTAINS FUNCTIONS LIKE MEMCPY & MEMSET
 * THESE FUNCTIONS MAYBE RELOCATED TO SOME
 * OTHER LIBRARY TO CLEAN UP THE ORDER.
 */
#include <stdio.h>
#include "string.h"

extern char *ecvt(double arg,int ndigits,int *decpt,int *sign);
extern int ecvt_r(double arg,int ndigits,int *decpt,int *sign,char *out,int out_len);

//
static volatile DWORD RunningNumber=0;

/*
//
void *memcpy(void *dest, const void *src, size_t n)
{
	BYTE *s,*d;
	int i;

	//
	s = src;
	d = dest;

	//
	for(i=0; i<n; i++)
	{
		d[i] = s[i];
	}
}
*/

// Call this function to get a new value everytime,
// used in various applications.
//
DWORD GetRunningNumber(void)
{
    DWORD previous=1;
    /* i486 is the kernel baseline and therefore has XADD.  The LOCK prefix
     * keeps this generator unique if JTMOS later grows beyond one CPU, while
     * also closing the current IRQ/preemption lost-update window. */
    __asm__ __volatile__("lock; xaddl %0,%1"
                         : "+r"(previous), "+m"(RunningNumber)
                         : : "memory", "cc");
    return previous+1U;
}

/************ MISCELLANOUS STRING FUNCTIONS START **********************/

// split string and get specified section - sptstr
// sptstr(str,"dog cat fireman judge",' ',1,0);
// ^^ copies cat to str
//
// NOTE: if max_length is a zero, no limit is used.
//
// NOTE2: max_length should be used to secure the copies,
// 	  so the copies won't exceed the max. length of dst -string.
//
void sptstr(char *dst,const char *src,char split_mark,int nr_item,int max_length)
{
    int item=0;
    int written=0;
    const char *p;

    if(!dst) return;
    dst[0]=0;
    if(!src || nr_item<0 || (max_length>0 && max_length<1)) return;

    p=src;
    while(*p && item<nr_item) {
        while(*p==split_mark) p++;
        if(!*p) return;
        while(*p && *p!=split_mark) p++;
        item++;
    }
    while(*p==split_mark) p++;
    if(item!=nr_item || !*p) return;

    while(*p && *p!=split_mark) {
        /* max_length is the destination capacity, not the maximum payload.
         * Always reserve one byte for the terminating NUL.  A zero value keeps
         * the historical unbounded behaviour for legacy callers. */
        if(max_length>0 && written+1>=max_length) break;
        dst[written++]=*p++;
    }
    dst[written]=0;
}

//
int strlen(const char *s)
{
    const char *p=s;
    if(!s) return 0;
    while(*p) p++;
    return (int)(p-s);
}

//
int strcpy(char *o,const char *s)
{
    char *d=o;
    if(!o || !s) return 0;
    while((*d++=*s++)!=0) { }
    return (int)(d-o-1);
}

// strcmp
// zero 	= strings match
// nonzero 	= .. do not
int strcmp(const char *o,const char *s)
{
    const unsigned char *a=(const unsigned char *)o;
    const unsigned char *b=(const unsigned char *)s;
    if(o==s) return 0;
    if(!o) return -1;
    if(!s) return 1;
    while(*a && *a==*b) { a++; b++; }
    return (int)*a-(int)*b;
}

// Copyright (C) 1991 Free Software Foundation, Inc.
// This function is part of the GNU C Library.
/* Append SRC on the end of DEST.  */
char *strcat(char *dest,const char *src)
{
    char *d=dest;
    if(!dest || !src) return dest;
    while(*d) d++;
    while((*d++=*src++)!=0) { }
    return dest;
}

/**************** NUMERICAL FUNCTIONS START *****************/

DWORD dec2int(const char *s)
{
	return str2int(s);
}

// DWORD str2int(char *s)
//
// string to integer
// this function converts a string with a decimal
// value to 32-Bit interger
//
// ALSO KNOWN AS dec2int
//
// ex. str2int("100");
//
DWORD str2int(const char *s)
{
    DWORD value=0;
    DWORD digit;
    if(!s || !*s) return 0;
    while(*s) {
        if(*s<'0' || *s>'9') return 0;
        digit=(DWORD)(*s-'0');
        if(value>429496729UL || (value==429496729UL && digit>5UL))
            return 0;
        value=value*10UL+digit;
        s++;
    }
    return value;
}

// This function's work is identical to
// phex32, except that this function does
// not output any zeros in front of any
// non-zero number.
// If the value equals to zero, it'll
// print plain zero.
void shex32z(char *s,DWORD value)
{
 //
 char str[50],first_non_zero;
 int i,i2;

 //
 shex32(str,value);

 // i=	read pointer
 // i2=	write pointerr
 for(i=0,i2=0,first_non_zero=0,s[0]=0; ; i++)
 {
  if(!str[i])break;
  if(str[i]!='0')first_non_zero=1;
  if(first_non_zero){s[i2]=str[i]; s[i2+1]=0; i2++;}
 }

 // If nothing yet there, we just output a zero at string buffer
 if(!strlen(s))strcpy(s,"0");

 // copy to result string
// strcpy(s,str);

 //
}

//
void shex32(char *s,DWORD value)
{
	char str[50],str2[50];

	//
	shex16(str,     value & 65535);
	shex16(str2,    (value>>16) & 65535);
	strcpy(s,str2);
	strcat(s,str);
}

//
void shex16(char *s,WORD value)
{
	char str[50],str2[50];

	//
	shex8(str,	value & 255);
	shex8(str2,	(value>>8) & 255);
	strcpy(s,str2);
	strcat(s,str);
}

// Generates a string with 8-Bit hexadecimal number
void shex8(char *s,char value)
{
	char *t="0123456789ABCDEF";
	int offs;

	//
	offs=0;
	s[offs]=t[(value>>4)&0xf]; offs++;
	s[offs]=t[value&0xf]; offs++;
	s[offs]=0; offs++;

	//
	return;
}

// PRINT DECIMAL NUMBER WITH ALL ZEROES IN FRONT
void sdec32z(char *s,DWORD value)
{
	char d[]={'0','1','2','3','4','5','6','7','8','9'};
	unsigned int i,i2,i3,i4,i5,i6,i7,i8,i9,i10;
	int offs;

	//
	offs=0;

	// 10x 0s at 32bit int
	i=  value/1000000000 % 10;
	i2= value/100000000  % 10;
	i3= value/10000000   % 10;
	i4= value/1000000    % 10;
	i5= value/100000     % 10;
	i6= value/10000      % 10;
	i7= value/1000       % 10;
	i8= value/100        % 10;
	i9= value/10         % 10;
	i10=value/1          % 10;

	// Print integer in zero fashion
	s[offs]=d[i ]; offs++;
	s[offs]=d[i2]; offs++;
	s[offs]=d[i3]; offs++;
	s[offs]=d[i4]; offs++;
	s[offs]=d[i5]; offs++;
	s[offs]=d[i6]; offs++;
	s[offs]=d[i7]; offs++;
	s[offs]=d[i8]; offs++;
	s[offs]=d[i9]; offs++;
	s[offs]=d[i10]; offs++;
	s[offs]=0; offs++;
}

void sdec32(char *s, int value)
{
    DWORD magnitude;
    if(value<0) {
        strcpy(s,"-");
        magnitude=(DWORD)(-(value+1));
        magnitude++;
        _sdec32(s+1,magnitude);
    } else {
        _sdec32(s,(DWORD)value);
    }
}

void sudec32(char *s, int value)
{
	_sdec32(s, value);
}

// GENERATE ASCII DECIMAL INTEGER(Atmost 32bit)
// (Non-zero fashioned)
void _sdec32(char *s, DWORD value)
{
 int offs;
 char d[]={'0','1','2','3','4','5','6','7','8','9'};
 unsigned int i,i2,i3,i4,i5,i6,i7,i8,i9,i10,l;

 //
 offs=0;

 // 10x 0s at 32bit int
 i=  value/1000000000 % 10;
 i2= value/100000000  % 10;
 i3= value/10000000   % 10;
 i4= value/1000000    % 10;
 i5= value/100000     % 10;
 i6= value/10000      % 10;
 i7= value/1000       % 10;
 i8= value/100        % 10;
 i9= value/10         % 10;
 i10=value/1          % 10;

 //
 l=0;
 // Print integer in non-zero fashion
 if(i   || l)  { l=1; s[offs]=d[i ]; offs++; }
 if(i2  || l)  { l=1; s[offs]=d[i2]; offs++; }
 if(i3  || l)  { l=1; s[offs]=d[i3]; offs++; }
 if(i4  || l)  { l=1; s[offs]=d[i4]; offs++; }
 if(i5  || l)  { l=1; s[offs]=d[i5]; offs++; }
 if(i6  || l)  { l=1; s[offs]=d[i6]; offs++; }
 if(i7  || l)  { l=1; s[offs]=d[i7]; offs++; }
 if(i8  || l)  { l=1; s[offs]=d[i8]; offs++; }
 if(i9  || l)  { l=1; s[offs]=d[i9]; offs++; }
 // (Atleast print '0', or so)
 s[offs]=d[i10]; offs++;
 // zero at end
 s[offs]=0; offs++;
}

/********** NUMERICAL FUNCTIONS END *****************/

//
int isValidString(const char *s)
{
 int i;

 /* A NULL pointer is never a valid C string.  The old implementation
  * dereferenced s unconditionally, turning ordinary input validation into
  * a page fault. */
 if(s==NULL)
        return 0;

 for(i=0; i<256; i++)
        if(!s[i])
                return 1;

 return 0;
}

//
int CountWords(const char *s)
{
	int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED,l,lastSpace,words;

	if(!strlen(s))return 0;

	l=strlen(s);

	for(i=0,lastSpace=1,words=0; i<l; i++)
	{
		if( !s[i] )break;

		if(s[i]!=32 && lastSpace)
			words++;

		
		if(s[i]==32)	lastSpace=1;
			else
				lastSpace=0;
	}

	return words;
}

//
int strcpyarg(char *dst, const char *s, int which)
{
	int i,i2,i3 JTM_UNUSED,i4 JTM_UNUSED,l,lastSpace,words;

	strcpy(dst,"");

	if(!strlen(s))return 0;

	l=strlen(s);

	for(i=0,lastSpace=1,words=0; i<l; i++)
	{
		if( !s[i] )break;

		if(s[i]!=32 && lastSpace)
			words++;

		if(words==(which+1))
		{
			for(i2=0; i<l; i++,i2++)
			{
				if(!s[i])break;
				if(s[i]==' ')break;
				dst[i2]=s[i];
			}
			dst[i2]=0;
			return 0;
		}
		
		if(s[i]==32)	lastSpace=1;
			else
				lastSpace=0;
	}

	return words;
}

int asc2vt220(int c)
{
	if(c==0x0d) { return 0x0a; }
	if(c==0x0a) { return 0x0d; }
	return c;
}

int vt2202asc(int c)
{
	if(c==0x0d) { return 0x0a; }
	if(c==0x0a) { return 0x0d; }
	return c;
}

// Convert a single hex character to int
// (e.g. '0'-'F')
int hexchar2int(char ch)
{
	char *hs="0123456789abcdef";
	char *HS="0123456789ABCDEF";
	int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	for(i=0; i<16; i++)
	{
		if( hs[i]==ch )
			return i;
		if( HS[i]==ch )
			return i;
	}
	return 0;
}

int hex2int(const char *s)
{
    DWORD value=0;
    int digit;
    int count=0;
    if(!s || !*s) return 0;
    if(s[0]=='0' && (s[1]=='x' || s[1]=='X')) s+=2;
    if(!*s) return 0;
    while(*s) {
        if(*s>='0' && *s<='9') digit=*s-'0';
        else if(*s>='a' && *s<='f') digit=*s-'a'+10;
        else if(*s>='A' && *s<='F') digit=*s-'A'+10;
        else return 0;
        if(count>=8) return 0;
        value=(value<<4)|(DWORD)digit;
        count++;
        s++;
    }
    return (int)value;
}

/* $Id: strncmp.c,v 1.2 2001/11/06 01:29:38 pavlovskii Exp $ */
/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
int strncmp(const char *s1, const char *s2, int n)
{

  if (n <= 0 || s1==NULL || s2==NULL)
    return 0;
  do {
    if (*s1 != *s2++)
      return *(unsigned const char *)s1 - *(unsigned const char *)--s2;
    if (*s1++ == 0)
      break;
  } while (--n != 0);
  return 0;
}

/* $Id: strstr.c,v 1.2 2001/11/06 01:29:38 pavlovskii Exp $ */
/* Copyright (C) 1994 DJ Delorie, see COPYING.DJ for details */
char *strstr(const char *s, const char *find)
{
  char c, sc;
  int len;

  if ((c = *find++) != 0)
  {
    len = strlen(find);
    do {
      do {
	if ((sc = *s++) == 0)
	  return 0;
      } while (sc != c);
    } while (strncmp(s, find, len) != 0);
    s--;
  }
  return (char*) s;
}

//
void StretchPrint(const char *s, int len)
{
        int i,l;

        l = strlen(s);
        for(i=0; i<len; i++)
        {
                if(i>=l)
                        printf(" ");
                        else
                        printf("%c", s[i]);
        }
}

//
char *strncpy(char *s1, const char *s2, int n)
{
    char *ret=s1;
    if(!s1 || !s2 || n<=0) return ret;
    while(n>0 && *s2) {
        *s1++=*s2++;
        n--;
    }
    while(n>0) {
        *s1++=0;
        n--;
    }
    return ret;
}

// Reads string from "source" and outputs at "output".
// Same as strcpy but stops on one of the characters featured
// at "stops" -string.
void readStringEx(char *output, char *source, const char *stops)
{
	int i,i2,l,l2,wi;

	// Initialize output string
	strcpy(output, "");

	// Get source string length
	l = strlen(source);

	// Get stop chars string length
	l2 = strlen(stops);

	// Go through whole string
	for(i=0,wi=0; i<l; i++,wi++)
	{
		// Check for end of string
		if(!source[i])break;

		// Get length of pattern string
		l2 = strlen(stops);

		// Search for stop chars
		for(i2=0; i2<l2; i2++)
		{
			if(source[i]==stops[i2])goto stop;
		}
		output[wi] = source[i];
	}
stop:
	// Sign end
	output[wi] = 0;
}

char *seekTowardEnd(char *ptr, char *stops)
{
	int i JTM_UNUSED,i2,i3 JTM_UNUSED,i4 JTM_UNUSED,l,l2 JTM_UNUSED;
	char *p;

	l = strlen(stops);
	for(p=ptr; *p; p++)
	{
		// Check for stop mark
		for(i2=0; i2<l; i2++)
		{
			if(*p==stops[i2])goto stopNow;
		}
	}
stopNow:
	return p;
}

char *skipSpaces(char *ptr)
{
	char *p;

	for(p=ptr; ; p++)
	{
		if(!*p)break;
		if(*p!=' ')break;
	}
	return p;
}

// convert a string into double
static int jt_ascii_space(char c)
{
    return c==' ' || c=='\t' || c=='\n' || c=='\r' || c=='\v' || c=='\f';
}

static int jt_ascii_lower(int c)
{
    if(c>='A' && c<='Z') return c+('a'-'A');
    return c;
}

static int jt_match_word(const char *p,unsigned long left,const char *word)
{
    unsigned long i=0;
    while(word[i]) {
        if(i>=left || jt_ascii_lower((unsigned char)p[i])!=(unsigned char)word[i]) return 0;
        i++;
    }
    return (int)i;
}

static double jt_ieee_special(int negative,int nan_value)
{
    union { double d; DWORD w[2]; } u;
    u.w[0]=nan_value ? 1U : 0U;
    u.w[1]=(negative ? 0x80000000UL : 0UL) |
           (nan_value ? 0x7ff80000UL : 0x7ff00000UL);
    return u.d;
}

double jt_strntod(const char *nptr,unsigned long maxchars,char **endptr)
{
    const char *orig=nptr,*p,*exp_start;
    unsigned long left=maxchars,exp_left;
    double value=0.0;
    int negative=0,any=0,seen_nonzero=0,kept=0,exp10=0;
    int exp_negative=0,exp_value=0,exp_digits=0;
    static const double pow10_table[9]={
        1e1,1e2,1e4,1e8,1e16,1e32,1e64,1e128,1e256
    };
    int i,scale_exp;

    if(endptr) *endptr=(char *)nptr;
    if(!nptr || maxchars==0) return 0.0;
    p=nptr;
    while(left && jt_ascii_space(*p)) { p++; left--; }
    if(left && (*p=='+' || *p=='-')) { negative=(*p=='-'); p++; left--; }

    i=jt_match_word(p,left,"infinity");
    if(!i) i=jt_match_word(p,left,"inf");
    if(i) {
        p+=i; left-=(unsigned long)i;
        if(endptr) *endptr=(char *)p;
        return jt_ieee_special(negative,0);
    }
    i=jt_match_word(p,left,"nan");
    if(i) {
        p+=i;
        if(endptr) *endptr=(char *)p;
        return jt_ieee_special(negative,1);
    }

    while(left && *p>='0' && *p<='9') {
        int d=*p-'0';
        any=1;
        if(!seen_nonzero && d==0) {
            /* Leading integer zero has no effect on significant precision. */
        } else if(kept<18) {
            value=value*10.0+(double)d;
            kept++; seen_nonzero=1;
        } else {
            exp10++;
        }
        p++; left--;
    }
    if(left && *p=='.') {
        p++; left--;
        while(left && *p>='0' && *p<='9') {
            int d=*p-'0';
            any=1;
            if(!seen_nonzero && d==0) {
                exp10--;
            } else if(kept<18) {
                value=value*10.0+(double)d;
                kept++; seen_nonzero=1; exp10--;
            }
            p++; left--;
        }
    }
    if(!any) {
        if(endptr) *endptr=(char *)orig;
        return 0.0;
    }

    if(left && (*p=='e' || *p=='E')) {
        exp_start=p; exp_left=left;
        p++; left--;
        if(left && (*p=='+' || *p=='-')) { exp_negative=(*p=='-'); p++; left--; }
        while(left && *p>='0' && *p<='9') {
            exp_digits=1;
            if(exp_value<10000) {
                exp_value=exp_value*10+(*p-'0');
                if(exp_value>10000) exp_value=10000;
            }
            p++; left--;
        }
        if(!exp_digits) { p=exp_start; left=exp_left; }
        else exp10 += exp_negative ? -exp_value : exp_value;
    }

    if(endptr) *endptr=(char *)p;
    if(!seen_nonzero) return negative ? -0.0 : 0.0;
    if(exp10>400) return jt_ieee_special(negative,0);
    if(exp10<-400) return negative ? -0.0 : 0.0;

    scale_exp=exp10<0 ? -exp10 : exp10;
    for(i=0;scale_exp && i<9;i++,scale_exp>>=1) {
        if(scale_exp&1) {
            if(exp10<0) value/=pow10_table[i];
            else value*=pow10_table[i];
        }
    }
    return negative ? -value : value;
}

double strtod(const char *s1,char **s2)
{
    return jt_strntod(s1,0xffffffffUL,s2);
}

double atof(const char *ascfloatptr)
{
    return strtod(ascfloatptr,NULL);
}

// Convert float to string
void stringfloat(float fval,char *s)
{
    if(!s) return;
    sdouble(s,(double)fval);
}

// Print float on stdout without enabling floating-point work inside printk.
void printfloat(float fval)
{
    pdouble((double)fval);
}

// I had problems with badly formatted strings.
// This is why JTMOS LIBC functions nowadays
// work so that these first checks the file names
// that are passed to them.
//
// Badly terminated strings lead into
// program termination.
//
int StringCheck(const char *s)
{
        /* String validation is a recoverable libc/API error, not a kernel
         * invariant.  Never panic the whole operating system for a bad FILE
         * name supplied to fwrite(). */
        if(!isValidString(s))
                return 1;
        return 0;
}

#define RAD 17
// Print double number
void pdouble(double d)
{
    char str[128];
    sdouble(str,d);
    puts(str);
}

static int jt_double_class(double d,int *negative)
{
    union { double d; DWORD w[2]; } u;
    DWORD exponent;
    u.d=d;
    if(negative) *negative=(u.w[1]&0x80000000UL)!=0;
    exponent=(u.w[1]>>20)&0x7ffUL;
    if(exponent!=0x7ffUL) return 0;
    return ((u.w[1]&0x000fffffUL)!=0 || u.w[0]!=0) ? 2 : 1;
}

void sdouble(char *s,double d)
{
    char digits[80],out[128],expbuf[16];
    int dec=0,sign=0,cls,di=0,oi=0,frac=0,i;
    const int decimal_digits=5;

    if(!s) return;
    cls=jt_double_class(d,&sign);
    if(cls) {
        if(sign) out[oi++]='-';
        if(cls==2) { out[oi++]='n'; out[oi++]='a'; out[oi++]='n'; }
        else { out[oi++]='i'; out[oi++]='n'; out[oi++]='f'; }
        out[oi]=0; strcpy(s,out); return;
    }
    if(ecvt_r(d,RAD,&dec,&sign,digits,(int)sizeof(digits))!=0) {
        strcpy(s,"0");
        return;
    }
    if(sign) out[oi++]='-';

    /* Keep normal values readable in fixed notation; switch to compact
     * scientific notation rather than constructing hundreds of zeroes. */
    if(dec>18 || dec<-4) {
        out[oi++]=digits[0] ? digits[0] : '0';
        if(decimal_digits>0) {
            out[oi++]='.';
            for(i=1;i<=decimal_digits && digits[i];i++) out[oi++]=digits[i];
            while(oi>0 && out[oi-1]=='0') oi--;
            if(oi>0 && out[oi-1]=='.') oi--;
        }
        out[oi++]='e';
        if(dec-1>=0) out[oi++]='+'; else out[oi++]='-';
        sdec32(expbuf,(dec-1>=0)?dec-1:1-dec);
        for(i=0;expbuf[i] && oi+1<(int)sizeof(out);i++) out[oi++]=expbuf[i];
        out[oi]=0; strcpy(s,out); return;
    }

    if(dec<=0) {
        out[oi++]='0';
        if(decimal_digits>0) out[oi++]='.';
        for(i=0;i<-dec && frac<decimal_digits;i++,frac++) out[oi++]='0';
    } else {
        for(i=0;i<dec;i++) {
            out[oi++]=digits[di] ? digits[di++] : '0';
        }
        if(decimal_digits>0) out[oi++]='.';
    }
    while(frac<decimal_digits && oi+1<(int)sizeof(out)) {
        out[oi++]=digits[di] ? digits[di++] : '0';
        frac++;
    }
    out[oi]=0;
    while(oi>0 && out[oi-1]=='0') out[--oi]=0;
    if(oi>0 && out[oi-1]=='.') out[--oi]=0;
    if(oi==0 || (oi==1 && out[0]=='-')) { out[oi++]='0'; out[oi]=0; }
    strcpy(s,out);
}
