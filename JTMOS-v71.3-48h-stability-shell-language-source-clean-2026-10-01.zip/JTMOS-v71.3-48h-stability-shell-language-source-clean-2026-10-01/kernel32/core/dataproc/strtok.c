/* Copyright (C) 1991-2020 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <https://www.gnu.org/licenses/>.  */

#include <stdio.h>
#include "kernel32.h"
#include "strtok.h"
#include "strtok_r.h"

/* Parse S into tokens separated by characters in DELIM.
   If S is NULL, the last string strtok() was called with is
   used.  For example:
	char s[] = "-abc-=-def";
	x = strtok(s, "-");		// x = "abc"
	x = strtok(NULL, "-=");		// x = "def"
	x = strtok(NULL, "=");		// x = NULL
		// s = "abc\0=-def\0"
*/
char *
strtok (char *s, const char *delim)
{
  static char *thread_old[N_MAX_THREADS];
  static DWORD thread_old_magic[N_MAX_THREADS];
  static char *bootstrap_old;
  char **slot;
  int pid=GetCurrentThread();

  /* strtok() keeps its historical implicit-state ABI, but the state must not
   * be shared by unrelated kernel threads.  Pair the slot with thread_magic so
   * PID reuse cannot resurrect a pointer into a terminated task's buffer. */
  if(pid>=0 && pid<N_MAX_THREADS && valid_pid(pid)) {
    DWORD magic=thread_magic[pid];
    if(thread_old_magic[pid]!=magic) {
      thread_old[pid]=NULL;
      thread_old_magic[pid]=magic;
    }
    slot=&thread_old[pid];
  } else {
    slot=&bootstrap_old;
  }
  return __strtok_r (s, delim, slot);
}
