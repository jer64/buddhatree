#ifndef __JTMOS_KFORMAT_H__
#define __JTMOS_KFORMAT_H__

#include "stdarg.h"

typedef void (*jt_format_emit_fn)(void *context, char ch);

/*
 * Freestanding kernel formatter shared by printk/printf and sprintf.
 * JTMOS/i386 uses 32-bit int, long, size_t and pointers, while long long is
 * handled as a true 64-bit vararg.  Common flags, bounded field width and
 * precision, plus hh/h/l/ll/z/t modifiers are supported.
 */
int jt_vformat(jt_format_emit_fn emit, void *context,
               const char *format, va_list args);

#endif
