/* locktop.c - JTMOS live kernel lock inspector.
 * V68.205.
 */
#include <stdio.h>
#include <string.h>

#include "kernel32.h"
#include "scheduler.h"
#include "lock.h"
#include "driver_lock.h"
#include "keyb.h"
#include "locktop.h"

#define LOCKTOP_MAX_ROWS 320
#define LOCKTOP_DEFAULT_INTERVAL_MS 1000UL
#define LOCKTOP_POLL_MS 50UL

typedef struct LOCKTOP_ROW
{
    JTMOS_LOCK_MONITOR_ENTRY e;
    DWORD held_ms;
} LOCKTOP_ROW;

/* Keep monitor scratch space out of the SMSH thread stack. */
static JTMOS_LOCK_MONITOR_ENTRY locktop_snapshot[LOCKTOP_MAX_ROWS];
static LOCKTOP_ROW locktop_rows[LOCKTOP_MAX_ROWS];
static volatile int locktop_scratch_busy=0;

static int claim_scratch(void)
{
    int flags,ok=0;
    flags=get_eflags();
    disable();
    if(!locktop_scratch_busy)
    {
        locktop_scratch_busy=1;
        ok=1;
    }
    set_eflags(flags);
    return ok;
}

static void release_scratch(void)
{
    int flags;
    flags=get_eflags();
    disable();
    locktop_scratch_busy=0;
    set_eflags(flags);
}

static const char *safe_string(const char *s)
{
    return (s && *s) ? s : "?";
}

static const char *base_name(const char *s)
{
    const char *p,*best;
    if(s==NULL) return "?";
    best=s;
    for(p=s;*p;p++)
        if(*p=='/' || *p=='\\') best=p+1;
    return *best ? best : s;
}

static const char *kind_name(int kind)
{
    switch(kind)
    {
        case JTMOS_LOCK_KIND_FUNCTION: return "func";
        case JTMOS_LOCK_KIND_NAMED: return "named";
        case JTMOS_LOCK_KIND_DRIVER: return "driver";
        case JTMOS_LOCK_KIND_DRIVER_DIRECT: return "direct";
        case JTMOS_LOCK_KIND_MUTEX: return "mutex";
    }
    return "?";
}

static int parse_uint(const char *s,DWORD *out)
{
    DWORD v=0;
    if(s==NULL || !*s || out==NULL) return 0;
    while(*s)
    {
        DWORD digit;
        if(*s<'0' || *s>'9') return 0;
        digit=(DWORD)(*s-'0');
        if(v>429496729UL || (v==429496729UL && digit>5UL)) return 0;
        v=v*10UL+digit;
        s++;
    }
    *out=v;
    return 1;
}

static int collect_rows(DWORD minimum_ms)
{
    DWORD now,held;
    int i,n,driver_n,total=0;

    memset(locktop_snapshot,0,sizeof(locktop_snapshot));
    n=JtmosLockSnapshot(locktop_snapshot,LOCKTOP_MAX_ROWS);
    if(n<0) n=0;
    if(n>LOCKTOP_MAX_ROWS) n=LOCKTOP_MAX_ROWS;

    driver_n=driver_lock_snapshot(locktop_snapshot+n,LOCKTOP_MAX_ROWS-n);
    if(driver_n<0) driver_n=0;
    n+=driver_n;
    if(n>LOCKTOP_MAX_ROWS) n=LOCKTOP_MAX_ROWS;

    now=GetTickCount();
    for(i=0;i<n;i++)
    {
        held=locktop_snapshot[i].acquired_ms ?
             (DWORD)(now-locktop_snapshot[i].acquired_ms) : 0;
        if(held<minimum_ms) continue;
        locktop_rows[total].e=locktop_snapshot[i];
        locktop_rows[total].held_ms=held;
        total++;
    }
    return total;
}

static void sort_rows(int count)
{
    int i,j;
    LOCKTOP_ROW x;
    for(i=1;i<count;i++)
    {
        x=locktop_rows[i];
        j=i;
        while(j>0 && locktop_rows[j-1].held_ms<x.held_ms)
        {
            locktop_rows[j]=locktop_rows[j-1];
            j--;
        }
        locktop_rows[j]=x;
    }
}

static void print_snapshot(DWORD minimum_ms)
{
    JTMOS_CPU_STATS cpu;
    DWORD now;
    int i,count;

    memset(&cpu,0,sizeof(cpu));
    (void)SchedulerGetCpuStats(&cpu,sizeof(cpu));
    now=GetTickCount();
    count=collect_rows(minimum_ms);
    sort_rows(count);

    printf("locktop: uptime=%u.%03us cpu=%u.%u%% busy active=%d filter>=%ums\n",
           (unsigned)(now/1000UL),(unsigned)(now%1000UL),
           (unsigned)(cpu.cpu_busy_per_mille/10UL),
           (unsigned)(cpu.cpu_busy_per_mille%10UL),count,(unsigned)minimum_ms);
    if(count==0)
    {
        printf("  no active locks match the filter\n");
        return;
    }

    printf(" HELD(ms)  KIND    KEY/ADDR   PID OWNER            DEPTH LOCATION\n");
    for(i=0;i<count;i++)
    {
        JTMOS_LOCK_MONITOR_ENTRY *e=&locktop_rows[i].e;
        char owner[128];
        const char *warn="";
        owner[0]=0;
        if(e->owner_pid>=0 && e->owner_pid<GetThreadCount() &&
           GetThreadPriority(e->owner_pid)!=0)
            (void)GetThreadName(e->owner_pid,owner);
        if(!owner[0]) strcpy(owner,"?");
        if(locktop_rows[i].held_ms>=3000UL) warn=" STUCK?";
        else if(locktop_rows[i].held_ms>=1000UL) warn=" WARN";

        if(e->kind==JTMOS_LOCK_KIND_FUNCTION ||
           e->kind==JTMOS_LOCK_KIND_MUTEX)
            printf(" %8u  %-7s  %08x  %3d %-16.16s %5u %s:%d %s%s\n",
                   (unsigned)locktop_rows[i].held_ms,kind_name(e->kind),
                   (unsigned)e->key,e->owner_pid,owner,(unsigned)e->depth,
                   base_name(e->owner_file),e->owner_line,
                   safe_string(e->owner_function),warn);
        else
            printf(" %8u  %-7s  %8u  %3d %-16.16s %5u %s:%d %s%s\n",
                   (unsigned)locktop_rows[i].held_ms,kind_name(e->kind),
                   (unsigned)e->key,e->owner_pid,owner,(unsigned)e->depth,
                   base_name(e->owner_file),e->owner_line,
                   safe_string(e->owner_function),warn);
    }
}

static int wait_interruptible(DWORD interval_ms)
{
    DWORD waited=0,step;
    int terminal=GetCurrentTerminal();
    while(waited<interval_ms)
    {
        if(ConsumeTerminalInterrupt(terminal)) return 1;
        step=interval_ms-waited;
        if(step>LOCKTOP_POLL_MS) step=LOCKTOP_POLL_MS;
        SchedulerWaitPause(step*1000UL);
        waited+=step;
    }
    return ConsumeTerminalInterrupt(terminal) ? 1 : 0;
}

static void usage(void)
{
    printf("Usage: locktop [-w] [-i milliseconds] [-m held_ms]\n");
    printf("  default        one snapshot of all currently held locks\n");
    printf("  -w             refresh until Ctrl+C\n");
    printf("  -i MS          watch interval (50..60000 ms, default 1000)\n");
    printf("  -m MS          show locks held for at least MS\n");
}

int locktop_app(int argc,char **argv)
{
    DWORD interval=LOCKTOP_DEFAULT_INTERVAL_MS,minimum=0,v;
    int watch=0,i;

    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-w") || !strcmp(argv[i],"--watch")) watch=1;
        else if(!strcmp(argv[i],"-i"))
        {
            if(++i>=argc || !parse_uint(argv[i],&v) || v<50UL || v>60000UL)
            {
                printf("locktop: invalid interval\n");
                return 2;
            }
            interval=v;
        }
        else if(!strcmp(argv[i],"-m"))
        {
            if(++i>=argc || !parse_uint(argv[i],&minimum))
            {
                printf("locktop: invalid minimum hold time\n");
                return 2;
            }
        }
        else if(!strcmp(argv[i],"-h") || !strcmp(argv[i],"--help"))
        {
            usage();
            return 0;
        }
        else
        {
            printf("locktop: unknown option '%s'\n",argv[i]);
            usage();
            return 2;
        }
    }

    if(!claim_scratch())
    {
        printf("locktop: another locktop instance is already running\n");
        return 1;
    }

    do
    {
        print_snapshot(minimum);
        if(!watch) break;
        if(wait_interruptible(interval))
        {
            printf("^C\n");
            break;
        }
        printf("\n");
    } while(1);

    release_scratch();
    return 0;
}
