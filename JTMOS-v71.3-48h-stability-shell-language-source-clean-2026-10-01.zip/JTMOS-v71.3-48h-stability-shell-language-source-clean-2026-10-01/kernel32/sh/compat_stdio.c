/* JTMOS native-kernel compatibility helpers for modernized shell sources. */
#include "kernel32.h"
#include "compat_stdio.h"

int putchar(int c)
{
    putch(c);
    return c;
}
