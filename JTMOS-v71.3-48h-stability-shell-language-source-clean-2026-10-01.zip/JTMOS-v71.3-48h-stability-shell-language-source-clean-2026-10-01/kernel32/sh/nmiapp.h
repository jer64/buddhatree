#ifndef JTMOS_NMIAPP_H
#define JTMOS_NMIAPP_H
int nmi_app(int argc,char **argv);
#endif
