#ifndef _JTMOS_HDBENCH_H
#define _JTMOS_HDBENCH_H

#include "basdef.h"

/* Read-only hard-disk benchmark ABI.  The kernel owns the transfer buffer;
 * raw disk bytes are never copied to Ring 3. */
#define JTMOS_HDBENCH_ABI_VERSION          1UL
#define JTMOS_HDBENCH_OP_INFO              0UL
#define JTMOS_HDBENCH_OP_RUN               1UL

#define JTMOS_HDBENCH_MODE_NATIVE          0UL
#define JTMOS_HDBENCH_MODE_RAW_PIO         1UL

#define JTMOS_HDBENCH_CAP_NATIVE_READ      0x00000001UL
#define JTMOS_HDBENCH_CAP_RAW_PIO          0x00000002UL
#define JTMOS_HDBENCH_CAP_READ_ONLY        0x80000000UL

#define JTMOS_HDBENCH_MAX_REQUEST_SECTORS  256UL
#define JTMOS_HDBENCH_MAX_TEST_SECTORS     2048UL /* 1 MiB/call; userspace loops */

typedef struct {
    DWORD version;
    DWORD size;
    DWORD sector_size;
    DWORD total_sectors;
    DWORD max_request_sectors;
    DWORD max_test_sectors;
    DWORD capabilities;
} JTMOS_HDBENCH_INFO;

typedef struct {
    DWORD version;
    DWORD size;
    DWORD mode;
    DWORD start_lba;
    DWORD requested_sectors;
    DWORD completed_sectors;
    DWORD request_sectors;
    DWORD elapsed_ms;
    DWORD failed_lba;
    int status;
} JTMOS_HDBENCH_RESULT;

#endif
