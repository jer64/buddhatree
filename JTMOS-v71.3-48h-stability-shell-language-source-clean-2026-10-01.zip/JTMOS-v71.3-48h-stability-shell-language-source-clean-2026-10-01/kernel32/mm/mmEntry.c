// =================================================================
// mmEntry.c - Entry database management functions.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: safer descriptor reuse, bounds validation and graceful
//             descriptor exhaustion.
// =================================================================
#include <stdio.h>
#include "mm.h"
#include "mmEntry.h"
#include "slab.h"

#define MM_MAP_HASH_BITS 10
#define MM_MAP_HASH_SIZE (1U << MM_MAP_HASH_BITS)
static MD *mm_map_hash[MM_MAP_HASH_SIZE];
static MD *mm_dynamic_active;

static DWORD mm_map_hash_key(DWORD mapad)
{
    DWORD page=mapad/PAGESIZE;
    return (page ^ (page>>MM_MAP_HASH_BITS)) & (MM_MAP_HASH_SIZE-1U);
}

void mmEntryResetIndex(void)
{
    memset(mm_map_hash,0,sizeof(mm_map_hash));
    mm_dynamic_active=NULL;
    if(p_mm!=NULL) p_mm->free_head=NULL;
}

void mmIndexEntry(MD *m)
{
    DWORD bucket;
    if(m==NULL || m->isFree || m->mapad==0) return;
    bucket=mm_map_hash_key(m->mapad);
    m->hash_next=mm_map_hash[bucket];
    mm_map_hash[bucket]=m;
}

void mmUnindexEntry(MD *m)
{
    DWORD bucket;
    MD *cur,*prev;
    if(m==NULL || m->mapad==0) return;
    bucket=mm_map_hash_key(m->mapad);
    prev=NULL;
    cur=mm_map_hash[bucket];
    while(cur!=NULL)
    {
        if(cur==m)
        {
            if(prev==NULL) mm_map_hash[bucket]=(MD *)cur->hash_next;
            else prev->hash_next=cur->hash_next;
            m->hash_next=NULL;
            return;
        }
        prev=cur;
        cur=(MD *)cur->hash_next;
    }
    m->hash_next=NULL;
}

void mmRemoveEntry(MD *m)
{
    DWORD start,end;
    int dynamic;
    MD *cur,*prev;

    if(m == NULL || m->isFree)
        return;

    dynamic=m->dynamic_slot;
    mmUnindexEntry(m);
    if(m->kind == MM_MD_KIND_CONTIG && m->page > 0 && m->pages > 0)
    {
        start = (DWORD)m->page;
        end = start + (DWORD)m->pages;
        if(end >= start)
            mmFreeRegion(start, end);
    }

    if(dynamic)
    {
        prev=NULL; cur=mm_dynamic_active;
        while(cur!=NULL)
        {
            if(cur==m)
            {
                if(prev) prev->all_next=cur->all_next;
                else mm_dynamic_active=(MD *)cur->all_next;
                break;
            }
            prev=cur; cur=(MD *)cur->all_next;
        }
        memset(m,0,sizeof(MD));
        (void)mm_slab_free(m);
        return;
    }

    memset(m, 0, sizeof(MD));
    m->PID = -1;
    m->isFree = 1;
    m->free_next=p_mm ? p_mm->free_head : NULL;
    if(p_mm) p_mm->free_head=m;
}


// Exact allocation-base lookup. free() must receive the pointer returned by malloc().
MD *mmGiveMD(void *ptr)
{
    DWORD ad,bucket;
    MD *m;

    if(p_mm == NULL || ptr == NULL)
        return NULL;

    ad=(DWORD)ptr;
    bucket=mm_map_hash_key(ad);
    m=mm_map_hash[bucket];
    while(m!=NULL)
    {
        if(!m->isFree && m->mapad==ad)
            return m;
        m=(MD *)m->hash_next;
    }
    return NULL;
}


MD *mmGetNewEntry(void)
{
    MD *m;

    m = mmFindFreeEntry();
    if(m == NULL)
        m = mmNewEntry();

    return m;
}

MD *mmNewEntry(void)
{
    int i;
    MD *m;

    if(p_mm == NULL || p_mm->allocated == NULL)
        return NULL;
    if(p_mm->n_allocated < 0 || p_mm->max_allocated <= 0)
        return NULL;

    for(i=p_mm->n_allocated; i<p_mm->max_allocated; i++)
    {
        m = p_mm->allocated[i];
        if(m == NULL)
            continue;
        p_mm->n_allocated = i + 1;
        memset(m, 0, sizeof(MD));
        m->PID = -1;
        m->isFree = 0;
        return m;
    }

    /* V70: after buddy/slab bootstrap, the fixed early descriptor array is
     * only a seed. Overflow descriptors grow dynamically without enlarging the
     * boot-time MM database. Avoid recursion before slab is fully enabled. */
    if(!mm_slab_ready())
        return NULL;
    m=(MD *)mm_slab_alloc(sizeof(MD));
    if(m==NULL) return NULL;
    memset(m,0,sizeof(*m));
    m->PID=-1;
    m->isFree=0;
    m->dynamic_slot=1;
    m->all_next=mm_dynamic_active;
    mm_dynamic_active=m;
    return m;
}


MD *mmFindFreeEntry(void)
{
    MD *m;
    if(p_mm==NULL) return NULL;
    m=p_mm->free_head;
    if(m==NULL) return NULL;
    p_mm->free_head=(MD *)m->free_next;
    m->free_next=NULL;
    m->isFree=0;
    return m;
}


int GetChunkOwner(void *p)
{
    MD *m;
    int owner;
    DWORD flags;

    flags = mmCriticalEnter();
    m = mmDetermineOwner(p);
    owner = (m == NULL) ? 0 : m->PID;
    mmCriticalLeave(flags);
    return owner;
}

// Locate the descriptor containing an arbitrary pointer inside an allocation.
MD *mmDetermineOwner(void *p)
{
    int i;
    DWORD ad,p1,len;
    MD *m;

    if(p_mm == NULL || p == NULL)
        return NULL;

    ad = (DWORD)p;
    for(i=0; i<p_mm->n_allocated; i++)
    {
        m = p_mm->allocated[i];
        if(m == NULL || m->isFree || m->mapad == 0 || m->bytes <= 0)
            continue;

        p1 = m->mapad;
        len = (DWORD)m->bytes;

        // Overflow-safe containment check: ad in [p1,p1+len).
        if(ad >= p1 && (ad - p1) < len)
            return m;
    }

    m=mm_dynamic_active;
    while(m!=NULL)
    {
        if(!m->isFree && m->mapad!=0 && m->bytes>0)
        {
            p1=m->mapad; len=(DWORD)m->bytes;
            if(ad>=p1 && (ad-p1)<len) return m;
        }
        m=(MD *)m->all_next;
    }
    return NULL;
}

MD *mmFindOwnedEntry(int pid)
{
    int i; MD *m;
    if(p_mm==NULL) return NULL;
    for(i=0;i<p_mm->n_allocated;i++)
    {
        m=p_mm->allocated[i];
        if(m!=NULL && !m->isFree && m->PID==pid) return m;
    }
    for(m=mm_dynamic_active;m!=NULL;m=(MD *)m->all_next)
        if(!m->isFree && m->PID==pid) return m;
    return NULL;
}

int mmCountActiveEntries(void)
{
    int i,n=0; MD *m;
    if(p_mm!=NULL) for(i=0;i<p_mm->n_allocated;i++)
    { m=p_mm->allocated[i]; if(m!=NULL && !m->isFree) n++; }
    for(m=mm_dynamic_active;m!=NULL;m=(MD *)m->all_next) if(!m->isFree) n++;
    return n;
}

DWORD mmCountSparseEntries(void)
{
    int i; DWORD n=0; MD *m;
    if(p_mm!=NULL) for(i=0;i<p_mm->n_allocated;i++)
    { m=p_mm->allocated[i]; if(m!=NULL && !m->isFree && m->kind==MM_MD_KIND_SPARSE) n++; }
    for(m=mm_dynamic_active;m!=NULL;m=(MD *)m->all_next)
        if(!m->isFree && m->kind==MM_MD_KIND_SPARSE) n++;
    return n;
}

MD *mmAddEntry(int sp, int pages, int bytes)
{
    MD *m;

    if(!mallocOK)
        return NULL;
    if(sp <= 0 || pages <= 0 || bytes <= 0)
        return NULL;

    m = mmGetNewEntry();
    if(m == NULL)
    {
        // Descriptor exhaustion is handled like ordinary OOM. The caller
        // rolls back the physical bitmap reservation.
        return NULL;
    }

    memset(m, 0, sizeof(MD));
    m->isFree = 0;
    m->PID = -1;
    m->kind = MM_MD_KIND_CONTIG;
    m->page = sp;
    m->pages = pages;
    m->bytes = bytes;
    m->p = (void *)((DWORD)sp * PAGESIZE);

    return m;
}
