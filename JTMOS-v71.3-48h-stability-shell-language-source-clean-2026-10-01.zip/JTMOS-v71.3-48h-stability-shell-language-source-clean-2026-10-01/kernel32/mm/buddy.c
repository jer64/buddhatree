/*
 * buddy.c - V68.215 elementary Linux-style buddy page allocator for JTMOS.
 *
 * This is intentionally an isolated kernel-page pool.  The historical JTMOS
 * malloc bitmap remains authoritative for the rest of the kernel, while one
 * reserved power-of-two arena is split/coalesced in classic buddy orders.
 */
#include <stdio.h>
#include "mm.h"
#include "mmAlloc.h"
#include "buddy.h"

#define BUDDY_NONE (-1)
#define BUDDY_META_UNUSED 0
#define BUDDY_META_FREE   1
#define BUDDY_META_ALLOC  2
#define BUDDY_TARGET_PAGES (1U << MM_BUDDY_MAX_ORDER) /* up to 64 MiB */
#define BUDDY_MIN_PAGES    256U                        /* 1 MiB */

typedef struct {
    int next;
    signed char order;
    unsigned char state;
    unsigned short pad;
} BUDDY_META;

static BUDDY_META *buddy_meta;
static int buddy_free_head[MM_BUDDY_MAX_ORDER+1];
static DWORD buddy_pool_pages;
static DWORD buddy_free_pages;
static DWORD buddy_phys_page;
static DWORD buddy_virtual;
static int buddy_max_order;
static int buddy_enabled;
static DWORD buddy_allocations;
static DWORD buddy_frees;
static DWORD buddy_failed;

static int buddy_order_for_pages(DWORD pages)
{
    int order=0;
    DWORD n=1;
    while(n<pages && order<MM_BUDDY_MAX_ORDER) { n<<=1; order++; }
    return n==pages ? order : -1;
}

static void buddy_push(int order,int index)
{
    buddy_meta[index].state=BUDDY_META_FREE;
    buddy_meta[index].order=(signed char)order;
    buddy_meta[index].next=buddy_free_head[order];
    buddy_free_head[order]=index;
}

static int buddy_pop(int order)
{
    int index=buddy_free_head[order];
    if(index==BUDDY_NONE) return BUDDY_NONE;
    buddy_free_head[order]=buddy_meta[index].next;
    buddy_meta[index].next=BUDDY_NONE;
    buddy_meta[index].state=BUDDY_META_UNUSED;
    return index;
}

static int buddy_remove(int order,int wanted)
{
    int prev=BUDDY_NONE;
    int cur=buddy_free_head[order];
    while(cur!=BUDDY_NONE) {
        if(cur==wanted) {
            if(prev==BUDDY_NONE) buddy_free_head[order]=buddy_meta[cur].next;
            else buddy_meta[prev].next=buddy_meta[cur].next;
            buddy_meta[cur].next=BUDDY_NONE;
            buddy_meta[cur].state=BUDDY_META_UNUSED;
            return 0;
        }
        prev=cur;
        cur=buddy_meta[cur].next;
    }
    return -1;
}

int mm_buddy_init(void)
{
    DWORD desired,free_pages;
    int order,start_page,i;
    DWORD flags;
    void *map;

    if(buddy_enabled) return 0;
    if(!mallocOK) return -1;

    free_pages=malloc_getfreepages();
    desired=BUDDY_TARGET_PAGES;
    /* V70 page consumers prefer buddy. Reserve up to one quarter of currently
     * free RAM, capped by the kernel virtual-map budget. Keep a substantial
     * legacy reserve for old physically-contiguous kmalloc callers. */
    while(desired>BUDDY_MIN_PAGES && desired>free_pages/4U) desired>>=1;
    if(desired>free_pages/4U || desired<BUDDY_MIN_PAGES) {
        dprintk("buddy: disabled; only %u legacy free pages.\n",(unsigned)free_pages);
        return -1;
    }
    order=buddy_order_for_pages(desired);
    if(order<0) return -1;

    buddy_meta=(BUDDY_META *)_kmalloc((int)(desired*sizeof(BUDDY_META)),mm_kernel_persistent_owner(),
                                      "buddy metadata");
    if(buddy_meta==NULL) return -1;
    memset(buddy_meta,0,desired*sizeof(BUDDY_META));

    flags=mmCriticalEnter();
    start_page=mmFindFreePages((int)desired);
    if(start_page<=0 || mmTryReserveRegion((DWORD)start_page,(DWORD)start_page+desired)!=0) {
        mmCriticalLeave(flags);
        _kfree(buddy_meta); buddy_meta=NULL;
        return -1;
    }
    mmCriticalLeave(flags);

    map=(void *)pg_mapmemory(start_page,(int)desired);
    if(map==NULL) {
        mmFreeRegion((DWORD)start_page,(DWORD)start_page+desired);
        _kfree(buddy_meta); buddy_meta=NULL;
        return -1;
    }

    for(i=0;i<=MM_BUDDY_MAX_ORDER;i++) buddy_free_head[i]=BUDDY_NONE;
    buddy_pool_pages=desired;
    buddy_free_pages=desired;
    buddy_phys_page=(DWORD)start_page;
    buddy_virtual=(DWORD)map;
    buddy_max_order=order;
    buddy_allocations=buddy_frees=buddy_failed=0;
    buddy_push(order,0);
    buddy_enabled=1;

    dprintk("buddy: pool phys=0x%x virt=0x%x pages=%u order=%d (%u KiB).\n",
            buddy_phys_page*PAGESIZE,buddy_virtual,(unsigned)desired,order,
            (unsigned)(desired*PAGESIZE/1024U));
    return 0;
}

void *mm_buddy_alloc_order(int order)
{
    int current,index,buddy;
    DWORD flags,pages;

    if(!buddy_enabled || order<0 || order>buddy_max_order) {
        buddy_failed++;
        return NULL;
    }
    flags=mmCriticalEnter();
    current=order;
    while(current<=buddy_max_order && buddy_free_head[current]==BUDDY_NONE) current++;
    if(current>buddy_max_order) {
        buddy_failed++;
        mmCriticalLeave(flags);
        return NULL;
    }
    index=buddy_pop(current);
    while(current>order) {
        current--;
        buddy=index+(1<<current);
        buddy_push(current,buddy);
    }
    buddy_meta[index].state=BUDDY_META_ALLOC;
    buddy_meta[index].order=(signed char)order;
    buddy_meta[index].next=BUDDY_NONE;
    pages=(DWORD)1U<<order;
    if(buddy_free_pages>=pages) buddy_free_pages-=pages; else buddy_free_pages=0;
    buddy_allocations++;
    mmCriticalLeave(flags);
    return (void *)(buddy_virtual+(DWORD)index*PAGESIZE);
}

void *mm_buddy_alloc_zero(int order)
{
    void *p=mm_buddy_alloc_order(order);
    if(p) memset(p,0,((DWORD)1U<<order)*PAGESIZE);
    return p;
}

int mm_buddy_owns(const void *ptr)
{
    DWORD p=(DWORD)ptr;
    DWORD end;
    if(!buddy_enabled || ptr==NULL) return 0;
    end=buddy_virtual+buddy_pool_pages*PAGESIZE;
    return p>=buddy_virtual && p<end;
}

DWORD mm_buddy_virtual_to_physical(const void *ptr)
{
    DWORD p=(DWORD)ptr;
    if(!mm_buddy_owns(ptr)) return 0;
    return buddy_phys_page*PAGESIZE+(p-buddy_virtual);
}

void *mm_buddy_physical_to_virtual(DWORD physical)
{
    DWORD first,last;
    if(!buddy_enabled || (physical&(PAGESIZE-1U))) return NULL;
    first=buddy_phys_page*PAGESIZE;
    last=first+buddy_pool_pages*PAGESIZE;
    if(physical<first || physical>=last) return NULL;
    return (void *)(buddy_virtual+(physical-first));
}

int mm_buddy_free(void *ptr)
{
    DWORD p;
    int index,order,buddy,new_index;
    DWORD flags,pages;

    if(!mm_buddy_owns(ptr)) return -1;
    p=(DWORD)ptr;
    if((p-buddy_virtual)&(PAGESIZE-1U)) return -1;
    index=(int)((p-buddy_virtual)/PAGESIZE);

    flags=mmCriticalEnter();
    if(index<0 || (DWORD)index>=buddy_pool_pages ||
       buddy_meta[index].state!=BUDDY_META_ALLOC) {
        mmCriticalLeave(flags);
        return -1;
    }
    order=buddy_meta[index].order;
    if(order<0 || order>buddy_max_order) {
        mmCriticalLeave(flags);
        return -1;
    }
    pages=(DWORD)1U<<order;
    buddy_meta[index].state=BUDDY_META_UNUSED;

    while(order<buddy_max_order) {
        buddy=index^(1<<order);
        if(buddy<0 || (DWORD)buddy>=buddy_pool_pages ||
           buddy_meta[buddy].state!=BUDDY_META_FREE ||
           buddy_meta[buddy].order!=order)
            break;
        if(buddy_remove(order,buddy)!=0) break;
        new_index=index<buddy?index:buddy;
        buddy_meta[index].state=BUDDY_META_UNUSED;
        buddy_meta[buddy].state=BUDDY_META_UNUSED;
        index=new_index;
        order++;
    }
    buddy_push(order,index);
    buddy_free_pages+=pages;
    if(buddy_free_pages>buddy_pool_pages) buddy_free_pages=buddy_pool_pages;
    buddy_frees++;
    mmCriticalLeave(flags);
    return 0;
}

void mm_buddy_get_stats(MM_BUDDY_STATS *out)
{
    DWORD flags;
    if(out==NULL) return;
    flags=mmCriticalEnter();
    memset(out,0,sizeof(*out));
    out->enabled=buddy_enabled;
    out->max_order=buddy_max_order;
    out->pool_pages=buddy_pool_pages;
    out->free_pages=buddy_free_pages;
    out->physical_start=buddy_phys_page*PAGESIZE;
    out->virtual_start=buddy_virtual;
    out->allocations=buddy_allocations;
    out->frees=buddy_frees;
    out->failed_allocations=buddy_failed;
    mmCriticalLeave(flags);
}
