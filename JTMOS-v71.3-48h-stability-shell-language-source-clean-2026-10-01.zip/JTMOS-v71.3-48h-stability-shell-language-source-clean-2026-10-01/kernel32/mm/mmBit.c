// ============================================================================
// Memory management system - Free memory bitmap operations.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: bounds-safe bit access, exact page search and conservative
//             address rounding for free/reserve operations.
// ============================================================================
#include <stdio.h>
#include "mm.h"
#include "mmBit.h"

BYTE mmOrBits[8]={1,2,4,8, 16,32,64,128};
BYTE mmAndBits[8]={255-1, 255-2, 255-4, 255-8,
        255-16, 255-32, 255-64, 255-128};
static DWORD mm_free_pages;
typedef struct { DWORD first_page,end_page; } MM_PHYS_EXTENT;
static MM_PHYS_EXTENT mm_phys_extents[MM_PHYS_EXTENT_MAX];
static int mm_phys_extent_count;

static BYTE mm_bit_mask(DWORD which)
{
    return (BYTE)(1U << (which & 7));
}

/* V67.8.33: the bitmap has one authoritative owner: the global MM state.
 * p_mm remains a compatibility pointer for the rest of the kernel, but the
 * physical allocator must not depend on a second pointer to discover its own
 * bitmap.  The V67.8.32 boot proved mm.bitmap itself contained the correct
 * edge bytes while the scan path still reported zero free pages. */
static DWORD mm_bitmap_pages(void)
{
    if(mm.bitmap != NULL && mm.l_bitmap > 0)
        return (DWORD)mm.l_bitmap * 8;
    return 0;
}

static volatile BYTE *mm_bitmap_ptr(void)
{
    if(mm.bitmap == NULL || mm.l_bitmap <= 0)
        return NULL;
    return (volatile BYTE *)mm.bitmap;
}

/* V70: the bitmap can manage several BIOS-usable physical extents.  When no
 * E820 extents were registered (unit tests/legacy boot), phMSTART..phMEND is
 * exposed as one compatibility extent. */
void mmPhysicalExtentsReset(void)
{
    mm_phys_extent_count=0;
    memset(mm_phys_extents,0,sizeof(mm_phys_extents));
}

int mmPhysicalExtentAdd(DWORD firstPage,DWORD endPage)
{
    DWORD pages=MM_BITMAP_PAGES;
    if(firstPage==0) firstPage=1;
    if(endPage>pages) endPage=pages;
    if(firstPage>=endPage || mm_phys_extent_count>=MM_PHYS_EXTENT_MAX)
        return -1;
    mm_phys_extents[mm_phys_extent_count].first_page=firstPage;
    mm_phys_extents[mm_phys_extent_count].end_page=endPage;
    mm_phys_extent_count++;
    return 0;
}

int mmPhysicalExtentCount(void)
{
    return mm_phys_extent_count;
}

int mmPhysicalExtentGet(int index,DWORD *firstPage,DWORD *endPage)
{
    DWORD first,end,pages;
    if(index<0) return -1;
    if(mm_phys_extent_count>0)
    {
        if(index>=mm_phys_extent_count) return -1;
        first=mm_phys_extents[index].first_page;
        end=mm_phys_extents[index].end_page;
    }
    else
    {
        if(index!=0 || phMSTART==NULL || phMEND==NULL) return -1;
        pages=mm_bitmap_pages();
        first=(DWORD)phMSTART/PAGESIZE;
        end=(DWORD)phMEND/PAGESIZE;
        if(first==0) first=1;
        if(end>pages) end=pages;
        if(first>=end) return -1;
    }
    if(firstPage) *firstPage=first;
    if(endPage) *endPage=end;
    return 0;
}

static int mm_page_is_managed(DWORD which)
{
    DWORD first,end;
    int i,count=mm_phys_extent_count>0 ? mm_phys_extent_count : 1;
    for(i=0;i<count;i++)
        if(mmPhysicalExtentGet(i,&first,&end)==0 && which>=first && which<end)
            return 1;
    return 0;
}

static int mm_range_is_managed(DWORD startPage,DWORD endPage)
{
    DWORD first,end;
    int i,count=mm_phys_extent_count>0 ? mm_phys_extent_count : 1;
    if(startPage>=endPage) return 0;
    for(i=0;i<count;i++)
        if(mmPhysicalExtentGet(i,&first,&end)==0 &&
           startPage>=first && endPage<=end)
            return 1;
    return 0;
}


/* Raw bit helpers.  The caller owns mmCritical and has validated the page. */
static int mm_bit_get_locked(DWORD which)
{
    volatile BYTE *bitmap = mm_bitmap_ptr();
    return (bitmap[which >> 3] & mm_bit_mask(which)) ? 1 : 0;
}

static void mm_bit_set_locked(DWORD which)
{
    volatile BYTE *bitmap;
    BYTE mask;

    bitmap = mm_bitmap_ptr();
    mask = mm_bit_mask(which);
    if(!(bitmap[which >> 3] & mask))
    {
        bitmap[which >> 3] = (BYTE)(bitmap[which >> 3] | mask);
        if(mm_free_pages)
            mm_free_pages--;
    }
}

static void mm_bit_remove_locked(DWORD which)
{
    volatile BYTE *bitmap;
    BYTE mask;

    bitmap = mm_bitmap_ptr();
    mask = mm_bit_mask(which);
    if(bitmap[which >> 3] & mask)
    {
        bitmap[which >> 3] = (BYTE)(bitmap[which >> 3] & (BYTE)~mask);
        mm_free_pages++;
    }
}

/* Bootstrap the physical arena without depending on the normal per-bit
 * allocator path.  The MM bitmap lives in freshly mapped bootstrap memory;
 * use volatile byte stores so every write is committed exactly once before
 * the first allocation is attempted.  [firstPage,endPage) becomes free and
 * every page outside that interval stays reserved. */
int mmBitmapBootstrapRange(DWORD firstPage, DWORD endPage)
{
    volatile BYTE *bitmap;
    DWORD represented,i,startByte,endByte,startBit,endBit;
    BYTE keep;

    bitmap = mm_bitmap_ptr();
    represented = mm_bitmap_pages();
    if(bitmap == NULL || represented == 0 ||
       firstPage >= endPage || endPage > represented)
        return -1;

    for(i=0; i<(DWORD)mm.l_bitmap; i++)
        bitmap[i] = 0xFF;

    startByte = firstPage >> 3;
    endByte = endPage >> 3;
    startBit = firstPage & 7;
    endBit = endPage & 7;

    if(startByte == endByte)
    {
        BYTE freeMask;
        freeMask = (BYTE)(((1U << endBit) - 1U) &
                          ~((1U << startBit) - 1U));
        bitmap[startByte] = (BYTE)(bitmap[startByte] & (BYTE)~freeMask);
    }
    else
    {
        /* First partial byte: preserve only pages below firstPage. */
        keep = startBit ? (BYTE)((1U << startBit) - 1U) : 0;
        bitmap[startByte] = keep;

        /* Complete interior bytes are entirely allocatable. */
        for(i=startByte+1; i<endByte; i++)
            bitmap[i] = 0x00;

        /* Last partial byte: free bits below endBit and keep the rest
         * reserved.  If endPage is byte aligned, endByte is outside the
         * free interval and must stay 0xFF. */
        if(endBit)
            bitmap[endByte] = (BYTE)~((1U << endBit) - 1U);
    }

    mm_free_pages = endPage - firstPage;

    /* Read back both edges immediately. */
    if((bitmap[firstPage >> 3] & mm_bit_mask(firstPage)) != 0 ||
       (bitmap[(endPage-1) >> 3] & mm_bit_mask(endPage-1)) != 0)
        return -2;

    return 0;
}

int mmBitmapBootstrapManagedExtents(void)
{
    volatile BYTE *bitmap;
    DWORD represented,i,p,first,end;
    int e,count;

    bitmap=mm_bitmap_ptr();
    represented=mm_bitmap_pages();
    if(bitmap==NULL || represented==0) return -1;
    for(i=0;i<(DWORD)mm.l_bitmap;i++) bitmap[i]=0xFF;
    mm_free_pages=0;

    count=mm_phys_extent_count>0 ? mm_phys_extent_count : 1;
    for(e=0;e<count;e++)
    {
        if(mmPhysicalExtentGet(e,&first,&end)!=0) continue;
        if(first>=end || end>represented) return -1;
        for(p=first;p<end;p++)
        {
            BYTE mask=mm_bit_mask(p);
            if(bitmap[p>>3]&mask)
            {
                bitmap[p>>3]=(BYTE)(bitmap[p>>3]&(BYTE)~mask);
                mm_free_pages++;
            }
        }
    }
    return mm_free_pages ? 0 : -1;
}


int mmBitGet(DWORD which)
{
    DWORD flags;
    int result;

    /* Pages outside phMSTART..phMEND are reserved even though the bitmap
     * represents the entire 32-bit physical address space. */
    if(!mm_page_is_managed(which))
        return 1;

    flags = mmCriticalEnter();
    result = mm_bit_get_locked(which);
    mmCriticalLeave(flags);
    return result;
}

int mmBitSet(DWORD which)
{
    DWORD flags;

    if(!mm_page_is_managed(which))
        return -1;

    flags = mmCriticalEnter();
    mm_bit_set_locked(which);
    mmCriticalLeave(flags);
    return 0;
}

int mmBitRemove(DWORD which)
{
    DWORD flags;

    if(!mm_page_is_managed(which))
        return -1;

    flags = mmCriticalEnter();
    mm_bit_remove_locked(which);
    mmCriticalLeave(flags);
    return 0;
}

int mmBitWrite(DWORD which, int state)
{
    if(state)
        return mmBitSet(which);
    return mmBitRemove(which);
}

int malloc_getamountfree(void)
{
    DWORD free_bytes;

    free_bytes = malloc_getmemoryfree();
    // Preserve the historical signed-int API without returning a negative
    // value on machines with more than 2 GB free.
    if(free_bytes > 0x7fffffffU)
        return 0x7fffffff;
    return (int)free_bytes;
}

void mmBitResetAccounting(void)
{
    mm_free_pages = 0;
}

void mmBitConfigurePhysicalRange(DWORD firstPage, DWORD endPage)
{
    if(mm_phys_extent_count==0)
        (void)mmPhysicalExtentAdd(firstPage,endPage);
}


DWORD mmBitRecountFreePages(void)
{
    DWORD p,first,end,count=0;
    volatile BYTE *bitmap=mm_bitmap_ptr();
    int e,n=mm_phys_extent_count>0 ? mm_phys_extent_count : 1;
    if(bitmap==NULL) { mm_free_pages=0; return 0; }
    for(e=0;e<n;e++)
    {
        if(mmPhysicalExtentGet(e,&first,&end)!=0) continue;
        for(p=first;p<end;p++)
            if((bitmap[p>>3]&mm_bit_mask(p))==0) count++;
    }
    mm_free_pages=count;
    return count;
}


DWORD malloc_getfreepages(void)
{
    return mm_free_pages;
}

// O(1) free-memory query. Bitmap mutations maintain the page counter.
DWORD malloc_getmemoryfree(void)
{
    return mm_free_pages * (DWORD)PAGESIZE;
}

// Returns the start page number containing at least 'pages' contiguous free pages.
int mmFindFreePages(int pages)
{
    DWORD p,first,end,run,start_page;
    volatile BYTE *bitmap;
    int e,n;
    if(pages<=0) return 0;
    bitmap=mm_bitmap_ptr();
    if(bitmap==NULL) return 0;
    n=mm_phys_extent_count>0 ? mm_phys_extent_count : 1;
    for(e=0;e<n;e++)
    {
        if(mmPhysicalExtentGet(e,&first,&end)!=0 ||
           (DWORD)pages>end-first) continue;
        run=0; start_page=0;
        for(p=first;p<end;p++)
        {
            if((bitmap[p>>3]&mm_bit_mask(p))==0)
            {
                if(run==0) start_page=p;
                run++;
                if(run>=(DWORD)pages) return (int)start_page;
            }
            else { run=0; start_page=0; }
        }
    }
    return 0;
}


// Mark an address range free. Only complete pages fully contained in
// [p_s,p_e) are freed; this avoids exposing bytes belonging to a neighbour.
int mmFreeRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = (s / PAGESIZE) + ((s % PAGESIZE) ? 1 : 0); // ceil(start)
    e = e / PAGESIZE;                                  // floor(end)
    if(e <= s)
        return 0;

    return mmFreeRegion(s,e);
}

// Mark an address range reserved. Every page touched by [p_s,p_e) is reserved.
int mmReserveRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = s / PAGESIZE;                                      // floor(start)
    e = (e / PAGESIZE) + ((e % PAGESIZE) ? 1 : 0);       // ceil(end)
    return mmReserveRegion(s,e);
}

int mmTryReserveRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return -1;

    s = s / PAGESIZE;
    e = (e / PAGESIZE) + ((e % PAGESIZE) ? 1 : 0);
    return mmTryReserveRegion(s,e);
}

int mmFreeRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,0);
}

int mmReserveRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,1);
}

/* Atomically claim a free physical range.  Unlike mmReserveRegion(), this
 * operation never overwrites somebody else's reservation and never leaves a
 * partially claimed run on failure. */
int mmTryReserveRegion(DWORD startPage, DWORD endPage)
{
    DWORD i,flags;
    int result;

    flags = mmCriticalEnter();
    result = 0;
    if(!mm_range_is_managed(startPage,endPage))
        result = -1;
    else
    {
        for(i=startPage; i<endPage; i++)
        {
            if(mm_bit_get_locked(i))
            {
                result = -2;
                break;
            }
        }
        if(result == 0)
            for(i=startPage; i<endPage; i++)
                mm_bit_set_locked(i);
    }
    mmCriticalLeave(flags);
    return result;
}

// Fill [startPage,endPage) in the bitmap to a defined state (0 or 1).
int mmSetRegion(DWORD startPage, DWORD endPage, int STATE)
{
    DWORD i,flags;
    int result;

    flags = mmCriticalEnter();
    result = 0;

    if(!mm_range_is_managed(startPage,endPage))
        result = -1;
    else
    {
        for(i=startPage; i<endPage; i++)
        {
            if(STATE)
                mm_bit_set_locked(i);
            else
                mm_bit_remove_locked(i);
        }
    }

    mmCriticalLeave(flags);
    return result;
}
