#!/bin/sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# JTMOS Linode/headless QEMU profile.
#
# IB700 is an optional QEMU watchdog device and is not available in every
# QEMU build.  The generic launcher deliberately validates it when the
# watchdog backend is requested.  Linode/headless boots must not depend on
# that optional emulated device, so default this profile to the JTMOS
# software/APIC fallback path.  An explicit caller override is still honored.
export JTMOS_NMI=${JTMOS_NMI:-off}

# Headless/Linode defaults.
export JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}
export JTMOS_USB_INPUT=${JTMOS_USB_INPUT:-off}
export JTMOS_AUDIO=${JTMOS_AUDIO:-off}
export JTMOS_BOOT_DEBUG_LOG=${JTMOS_BOOT_DEBUG_LOG:-"$DIR/boot32pm_debug.log"}
export JTMOS_NET_MODE=${JTMOS_NET_MODE:-user}
export JTMOS_HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-0.0.0.0}
export JTMOS_HTTP_HOST_PORT=${JTMOS_HTTP_HOST_PORT:-8080}
export JTMOS_TELNET_HOST_ADDR=${JTMOS_TELNET_HOST_ADDR:-127.0.0.1}
export JTMOS_TELNET_HOST_PORT=${JTMOS_TELNET_HOST_PORT:-2323}

# Use whichever root medium is available.
if [ -z "${JTMOS_ROOT_FLOPPY+x}" ]; then
    if [ -f "$DIR/root1440.img" ]; then
        export JTMOS_ROOT_FLOPPY="$DIR/root1440.img"
    else
        export JTMOS_ROOT_FLOPPY=none
    fi
fi

if [ -z "${JTMOS_ROOT_CDROM+x}" ]; then
    if [ -f "$DIR/utilities.iso" ]; then
        export JTMOS_ROOT_CDROM="$DIR/utilities.iso"
    else
        export JTMOS_ROOT_CDROM=none
    fi
fi

if [ "$JTMOS_ROOT_FLOPPY" = none ] && \
   [ "$JTMOS_ROOT_CDROM" = none ]; then
    echo "JTMOS Linode root media missing." >&2
    echo "Run: make image-linode" >&2
    exit 1
fi

exec "$DIR/run_jtmos_qemu.sh" "$@"
