# boot32pm — maintained protected-mode loader

V69.50 makes this directory self-contained. `make image`, `make image-safe`, and the DOSBOOT targets assemble sources from `boot32pm/` itself. They do not include or compile sources from legacy `boot32/`. The only parent-tree include retained by the assembler is the shared kernel memory-layout contract in `kernel32/include/memory_layout.inc`.

# JTMOS boot32pm nzip loader

`boot32pm` is the default protected-mode JTMOS boot loader.  It includes the
maintained `boot32/boot.asm` / `boot32/bootmod.inc` sources with
`BOOT32PM_CANDIDATE` and `BOOT32PM_NZIP_KERNEL` enabled.

## Kernel path

The default release stores `kernel32/kernel32.bin.nz` immediately after the
18 KiB two-track loader area. BIOS services use an 8 KiB low-DMA bounce window at physical
`0x00005200..0x000071ff`; V16.86 fills/copies only 8 KiB (16 sectors) per PM excursion. Each completed chunk is copied in protected mode to the dedicated
high-memory staging window at `JTMOS_BOOT_NZIP_STAGING_PHYS` (`0x01000000`).
After the exact compressed stream has been staged, the small boot32 NZIP2
fast-LZ77 decoder expands it directly to `JTMOS_KERNEL_LOAD_PHYS`
(`0x00100000`) and verifies the 16-bit checksum of the resulting raw
`kernel32.bin` before entering the kernel.

Both floppy and IDE hard-disk boot use the same nzip contract:

1. `prepare_kernel_handoff` writes the expected raw-kernel checksum to `0x1000`.
2. The BIOS loader uses `0x5200..0x71ff` as an 8 KiB low-DMA bounce window and copies 8 KiB chunks
   completed chunks to the 16 MiB high-memory staging window.
3. Floppy and HD loaders both consume exactly `kernel_nz_sectors` sectors; the
   final sector may contain zero padding that is excluded by `kernel_nz_bytes`.
4. Protected mode expands `kernel32.bin.nz` at 1 MiB.
5. The decoder writes the measured raw checksum to `0x1002` and compares it
   with the expected checksum at `0x1000`.
6. The BIOS boot drive is handed to the kernel at `0x1004`.

A partitioned JTMOS HDD reserves LBA0..4095 (2 MiB) as a dedicated
pre-partition boot/system area. The standard layout created by
`partition hda auto` therefore starts hda1 at LBA4096. boot32pm keeps its
36-sector/two-track loader at HDD LBA0..35. The transport/floppy image keeps
`kernel32.bin.nz` at LBA36, while `rootinstall` maps that payload to HDD
LBA64..2111. LBA36..63 is the immediate alignment gap and LBA2112..4095 is
reserved for future boot/system growth. JTMFS on hda1 does not own these LBAs.

Since V16.71.2 sector 0 is a standard MBR: boot code occupies bytes 0..445,
partition entries occupy 446..509 and 0x55AA remains at 510..511.  BIOS DL is
captured at runtime.  The JTMOS checksum/kernel-offset runtime record moved to
LBA3 and is identified by the `JMB2` magic, so partitioning cannot overwrite
loader metadata.  `rootinstall hda jtm32.img` preserves the target partition
table while installing the matching boot track and kernel payload.

Build with:

```sh
make -j2 boot
```

Static source validation is also available:

```sh
./tools/check_boot32_hd_nzip.sh
```

The normal full build additionally validates the raw 1 MiB linked kernel
window, the 1 MiB compressed high-memory staging window, the 2048-sector HDD
boot reservation, and the 18 KiB / two-track loader size.


## V67.8.57.1 streamed BIOS loader

The default BOOT32PM path no longer keeps the full compressed kernel below
640 KiB. BIOS INT 13h reads one sector at a time into the 8 KiB low-DMA bounce window
at physical 0x5200. At each 16-sector / 8 KiB boundary the loader enters protected
mode, copies the chunk to the 16 MiB boot scratch window, returns to real mode,
and continues BIOS I/O. The compressed and raw kernel limits are each 1 MiB.

Release media are split: A: contains boot32pm + kernel only; B: contains the
root/system SQARC archive. The same archive family may be supplied through an
ATAPI raw image, and sys: chooses a medium by verifying the SQARC520 signature.

## V67.8.57.10.18.16.4 DOSBOOT package + Makefile parity with boot32

`boot32pm/Makefile` now owns both maintained boot outputs. A plain `make` in
`boot32pm` builds the BIOS/VESA/nzip loader and the MS-DOS protected-mode
DOSBOOT package. `make bios` builds only BIOS artifacts; `make dos` builds
`DOSBOOT.COM` + `KERNEL32.NZ`; and `make dos-package` emits the 8.3-compatible
`boot32pm/dosboot/` directory.

At that historical release, top-level `make dosboot` also built `utilities.iso`
and emitted `dosboot.com`, `kernel32.nz`, and `utils.iso`.  V69.49 changes the
default/recovery DOS package to two files and compiles optional UTILS staging
out; use `make dosboot-full` for the historical three-file package. DOS still
resolves the 8.3 names case-insensitively.

The DOS assembler implementation remains shared from `boot32/dosboot.asm` so
there is only one PMODE/nzip DOS loader implementation. The metadata is built
locally by boot32pm, and the top-level `make dosboot` now delegates to
`boot32pm dos-package`. `boot32/boot.bin` remains an explicit raw recovery
loader.

## V68.8.57.10.18.16.75 metadata contract cleanup

`kernelmeta.inc` now contains only the canonical values used by the streamed
BIOS path: `kernel_raw_bytes`, `kernel_nz_bytes`, `kernel_nz_sectors`, and
`kernel_nz_chunks` (plus the raw checksum emitted by `kchecksum`).  Obsolete
`kernel_nz_tracks` and `kernel_nz_loadlimit` fields were removed.  The optional
non-streaming compatibility branch derives its old track-rounded conventional-
memory limit from `kernel_nz_sectors`, so it does not require stale metadata.

Metadata generation itself enforces the 1 MiB raw/compressed limits and the
2048-sector compressed reservation before `kernelmeta.inc` is published.

## V16.83 staged-payload integrity guard

Before NZIP2 token decoding, boot32pm now checks a build-bound 16-bit additive
checksum over the exact `kernel_nz_bytes` staged at 16 MiB.  Failure codes are
printed directly in text/curses mode and to QEMU debugcon:

- `1` truncated compressed stream
- `2` decoded output would exceed `kernel_raw_bytes`
- `3` NZIP2 format/input-consumption error
- `4` invalid LZ77 back-reference
- `5` raw-size/header mismatch
- `6` decoded raw-kernel checksum mismatch
- `7` compressed staging checksum mismatch (BIOS/image/stream transport)

The floppy streamer also keeps CHS in loader-owned memory and reloads CH/CL/DH
before every INT 13h read, rather than assuming BIOS register preservation.

## V16.85 floppy LBA / BIOS geometry hardening

After V16.84 reported `PM32 NZIP2 FAILED code=8`, the floppy BIOS transport was
changed from cumulative CHS state to a linear-sector contract.  The compressed
kernel source starts at LBA36.  Before each INT 13h read the loader converts the
current LBA to CHS using geometry returned by AH=08; 18 sectors/track and two
heads remain safe 1.44 MiB fallbacks if the BIOS query fails.

V16.86 reports code 10 when the first sector magic is not `NZP2`, and code 11 when the magic is valid but the raw-size field differs from the build metadata.

The first payload sector must contain the `NZP2` signature and the build-bound
raw kernel size.  Error `10` means that this first-sector contract failed.
Error output also includes the BIOS-side additive checksum and its expected
value, for example `code=08 disk=ABCD exp=1234`, making later-sector drift
distinguishable from a wrong starting sector.


### V69.49 recovery packaging

Top-level `make dosboot`, `dosboot-noapic`, `dosboot-nogui`, and `dosboot-safe`
assemble DOSBOOT.COM with `BOOT_UTILS_REQUIRED=0`.  These recovery packages do
not open UTILS.ISO and publish a cleared optional utility-RAM handoff; kernel32
continues normally without a staged utilities image.  Use `make dosboot-full`
(or `dosboot-safe-full`) when the historical UTILS.ISO handoff is required.

### V69.58 transactional full FreeDOS packaging

V69.58 restores the local historical convenience without weakening the explicit
recovery targets. A plain `make` inside `boot32pm` now defaults to `UTILS=1` and
produces the complete three-file `dosboot/` directory: `dosboot.com`,
`kernel32.nz`, and `utils.iso`. If `../utilities.iso` is missing, boot32pm asks
the repository root to build the first-class `utilities.iso` target using the
current VESA/SAFE/NOAPIC/NOGUI profile.

Minimal recovery remains explicit: top-level `make dosboot` (and the noapic,
nogui, and safe variants) invokes boot32pm with `UTILS=0`. Full packaging is
transactional: files are staged in a temporary directory, `utils.iso` is checked
for the complete package-only SQA set (`boot.sqa` through `tests.sqa`) and rejects non-SQA members; only then is the previous `dosboot/` directory
replaced. Thus a failed utilities-media build no longer destroys or downgrades a
previous working full FreeDOS package.
