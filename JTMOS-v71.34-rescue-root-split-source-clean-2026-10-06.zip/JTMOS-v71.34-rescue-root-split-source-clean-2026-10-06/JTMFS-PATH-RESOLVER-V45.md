# JTMFS pathname resolver V45

JTMOS identifies a real directory by `(DNR, DB)`:

- `DNR` = block-device number
- `DB` = directory block number on that device

V45 makes pathname conversion a pure operation. `jtmfsPath.c` no longer calls
`jtmfs_chdir()` and never writes the current thread's DNR/DB while resolving a
name.

## Canonical namespace

- `/` = root directory of `getRootDNR()`
- `/hda` = root directory of the formatted device named `hda`
- `/hda/foo` = directory `foo` on `hda`
- `hda:` = `hda` root (historical syntax)
- `hda:/foo` = `/hda/foo`
- `hda:file` = file `file` in the `hda` root
- `.` = current directory
- `..` = parent directory
- `/..` = `/`
- `/hda/..` = `/`

A failed multi-component `chdir` does not partially alter the current working
directory. The resolved DNR/DB is committed only after the entire path is valid.

## Core functions

- `jtmfsResolvePathAt(start_dnr,start_db,path,&dnr,&db)`
- `resolvePath(path,&dnr,&db)`
- `resolveFileNamePath(filepath,&dnr,&db,&resolve)`
- `jtmfsBuildPath(dnr,db,path,max_len)`

`jtmfsBuildPath` performs reverse lookup without temporary `chdir("..")` calls.
For non-root devices it produces canonical names such as `/hda` and
`/hda/usr/bin`.

## Compatibility

Directory entries still store the real parent DB in `..` and their own name in
the `JTMFS_ID_DIRNAME` entry. Device roots are represented in the global JTMOS
namespace as `/device-name`; they do not require a physical directory entry on
the root filesystem.
