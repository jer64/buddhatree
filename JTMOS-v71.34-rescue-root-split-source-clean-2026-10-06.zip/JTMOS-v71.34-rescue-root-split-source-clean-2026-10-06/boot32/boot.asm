;=================================================================================
; System loader for the 32-bit JTMOS operating system
; ---------------------------------------------------
;
; 3.5" 1.44M disk / IDE hard disk versions.
; Variable bootdrv specifies which boot drive is being used.
;
; (C) 2002-2018 by Jari Tuominen (jari.t.tuominen@gmail.com).
; Radically modified and converted from double segment version to COM stylish
; single segment executable.
; Special thanks to NASM tutorial for providing information:
; "The Netwide Assembler: NASM - Chapter 10: Troubleshooting"
; http://home.comcast.net/~fbkotler/nasmdo10.html
;=================================================================================
;
;	I decided to modify the bootloader so that it automatically
;	boots up the kernel(without asking to press a key to start it).
;	This makes possible to test it without keyboard f.e.
;	Set WAIT_KEY to 1 if you want to it to ask a key press.
;
[bits 16]
org 0x100 ; 'COM file' start address (Yes, this is [.COM] file actually).
; V16.78: VGA text/headless boot is the normal JTMOS default; VESA is opt-in.
; Do NOT assume Bochs/QEMU VBE mode numbers on real hardware.  Physical VBE
; BIOSes (including NVIDIA) may assign different mode IDs, so boot32 scans the
; controller-supplied mode list and selects by geometry/format.  Fixed Bochs
; mode IDs are retained only as a last-resort compatibility fallback.
%ifndef BOOT_VESA_GRAPHICS
%define BOOT_VESA_GRAPHICS 0
%endif
%ifndef BOOT_SAFE_DEFAULT
%define BOOT_SAFE_DEFAULT 0
%endif
%ifndef BOOT_NOAPIC_DEFAULT
%define BOOT_NOAPIC_DEFAULT 0
%endif
%ifndef BOOT_NOGUI_DEFAULT
%define BOOT_NOGUI_DEFAULT 0
%endif
%if (BOOT_SAFE_DEFAULT != 0) && (BOOT_SAFE_DEFAULT != 1)
%error "BOOT_SAFE_DEFAULT must be 0 or 1"
%endif
%if (BOOT_NOAPIC_DEFAULT != 0) && (BOOT_NOAPIC_DEFAULT != 1)
%error "BOOT_NOAPIC_DEFAULT must be 0 or 1"
%endif
%if (BOOT_NOGUI_DEFAULT != 0) && (BOOT_NOGUI_DEFAULT != 1)
%error "BOOT_NOGUI_DEFAULT must be 0 or 1"
%endif
%define GRAOS_VESA_MODE 0x0144 ; last-resort Bochs/SeaBIOS 1024x768x32
%define GRAOS_VESA_FALLBACK_MODE 0x0143 ; legacy Bochs 800x600x32 (not GraOS-ready)
%define GRAOS_VESA_SAFE_MODE 0x0142 ; last-resort Bochs/SeaBIOS 640x480x32
%define GRAOS_VESA_WIDTH 1024
%define GRAOS_VESA_HEIGHT 768
%define GRAOS_VESA_SAFE_WIDTH 640
%define GRAOS_VESA_SAFE_HEIGHT 480
%define VESA_CTRLINFO_SEG 0x0500 ; physical 0x5000, clear of E820 handoff at 0x4200
%define VESA_BOOT_HANDOFF_SIGNATURE 0x41534556 ; "VESA", physical 0x4100
%define BOOTOPT_HANDOFF_SIGNATURE 0x54504F4A ; "JOPT"
%define BOOTOPT_HANDOFF_VERSION   1
%define BOOTOPT_TEXT_OFFSET       12
%ifdef BOOT32PM_CANDIDATE
%define BOOT_IMAGE_SEGMENT 0x07B0
%define BOOT_IMAGE_BASE    0x00007B00
%define BOOT_REBASE(x)     (BOOT_IMAGE_BASE + (x))
%endif
;
%include "../kernel32/include/memory_layout.inc"
%ifndef BOOT32PM_CANDIDATE
%if JTMOS_KERNEL_LOAD_PHYS != 0x00010000
    %error "Relocated JTMOS kernels require the protected-mode candidate entry path"
%endif
%endif
%include "bios.mac" ;;;; (puts,putchar)
%include "bootmod.inc" ;;;; Boot Module (Calls BIOS to read rest of boot+krn)
jmp start ; Jump to PMODE initialization code.

%include "header.inc" ;;;; Bootsector header
;%include "bloche.inc" ; obsolete

%include "seg.mac" ;;;; Segment Descriptor Macros
%include "text.inc" ;;;; Any text things bootsector code needs
; moved text.inc to bootmod.inc
%include "a20.inc" ;;;; A20 line setup code
%include "detection.inc" ;;;; Detects drives.
%include "e820.inc" ;;;; BIOS E820 memory-map handoff for kernel32.
;
WAIT_KEY equ 0
;----------------------------------------------------------------------------
code16  dw 0
;----------------------------------------------------------------------------
; Build the descriptor-table pointers used by every protected-mode excursion.
; bootmod's high-memory streaming enters PM before start:, so this must be a
; callable shared helper rather than start-only setup.  The exception gates
; all target one physical, stack-independent emergency halt handler.
prepare_pmode_tables:
        mov     ax,cs
        movzx   eax,ax
        shl     eax,4
        add     eax,dummy_descriptor
        mov     dword [cs:gdt_start+2],eax

        mov     ax,cs
        movzx   eax,ax
        shl     eax,4
        add     eax,interrupt_0
        mov     dword [cs:idt_start+2],eax

        mov     ax,cs
        movzx   eax,ax
        shl     eax,4
        add     eax,pmode_early_fault32
        mov     edx,eax
        shr     edx,16
        mov     di,interrupt_0
        mov     cx,32
.fill_early_exception_idt:
        mov     word [cs:di+0],ax
        mov     word [cs:di+2],code32_idx
        mov     byte [cs:di+4],0
        mov     byte [cs:di+5],0x8E
        mov     word [cs:di+6],dx
        add     di,8
        loop    .fill_early_exception_idt
        ret

; main procedure, this is the entry point to the kernel
start:
        ; Stop floppy motor.
        mov dx,0x3F2
        mov al,0
        out dx,al

        ; V69.44: do not drain the 8042 data port directly.  The old 2000-read
        ; loop bypassed BIOS keyboard bookkeeping and could disturb INT 16h on
        ; physical PS/2 controllers.  The BIOS boot-options prompt already ran
        ; immediately after the complete loader became resident.

        ; Begin protected mode setup code ...
	mov	ax,cs		; load code-segment into DS and ES
	mov	ds,ax
	mov	es,ax

        call    prepare_pmode_tables

        ; Historical explicit wait remains available for diagnostic builds.
	mov ax,WAIT_KEY
	cmp ax,0
	je dont_wait_key
        puts str_key
        mov ax,0
        int 0x16
dont_wait_key:

	; Capture the BIOS physical-memory map while INT 15h services are still
	; available. kernel32 consumes this after entering protected mode.
	call detect_e820

%ifdef BOOT32PM_STREAM_KERNEL
	; V16.74 handoff breadcrumb.  If the display stops after this line, the
	; kernel payload itself has already been streamed successfully and the next
	; operation is BIOS VESA setup -- not another floppy read.
	puts str_stream_handoff
%endif

	; Clear the explicit VESA handoff marker first.  The kernel will not trust
	; stale bytes in the low-memory ModeInfoBlock unless this marker is set.
	push es
	mov ax,0x0400
	mov es,ax
	mov dword [es:0x0100],0
	pop es

	; -- VESA job. --
	; 0x100	640x400x8	graphics	yes
	; 0x102	800x600x4	graphics	no
	; 0x103	800x600x8	graphics	yes	
	; Classic VBE 0x112/0x118 are 24-bpp modes.
	; QEMU/SeaBIOS Bochs VBE exposes 32-bpp LFB modes as 0x142..0x144.

%if BOOT_VESA_GRAPHICS
    cmp byte [cs:boot_gui_disabled],0
    jne vesa_runtime_skipped
    ; Real hardware must be selected from the BIOS-advertised VBE mode list.
    ; VESA stopped assigning universal mode numbers, so 0x142..0x144 are not
    ; portable to the NVIDIA VBE BIOS in the eMachines test machine.
    mov bx,GRAOS_VESA_WIDTH
    mov dx,GRAOS_VESA_HEIGHT
    call select_vesa_resolution
    jnc vesa_okay

    ; Keep a 640x480x32 recovery console if the BIOS truly lacks 1024x768x32.
    ; Ring3 GraOS still needs 1024x768, but boot diagnostics remain graphical.
    mov bx,GRAOS_VESA_SAFE_WIDTH
    mov dx,GRAOS_VESA_SAFE_HEIGHT
    call select_vesa_resolution
    jnc vesa_okay

    ; Compatibility fallback for old Bochs VBE BIOSes with a broken/missing
    ; controller mode list.  Do not try 0x143/800x600 here: kernel32 correctly
    ; rejects that geometry for the fixed 1024x768 GraOS framebuffer contract.
    mov cx,GRAOS_VESA_MODE
    mov bx,GRAOS_VESA_WIDTH
    mov dx,GRAOS_VESA_HEIGHT
    call try_vesa_mode
    jnc vesa_okay

    mov cx,GRAOS_VESA_SAFE_MODE
    mov bx,GRAOS_VESA_SAFE_WIDTH
    mov dx,GRAOS_VESA_SAFE_HEIGHT
    call try_vesa_mode
    jnc vesa_okay

vesa_error:
    puts str_bad_vesa
    jmp $
vesa_okay:
    ; ModeInfoBlock is at physical 0x4000.  Write a separate success marker
    ; at 0x4100 so kernel32 can safely detect that boot32 really selected VESA.
    mov ax,0x0400
    mov es,ax
    mov dword [es:0x0100],VESA_BOOT_HANDOFF_SIGNATURE
vesa_runtime_skipped:
%endif

	; With BOOT_VESA_GRAPHICS=1 the selected VBE mode is already active here
	; and the handoff marker tells kernel32 to preserve/use its LFB.
	; ^^VESA job done.^^

	; Max. keyboard repeat rate is useful for the interactive GUI profile, but
	; it is not part of the boot contract.  Some headless/virtual BIOS keyboard
	; paths can spend an unbounded time waiting for the 8042 ACK here.  Keep the
	; curses/Linode text profile free of this optional BIOS call.
%if BOOT_VESA_GRAPHICS
	cmp byte [cs:boot_gui_disabled],0
	jne .skip_keyboard_repeat
	mov	ax,0x0305
	xor	bx,bx
	int	0x16
.skip_keyboard_repeat:
%endif

	; Disable NMI.
	mov al,0x80
	mov dx,0x70
	out dx,al

	; A20 setup.
%ifdef BOOT32PM_STREAM_KERNEL
	; Streaming has already crossed 1 MiB repeatedly and therefore could not
	; have completed with A20 closed.  Do not run the historical 8042 sequence
	; a second time here: its wait loops are intentionally unbounded and some
	; BIOS/KBC combinations can stall forever after floppy I/O.  Reassert the
	; fast A20 gate instead; kernel32 verifies A20 again at its first C entry.
	in al,0x92
	or al,0x02
	and al,0xFE
	out 0x92,al
%else
        call a20
%endif

%ifdef BOOT32PM_STREAM_KERNEL
	; Final real-mode breadcrumb.  If this is visible, every optional BIOS call
	; has returned and the very next phase is the permanent protected-mode entry.
	puts str_stream_prepm
	mov al,'R'
	out 0xE9,al
%endif

        ; -------- Let's go to the kernel.
	; Disable interrupts.
        cli
        ; Load descriptor tables.
        lgdt    [dword global_descriptor_table]
        lidt    [dword interrupt_descriptor_table]

%ifdef BOOT32PM_CANDIDATE
%ifndef BOOT32PM_STREAM_KERNEL
	; Non-stream candidate smoke test: enter 32-bit protected mode, return
	; through the 16-bit protected selector to real mode, then enter PM for real.
	call pmode_roundtrip
	cmp byte [cs:pmode_probe_ok],1
	jne pmode_probe_failed
%endif
	; BOOT32PM_STREAM_KERNEL already performed one PM round-trip per 64 KiB
	; staged chunk.  Repeating the probe here adds no coverage and gives floppy
	; boots one more avoidable real/protected transition at the final handoff.
	lgdt [dword global_descriptor_table]
	lidt [dword interrupt_descriptor_table]
	; pmode_on performs the mandatory far jump immediately after CR0.PE is
	; changed.  It must not return through a real-mode CS cache.
	jmp pmode_on
%ifndef BOOT32PM_STREAM_KERNEL
pmode_probe_failed:
	puts str_pmode_failed
	jmp $
%endif
%else
        ; Enter protected mode.
        mov     eax,cr0
        or      al,1
        mov     cr0,eax

	; Make mandatory jump.
        jmp shortjump0
shortjump0:

        ;
        ;***************************************************
        ; ENTER KERNEL32
        ; 
        ; Setup protected mode stack in the kernel-reserved 0x1E0000..0x1EFFFF area.
        mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
        mov ax,0x18
        mov ss,ax
        ; Also define rest of the segments, just to prevent
        ; additional errors occuring.
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax

	; Make another jump.
        jmp shortjump1
shortjump1:

	; Jump at linear address 0x10000.
	; Jump ssss:oooooooo, 16:32, segment:offset.
	db 0x66,0xEA
	dd 0x00010000
	dw code32_idx
;	db	0xEA            ; opcode for far jump (to set CS correctly)
;	dw	0x10000,code32_idx
%endif

%ifdef BOOT32PM_CANDIDATE
; ---------------------------------------------------------------------------
; boot32pm protected-mode candidate.
; The GDT has base-zero 32-bit and 16-bit code/data selectors. BOOT_REBASE()
; converts this COM image's ORG-relative labels to their physical addresses.
pmode_on:
	cli
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_kernel_entry32)

; Call only while executing through the 16-bit protected-mode selector.
pmode_off:
	mov eax,cr0
	and eax,0xFFFFFFFE
	mov cr0,eax
	; Reload CS immediately after leaving protected mode.  A near RET here is
	; invalid because CS still has the protected-mode descriptor cache.
	jmp word BOOT_IMAGE_SEGMENT:pmode_real_return

pmode_roundtrip:
	cli
	mov byte [cs:pmode_probe_ok],0
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_probe32)

[bits 32]
pmode_probe32:
	mov ax,data32_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov byte [BOOT_REBASE(pmode_probe_ok)],1
	jmp word code16_idx:BOOT_REBASE(pmode_probe16)

[bits 16]
pmode_probe16:
	mov ax,data16_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	jmp pmode_off

pmode_real_return:
	mov ax,cs
	mov ds,ax
	mov es,ax
	lidt [cs:real_mode_idtr]
	ret

%ifdef BOOT32PM_STREAM_KERNEL
; Real-mode callable high-memory copy. The caller has already filled the
; bounce window and stored a <=32 KiB destination/count in stream_* variables.
; No stack accesses occur while SS still carries its real-mode descriptor
; cache; this keeps the PM round-trip independent of a protected-mode stack.
pmode_stream_copy:
	cli
	mov ax,cs
	mov ds,ax
	mov es,ax
	lgdt [dword global_descriptor_table]
	lidt [dword interrupt_descriptor_table]
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_stream_copy32)

[bits 32]
pmode_stream_copy32:
	mov ax,data32_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax

	; Flat 32-bit copy from the bounce window to the current staging address.
	; V16.86 uses an 8 KiB low-DMA bounce at 0x5200..0x71ff, so BIOS DMA
	; never starts on or approaches a 64 KiB page boundary.
	mov esi,STREAM_BUFFER_PHYS
	mov edi,dword [BOOT_REBASE(stream_high_dest)]
	mov ecx,dword [BOOT_REBASE(stream_chunk_bytes)]
	mov edx,ecx
	shr ecx,2
	cld
	rep movsd
	mov ecx,edx
	and ecx,3
	rep movsb

	; Immediately verify the high copy byte-for-byte, not merely by checksum.
	; A mismatch marks code 9 but returns to real mode cleanly so the final PM
	; handoff can report the error on curses/debugcon.
	mov esi,STREAM_BUFFER_PHYS
	mov edi,dword [BOOT_REBASE(stream_high_dest)]
	mov ecx,dword [BOOT_REBASE(stream_chunk_bytes)]
	repe cmpsb
	je .pmsc_copy_ok
	mov byte [BOOT_REBASE(stream_copy_error)],1
	mov ax,word [BOOT_REBASE(stream_chunk_index)]
	mov word [BOOT_REBASE(stream_copy_bad_chunk)],ax
.pmsc_copy_ok:
	inc word [BOOT_REBASE(stream_chunk_index)]
	jmp word code16_idx:BOOT_REBASE(pmode_stream_copy16)

[bits 16]
pmode_stream_copy16:
	mov ax,data16_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov eax,cr0
	and eax,0xFFFFFFFE
	mov cr0,eax
	jmp word BOOT_IMAGE_SEGMENT:pmode_stream_real_return

pmode_stream_real_return:
	mov ax,cs
	mov ds,ax
	mov es,ax
	lidt [cs:real_mode_idtr]
	sti
	ret
%endif

[bits 32]
pmode_kernel_entry32:
	; Establish flat data selectors and the dedicated early stack before any
	; CALL/PUSH-based diagnostics or decompression.
	mov ax,core32_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov ss,ax
	mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
	mov esi,BOOT_REBASE(str_pm_entry)
	call pmode_vga_status32
%ifdef BOOT32PM_NZIP_KERNEL
	; BIOS/PMODE streaming staged kernel32.bin.nz in the 16 MiB boot scratch
	; window.  Make the expensive decoder phase explicit in curses/debugcon.
	mov esi,BOOT_REBASE(str_pm_nzip)
	call pmode_vga_status32
	call nzip_decompress_kernel32
	test eax,eax
	jnz pmode_nzip_failed32
	mov esi,BOOT_REBASE(str_pm_nzip_ok)
	call pmode_vga_status32
	mov esi,BOOT_REBASE(str_pm_kernel_jump)
	call pmode_vga_status32
	jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS
pmode_nzip_failed32:
	; Preserve a machine-readable failure code and show it on curses/VGA +
	; debugcon. Two decimal digits cover codes 10..12: BIOS-source magic/size
	; failures and a distinct 0x5000 -> 0x5200 first-sector copy failure.
	; No BIOS calls are legal here because we are already in protected mode.
	mov dword [0x00001008],eax
	mov ebx,eax
	mov byte [BOOT_REBASE(str_pm_nzip_fail_code_tens)],'0'
	cmp ebx,10
	jb .pnn_one_digit
	mov byte [BOOT_REBASE(str_pm_nzip_fail_code_tens)],'1'
	sub ebx,10
.pnn_one_digit:
	and ebx,0x0F
	add bl,'0'
	mov byte [BOOT_REBASE(str_pm_nzip_fail_code_ones)],bl
	movzx eax,word [BOOT_REBASE(stream_disk_sum)]
	mov edi,BOOT_REBASE(str_pm_nzip_fail_disk_sum)
	call pmode_store_hex16_ascii32
	mov eax,kernel_nz_checksum
	mov edi,BOOT_REBASE(str_pm_nzip_fail_expected_sum)
	call pmode_store_hex16_ascii32
	movzx eax,word [BOOT_REBASE(stream_first_bios_hdr)]
	mov edi,BOOT_REBASE(str_pm_nzip_fail_src_lo)
	call pmode_store_hex16_ascii32
	movzx eax,word [BOOT_REBASE(stream_first_bios_hdr)+2]
	mov edi,BOOT_REBASE(str_pm_nzip_fail_src_hi)
	call pmode_store_hex16_ascii32
	movzx eax,word [BOOT_REBASE(stream_first_bounce_hdr)]
	mov edi,BOOT_REBASE(str_pm_nzip_fail_bnc_lo)
	call pmode_store_hex16_ascii32
	movzx eax,word [BOOT_REBASE(stream_first_bounce_hdr)+2]
	mov edi,BOOT_REBASE(str_pm_nzip_fail_bnc_hi)
	call pmode_store_hex16_ascii32
	mov word [0x000B8000],0x4F4E ; N
	mov word [0x000B8002],0x4F5A ; Z
	mov word [0x000B8004],0x4F21 ; !
	mov esi,BOOT_REBASE(str_pm_nzip_fail)
	call pmode_vga_status32
	cli
.halt_nzip:
	hlt
	jmp .halt_nzip
%else
%ifdef BOOT32_RAW_RELOCATE_KERNEL_1M
	; Legacy boot32 comparison path: stage raw kernel32.bin below 1 MiB, then
	; copy only the actual file bytes to the linked address.
	cld
	mov esi,0x00010000
	mov edi,JTMOS_KERNEL_LOAD_PHYS
	mov ecx,kernel_raw_bytes
	mov edx,ecx
	shr ecx,2
	rep movsd
	mov ecx,edx
	and ecx,3
	rep movsb
	jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS
%else
	jmp dword code32_idx:0x00010000
%endif
%endif

; ---------------------------------------------------------------------------
; Protected-mode text/debugcon breadcrumb.
; ESI = flat linear pointer to a NUL-terminated loader string.
; The string is written to VGA text row 12 and QEMU's optional debugcon port
; 0xE9.  pushad/popad keeps the actual handoff registers untouched.
; Store low 16 bits of EAX as four uppercase hexadecimal ASCII digits at EDI.
pmode_store_hex16_ascii32:
	pushad
	add edi,3
	mov ecx,4
.psh_loop:
	mov edx,eax
	and edx,0x0F
	cmp dl,9
	jbe .psh_digit
	add dl,('A'-10)
	jmp .psh_store
.psh_digit:
	add dl,'0'
.psh_store:
	mov byte [edi],dl
	dec edi
	shr eax,4
	loop .psh_loop
	popad
	ret

pmode_vga_status32:
	pushad
	mov edi,(0x000B8000 + 12*160)
	mov ah,0x07
.pv_loop:
	lodsb
	test al,al
	jz .pv_done
	out 0xE9,al
	mov word [edi],ax
	add edi,2
	jmp .pv_loop
.pv_done:
	popad
	ret

%ifdef BOOT32PM_NZIP_KERNEL
; ---------------------------------------------------------------------------
; Tiny protected-mode NZIP2 decoder.
;
; V16.71 replaces the historical RLE/ADVPAK/BWT boot stream with the same
; fixed-token 32 KiB LZ77 geometry used by userspace nzip --fast.  This removes
; marker parsing and absolute-copy overhead from the boot hot path.
;
; Input : JTMOS_BOOT_NZIP_STAGING_PHYS .. +kernel_nz_bytes
; Output: JTMOS_KERNEL_LOAD_PHYS .. +kernel_raw_bytes
; Return: EAX=0 success, nonzero compact error code.
nzip_decompress_kernel32:
	cld

	; Distinguish where a transport mismatch arose.  Code 8 means the exact
	; bytes observed in the BIOS bounce buffer already differed from the build
	; payload.  Code 9 means those bytes were read, but a 32 KiB PM high copy
	; failed its immediate source/destination checksum.
	mov al,byte [BOOT_REBASE(stream_first_header_error)]
	test al,al
	jz .nz_first_header_ok
	cmp al,3
	je .nz_err_first_bounce_copy
	cmp al,2
	je .nz_err_first_header_size
	jmp .nz_err_first_header_magic
.nz_first_header_ok:
	cmp dword [BOOT_REBASE(stream_exact_remaining)],0
	jne .nz_err_disk_checksum
	cmp word [BOOT_REBASE(stream_disk_sum)],kernel_nz_checksum
	jne .nz_err_disk_checksum
	cmp byte [BOOT_REBASE(stream_copy_error)],0
	jne .nz_err_copy_checksum

	; Verify the exact compressed payload after BIOS -> bounce -> PM staging
	; and before interpreting any NZIP2 token.  This distinguishes transport
	; corruption from a decoder/format failure.  The checksum is the same
	; 16-bit additive byte sum used by the raw-kernel handoff.
	mov esi,JTMOS_BOOT_NZIP_STAGING_PHYS
	mov ecx,kernel_nz_bytes
	xor edx,edx
.nz_stage_sum:
	test ecx,ecx
	jz .nz_stage_sum_done
	movzx eax,byte [esi]
	add dx,ax
	inc esi
	dec ecx
	jmp .nz_stage_sum
.nz_stage_sum_done:
	cmp dx,kernel_nz_checksum
	jne .nz_err_stage_checksum

	mov esi,JTMOS_BOOT_NZIP_STAGING_PHYS
	mov edi,JTMOS_KERNEL_LOAD_PHYS
	mov ebp,(JTMOS_KERNEL_LOAD_PHYS + kernel_raw_bytes)

	; NZIP2 header: "NZP2" + exact raw byte count.
	lea eax,[esi+8]
	cmp eax,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	ja .nz_err_truncated
	cmp dword [esi],0x32505A4E
	jne .nz_err_format
	cmp dword [esi+4],kernel_raw_bytes
	jne .nz_err_size
	add esi,8

.nz_group:
	cmp edi,ebp
	je .nz_end
	cmp esi,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	jae .nz_err_truncated
	mov dl,byte [esi]
	inc esi
	mov dh,8

.nz_token:
	cmp edi,ebp
	je .nz_end
	test dl,1
	jnz .nz_match

	; Literal token.
	cmp esi,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	jae .nz_err_truncated
	mov al,byte [esi]
	inc esi
	mov byte [edi],al
	inc edi
	jmp .nz_token_done

.nz_match:
	; Three-byte DEFLATE-style LZ77 token:
	;   LE15(distance-1), U8(length-3).  Overlap is explicitly legal.
	lea eax,[esi+3]
	cmp eax,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	ja .nz_err_truncated
	movzx eax,word [esi]
	test eax,0x8000
	jnz .nz_err_format
	and eax,0x7FFF
	inc eax
	movzx ecx,byte [esi+2]
	add ecx,3
	add esi,3

	mov ebx,edi
	sub ebx,JTMOS_KERNEL_LOAD_PHYS
	cmp eax,ebx
	ja .nz_err_backref
	mov ebx,edi
	add ebx,ecx
	jc .nz_err_output
	cmp ebx,ebp
	ja .nz_err_output

	; Forward rep movsb gives the required LZ77 overlap semantics: bytes just
	; produced become source bytes when distance < length (gzip-style runs).
	push esi
	mov esi,edi
	sub esi,eax
	rep movsb
	pop esi

.nz_token_done:
	shr dl,1
	dec dh
	jnz .nz_token
	jmp .nz_group

.nz_end:
	cmp edi,ebp
	jne .nz_err_size
	; No end marker exists in NZIP2; raw_size terminates the token stream.
	cmp esi,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	jne .nz_err_format
	; Exact uncompressed checksum handoff expected by kernel32/init/start.c.
	mov esi,JTMOS_KERNEL_LOAD_PHYS
	mov ecx,kernel_raw_bytes
	xor eax,eax
.nz_sum:
	test ecx,ecx
	jz .nz_sum_done
	movzx ebx,byte [esi]
	add ax,bx
	inc esi
	dec ecx
	jmp .nz_sum
.nz_sum_done:
	mov word [0x00001002],ax
	cmp ax,word [0x00001000]
	jne .nz_err_checksum
	xor eax,eax
	ret

.nz_err_truncated: mov eax,1
	ret
.nz_err_output:    mov eax,2
	ret
.nz_err_format:    mov eax,3
	ret
.nz_err_backref:   mov eax,4
	ret
.nz_err_size:      mov eax,5
	ret
.nz_err_checksum:       mov eax,6
	ret
.nz_err_stage_checksum: mov eax,7
	ret
.nz_err_disk_checksum:  mov eax,8
	ret
.nz_err_copy_checksum:  mov eax,9
	ret
.nz_err_first_header_magic: mov eax,10
	ret
.nz_err_first_header_size:  mov eax,11
	ret
.nz_err_first_bounce_copy:  mov eax,12
	ret
%endif

[bits 16]
real_mode_idtr:
	dw 0x03FF
	dd 0x00000000
pmode_probe_ok db 0
str_pmode_failed db 13,10,"boot32pm: protected-mode roundtrip failed.",13,10,0
str_stream_handoff db 13,10,"boot32pm: payload staged; BIOS handoff...",13,10,0
str_stream_prepm db "boot32pm: entering protected mode...",13,10,0
str_pm_entry db "PM32 entry OK",0
str_pm_nzip db "PM32 NZIP2 decoding...",0
str_pm_nzip_ok db "PM32 NZIP2 decode + checksum OK",0
str_pm_kernel_jump db "PM32 jumping to kernel @ 00100000",0
str_pm_nzip_fail db "PM32 NZIP2 FAILED code="
str_pm_nzip_fail_code_tens db "0"
str_pm_nzip_fail_code_ones db "0 disk="
str_pm_nzip_fail_disk_sum db "0000 exp="
str_pm_nzip_fail_expected_sum db "0000 src="
str_pm_nzip_fail_src_lo db "0000:"
str_pm_nzip_fail_src_hi db "0000 bnc="
str_pm_nzip_fail_bnc_lo db "0000:"
str_pm_nzip_fail_bnc_hi db "0000",0
%endif




;----------------------------------------------------------------------------
; V69.49 strict BIOS/8042 boot command line.
; Simple recovery words are preferred: `noapic`, `nogui`, or `safe` where
; `safe` means exactly `noapic nogui`.  A BOOT_SAFE_DEFAULT=1 image applies
; `safe` even if a physical BIOS skips/ignores the interactive prompt.
; The prompt remains a best-effort convenience and is not a correctness
; dependency for the eMachines recovery image.
boot_options_prompt:
    pusha
    push ds
    push es
    mov ax,cs
    mov ds,ax
    mov es,ax
    mov byte [boot_gui_disabled],0
    mov word [boot_options_length],0
    mov byte [boot_options_buffer],0

    ; V69.46: show the prompt even in image-noapic/image-nogui/image-safe.
    ; A compiled recovery profile remains the timeout/empty-line default, but
    ; it must never make the boot UI disappear.

    ; V69.47 strict keyboard arm sequence.  Empty the BIOS ring, synchronise
    ; the BDA head/tail pointers, drain a bounded amount of stale 8042 output,
    ; then flush the BIOS ring once more.  Only a key arriving after this point
    ; can select a recovery option.
    call boot_options_flush_strict
    puts str_boot_options_prompt

    ; Program PIT0 ourselves to the standard PC BIOS 18.2065 Hz cadence.
    ; This removes another firmware dependency from the EL1352 prompt timeout.
    call boot_options_init_pit0
    call boot_options_read_pit0
    mov [boot_options_pit_prev],ax
    mov word [boot_options_pit_wraps],0
.first_wait:
    mov ah,0x01
    int 0x16
    jnz .read_key

    ; Some legacy USB/PS2 firmware does not reliably enqueue INT 16h data.
    ; Poll the 8042 as a fallback after giving BIOS first refusal.
    call boot_options_poll_8042_key
    jc .read_key_common

    call boot_options_read_pit0
    mov dx,[boot_options_pit_prev]
    cmp ax,dx
    jbe .pit_no_wrap             ; PIT counts down; a larger value means reload/wrap
    inc word [boot_options_pit_wraps]
    cmp word [boot_options_pit_wraps],146 ; ~8.0 s: 146 * 54.9254 ms
    jae .timeout
.pit_no_wrap:
    mov [boot_options_pit_prev],ax
    jmp .first_wait
.timeout:
    call boot_options_apply_build_default
    puts str_boot_options_default
    mov ax,0x0E0D
    mov bx,0x0007
    int 0x10
    mov ax,0x0E0A
    int 0x10
    jmp .finish

.read_key:
    xor ah,ah
    int 0x16
.read_key_common:
    ; One-key recovery shortcuts when the line is still empty:
    ;   1 = noapic, 2 = nogui, 3 = safe (noapic + nogui).
    cmp word [boot_options_length],0
    jne .read_key_decode
    cmp al,'1'
    je .shortcut_noapic
    cmp al,'2'
    je .shortcut_nogui
    cmp al,'3'
    je .shortcut_safe
.read_key_decode:
    cmp al,13
    je .newline_finish
    cmp al,27
    je .clear_finish
    cmp al,8
    je .backspace
    cmp al,32
    jb .next_blocking
    cmp al,126
    ja .next_blocking
    mov bx,[boot_options_length]
    cmp bx,JTMOS_BOOT_OPTIONS_TEXT_MAX
    jae .next_blocking
    mov [boot_options_buffer+bx],al
    inc bx
    mov [boot_options_length],bx
    mov byte [boot_options_buffer+bx],0
    mov ah,0x0E
    mov bx,0x0007
    int 0x10
    jmp .next_blocking

.backspace:
    mov bx,[boot_options_length]
    test bx,bx
    jz .next_blocking
    dec bx
    mov [boot_options_length],bx
    mov byte [boot_options_buffer+bx],0
    mov ax,0x0E08
    mov bx,0x0007
    int 0x10
    mov ax,0x0E20
    int 0x10
    mov ax,0x0E08
    int 0x10
.next_blocking:
    xor ah,ah
    int 0x16
    jmp .read_key_from_al
.read_key_from_al:
    ; AH/AL already contain the blocking INT 16h result.  Re-enter the common
    ; decoder without issuing another BIOS read.
    cmp al,13
    je .newline_finish
    cmp al,27
    je .clear_finish
    cmp al,8
    je .backspace
    cmp al,32
    jb .next_blocking
    cmp al,126
    ja .next_blocking
    mov bx,[boot_options_length]
    cmp bx,JTMOS_BOOT_OPTIONS_TEXT_MAX
    jae .next_blocking
    mov [boot_options_buffer+bx],al
    inc bx
    mov [boot_options_length],bx
    mov byte [boot_options_buffer+bx],0
    mov ah,0x0E
    mov bx,0x0007
    int 0x10
    jmp .next_blocking

.shortcut_noapic:
    mov si,str_opt_noapic
    mov cx,6
    jmp .shortcut_copy
.shortcut_nogui:
    mov si,str_opt_nogui
    mov cx,5
    jmp .shortcut_copy
.shortcut_safe:
    mov si,str_opt_safe
    mov cx,4
.shortcut_copy:
    xor bx,bx
.shortcut_copy_loop:
    mov al,[cs:si+bx]
    mov [cs:boot_options_buffer+bx],al
    inc bx
    loop .shortcut_copy_loop
    mov [cs:boot_options_length],bx
    mov byte [cs:boot_options_buffer+bx],0
    puts str_boot_options_selected
    mov ax,0x0E0D
    mov bx,0x0007
    int 0x10
    mov ax,0x0E0A
    int 0x10
    jmp .finish

.clear_finish:
    mov word [boot_options_length],0
    mov byte [boot_options_buffer],0
.newline_finish:
    mov ax,0x0E0D
    mov bx,0x0007
    int 0x10
    mov ax,0x0E0A
    int 0x10
.finish:
    ; In a compiled recovery build an empty/firmware-skipped prompt still produces
    ; a real JOPT recovery record.  The kernel also has the same compile-time
    ; policy, so this is deliberately redundant.
    call boot_options_apply_build_default
    call boot_options_publish
    call boot_options_detect_gui0
    pop es
    pop ds
    popa
    ret


; Force PIT0 to the conventional BIOS timer cadence: channel 0, lobyte/hibyte,
; mode 3, reload 65536.  JTMOS reprograms its timer later during kernel init.
boot_options_init_pit0:
    push ax
    push dx
    mov dx,0x43
    mov al,0x36
    out dx,al
    mov dx,0x40
    xor al,al
    out dx,al
    out dx,al
    pop dx
    pop ax
    ret

; Read current PIT channel 0 count.
; Return AX = latched 16-bit down-counter.
boot_options_read_pit0:
    push dx
    mov dx,0x43
    xor al,al                    ; latch channel 0 count
    out dx,al
    mov dx,0x40
    in al,dx
    mov ah,al                    ; stash low byte in AH temporarily
    in al,dx                     ; AL = high byte
    xchg al,ah                   ; AX = high:low
    pop dx
    ret

boot_options_apply_build_default:
    cmp word [cs:boot_options_length],0
    jne .done
%if BOOT_SAFE_DEFAULT || (BOOT_NOAPIC_DEFAULT && BOOT_NOGUI_DEFAULT)
    mov byte [cs:boot_options_buffer+0],'s'
    mov byte [cs:boot_options_buffer+1],'a'
    mov byte [cs:boot_options_buffer+2],'f'
    mov byte [cs:boot_options_buffer+3],'e'
    mov byte [cs:boot_options_buffer+4],0
    mov word [cs:boot_options_length],4
%elif BOOT_NOAPIC_DEFAULT
    mov byte [cs:boot_options_buffer+0],'n'
    mov byte [cs:boot_options_buffer+1],'o'
    mov byte [cs:boot_options_buffer+2],'a'
    mov byte [cs:boot_options_buffer+3],'p'
    mov byte [cs:boot_options_buffer+4],'i'
    mov byte [cs:boot_options_buffer+5],'c'
    mov byte [cs:boot_options_buffer+6],0
    mov word [cs:boot_options_length],6
%elif BOOT_NOGUI_DEFAULT
    mov byte [cs:boot_options_buffer+0],'n'
    mov byte [cs:boot_options_buffer+1],'o'
    mov byte [cs:boot_options_buffer+2],'g'
    mov byte [cs:boot_options_buffer+3],'u'
    mov byte [cs:boot_options_buffer+4],'i'
    mov byte [cs:boot_options_buffer+5],0
    mov word [cs:boot_options_length],5
%endif
.done:
    ret

boot_options_flush_bios_keys:
    push ax
.flush:
    mov ah,0x01
    int 0x16
    jz .done
    xor ah,ah
    int 0x16
    jmp .flush
.done:
    pop ax
    ret

; Strict physical-machine keyboard reset for the boot menu.
; 1. Drain BIOS INT 16h queue.
; 2. Make the BIOS Data Area keyboard ring logically empty (head := tail).
; 3. With IRQ delivery paused, drain at most 64 stale bytes from 8042 OBF.
; 4. Restore flags and drain BIOS once more.
; The bounded raw drain is intentionally used only here, before the prompt; it
; is not the old unbounded/2000-read port-60 loop that ran later in boot.
boot_options_flush_strict:
    push ax
    push bx
    push cx
    push dx
    push es

    call boot_options_flush_bios_keys

    pushf
    cli
    xor ax,ax
    mov es,ax
    mov bx,[es:0x041c]          ; BDA keyboard tail
    mov [es:0x041a],bx          ; BDA keyboard head := tail

    mov cx,64
.raw_drain:
    mov dx,0x64
    in al,dx
    test al,0x01               ; output buffer full?
    jz .raw_done
    mov dx,0x60
    in al,dx                    ; discard stale keyboard/AUX byte
    loop .raw_drain
.raw_done:
    mov byte [cs:boot_options_raw_break],0
    mov byte [cs:boot_options_raw_pending],0
    popf

    call boot_options_flush_bios_keys

    pop es
    pop dx
    pop cx
    pop bx
    pop ax
    ret

; Poll the legacy 8042 data path without blocking. BIOS INT 16h is always
; checked first; this is only a physical-machine fallback.  Accept the recovery
; keys in either common Set-1 or Set-2 make-code form.
; Return: CF=1 and AL=ASCII when recognised, CF=0 otherwise.
boot_options_poll_8042_key:
    push bx
    push dx
    mov dx,0x64
    in al,dx
    test al,0x01
    jz .none
    mov ah,al
    mov dx,0x60
    in al,dx                    ; always consume OBF byte
    test ah,0x20               ; AUX/mouse byte
    jnz .none

    cmp al,0xF0                ; Set-2 break prefix
    je .set2_break_prefix
    cmp byte [cs:boot_options_raw_break],0
    jne .set2_break_code
    test al,0x80               ; Set-1 break byte
    jnz .set1_break_code

    ; A make code alone never selects a mode. Save it and wait for the matching
    ; release sequence; that disambiguates translated Set-1 from native Set-2.
    mov [cs:boot_options_raw_pending],al
    jmp .none

.set2_break_prefix:
    mov byte [cs:boot_options_raw_break],1
    jmp .none

.set2_break_code:
    mov byte [cs:boot_options_raw_break],0
    mov bl,[cs:boot_options_raw_pending]
    cmp bl,al
    jne .clear_pending
    mov al,bl
    mov byte [cs:boot_options_raw_pending],0
    cmp al,0x16                ; Set-2 '1'
    je .key1
    cmp al,0x1E                ; Set-2 '2'
    je .key2
    cmp al,0x26                ; Set-2 '3'
    je .key3
    cmp al,0x5A                ; Set-2 Enter
    je .enter
    cmp al,0x76                ; Set-2 Esc
    je .escape
    jmp .none

.set1_break_code:
    and al,0x7F
    mov bl,[cs:boot_options_raw_pending]
    cmp bl,al
    jne .clear_pending
    mov al,bl
    mov byte [cs:boot_options_raw_pending],0
    cmp al,0x02                ; Set-1 '1'
    je .key1
    cmp al,0x03                ; Set-1 '2'
    je .key2
    cmp al,0x04                ; Set-1 '3'
    je .key3
    cmp al,0x1C                ; Set-1 Enter
    je .enter
    cmp al,0x01                ; Set-1 Esc
    je .escape
    jmp .none

.clear_pending:
    mov byte [cs:boot_options_raw_pending],0
.none:
    clc
    pop dx
    pop bx
    ret
.key1:
    mov al,'1'
    jmp .have
.key2:
    mov al,'2'
    jmp .have
.key3:
    mov al,'3'
    jmp .have
.enter:
    mov al,13
    jmp .have
.escape:
    mov al,27
.have:
    mov byte [cs:boot_options_raw_break],0
    mov byte [cs:boot_options_raw_pending],0
    stc
    pop dx
    pop bx
    ret

boot_options_publish:
    push ax
    push cx
    push si
    push di
    push es
    xor ax,ax
    mov es,ax
    cld
    mov di,JTMOS_BOOT_OPTIONS_PHYS
    mov cx,JTMOS_BOOT_OPTIONS_BYTES/2
    xor ax,ax
    rep stosw
    mov dword [es:JTMOS_BOOT_OPTIONS_PHYS+0],BOOTOPT_HANDOFF_SIGNATURE
    mov dword [es:JTMOS_BOOT_OPTIONS_PHYS+4],BOOTOPT_HANDOFF_VERSION
    mov ax,[cs:boot_options_length]
    mov word [es:JTMOS_BOOT_OPTIONS_PHYS+8],ax
    mov word [es:JTMOS_BOOT_OPTIONS_PHYS+10],0
    mov cx,ax
    inc cx
    mov si,boot_options_buffer
    mov di,JTMOS_BOOT_OPTIONS_PHYS+BOOTOPT_TEXT_OFFSET
    rep movsb
    pop es
    pop di
    pop si
    pop cx
    pop ax
    ret

boot_options_detect_gui0:
    push ax
    push bx
    push cx
    push si
    mov byte [cs:boot_gui_disabled],0
    mov cx,[cs:boot_options_length]
    mov si,boot_options_buffer
.scan:
    cmp cx,5
    jb .scan_nogui
    cmp byte [cs:si+0],'g'
    jne .advance
    cmp byte [cs:si+1],'u'
    jne .advance
    cmp byte [cs:si+2],'i'
    jne .advance
    cmp byte [cs:si+3],'='
    jne .advance
    cmp byte [cs:si+4],'0'
    je .disabled
.advance:
    inc si
    dec cx
    jmp .scan
.scan_nogui:
    mov cx,[cs:boot_options_length]
    mov si,boot_options_buffer
.nogui_loop:
    cmp cx,5
    jb .scan_safe
    cmp byte [cs:si+0],'n'
    jne .nogui_advance
    cmp byte [cs:si+1],'o'
    jne .nogui_advance
    cmp byte [cs:si+2],'g'
    jne .nogui_advance
    cmp byte [cs:si+3],'u'
    jne .nogui_advance
    cmp byte [cs:si+4],'i'
    je .disabled
.nogui_advance:
    inc si
    dec cx
    jmp .nogui_loop
.scan_safe:
    mov cx,[cs:boot_options_length]
    mov si,boot_options_buffer
.safe_loop:
    cmp cx,4
    jb .done
    cmp byte [cs:si+0],'s'
    jne .safe_advance
    cmp byte [cs:si+1],'a'
    jne .safe_advance
    cmp byte [cs:si+2],'f'
    jne .safe_advance
    cmp byte [cs:si+3],'e'
    je .disabled
.safe_advance:
    inc si
    dec cx
    jmp .safe_loop
.disabled:
    mov byte [cs:boot_gui_disabled],1
.done:
    pop si
    pop cx
    pop bx
    pop ax
    ret

boot_options_pit_prev   dw 0
boot_options_pit_wraps  dw 0
boot_options_raw_break  db 0
boot_options_raw_pending db 0
boot_options_length     dw 0
boot_gui_disabled      db 0
boot_options_buffer    times (JTMOS_BOOT_OPTIONS_TEXT_MAX+1) db 0
str_boot_options_prompt  db 13,10,"JTMOS V69.50 strict boot [1=noapic 2=nogui 3=safe] (8s)> ",0
str_boot_options_selected db " <selected>",0
str_opt_noapic db "noapic"
str_opt_nogui  db "nogui"
str_opt_safe   db "safe"
%if BOOT_SAFE_DEFAULT || (BOOT_NOAPIC_DEFAULT && BOOT_NOGUI_DEFAULT)
str_boot_options_auto db 13,10,"JTMOS V69.49 build default: safe (noapic nogui)",13,10,0
str_boot_options_default db "<safe default: noapic nogui>",0
%elif BOOT_NOAPIC_DEFAULT
str_boot_options_auto db 13,10,"JTMOS V69.49 build default: noapic",13,10,0
str_boot_options_default db "<noapic default>",0
%elif BOOT_NOGUI_DEFAULT
str_boot_options_auto db 13,10,"JTMOS V69.49 build default: nogui",13,10,0
str_boot_options_default db "<nogui default>",0
%else
str_boot_options_auto db 0
str_boot_options_default db "<default>",0
%endif

;----------------------------------------------------------------------------
; Select a VBE graphics mode by geometry rather than by OEM mode number.
;
; Input : BX = requested width, DX = requested height
; Output: CF=0 mode selected and ModeInfoBlock refreshed at physical 0x4000
;         CF=1 no matching supported 32-bpp direct-colour LFB
;
; INT 10h/4F00 returns a far pointer to the BIOS-owned list of mode numbers.
; Scan at most 512 entries and query every candidate with 4F01.  This is the
; portable VBE path for physical NVIDIA/ATI/Intel BIOSes; mode IDs such as
; Bochs 0x144 are explicitly not assumed here.
select_vesa_resolution:
    mov [cs:vesa_want_width],bx
    mov [cs:vesa_want_height],dx
    pusha
    push ds
    push es
    push fs

    ; VBE2 request signature asks BIOS for the complete controller block.
    ; 0x5000 is scratch only; 0x4200 is reserved for the E820 handoff.
    mov ax,VESA_CTRLINFO_SEG
    mov es,ax
    xor di,di
    mov dword [es:di],0x32454256   ; "VBE2"
    mov ax,0x4F00
    int 0x10
    cmp ax,0x004F
    jne .fail
    mov ax,VESA_CTRLINFO_SEG
    mov es,ax
    xor di,di
    cmp dword [es:di],0x41534556   ; "VESA"
    jne .fail

    mov ax,[es:di+0x0E]            ; VideoModePtr.offset
    mov [cs:vesa_mode_list_off],ax
    mov ax,[es:di+0x10]            ; VideoModePtr.segment
    mov [cs:vesa_mode_list_seg],ax
    or ax,[cs:vesa_mode_list_off]
    jz .fail
    mov word [cs:vesa_mode_scan_left],512

.scan:
    cmp word [cs:vesa_mode_scan_left],0
    je .fail
    dec word [cs:vesa_mode_scan_left]

    mov ax,[cs:vesa_mode_list_seg]
    mov fs,ax
    mov si,[cs:vesa_mode_list_off]
    mov cx,[fs:si]
    cmp cx,0xFFFF
    je .fail
    add si,2
    mov [cs:vesa_mode_list_off],si
    jnc .ptr_ok
    add word [cs:vesa_mode_list_seg],0x1000
.ptr_ok:
    mov [cs:vesa_candidate_mode],cx

    ; Query this BIOS-advertised mode into the historical kernel handoff block.
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,0x4F01
    int 0x10
    cmp ax,0x004F
    jne .scan
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,[es:di+0x00]            ; D0=supported, D4=graphics, D7=LFB
    and ax,0x0091
    cmp ax,0x0091
    jne .scan
    cmp byte [es:di+0x18],1        ; NumberOfPlanes
    jne .scan
    cmp byte [es:di+0x19],32       ; BitsPerPixel
    jne .scan
    cmp byte [es:di+0x1B],6        ; Direct Color memory model
    jne .scan
    cmp dword [es:di+0x28],0       ; PhysBasePtr
    je .scan
    cmp byte [es:di+0x1F],0        ; red mask
    je .scan
    cmp byte [es:di+0x21],0        ; green mask
    je .scan
    cmp byte [es:di+0x23],0        ; blue mask
    je .scan
    mov ax,[cs:vesa_want_width]
    cmp word [es:di+0x12],ax       ; XResolution
    jne .scan
    mov ax,[cs:vesa_want_height]
    cmp word [es:di+0x14],ax       ; YResolution
    jne .scan

    ; Request this exact BIOS mode with linear-framebuffer bit 14 set.
    mov bx,[cs:vesa_candidate_mode]
    or bx,0x4000
    mov ax,0x4F02
    int 0x10
    cmp ax,0x004F
    jne .scan
    mov ax,0x4F03
    int 0x10
    cmp ax,0x004F
    jne .scan
    and bx,0x3FFF
    cmp bx,[cs:vesa_candidate_mode]
    jne .scan

    ; Refresh ModeInfoBlock after 4F02.  Some BIOS implementations use scratch
    ; memory internally during mode set; kernel32 must receive the final block.
    mov cx,[cs:vesa_candidate_mode]
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,0x4F01
    int 0x10
    cmp ax,0x004F
    jne .scan

    pop fs
    pop es
    pop ds
    popa
    clc
    ret
.fail:
    pop fs
    pop es
    pop ds
    popa
    stc
    ret

vesa_want_width      dw 0
vesa_want_height     dw 0
vesa_mode_list_off   dw 0
vesa_mode_list_seg   dw 0
vesa_mode_scan_left  dw 0
vesa_candidate_mode  dw 0

;----------------------------------------------------------------------------
; Last-resort fixed-mode compatibility helper for old Bochs VBE BIOSes whose
; 4F00 mode-list path is unusable. Input: CX=mode, BX=width, DX=height.
try_vesa_mode:
    mov [cs:vesa_want_width],bx
    mov [cs:vesa_want_height],dx
    mov [cs:vesa_candidate_mode],cx
    push cx
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,0x4F01
    int 0x10
    pop cx
    cmp ax,0x004F
    jne try_vesa_mode_fail
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,[es:di+0x00]
    and ax,0x0091
    cmp ax,0x0091
    jne try_vesa_mode_fail
    cmp byte [es:di+0x18],1        ; NumberOfPlanes
    jne try_vesa_mode_fail
    cmp byte [es:di+0x19],32       ; BitsPerPixel
    jne try_vesa_mode_fail
    cmp byte [es:di+0x1B],6        ; Direct Color memory model
    jne try_vesa_mode_fail
    cmp dword [es:di+0x28],0
    je try_vesa_mode_fail
    mov ax,[cs:vesa_want_width]
    cmp word [es:di+0x12],ax
    jne try_vesa_mode_fail
    mov ax,[cs:vesa_want_height]
    cmp word [es:di+0x14],ax
    jne try_vesa_mode_fail

    push cx
    mov bx,cx
    or bx,0x4000
    mov ax,0x4F02
    int 0x10
    pop cx
    cmp ax,0x004F
    jne try_vesa_mode_fail
    mov ax,0x4F03
    int 0x10
    cmp ax,0x004F
    jne try_vesa_mode_fail
    and bx,0x3FFF
    cmp bx,[cs:vesa_candidate_mode]
    jne try_vesa_mode_fail

    ; Keep the handoff block coherent with the mode actually made current.
    mov cx,[cs:vesa_candidate_mode]
    push cx
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,0x4F01
    int 0x10
    pop cx
    cmp ax,0x004F
    jne try_vesa_mode_fail
    clc
    ret
try_vesa_mode_fail:
    stc
    ret

no_vesa:
	pushad
	push ds
	mov bp,0x400
	mov ds,bp
	mov bp,0x28
	mov word [ds:bp+0],ax
	mov word [ds:bp+2],ax
	pop ds
	popad
	ret
;----------------------------------------------------------------------------
storeinfo:
	pushf
	; Push info
	push ax
	mov ax,0
	mov ds,ax
	pop ax

	; Pull info to location
	mov word [ds:bp],ax
	add bp,2
	mov word [ds:bp],bx
	add bp,2
	mov word [ds:bp],cx
	add bp,2
	mov word [ds:bp],dx
	add bp,2
	mov ax,es
	mov word [ds:bp],ax
	add bp,2
	mov ax,di
	mov word [ds:bp],ax
	add bp,2

	popf
	jc  case1
	mov ax,0
	jmp ncase1
case1:
	mov ax,1
ncase1:
	mov word [ds:bp],ax
	ret
;----------------------------------------------------------------------------
global_descriptor_table:     ; here begins the GDT
;
gdt_start:        dw                 gdt_size-1,0,0          ; val for GDT reg
;
gdtoff:
segdes dummy_descriptor,0xFFFF,0,0,0x9A,0xCF,0
segdes code32_descriptor,0xFFFF,0,0,0x9A,0xCF,0
segdes data32_descriptor,0xFFFF,0,0,0x92,0xCF,0
segdes core32_descriptor,0xFFFF,0,0,0x92,0xCF,0
segdes code16_descriptor,0xFFFF,0,0,0x9A,0,0
segdes data16_descriptor,0xFFFF,0,0,0x92,0,0

gdt_size equ $-(dummy_descriptor)

code32_idx      equ   0x08              ; offset of 32-bit code segment in GDT
data32_idx      equ   0x10              ; offset of 32-bit data segment in GDT
core32_idx      equ   0x18              ; offset of 32-bit core segment in GDT
code16_idx      equ   0x20              ; 16-bit protected-mode code
data16_idx      equ   0x28              ; 16-bit protected-mode data

interrupt_descriptor_table: ;*** here begins the early PM IDT ***;

idt_start:      dw                      idt_size-1,0,0
interrupt_0:
        times (32*8) db 0
idt_size equ $-(interrupt_0)

; One deliberately tiny emergency target is enough to stop exception
; escalation while kernel32 has not installed its safe IDT yet.  It does not
; touch the exception stack (some vectors have CPU error codes, some do not).
; Store a low-memory signature/CR2 for post-mortem tools and halt instead of
; allowing an invalid gate to reset the machine via triple fault.
[bits 32]
pmode_early_fault32:
        cli
        mov     dword [0x0000100C],0x21454D50 ; "PME!"
        mov     eax,cr2
        mov     dword [0x00001024],eax
        mov     word [0x000B8000],0x4F50      ; P (visible in VGA text mode)
        mov     word [0x000B8002],0x4F4D      ; M
        mov     word [0x000B8004],0x4F45      ; E
        mov     word [0x000B8006],0x4F21      ; !
.halt_early_fault:
        hlt
        jmp     .halt_early_fault
;----------------------------------------------------------------------------
