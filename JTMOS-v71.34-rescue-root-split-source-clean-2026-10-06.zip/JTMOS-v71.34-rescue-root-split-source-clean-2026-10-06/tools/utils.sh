#!/bin/bash

STAGE=$(mktemp -d "${TMPDIR:-/tmp}/jtmos-stage.XXXXXX")
trap 'rm -rf "$STAGE"' EXIT HUP INT TERM
#####################################################
# PRODUCE UTILITIES DISK 1
# utilsdisk.img
#####################################################

# Make LIBC.
cd ../libc/libc
make
cd ../../tools

# Make drivers.
cd ../libc/drv
make
cd ../../tools

# Make disk specific tools
cd ../libc/apps
make clean
make utilsdisk
cd ../../tools

# Clean up our temp. dir.
rm -f "$STAGE"/*
# Copy device drivers
cp ../libc/drv/*.bin "$STAGE"/
cp ../libc/drv/*.cfg "$STAGE"/
cp ../libc/docs/*.txt "$STAGE"/
# Useful programs
#cp ../misc/compress.biz "$STAGE"/compress.bin
#cp ../misc/bwbasic.biz "$STAGE"/bwbasic.bin
# Copy the binaries + help files into the temp dir
cp ../libc/apps/*.bin "$STAGE"/
cp ../libc/apps/*.hlp "$STAGE"/
cp ../libc/apps/boot.sh "$STAGE"/
cp ../libc/apps/help.sh "$STAGE"/
cp ../libc/apps/setup.sh "$STAGE"/
#cp ../libc/apps/*.raw "$STAGE"
#cp ../libc/apps/brandy/src/*.bin "$STAGE"
#cp ../libc/apps/gui/*.bin "$STAGE"
#cp ../libc/apps/gui/*.raw "$STAGE"

# Make an archive disk image out of
# the directory's contents.
./sqarc "$STAGE" > _utilsdisk.img

######################################
# Build compressed disk.
######################################

# Wipe temp. files.
rm -f comp/*

# Build unz
cd ../libc/apps
make -f unz.mak
cd ../../tools

# Build disk with compressed image.
# Remark any unneeded programs.
#cp "$STAGE"/nzip.bin comp
#cp "$STAGE"/sqa.bin comp
#cp "$STAGE"/sqsh.bin comp
#cp ../libc/apps/rt.bin comp	# ramdisk store/restore
cp ../libc/apps/unz.bin comp	# automatic unzip/unarchive

# Compress image.
./nzip _utilsdisk.img
# Copy into final compression folder.
cp _utilsdisk.img.nz comp/install.img.nz
# Copy graos there too.
####cp graos.img.nz comp
# Produce squirrel archive.
./sqarc comp > utilsdisk.img
cp utilsdisk.img ..
echo "Maximum size for utilsdisk.img is 800K"
echo "current size is:"
ls -l -s -k utilsdisk.img
# Remove temp. files.
#rm -f comp/*

# Produce boot disk image (combination).
cd ..
make image
cd tools

