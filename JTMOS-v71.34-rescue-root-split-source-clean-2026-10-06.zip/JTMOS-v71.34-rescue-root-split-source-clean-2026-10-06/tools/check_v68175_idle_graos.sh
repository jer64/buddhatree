#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.175 idle/GraOS regression: FAIL: $*" >&2; exit 1; }
S="$ROOT/libc/apps/gui/guiStart.c"
line_of(){ awk -v pat="$1" '$0 ~ pat { print NR; exit }' "$S"; }
grep -Eq '#define SCHED_IDLE_HLT_BURST +(64|[1-9][0-9][0-9]+)U' "$ROOT/kernel32/core/cp/scheduler.h" || fail 'HLT64-or-larger burst missing'
grep -q 'for(i=0; i<SCHED_IDLE_HLT_BURST; ++i)' "$ROOT/kernel32/core/cp/scheduler.c" || fail 'idle burst loop missing'
grep -q 'cpu_sti_hlt();' "$ROOT/kernel32/core/cp/scheduler.c" || fail 'sti/hlt missing'
grep -q 'if(current==idle) return scheduler_runnable_nonidle_exists();' "$ROOT/kernel32/core/cp/scheduler.c" || fail 'idle timer fast path missing'
(grep -q 'usleep((useconds_t)usec)' "$ROOT/libc/apps/gui/guiStartup.c" || grep -Eq 'splash_wait_(turns|bounded)' "$ROOT/libc/apps/gui/guiStartup.c") || fail 'bounded GraOS splash wait missing'
! grep -q 'GetTickCount()-start' "$ROOT/libc/apps/gui/guiStartup.c" || fail 'old splash yield-spin remains'
wdb_line=$(line_of '^[[:space:]]*wdbInit[(][)][;]')
layout_line=$(line_of '^[[:space:]]*guiLayoutInit[(]v[)][;]')
server_line=$(line_of '^[[:space:]]*guiServerInit[(][)][;]')
[ -n "$wdb_line" ] && [ -n "$layout_line" ] && [ -n "$server_line" ] || fail 'GraOS window core init missing'
[ "$wdb_line" -lt "$layout_line" ] && [ "$layout_line" -lt "$server_line" ] || fail 'GraOS window core init order changed'
! grep -q 'guiStartupShowPoster(v)' "$ROOT/libc/apps/gui/guiStart.c" || fail 'optional poster returned to the critical startup path'
grep -q 'classic solid desktop ready without asset I/O' "$ROOT/libc/apps/gui/guiStart.c" || fail 'built-in desktop fallback missing'
echo 'V68.175 idle/GraOS regression: PASS'
