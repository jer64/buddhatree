#!/bin/sh
set -eu
fail(){ echo "check_graos_doubleclick: FAIL: $*" >&2; exit 1; }
GUI=libc/apps/gui
P1=libc/include/jtmos/graosprotocol.h
P2=libc/libc/include/jtmos/graosprotocol.h
P3=libc/libc/include2026/jtmos/graosprotocol.h
for p in "$P1" "$P2" "$P3"; do
    grep -q 'GRAOS_GSID_DOUBLECLICK 47' "$p" || fail "double-click ABI missing from $p"
done
grep -q 'GRAOS_DOUBLE_CLICK_MS 500UL' "$GUI/windowMoving.c" || fail "500 ms double-click window missing"
grep -q 'GRAOS_DOUBLE_CLICK_SLOP 4' "$GUI/windowMoving.c" || fail "double-click movement tolerance missing"
grep -q 'last_click_window_id==w->id' "$GUI/windowMoving.c" || fail "same-window click identity missing"
grep -q 'last_click_widget_id==widget_id' "$GUI/windowMoving.c" || fail "same-control click identity missing"
grep -q 'guiQueueWindowEvent(w,GRAOS_GSID_DOUBLECLICK' "$GUI/windowMoving.c" || fail "public double-click event is not queued"
grep -q 'click_kind==GRAOS_CLICK_CAPTION' "$GUI/windowMoving.c" || fail "caption double-click detection missing"
grep -q 'guiToggleMaximizeWindow(v,cw)' "$GUI/windowMoving.c" || fail "caption maximize/restore action missing"
grep -q 'restore happens only' "$GUI/windowMoving.c" || fail "maximized title click is not deferred until drag"
if grep -q 'else if(cw->maximized) guiToggleMaximizeWindow(v,cw)' "$GUI/windowMoving.c"; then
    fail "single caption click still restores a maximized window"
fi
grep -q 'v->last_click_window_id=-1' "$GUI/guiStart.c" || fail "double-click state not initialized"
echo "check_graos_doubleclick: PASS (500ms/same-target event + title maximize/restore + drag-safe maximized caption)"
