#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
SQA="$ROOT/kernel32/sh/sqa.c"
SQAH="$ROOT/kernel32/sh/sqa.h"
MAIN="$ROOT/kernel32/sh/sqaMain.c"
LOG="$ROOT/kernel32/core/int/logging.c"
LOGH="$ROOT/kernel32/core/int/logging.h"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.29 SQA single commit: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.29|69.30|69.31|69.32|69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
if [ "$VERSION" = "69.29" ] || [ "$VERSION" = "69.30" ]; then
    grep -Eq '#define SQA_MEMBER_STAGE_MAX \((1|16)U \* 1024U \* 1024U\)' "$SQAH" || fail "bounded staging cap missing"
    grep -Fq 'stage=(BYTE *)malloc((size_t)e->length)' "$SQA" || fail "large-member staging allocation missing"
    grep -Fq 'read_exact(fd,stage+done,chunk)' "$SQA" || fail "staged source does not use transport-sized reads"
    grep -Fq 'write_exact(outfd,stage,(size_t)e->length)' "$SQA" || fail "single destination write missing"
else
    ! grep -Fq 'stage=(BYTE *)malloc((size_t)e->length)' "$SQA" || fail "obsolete whole-member staging remains"
    grep -Fq 'write_exact(outfd,buffer,chunk)' "$SQA" || fail "bounded replacement path missing"
fi
grep -Fq 'SystemLoggingPausePersistence' "$MAIN" || fail "SQA does not pause KLOGGER persistence"
grep -Fq 'SystemLoggingResumePersistence' "$MAIN" || fail "SQA does not resume KLOGGER persistence"
grep -Fq 'int SystemLoggingPausePersistence(void)' "$LOG" || fail "logging pause implementation missing"
grep -Fq 'logging_quiescing=1' "$LOG" || fail "logging persistence is not quiesced"
grep -Fq 'SystemLoggingPausePersistence' "$LOGH" || fail "logging pause API not exported"

if [ "$VERSION" = "69.29" ] || [ "$VERSION" = "69.30" ]; then
python3 - "$SQA" <<'PY' || fail "staged path is not a one-write destination commit"
import pathlib, re, sys

text = pathlib.Path(sys.argv[1]).read_text()
match = re.search(r"if\(stage!=NULL\) \{(.*?)\n    \} else \{", text, re.S)
if not match:
    raise SystemExit("staged branch missing")
body = match.group(1)
if body.count("write_exact(outfd,stage,(size_t)e->length)") != 1:
    raise SystemExit("staged branch must contain exactly one destination write")
if "write_exact(outfd,buffer,chunk)" in body:
    raise SystemExit("streaming destination write leaked into staged branch")
PY
fi

echo "V69.29 SQA single commit: PASS"
