#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
S="$ROOT/kernel32/core/cp/scheduler.c"
P="$ROOT/kernel32/core/int/pit.c"
G="$ROOT/kernel32/core/cp/gpf.c"
PAN="$ROOT/kernel32/core/cp/panic.c"
H="$ROOT/kernel32/core/cp/scheduler.h"

grep -q 'SCHED_TSS_BAD_KERNEL_EIP' "$S"
grep -q 'scheduler_validate_switch_target' "$S"
grep -q 'scheduler_tss_descriptor_base' "$S"
grep -q 't->eip<JTMOS_KERNEL_LOAD_PHYS' "$S"
grep -q 'SCHED_TSS_BAD_TARGET_BUSY' "$S"
grep -q 'SchedulerDebugDumpRunnable("PIT/pre-steady-state")' "$P"
grep -q 'ENTRY_ESP=%x' "$G"
grep -q 'EFLAGS(current before panic CLI)' "$PAN"
grep -q 'SchedulerTaskContextSane' "$H"

# The exception assembly must continue to distinguish same-CPL from CPL3 frames.
EXC="$ROOT/kernel32/core/int/exc.inc"
grep -q 'mov eax,\[esi+44\].*interrupted EFLAGS' "$EXC"
grep -q 'cmp eax,3' "$EXC"
grep -q 'mov eax,\[esi+48\]' "$EXC"
grep -q 'mov eax,\[esi+52\]' "$EXC"

echo 'PASS: V68.160 scheduler/TSS context hardening present.'
