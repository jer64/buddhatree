#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
N="$ROOT/kernel32/sh/networkapp.c"
K="$ROOT/kernel32/drivers/keyboard/keyb.c"
H="$ROOT/kernel32/drivers/keyboard/keyb.h"
J="$ROOT/kernel32/drivers/tcpip/jnet.c"
grep -Fq 'network_interactive_keyboard_start();' "$N"
grep -Fq 'enable_irq(1);' "$N"
grep -Fq 'enable();' "$N"
grep -Fq 'network_interactive_keyboard_poll();' "$N"
grep -Fq 'void KeyboardPollInputOnce(void)' "$K"
grep -Fq 'void KeyboardPollInputOnce(void);' "$H"
grep -Fq 'KeyboardPollInputOnce();' "$J"
# V68.167 terminal isolation must remain.
! grep -Fq 'SetTerminalForegroundProcess(input_terminal' "$N"
! grep -Fq 'ping_drain_terminal_keys' "$N"
echo 'V68.168 ping IRQ1/input rescue regression: PASS'
