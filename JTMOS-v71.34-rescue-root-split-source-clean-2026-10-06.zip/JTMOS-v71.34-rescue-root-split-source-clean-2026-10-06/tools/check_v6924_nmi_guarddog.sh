#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
SRC="$ROOT/kernel32/core/int/nmi_source.c"
NMI="$ROOT/kernel32/core/int/nmi.c"
HDR="$ROOT/kernel32/core/int/nmi.h"
RESCUE="$ROOT/kernel32/core/int/nmi_rescue.c"
APP="$ROOT/kernel32/sh/nmiapp.c"
EXC="$ROOT/kernel32/core/int/exception.c"
ASM="$ROOT/kernel32/core/int/exc.inc"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail() { echo "V69.24 NMI Guard Dog: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in
    69.24|69.2[5-9]|69.[3-9][0-9]|[7-9][0-9].*) ;;
    *) fail "unexpected VERSION for V69.24+ NMI Guard Dog feature check" ;;
esac

grep -Fq 'cmos_set_nmi_masked(0);' "$SRC" || fail "shared CMOS/NMI gate is never opened"
! grep -Fq 'outportb(NMI_CMOS_INDEX_PORT' "$SRC" || fail "nmi_source still open-codes shared port 70h"
python3 - "$SRC" <<'PYCHECK' || fail "NMI gate opens before source publication"
import pathlib,sys
s=pathlib.Path(sys.argv[1]).read_text()
q=s.index('src_status="QEMU/KVM IB700 4s watchdog -> injected NMI";')
qopen=s.index('nmi_open_pc_gate();',q)
qret=s.index('return 0;',q)
if not q < qopen < qret: raise SystemExit(1)
p=s.index('lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;')
popen=s.index('nmi_open_pc_gate();',p)
pret=s.index('return 0;',popen)
if not p < popen < pret: raise SystemExit(1)
PYCHECK

sed -n '/^ASMexception_2:/,/^ASMexception_3:/p' "$ASM" | grep -Fq 'iretd' || fail "vector-2 fallback no longer returns with IRETD"
grep -Fq 'lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;' "$SRC" || fail "LVTPC NMI unmask/rearm missing"
grep -Fq 'frame->eflags|=0x100U; /* TF: deterministic post-NMI kill trap */' "$NMI" || fail "TF kill trap arm missing"
! grep -Fq 'frame->eflags|=0x300U' "$NMI" || fail "AUTOKILL unsafely forces IF from NMI"
grep -Fq 'int NmiGuardDogReapOne(JTMOS_NMI_RESCUE_INFO *out)' "$NMI" || fail "deferred Guard Dog reaper missing"
grep -Fq 'ThreadQuarantineFromException(i);' "$NMI" || fail "Guard Dog quarantine missing"
grep -Fq 'KillThreadEx((DWORD)i,KT_NO_THREAD_SWITCH);' "$NMI" || fail "Guard Dog process-context kill missing"
grep -Fq 'magic!=(DWORD)thread_magic[i]' "$NMI" || fail "PID generation guard missing"
grep -Fq 'NmiGuardDogReapOne(&r)>0' "$RESCUE" || fail "rescue worker does not drain AUTOKILL slots"
grep -Fq 'watchdog_guarddog_reaps' "$HDR" || fail "Guard Dog stats field missing"
grep -Fq 'NmiWatchdogKillTrapPending(pid)' "$EXC" || fail "#DB first-stage containment missing"
grep -Fq 'IdentifyThread(me,"NMI-KILLPROBE")' "$APP" || fail "killprobe worker missing"
grep -Fq 'NmiWatchdogSetThreadAutokill(me,1)' "$APP" || fail "killprobe is not fail-stop opted in"
grep -Fq 'for(;;) __asm__ volatile("nop");' "$APP" || fail "killprobe does not create a true CLI hard loop"
grep -Fq 'killprobe' "$APP" || fail "killprobe command missing"

sh -n "$0" || fail "regression script syntax error"
echo "V69.24 NMI Guard Dog: PASS"
