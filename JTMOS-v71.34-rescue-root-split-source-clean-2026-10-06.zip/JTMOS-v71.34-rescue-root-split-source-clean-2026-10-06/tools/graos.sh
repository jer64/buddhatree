#!/bin/bash

STAGE=$(mktemp -d "${TMPDIR:-/tmp}/jtmos-stage.XXXXXX")
trap 'rm -rf "$STAGE"' EXIT HUP INT TERM
###################################################
## Build graos windowing system
###################################################

# Make disk specific tools
cd ../libc/apps
make graos
cd ../../tools

# Clean up our temp dir
rm -f "$STAGE"/*
# Copy the binaries into the temp dir
cp ../libc/apps/gui/*.bin "$STAGE"/
cp ../libc/apps/gui/*.raw "$STAGE"/
cp ../libc/apps/gui/*.bmp "$STAGE"/
# Make an archive disk image out of
# the directory's contents
./sqarc "$STAGE" > graos.img
#./nzip graos.img
