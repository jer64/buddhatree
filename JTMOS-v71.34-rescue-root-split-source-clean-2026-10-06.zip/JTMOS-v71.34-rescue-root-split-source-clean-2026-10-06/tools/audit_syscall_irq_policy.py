#!/usr/bin/env python3
"""Validate and report the JTMOS INT 0x7F syscall IRQ-body policy.

V69.37 rule:
  * IRQ_BODY: for callers that entered with IF=1, scall_handler executes STI
    immediately before CALL and CLI immediately after the handler returns.
  * ATOMIC: the whole handler body stays at IF=0.

The script intentionally requires one explicit policy row per registered syscall
so adding a dispatch entry cannot silently inherit an accidental policy.
"""
from __future__ import annotations
import argparse
import re
from pathlib import Path
import sys

ATOMIC_EXPECTED = {0, 5, 8, 65, 67, 68, 71, 72, 87, 130}


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//.*", "", text)
    return text


def parse_dispatch(scs: str):
    m = re.search(r"void\s*\*scall_functions\[N_MAX_SCALLS\]\s*=\s*\{(.*?)\n\};", scs, re.S)
    if not m:
        raise ValueError("scall_functions table not found")
    body = strip_comments(m.group(1))
    return [x.strip() for x in body.split(',') if x.strip()]


def parse_policy(scs: str):
    m = re.search(r"const\s+unsigned\s+char\s+scall_irq_policy\[N_MAX_SCALLS\]\s*=\s*\{(.*?)\n\};", scs, re.S)
    if not m:
        raise ValueError("scall_irq_policy table not found")
    rows = []
    rx = re.compile(r"/\*\s*(\d+)\s+([^*]+?)\s*\*/\s*(SCALL_IRQ_(?:ON|OFF))\s*,")
    for mm in rx.finditer(m.group(1)):
        nr = int(mm.group(1))
        desc = " ".join(mm.group(2).split())
        rows.append((nr, desc, mm.group(3)))
    return rows


def parse_codes(path: Path):
    by_num = {}
    rx = re.compile(r"^\s*#define\s+(SYS_[A-Za-z0-9_]+)\s+([0-9]+)\s*$")
    for line in path.read_text().splitlines():
        m = rx.match(line)
        if m:
            by_num.setdefault(int(m.group(2)), m.group(1))
    return by_num


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--markdown", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    scs_path = root / "kernel32/core/int/scs.c"
    codes_path = root / "kernel32/core/int/syscallcodes.h"
    scs = scs_path.read_text()

    dispatch = parse_dispatch(scs)
    policy = parse_policy(scs)
    codes = parse_codes(codes_path)
    m = re.search(r"DWORD\s+nr_scall_func\s*=\s*(\d+)\s*;", scs)
    if not m:
        raise ValueError("nr_scall_func not found")
    registered = int(m.group(1))

    errors = []
    if len(dispatch) != registered:
        errors.append(f"dispatch entries={len(dispatch)} but nr_scall_func={registered}")
    if len(policy) != registered:
        errors.append(f"explicit policy entries={len(policy)} but nr_scall_func={registered}")
    for i, row in enumerate(policy):
        if row[0] != i:
            errors.append(f"policy row {i} is numbered {row[0]}")
    for i in range(min(len(dispatch), len(policy))):
        policy_handler = policy[i][1].split(' - ', 1)[0].strip()
        if policy_handler != dispatch[i]:
            errors.append(f"slot {i}: policy says {policy_handler}, dispatch says {dispatch[i]}")

    atomic = {nr for nr, _, pol in policy if pol == "SCALL_IRQ_OFF"}
    if atomic != ATOMIC_EXPECTED:
        errors.append(
            "atomic set changed: expected " + str(sorted(ATOMIC_EXPECTED)) +
            ", got " + str(sorted(atomic))
        )

    if registered != 170 or codes.get(169) != "SYS_graosstartup":
        errors.append("registered syscall ABI no longer ends at SYS_graosstartup=169; audit map must be updated")

    body_count = sum(1 for _, _, p in policy if p == "SCALL_IRQ_ON")
    atomic_count = sum(1 for _, _, p in policy if p == "SCALL_IRQ_OFF")

    if args.markdown:
        print("| # | ABI name | Handler | IRQ policy |")
        print("|---:|---|---|---|")
        for nr, desc, pol in policy:
            handler = desc.split(' - ', 1)[0].strip()
            abi = codes.get(nr, "(reserved/dummy)")
            mode = "IRQ body" if pol == "SCALL_IRQ_ON" else "Atomic IF=0"
            print(f"| {nr} | `{abi}` | `{handler}` | {mode} |")
    else:
        print(f"registered={registered} irq_body={body_count} atomic={atomic_count}")
        print("atomic slots:")
        for nr, desc, pol in policy:
            if pol == "SCALL_IRQ_OFF":
                print(f"  {nr:3d} {codes.get(nr, '(reserved/dummy)'):28s} {desc}")

    if errors:
        print("AUDIT: FAIL", file=sys.stderr)
        for e in errors:
            print(" - " + e, file=sys.stderr)
        return 1
    print("AUDIT: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
