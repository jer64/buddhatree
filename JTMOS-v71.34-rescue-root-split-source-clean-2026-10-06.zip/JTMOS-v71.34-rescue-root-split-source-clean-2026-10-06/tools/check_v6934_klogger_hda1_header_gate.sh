#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}
L="$ROOT/kernel32/core/int/logging.c"
REL="$ROOT/kernel32/include/jtmos_release.h"
fail(){ echo "V69.34 KLOGGER hda1/header gate: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in 69.34|69.35|7[0-9].*) ;; *) fail "unsupported VERSION $VERSION" ;; esac
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
grep -Fq 'driver_getdevicenrbyname("hda1")' "$L" || fail "hda1 DNR lookup missing"
grep -Fq 'strncmp(inf->detstr,"JTMFS",5)!=0' "$L" || fail "explicit cached JTMFS signature gate missing"
grep -Fq 'jtmfat_validateinfoblock(dnr,inf)!=0' "$L" || fail "cached info-header validation missing"
grep -Fq 'fatsys->bb[dnr]==NULL || !fatsys->isJTMFS[dnr]' "$L" || fail "cached header publication check missing"
grep -Fq 'if(logging_hda1_header_gate_check()<0) return -1;' "$L" || fail "target activation is not fail-closed"
grep -Fq 'if(!logging_persistence_gate_allows_io())' "$L" || fail "persistence entry-point gate missing"
python3 - "$L" <<'PY'
import pathlib,re,sys
s=pathlib.Path(sys.argv[1]).read_text()
a=s.index('static int logging_hda1_header_gate_check(void)')
b=s.index('static int logging_persistence_gate_allows_io(void)',a)
f=re.sub(r'/\*.*?\*/','',s[a:b],flags=re.S)
for forbidden in ('jtmfat_LoadNewInfoBlock(', 'jtmfat_getinfoblock(', 'jtmfs_isDriveReady(', 'readblock(', 'open(', 'mkdir(', 'syncdev('):
    if forbidden in f:
        raise SystemExit('gate performs forbidden storage-capable call: '+forbidden)
for name,next_name in [
 ('SystemLogFlushNow','SystemLoggingPausePersistence'),
 ('WriteCrashLogRaw','WriteWWWLog'),
 ('WriteWWWLog','SystemDiskSpacePersistNow'),
 ('SystemDiskSpacePersistNow','initSystemLogging')]:
    a=s.index(name+'('); b=s.index(next_name+'(',a); f=s[a:b]
    if 'logging_persistence_gate_allows_io()' not in f:
        raise SystemExit(name+' lacks persistence gate')
PY
echo "V69.34 KLOGGER hda1/header gate: PASS"
