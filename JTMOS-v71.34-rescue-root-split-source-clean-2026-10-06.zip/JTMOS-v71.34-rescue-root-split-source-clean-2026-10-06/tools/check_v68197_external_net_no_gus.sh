#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V68.197 external-net/no-GUS regression: FAIL: $*" >&2; exit 1; }
python3 - "$ROOT/VERSION" <<'PY'
import sys
v=open(sys.argv[1]).read().strip().split('.')
major=int(v[0]); rel=int(v[1])
raise SystemExit(0 if major > 68 or (major == 68 and rel >= 197) else 1)
PY
[ -x 1.sh ] || fail "1.sh missing or not executable"
grep -Fq 'JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}' 1.sh || fail "1.sh does not default to curses"
grep -Fq 'JTMOS_NET_MODE=${JTMOS_NET_MODE:-bridge}' 1.sh || fail "1.sh does not default to bridged networking"
grep -Fq 'JTMOS_BRIDGE=${JTMOS_BRIDGE:-br0}' 1.sh || fail "1.sh does not default to br0"
grep -Fq 'JTMOS_AUDIO=${JTMOS_AUDIO:-off}' 1.sh || fail "1.sh does not disable audio"
for Q in run_jtmos_qemu.sh run_jtmos_qemu_sata.sh; do
  grep -Fq 'AUDIO_MODE=${JTMOS_AUDIO:-off}' "$Q" || fail "$Q does not default audio off"
  grep -Fq 'gus|off|none)' "$Q" || fail "$Q lost explicit GUS compatibility selector"
  grep -Fq 'if [ "$AUDIO_MODE" = gus ]; then' "$Q" || fail "$Q does not gate GUS device explicitly"
  grep -Fq 'set -- "$@" -device gus,irq=5' "$Q" || fail "$Q lacks explicit GUS opt-in path"
done
python3 - <<'PY'
s=open('run_jtmos_qemu_sata.sh').read()
old='set -- "$@" \\\n  -device gus,irq=5 \\\n  -netdev'
if old in s:
    raise SystemExit('unconditional SATA GUS still present')
PY
echo "check_v68197_external_net_no_gus: PASS (1.sh bridge/curses + QEMU GUS opt-in only)"
