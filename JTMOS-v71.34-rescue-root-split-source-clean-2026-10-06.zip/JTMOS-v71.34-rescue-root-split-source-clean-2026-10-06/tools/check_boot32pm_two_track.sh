#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_boot32pm_two_track: FAIL: $*" >&2; exit 1; }
B=boot32pm/bootmod.inc
P=boot32pm/Makefile
H=kernel32/fs/jtmfs/jtmfat.h
C=kernel32/fs/jtmfs/createfat.c
L=boot_storage_layout.h

grep -Fq 'kernel32/kernel32.bin.nz 2 1' jtm32.cfg || fail "compressed kernel is not at floppy track 2"
grep -Fq 'boot.bin)" -le 18432' "$P" || fail "boot32pm size limit is not 18 KiB"
grep -Fq '#define JTMOS_FLOPPY_LOADER_SECTORS         36UL' "$L" || fail "floppy loader is not 36 sectors"
grep -Fq '#define JTMOS_FLOPPY_KERNEL_LBA             36UL' "$L" || fail "floppy kernel is not at LBA36"
grep -Fq '#define JTMOS_HDD_LOADER_SECTORS            36UL' "$L" || fail "HDD loader is not 36 sectors"
grep -Fq '#define JTMOS_HDD_KERNEL_LBA                64UL' "$L" || fail "HDD kernel is not at LBA64"
grep -Fq '#define FAT_BOOT_SECTION_LEN_K  32' "$H" || fail "legacy whole-disk JTMFS prefix changed unexpectedly"
grep -Fq 'keroffs' "$B" || fail "HDD runtime kernel offset missing"
grep -Fq 'dw 0x8000' "$B" || fail "HDD kernel is not at byte offset 0x8000/LBA64"
grep -Fq 'mov ax,0x0A00' "$B" || fail "second loader track is not placed at physical 0xA000"
grep -Fq 'load_second_loader_track_floppy:' "$B" || fail "second floppy-track BIOS read helper missing"
grep -Fq 'call load_second_loader_track_floppy' "$B" || fail "floppy stage-1 does not invoke second-track helper"
grep -Fq 'load_second_loader_track_hd:' "$B" || fail "second HDD loader-track read missing"
grep -Fq 'mov cl,19' "$B" || fail "HDD second loader read does not begin at sector 19"
grep -Fq 'FLOPPY_KERNEL_LBA         equ 36' "$B" || fail "floppy kernel streamer does not begin at LBA36"
grep -Fq 'stream_floppy_lba_to_chs:' "$B" || fail "floppy LBA-to-CHS conversion missing"
grep -Fq 'JTMOS_FLOPPY_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES+offset' "$C" || fail "rootinstall source offset is not explicit floppy LBA36"
grep -Fq 'JTMOS_HDD_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES' "$C" || fail "rootinstall target offset is not explicit HDD LBA64"

loader_bytes=$((36*512))
[ "$loader_bytes" -eq 18432 ] || fail "36-sector arithmetic broken"
hdd_kernel_lba=$((32*1024/512))
[ "$hdd_kernel_lba" -eq 64 ] || fail "32 KiB HDD kernel offset arithmetic broken"
[ "$hdd_kernel_lba" -gt 35 ] || fail "HDD kernel overlaps two-track loader"

echo "check_boot32pm_two_track: PASS (floppy 36-sector loader + kernel@track2; HDD kernel@LBA64)"
