#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_partitioned_hdd_boot: FAIL: $*" >&2; exit 1; }
B="$ROOT/boot32pm/bootmod.inc"
C="$ROOT/kernel32/fs/jtmfs/createfat.c"
H="$ROOT/kernel32/fs/jtmfs/jtmfat.h"
F="$ROOT/kernel32/sh/fsadmin.c"
P="$ROOT/libc/apps/partition.c"
L="$ROOT/boot_storage_layout.h"

grep -Fq '#define JTMFS_MBR_BOOTCODE_BYTES          446' "$H" || fail "446-byte MBR code boundary missing"
grep -Fq '#define JTMFS_MBR_PARTITION_BYTE_OFFS     446' "$H" || fail "MBR partition offset missing"
grep -Fq '#define JTMFS_BOOT_RUNTIME_BYTE_OFFS      (3UL*512UL)' "$H" || fail "runtime metadata not moved to LBA3"
grep -Fq 'TIMES 446-($-$$) DB 0xBD' "$B" || fail "assembler does not enforce MBR stage-1 <=446 bytes"
grep -Fq 'MBR_Partition_Table:' "$B" || fail "MBR partition table placeholder missing"
grep -Fq 'TIMES 64 DB 0' "$B" || fail "64-byte primary partition table placeholder missing"
grep -Fq 'mov byte [cs:runtime_bootdrive],dl' "$B" || fail "BIOS boot drive is not captured from DL"
grep -Fq 'dd 0x32424D4A' "$B" || fail "JMB2 runtime metadata missing"
grep -Fq 'keroffs' "$B" || fail "HDD kernel offset runtime field missing"
! grep -Eq '^bootdrv:[[:space:]].*509' "$B" || fail "boot drive still stored inside MBR partition table"

grep -Fq 'CopyKernelPartitionedHddTarget' "$C" || fail "partitioned target detector missing"
grep -Fq 'CopyKernelInstallPartitionedBootTrack' "$C" || fail "partitioned boot-track writer missing"
grep -Fq 'memcpy(buf+JTMFS_MBR_PARTITION_BYTE_OFFS' "$C" || fail "target partition table is not preserved"
grep -Fq 'first_partition_lba' "$C" || fail "first partition safety check missing"
grep -Fq 'JTMFS_BOOT_RUNTIME_MAGIC' "$C" || fail "rootinstall does not require partition-safe source metadata"
grep -Fq 'strcmp(target,"hda")!=0' "$F" || fail "rootinstall still requires hda itself to be JTMFS"
grep -Fq '#define JTMOS_HDD_FIRST_PARTITION_LBA       4096UL' "$L" || fail "shared HDD partition boundary is not LBA4096"
grep -Fq 'JTMOS_HDD_FIRST_PARTITION_LBA' "$P" || fail "partition auto does not use shared HDD layout"
grep -Fq 'min_lba<JTMOS_HDD_FIRST_PARTITION_LBA' "$C" || fail "rootinstall does not enforce the full LBA0..4095 boot reserve"
grep -Fq 'JTMOS_HDD_KERNEL_LBA' "$C" || fail "rootinstall does not use explicit HDD kernel LBA"

echo "check_partitioned_hdd_boot: PASS (shared HDD layout + preserved MBR table + kernel@LBA64 + hda1>=4096)"
