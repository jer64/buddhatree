#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_bwbasic_jtmos: FAIL: $*" >&2; exit 1; }
U="$ROOT/libc/apps/bwbasic/upstream"
[ -f "$ROOT/libc/apps/bwbasic.mak" ] || fail "bwbasic.mak missing"
[ -f "$U/COPYING" ] || fail "upstream GPL COPYING missing"
[ -f "$U/README.patch02" ] || fail "patch level 2 provenance missing"
[ -f "$U/bwx_jtmos.c" ] || fail "JTMOS backend missing"
[ -f "$ROOT/libc/apps/bwbasic/README-JTMOS.txt" ] || fail "JTMOS port README missing"
grep -q 'bwbasic' "$ROOT/libc/apps/Makefile" || fail "canonical app list missing bwbasic"
grep -Fq 'list-utilities' "$ROOT/tools/build_release_apps.sh" || fail "release utility gate missing"
grep -q '#include <graphics.h>' "$U/bwx_jtmos.c" || fail "GraOS/BGI graphics backend missing"
grep -q '#include <jtsound.h>' "$U/bwx_jtmos.c" || fail "generic sound backend missing"
for cmd in CMD_SCREEN CMD_PSET CMD_GLINE CMD_RECT CMD_CIRCLEJT CMD_GCLEAR CMD_GPRESENT CMD_SOUND CMD_BEEP; do
    grep -q "$cmd" "$U/bwb_tbl.c" || fail "command table missing $cmd"
done
grep -q 'clrscr()' "$U/bwx_jtmos.c" || fail "CLS console mapping missing"
grep -q 'gotoxy(col, row)' "$U/bwx_jtmos.c" || fail "LOCATE console mapping missing"
grep -q 'fnc_inkey' "$U/bwx_jtmos.c" || fail "INKEY$ backend missing"
# BASIC must not access NVIDIA/PCI/MMIO directly. GeForce is a display backend.
if grep -Eiq '(0x10de|pci_|mmio|outl[[:space:]]*\(|inl[[:space:]]*\()' "$U/bwx_jtmos.c"; then
    fail "BASIC backend contains hardware-specific GPU access"
fi
grep -q 'SCREEN 1' "$ROOT/libc/apps/bwbasic/tests/jtmos-graphics.bas" || fail "graphics smoke BASIC missing"

# V68.172 crash-hardening invariants. These are deliberately source-level as the
# target binary cannot be executed on the build host without JTMOS syscalls.
! grep -Eq 'lhs->type[[:space:]]*=[[:space:]]*NUMBER' "$U/bwb_var.c" || fail "SWAP still assigns instead of comparing type"
grep -Fq 'lhs->type == NUMBER' "$U/bwb_var.c" || fail "SWAP type comparison fix missing"
grep -Fq 'BWB_DEVICE_VALID' "$U/bwbasic.h" || fail "device-number bounds helper missing"
grep -Fq '!BWB_DEVICE_VALID( dev_no )' "$U/bwb_inp.c" || fail "LINE INPUT device bounds check missing"
grep -Fq '!BWB_DEVICE_VALID( dev_number )' "$U/bwb_dio.c" || fail "random-file device bounds checks missing"
grep -Fq '!BWB_DEVICE_VALID( dev_number )' "$U/bwb_fnc.c" || fail "LOC/EOF/LOF device bounds checks missing"
! grep -Fq 'fgets( tbuf, MAXSTRINGSIZE + 2' "$U/bwb_inp.c" || fail "LINE INPUT one-byte fgets overflow remains"
grep -Fq 'fgets( tbuf, sizeof( tbuf ), inp_device )' "$U/bwb_inp.c" || fail "bounded LINE INPUT read missing"
grep -Fq 'MAXFILENAMESIZE 1024' "$U/bwbasic.h" || fail "JTMOS path-sized filename buffer missing"
grep -Fq 'dev_table[ req_devnumber ].filename[ MAXFILENAMESIZE ]' "$U/bwb_dio.c" || fail "OPEN filename termination missing"
grep -Fq 'if ( fp != NULL )' "$U/bwb_dio.c" || fail "random OPEN fclose(NULL) guard missing"
grep -Fq 'mode != DEVMODE_RANDOM' "$U/bwb_dio.c" || fail "FIELD/GET/PUT random-device guard missing"
grep -Fq 'buffer == NULL' "$U/bwb_dio.c" || fail "random-device buffer guard missing"
grep -Fq 'bwb_jump_ready == FALSE' "$U/bwb_prn.c" || fail "early error/longjmp guard missing"
grep -Fq 'fgets( buffer, MAXREADLINESIZE, stdin ) == NULL' "$U/bwx_jtmos.c" || fail "console EOF handling missing"
[ -f "$ROOT/libc/apps/bwbasic/tests/jtmos-swap.bas" ] || fail "SWAP regression BASIC missing"
[ -f "$ROOT/libc/apps/bwbasic/tests/jtmos-invalid-device.bas" ] || fail "invalid-device regression BASIC missing"

echo "check_bwbasic_jtmos: PASS (bwBASIC 2.20pl2 + crash hardening + console/GraOS/sound)"
