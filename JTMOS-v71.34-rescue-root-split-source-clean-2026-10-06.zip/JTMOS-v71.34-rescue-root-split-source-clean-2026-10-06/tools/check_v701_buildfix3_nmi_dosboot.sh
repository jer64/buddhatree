#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "V70.1 buildfix3 NMI/DOSBOOT: FAIL: $*" >&2; exit 1; }

grep -Fq 'JTMOS_BOOT_UTILS_HANDOFF_PHYS          0x00003300' "$ROOT/kernel32/include/memory_layout.h" || fail "handoff not moved to 0x3300"
grep -Fq 'BootUtilsRamReserveEarly();' "$ROOT/kernel32/mm/mm.c" || fail "staged bank not reserved inside mmInit"
grep -Fq 'staged pages already allocated/reserved' "$ROOT/kernel32/init/bootutilsram.c" || fail "ramextract conflict diagnostic missing"
grep -Fq 'InstallNmiInterruptGateFallback();' "$ROOT/kernel32/core/int/nmi.c" || fail "safe NMI gate missing"
! sed -n '/int NmiSystemSetEnabled/,/int NmiSystemBootInit/p' "$ROOT/kernel32/core/int/nmi.c" | grep -Fq 'InstallNmiTaskGate();' || fail "nmi on still installs task gate"
! sed -n '/int NmiSystemSetEnabled/,/int NmiSystemBootInit/p' "$ROOT/kernel32/core/int/nmi.c" | grep -Fq 'NmiPeriodicSourceInit()' || fail "nmi on still auto-starts autonomous source"
grep -Fq 'bare-metal PMU auto-source disabled' "$ROOT/kernel32/core/int/nmi_source.c" || fail "bare-metal PMU safe policy missing"
sh -n "$0"
echo "V70.1 buildfix3 NMI/DOSBOOT hardware-safety regression: PASS"
