#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
APIC="$ROOT/kernel32/core/int/apic.c"
APICH="$ROOT/kernel32/core/int/apic.h"
KEYB="$ROOT/kernel32/drivers/keyboard/keyb.c"
USB="$ROOT/kernel32/drivers/usb/usb_input.c"
OHCI="$ROOT/kernel32/drivers/usb/ohci.c"
SHC="$ROOT/kernel32/sh/sh.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail(){ echo "V69.22 APIC keyboard: FAIL: $*" >&2; exit 1; }
[ "$(cat "$ROOT/VERSION")" = "69.22" ] || fail "VERSION is not 69.22"
grep -Fq 'JTMOS_SOURCE_RELEASE "V69.22"' "$REL" || fail "release header is not V69.22"

# Retain the V69.21 null-page-safe ACPI fix.
grep -Fq 'APIC_LOWMEM_ALIAS_BASE   0x10000000UL' "$APIC" || fail "APIC low-memory alias missing"
grep -Fq 'apic_read_lowmem_word(0x0000040eUL)' "$APIC" || fail "safe EBDA pointer access missing"

# i8042 BIOS-preserve mode must repair IRQ1 without a device reset.
grep -Fq 'keyb_bios_preserve_enable_irq1' "$KEYB" || fail "i8042 BIOS-preserve IRQ1 repair missing"
grep -Fq 'I8042_CMD_ENABLE_KBD' "$KEYB" || fail "i8042 first-port enable missing"
grep -Fq 'oldcb|I8042_CBYTE_IRQ1' "$KEYB" || fail "i8042 IRQ1 command-byte enable missing"
grep -Fq '~I8042_CBYTE_KBD_DISABLED' "$KEYB" || fail "i8042 disabled-bit clear missing"
grep -Fq '#define KEYB_FORCE_DEVICE_RESET     0' "$KEYB" || fail "keyboard hard reset unexpectedly enabled"

# Idle USB samples must not steal ownership from PS/2.
grep -Fq 'input_policy_keyboard_backend()!=INPUT_BACKEND_USB && !activity' "$USB" || fail "USB idle-report ownership guard missing"
grep -Fq 'input_policy_keyboard_event(INPUT_BACKEND_USB)' "$USB" || fail "USB promotion path missing"

# QEMU OHCI fallback is intentionally narrow and throttled.
grep -Fq '#define QEMU_USB_HID_VENDOR        0x0627' "$OHCI" || fail "QEMU HID vendor guard missing"
grep -Fq 'ohci_qemu_keyboard_control_rescue' "$OHCI" || fail "QEMU keyboard rescue missing"
grep -Fq 'USB_HID_GET_REPORT' "$OHCI" || fail "HID GET_REPORT rescue missing"
grep -Fq 'OHCI_QEMU_RESCUE_USEC      20000UL' "$OHCI" || fail "QEMU rescue throttle missing"
grep -Fq 'h->reports!=0 || h->control_rescue_disabled' "$OHCI" || fail "periodic-path takeover/disable guard missing"

# I/O APIC write/readback and boot diagnostics.
grep -Fq 'apic_get_legacy_redir' "$APICH" || fail "APIC redirection diagnostic API missing"
grep -Fq 'if(low&IOAPIC_REDIR_MASK)' "$APIC" || fail "I/O APIC unmask readback missing"
grep -Fq 'SMSH keyboard APICdiag:' "$SHC" || fail "SMSH IRQ1 APIC diagnostic missing"
grep -Fq 'USBreports=' "$SHC" || fail "SMSH USB keyboard counters missing"

echo 'V69.22 APIC keyboard: PASS'
