#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.17 NMI hard watchdog: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
# This is both the 69.17 release check and a feature-regression check for later releases.
awk -v v="$VERSION" -v base="69.17" 'BEGIN{split(v,a,"."); split(base,b,"."); ok=(a[1]+0>b[1]+0)||((a[1]+0==b[1]+0)&&(a[2]+0>=b[2]+0)); exit ok?0:1}' \
    || fail "VERSION predates 69.17"
if [ "$VERSION" = "69.17" ]; then
    grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.17"' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
fi
N="$ROOT/kernel32/core/int/nmi.c"
H="$ROOT/kernel32/core/int/nmi.h"
E="$ROOT/kernel32/core/int/exception.c"
C="$ROOT/kernel32/core/int/crash_analysis.c"
I="$ROOT/kernel32/core/int/IdleThread.c"
grep -Fq 'thread_type[pid]&THREAD_TYPE_APPLICATION' "$N" || fail "applications are not automatic watchdog targets"
grep -Fq 'nmi_thread_watchdog_kill_pending[pid]=1;' "$N" || fail "kill-pending marker missing"
grep -Eq 'frame->eflags\|=0x(100|300)U;' "$N" || fail "NMI does not arm TF kill trap"
grep -Fq 'JTMOS_NMI_RESCUE_AUTOKILL' "$H" || fail "autokill rescue state missing"
grep -Fq 'NmiWatchdogKillTrapPending(pid)' "$E" || fail "#DB handler does not recognize watchdog trap"
grep -Fq '(NMI watchdog) unresponsive application terminated' "$E" || fail "explicit watchdog crash reason missing"
grep -Fq 'CrashAnalysisNotifyPending();' "$I" || fail "CPU_IDLE visible crash notification missing"
grep -Fq 'Process PID %d (%s) stopped:' "$C" || fail "visible process failure message missing"
grep -Fq 'no autonomous NMI source is active' "$ROOT/kernel32/sh/nmiapp.c" || fail "inactive-source runtime warning missing"
echo "V69.17 NMI hard watchdog regression: PASS"
