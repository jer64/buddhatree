#!/bin/sh
set -eu

KEYB=kernel32/drivers/keyboard/keyb.c
MOUSE=kernel32/drivers/mouse/ps2mouse.c
INT=kernel32/core/int/int.c

fail() { echo "ps2/i8042 check: FAIL: $*" >&2; exit 1; }

[ -f "$KEYB" ] || fail "missing $KEYB"
[ -f "$MOUSE" ] || fail "missing $MOUSE"

# Keyboard controller must explicitly configure IRQ1, first-port clock and
# scan-code-set-1 translation instead of inheriting BIOS/DOS state.
grep -q 'I8042_CBYTE_IRQ1' "$KEYB" || fail "IRQ1 command-byte bit is not configured"
grep -q 'I8042_CBYTE_KBD_DISABLED' "$KEYB" || fail "keyboard clock/interface bit is not configured"
grep -q 'I8042_CBYTE_TRANSLATION' "$KEYB" || fail "set-1 translation is not configured"
grep -q 'I8042_CMD_ENABLE_KBD' "$KEYB" || fail "first PS/2 port is never explicitly enabled"

# Firmware-preserving handoff: hard keyboard reset is opt-in, while F4 is
# unconditional so an init warning can never leave scanning disabled.
grep -q 'KEYB_FORCE_DEVICE_RESET     0' "$KEYB" || fail "keyboard reset is not default-off"
grep -q 'keyb_device_command_ack(0xF4)' "$KEYB" || fail "enable-scanning command missing"
awk '/int kb_hwinit\(void\)/,/^}/' "$KEYB" | grep -q 'keyb_device_command_ack(0xF4)' || fail "F4 is not in hardware bring-up"

# IRQ source is already known from IRQ1/IRQ12. Requiring status bit 5 inside
# the handlers can leave OBF stuck on 8042-compatible implementations.
KEYB_HANDLER=$(sed -n '/void keyb_handler(void)/,/^}/p' "$KEYB")
printf '%s\n' "$KEYB_HANDLER" | grep -q 'status&KBD_STAT_OBF' || fail "IRQ1 does not consume OBF"
printf '%s\n' "$KEYB_HANDLER" | grep -q 'KBD_STAT_MOUSE_OBF' && fail "IRQ1 still gates receive on AUX status bit"
MOUSE_HANDLER=$(sed -n '/void ps2mouse_irqhandler12(void)/,/^}/p' "$MOUSE")
printf '%s\n' "$MOUSE_HANDLER" | grep -q 'status&KBD_STAT_OBF' || fail "IRQ12 does not consume OBF"
printf '%s\n' "$MOUSE_HANDLER" | grep -q 'KBD_STAT_MOUSE_OBF' && fail "IRQ12 still gates receive on AUX status bit"

# PIC sanity: PC cascade master IRQ2 and explicit unmasking helper.
grep -q 'outportb(M_PIC+1, 1<<2)' "$INT" || fail "8259 master cascade wiring is not IRQ2"
grep -q 'irq_mask &= ~(1 << irq_no)' "$INT" || fail "IRQ unmask helper missing"

# SMSH rescue boot must keep AUX quiet so polling can accept keyboard OBF even
# when status bit 5 is unreliable. Mouse attach belongs to GraOS startup.
grep -q 'deferred until GraOS start' kernel32/init/initsystem.c || fail "PS/2 mouse is not deferred during SMSH rescue"
grep -q 'attaching deferred PS/2 mouse' kernel32/init/graos_boot.c || fail "GraOS does not attach deferred mouse"
grep -q '!ps2mouse_enabled || !(status&KBD_STAT_MOUSE_OBF)' "$KEYB" || fail "keyboard-only poll fallback still trusts AUX bit"

echo "ps2/i8042 checks: PASS"
