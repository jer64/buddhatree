#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_ircii_jtmos: FAIL: $*" >&2; exit 1; }

[ -s "$ROOT/libc/apps/irc.c" ] || fail "canonical irc.c missing"
[ -s "$ROOT/libc/apps/irc.mak" ] || fail "irc.mak missing"
[ -s "$ROOT/libc/apps/ircii/README.JTMOS" ] || fail "port README missing"
[ -s "$ROOT/libc/apps/ircii/upstream/doc/Copyright" ] || fail "upstream copyright missing"
grep -q 'Versions 2.2pre8 and above are copyright' "$ROOT/libc/apps/ircii/upstream/doc/Copyright" || fail "upstream copyright was not preserved"

grep -Eq '(^|[[:space:]])irc([[:space:]\\]|$)' "$ROOT/libc/apps/Makefile" || fail "irc not in canonical app list"
grep -q 'irc.bin' "$ROOT/tools/build_release_apps.sh" || fail "release app gate does not require irc.bin"

grep -q 'resolvehost4' "$ROOT/libc/apps/irc.c" || fail "IRC client lacks DNS bridge"
grep -q 'opensocket' "$ROOT/libc/apps/irc.c" || fail "IRC client lacks userspace TCP open"
grep -q 'readsocket' "$ROOT/libc/apps/irc.c" || fail "IRC client lacks userspace TCP read"
grep -q 'writesocket' "$ROOT/libc/apps/irc.c" || fail "IRC client lacks userspace TCP write"
grep -q 'PONG :' "$ROOT/libc/apps/irc.c" || fail "IRC PING/PONG handling missing"
grep -q 'PRIVMSG' "$ROOT/libc/apps/irc.c" || fail "IRC PRIVMSG handling missing"
grep -q 'ACTION' "$ROOT/libc/apps/irc.c" || fail "CTCP ACTION handling missing"
if grep -Ev '^[[:space:]]*\*' "$ROOT/libc/apps/irc.c" | grep -Eq '\b(fork|exec[lvpe]*|select|poll)[[:space:]]*\('; then
    fail "first JTMOS profile unexpectedly depends on Unix process/select APIs"
fi

[ -s "$ROOT/kernel32/drivers/tcpip/jt_usersock.c" ] || fail "generic uIP usersocket bridge missing"
[ -s "$ROOT/kernel32/drivers/tcpip/jt_usersock.h" ] || fail "generic uIP usersocket header missing"
grep -q 'JtUserSocketService();' "$ROOT/kernel32/drivers/tcpip/uipMain.c" || fail "uIP owner does not service usersockets"
grep -q 'if(JtUserSocketAppCall()) return;' "$ROOT/kernel32/drivers/tcpip/uip_appcall.c" || fail "uIP app dispatcher does not exclusively dispatch owned usersockets"
grep -q 'JtUserSocketNetworkReset();' "$ROOT/kernel32/drivers/tcpip/uipMain.c" || fail "usersockets are not reset with network lifecycle"

for f in \
  kernel32/core/int/scs.c; do
    grep -q 'JtUserSocketOpen' "$ROOT/$f" || fail "$f does not route opensocket to uIP bridge"
    grep -q 'JtUserSocketRead' "$ROOT/$f" || fail "$f does not route readsocket to uIP bridge"
    grep -q 'JtUserSocketWrite' "$ROOT/$f" || fail "$f does not route writesocket to uIP bridge"
    grep -q 'scall_resolvehost4' "$ROOT/$f" || fail "$f lacks resolver syscall"
    awk '/nr_scall_func[[:space:]]*=/ { v=$4; gsub(/;/,"",v); if ((v+0) >= 156) ok=1 } END { exit ok?0:1 }' "$ROOT/$f" || fail "$f syscall count not extended past resolver"
done

for f in \
  libc/libc/include/jtmos/syscallcodes.h \
  libc/libc/include2026/jtmos/syscallcodes.h \
  libc/include/jtmos/syscallcodes.h \
  libc/include/jtmos/k_syscallcodes.h; do
    grep -q 'SYS_resolvehost4.*155' "$ROOT/$f" || fail "$f lacks SYS_resolvehost4=155"
done

grep -q 'int resolvehost4' "$ROOT/libc/include/jtmos/network.h" || fail "legacy/public network header lacks resolver declaration"
grep -q 'int resolvehost4' "$ROOT/libc/libc/modern/jtmos_extra.c" || fail "libc resolver wrapper missing"

echo "check_ircii_jtmos: PASS (ircII 4.4 native profile + uIP Ring3 TCP/DNS bridge)"
