#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
F=kernel32/fs/jtmfs/diskcache/flexFat.c
C=kernel32/fs/jtmfs/createfat.c
T=tests/lazyfat_flush_order_v68162.py
fail(){ echo "check_v68162_lazyfat_order: FAIL: $*" >&2; exit 1; }

grep -F 'refusing out-of-order lazy page flush' "$F" >/dev/null || fail 'out-of-order lazy page guard missing'
grep -F 'for(i=0; i<n; i++)' "$F" >/dev/null || fail 'sorted dirty-page loop missing'
grep -F 'flexFlushSlot(f, order[i])' "$F" >/dev/null || fail 'non-HDA flush does not use sorted order[]'
grep -F '(DWORD)f->cache_page[slot] > f->lazy_materialized_pages' "$F" >/dev/null || fail 'LRU victim does not detect lazy prefix ordering'
grep -F 'dirty_pages=inf->fat_length;' "$C" >/dev/null || fail 'ram eager FAT materialization missing'
grep -F '!strcmp(devname,"ram")' "$C" >/dev/null || fail 'ram-only eager FAT policy missing'
python3 "$T"
echo 'check_v68162_lazyfat_order: PASS'
