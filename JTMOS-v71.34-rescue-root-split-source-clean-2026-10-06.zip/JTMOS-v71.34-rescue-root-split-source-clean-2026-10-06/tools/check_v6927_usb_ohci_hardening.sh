#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
OHCI="$ROOT/kernel32/drivers/usb/ohci.c"
USB="$ROOT/kernel32/drivers/usb/usb_input.c"
USBH="$ROOT/kernel32/drivers/usb/usb_input.h"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.27 USB/OHCI hardening: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.27|69.28|69.29|69.30|69.31|69.32|69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"

# A timed-out endpoint-zero request must be stopped before its fixed TD memory
# is reused.  The QEMU maintenance request gets a shorter bounded timeout.
grep -Eq 'static (void|int) ohci_control_quiesce\(DWORD control\)' "$OHCI" || fail "control quiesce helper missing"
if [ "$VERSION" = "69.27" ]; then
    grep -Fq 'OHCI_REG_CONTROL_CURRENT)&~0x0fUL)==0' "$OHCI" || fail "ControlCurrentED drain missing"
else
    grep -Fq 'ohci_wait_next_frame(OHCI_CTRL_QUIESCE_MS)' "$OHCI" || fail "SOF control quiesce missing"
fi
grep -Fq '#define OHCI_CTRL_RESCUE_TIMEOUT_MS 50' "$OHCI" || fail "bounded rescue timeout missing"
grep -Fq 'ohci.control_timeouts++;' "$OHCI" || fail "control timeout diagnostic missing"

# Root-port changes must drop old EDs, release logical input state and rebuild.
grep -Eq 'static (void|int) ohci_reenumerate_root_hub\(DWORD new_bitmap\)' "$OHCI" || fail "root-hub rebuild missing"
if [ "$VERSION" = "69.27" ]; then
    grep -Fq 'OHCI_REG_PERIOD_CURRENT)&~0x0fUL)==0' "$OHCI" || fail "periodic schedule drain missing"
else
    grep -Fq 'ohci_wait_next_frame(OHCI_PERIODIC_QUIESCE_MS)' "$OHCI" || fail "SOF periodic quiesce missing"
fi
grep -Fq 'usb_input_disconnect_all();' "$OHCI" || fail "disconnect state release missing"
grep -Fq 'ohci.connected_bitmap=ohci_connected_bitmap();' "$OHCI" || fail "topology snapshot missing"
grep -Fq 'bitmap!=ohci.connected_bitmap || connection_change' "$OHCI" || fail "rapid reconnect CSC handling missing"
grep -Eq 'static (void|int) ohci_periodic_watchdog\(void\)' "$OHCI" || fail "frame watchdog missing"
grep -Eq 'ohci\.(schedule_(restarts|republishes)|hard_recoveries)\+\+;' "$OHCI" || fail "periodic recovery diagnostic missing"

# Every connected root port consumes an address even if class binding fails
# after SET_ADDRESS; the next port must never reuse it.
python3 - "$OHCI" <<'PY' || fail "USB address reservation is not unconditional"
import pathlib, sys
text=pathlib.Path(sys.argv[1]).read_text()
needle="(void)ohci_enumerate_port(i,addr);"
positions=[]
start=0
while True:
    pos=text.find(needle,start)
    if pos<0:
        break
    positions.append(pos)
    start=pos+len(needle)
if len(positions)<2:
    raise SystemExit(1)
for pos in positions:
    tail=text[pos:pos+500]
    if "addr++;" not in tail:
        raise SystemExit(1)
PY

# Idle USB samples cannot evict working PS/2 input, and DEVDB keeps the PS/2
# fallback registered so disconnect recovery does not need an i8042 reset.
grep -Fq 'input_policy_mouse_backend()!=INPUT_BACKEND_USB && !activity' "$USB" || fail "idle mouse ownership guard missing"
! grep -Fq 'driver_removedevice' "$USB" || fail "USB promotion still deletes PS/2 fallback"
grep -Fq 'void usb_input_disconnect_all(void)' "$USB" || fail "input disconnect helper missing"
grep -Fq 'void usb_input_disconnect_all(void);' "$USBH" || fail "disconnect API missing"

sh "$ROOT/tests/usb_keyboard_report_regression.sh"
echo "V69.27 USB/OHCI hardening: PASS"
