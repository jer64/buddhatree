#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "GraOS V56 media players: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

[ -f libc/apps/media_browser.h ] || fail "shared file browser missing"
[ -f libc/apps/mp3/mp3.c ] || fail "MP3 player source missing"
[ -f libc/apps/mp3/minimp3.h ] || fail "minimp3 decoder missing"
[ -f libc/apps/mpeg1/mpeg1.c ] || fail "MPEG-1 player source missing"
[ -f libc/apps/mp3.mak ] || fail "MP3 build file missing"
[ -f libc/apps/mpeg1.mak ] || fail "MPEG-1 build file missing"

has 'creativecommons.org/publicdomain/zero/1.0/' libc/apps/mp3/minimp3.h "minimp3 CC0 notice missing"
has 'media_browser_select("Select MP3 music"' libc/apps/mp3/mp3.c "MP3 file browser missing"
has 'playlist_directory' libc/apps/mp3/mp3.c "MP3 directory playlist missing"
has 'mp3dec_decode_frame' libc/apps/mp3/mp3.c "MP3 decode loop missing"
has 'frame.hz>44100?44100:frame.hz' libc/apps/mp3/mp3.c "MP3 48 kHz resampling guard missing"
has 'media_browser_select("Select MPEG-1 video"' libc/apps/mpeg1/mpeg1.c "MPEG-1 file browser missing"
has 'scaled_size(source_w,source_h' libc/apps/mpeg1/mpeg1.c "aspect-ratio scaling missing"
has 'p.samplerate>44100?44100:p.samplerate' libc/apps/mpeg1/mpeg1.c "MP2 48 kHz resampling guard missing"

has 'GRAOS_ICON_MUSIC 10' libc/include/jtmos/graosprotocol.h "public music icon missing"
has 'GRAOS_ICON_VIDEO 11' libc/include/jtmos/graosprotocol.h "public video icon missing"
has 'case GRAOS_ICON_MUSIC:' libc/apps/gui/guiChrome.c "music icon renderer missing"
has 'case GRAOS_ICON_VIDEO:' libc/apps/gui/guiChrome.c "video icon renderer missing"
has '"/bin/mp3.bin"' libc/apps/gui/controlpanel.c "external Control Panel MP3 launcher missing"
has '"/bin/mpeg1.bin"' libc/apps/gui/controlpanel.c "external Control Panel MPEG-1 launcher missing"
has '"MP3 Music Player"' libc/apps/gui/guiStart.c "internal Control Panel MP3 button missing"
has '"MPEG-1 Video"' libc/apps/gui/guiStart.c "internal Control Panel MPEG-1 button missing"
has '"/bin/mp3.bin"' libc/apps/gui/windowFunc.c "internal Control Panel MP3 action missing"
has '"/bin/mpeg1.bin"' libc/apps/gui/windowFunc.c "internal Control Panel MPEG-1 action missing"

has 'linuxcore10 mp3 otest' libc/apps/Makefile "MP3 utilities-only registration missing"
has 'for app in mpeg1 mp3 sound rawplay aud' tools/build_install_image.sh "media.sqa packaging missing MP3/MPEG-1"
./tools/check_utilities_only_apps.sh

for binary in libc/apps/mp3.bin libc/apps/mpeg1.bin; do
    if [ -f "$binary" ]; then
        LC_ALL=C readelf -h "$binary" | grep -q 'Class:.*ELF32' || fail "$binary is not ELF32"
        LC_ALL=C readelf -h "$binary" | grep -q 'Machine:.*Intel 80386' || fail "$binary is not i386"
        LC_ALL=C readelf -h "$binary" | grep -q 'Entry point address:.*0x80004000' || fail "$binary has the wrong entry point"
    fi
done

echo 'GraOS V56 media players: PASS'
