#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "apps/audio cleanup: FAIL: $*" >&2; exit 1; }
for f in plasma plasma2 vgaplasma picture snake; do
    grep -q 'jtgame.h' "libc/apps/$f.c" || fail "$f is not using jtgame"
done
grep -q 'APPRAM_2048K' libc/apps/snake.c || fail 'snake memory request is too small'
grep -q 'formatDrive("hda")' libc/apps/setup.c || fail 'setup is not using native formatDrive'
! grep -Eq '^[[:space:]]*(if[[:space:]]*\(|return[[:space:]]+|[A-Za-z_][A-Za-z0-9_]*[[:space:]]*=)?[[:space:]]*system[[:space:]]*\(' libc/apps/setup.c || fail 'setup still calls ENOSYS system()'
grep -q 'findfirst("\*"' libc/apps/setup.c || fail 'setup runtime copy does not enumerate source files'
grep -Eq 'EDIT_MAX_LINES[[:space:]]+2048' libc/apps/edit.h || fail 'new editor document model missing'
grep -Eq 'EDIT_LINE_BYTES[[:space:]]+256' libc/apps/edit.h || fail 'new editor line bound missing'
grep -q 'Generic audio device: audio' kernel32/drivers/audio/audio.c || fail 'generic audio device missing'
grep -q 'HDA -> SB -> GUS' kernel32/drivers/audio/audio.c || fail 'generic audio backend policy missing'
grep -q 'audio_init();' kernel32/init/init.c || fail 'generic audio device is not registered by the current boot sequence'
grep -q '#if JTMOS_MOD_AUDIO_DRIVERS' kernel32/init/init.c || fail 'audio module policy guard missing'
grep -q 'AUDIO_BACKEND_HDA' libc/apps/sound.c || fail 'sound app cannot select generic HDA backend'
[ "$(wc -c < libc/apps/sqfam.raw)" -eq 256000 ] || fail 'sqfam.raw is not exact 320x200 RGBA32'
echo 'apps/audio cleanup: PASS'
