#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
MM="$ROOT/kernel32/mm/mmap.c"
fail(){ echo "check_mmap_bss_headroom: FAIL: $*" >&2; exit 1; }

grep -q 'static MM_PROCESS_MAPPING \*process_mmaps\[MM_PROCESS_PAGE_TABLE_CAPACITY\]' "$MM" || fail "per-PID pointer registry missing"
! grep -Eq 'process_mmaps\[MM_PROCESS_PAGE_TABLE_CAPACITY\]\[MM_PROCESS_MMAP_SLOTS\]' "$MM" || fail "large fixed 2-D mmap registry returned"
grep -q 'mm_process_registry_ensure' "$MM" || fail "lazy registry allocator missing"
grep -q '0,"process mmap registry"' "$MM" || fail "registry is not kernel/PID0-owned"
grep -q 'reservation_id' "$MM" || fail "ABA reservation token missing"
grep -q 'MM_PROCESS_MAP_RESERVED' "$MM" || fail "reservation state missing"
echo "check_mmap_bss_headroom: PASS (lazy per-PID mmap registry; fixed BSS pointer table only)"
