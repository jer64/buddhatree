#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
NF="$ROOT/kernel32/drivers/tcpip/nforce.c"
NFW="$ROOT/kernel32/drivers/tcpip/nforce.h"
UIP="$ROOT/kernel32/drivers/tcpip/uipMain.c"
JNET="$ROOT/kernel32/drivers/tcpip/jnet.c"
NET="$ROOT/kernel32/sh/networkapp.c"
fail(){ echo "check_el1352_mcp61: FAIL: $*" >&2; exit 1; }

# eMachines EL1352 = MCP61 MAC with a Realtek RTL8211-family external PHY.
grep -Fq 'id==0x03e5||id==0x03e6||id==0x03ee||id==0x03ef' "$NF" || fail 'MCP61 PCI IDs missing'
grep -Fq 'PHY_OUI_REALTEK2 0x0020' "$NF" || fail 'Realtek zero-ID1 OUI alias missing'
grep -Fq 'if(a>=0 && a!=0xffff && b>0 && b!=0xffff)' "$NF" || fail 'PHY scan still rejects Realtek PHYSID1=0'
grep -Fq 'PHY_MODEL_REALTEK_8211' "$NF" || fail 'RTL8211 model detection missing'
grep -Fq 'MII_RESV1' "$NF" || fail 'RTL8211 revision detection missing'
grep -Fq 'POWER2_PHY_RESET' "$NF" || fail 'RTL8211C hardware PHY reset missing'
grep -Fq 'PHY_REALTEK_INIT10' "$NF" || fail 'RTL8211C forcedeth vendor init missing'
grep -Fq 'Always restore it, including' "$NF" || fail 'RTL8211C failure path can leave vendor page selected'
grep -Fq 'phy_adapter_quiesce();' "$NF" || fail 'AdapterControl is not quiesced before MDIO ownership'
grep -Fq 'BMSR_ANEGCOMPLETE' "$NF" || fail 'carrier is accepted before PHY autonegotiation completes'

# MCP61 is the MAC.  The external RTL8211C/CL is its PHY; both sides of the
# RGMII link must be programmed to the negotiated speed/duplex.
grep -Fq 'phyif&=~(PHY_HALF|PHY_100|PHY_1000);' "$NF" || fail 'MCP61 PHY-interface mode bits are not updated'
grep -Fq 'wr(R_PHYIF,phyif);' "$NF" || fail 'MCP61 PHY-interface mode is not committed'
grep -Fq 'TXDEF_RGMII_10_100' "$NF" || fail 'RGMII 10/100 deferral is missing'
grep -Fq 'TXDEF_RGMII_1000' "$NF" || fail 'RGMII gigabit deferral is missing'
grep -Fq 'forcedeth stops both engines before changing' "$NF" || fail 'live link-mode update does not quiesce DMA engines'

# MCP61 management firmware arbitration must be preserved and bounded.
grep -Fq 'TXCTL_MGMT_SEMA_MASK' "$NF" || fail 'MCP61 management semaphore mask missing'
grep -Fq 'TXCTL_HOST_SEMA_ACQ' "$NF" || fail 'MCP61 host semaphore acquire missing'
grep -Fq 'TXCTL_SYNC_PHY_INIT' "$NF" || fail 'management PHY-init state test missing'
grep -Fq 'rtc_io_deadline_start(&deadline,500UL,2U,500UL);' "$NF" || fail 'management semaphore wait has no independent poll bound'
grep -Fq 'if(rtc_io_deadline_expired(&deadline)) return 0;' "$NF" || fail 'management semaphore wait does not enforce its deadline'
grep -Fq 'wr(R_TXCTL,rr(R_TXCTL)&~TXCTL_START)' "$NF" || fail 'controller stop clobbers management bits'
! grep -Fq 'wr(R_TXCTL,0)' "$NF" || fail 'raw zero write to transmitter control reintroduced'

# BIT2 is a reset-sequence bit, not part of an ordinary ownership kick.
! grep -Fq 'TXRX_KICK|TXRX_BIT2' "$NF" || fail 'normal TX kick incorrectly asserts reset BIT2'

# Failed physical DHCP must not invent a no-gateway 192.168.50.x network.
! grep -Fq 'jnet_configure_nforce_direct_fallback()<0' "$UIP" || fail 'automatic no-gateway nForce fallback still active'
grep -Fq 'DHCP failed; no address/default route configured' "$UIP" || fail 'physical DHCP failure is not explicit'

# A missing route is permanent until configuration changes: ping must return.
grep -Fq 'break; /* permanent configuration error, not a packet timeout */' "$NET" || fail 'ping still loops forever on ENETUNREACH'
# V68.167 deliberately replaced the old all-VT scan: a background request must
# never steal Ctrl+C from whichever terminal currently owns keyboard focus.
grep -Fq 'terminal=GetCurrentTerminal();' "$NET" || fail 'ping Ctrl+C is not scoped to its own terminal'
grep -Fq 'ConsumeTerminalInterrupt(terminal)' "$NET" || fail 'ping does not consume its terminal interrupt latch'
grep -Fq 'GetTerminalForegroundProcess(terminal)==pid' "$JNET" || fail 'JNET blocking wait lacks foreground-owner validation'
grep -Fq 'PeekTerminalInterrupt(terminal)' "$JNET" || fail 'JNET blocking wait does not observe the caller terminal interrupt'

# Status should expose enough PHY identity to diagnose the physical EL1352.
grep -Fq 'MCP61 PHY: addr=%d OUI=0x%x model=0x%x rev=%d' "$NET" || fail 'inet status lacks MCP61 PHY identity'
grep -Fq 'nforce_phy_oui' "$NFW" || fail 'nForce PHY diagnostic API missing'

echo 'check_el1352_mcp61: PASS (MCP61 MAC/RGMII + RTL8211C/CL PHY + DHCP truth + ping Ctrl+C)'
