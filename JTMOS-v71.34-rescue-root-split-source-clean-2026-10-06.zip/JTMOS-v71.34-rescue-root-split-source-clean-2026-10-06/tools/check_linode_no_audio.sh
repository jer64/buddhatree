#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_linode_no_audio: FAIL: $*" >&2; exit 1; }

M=Makefile
L=kernel32/modules.linode.conf
A=kernel32/autogen.pl
TMP=${TMPDIR:-/tmp}/jtmos-linode-audio-$$.mak
trap 'rm -f "$TMP" kernel32/generated.mak kernel32/modules.generated.h kernel32/console_profile.generated.h' EXIT HUP INT TERM

[ -f "$L" ] || fail "modules.linode.conf missing"
grep -Eq '^AUDIO_DRIVERS=0$' "$L" || fail "Linode audio module is not disabled"
grep -Eq '^NETWORK=1$' "$L" || fail "Linode network module must remain enabled"
grep -Eq '^APP_LOADER=1$' "$L" || fail "Linode application loader must remain enabled"
grep -Eq '^SH=1$' "$L" || fail "Linode shell must remain enabled"
grep -Eq '^PCI=1$' "$L" || fail "Linode PCI support must remain enabled"
grep -Fq 'KERNEL_MODULE_CONFIG ?= modules.conf' "$M" || fail "normal module default missing"
grep -Fq 'KERNEL_MODULE_CONFIG=modules.linode.conf rootimage rootdisk utilscdrom' "$M" || fail "image-linode does not select Linode module profile"
grep -Fq 'JTMOS_MODULE_CONFIG=$(KERNEL_MODULE_CONFIG)' "$M" || fail "kernel build does not receive selected module profile"
grep -Fq "drivers/(?:audio|gus|sb|hda)" "$A" || fail "autogen audio source filtering missing"

(
  cd kernel32
  JTMOS_MODULE_CONFIG=modules.linode.conf \
  JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT=0 \
  JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT=0 \
  ./autogen.pl > "$TMP"
)
grep -Fq '#define JTMOS_MOD_AUDIO_DRIVERS 0' kernel32/modules.generated.h || fail "generated module header does not disable audio"
# The Linode object graph must contain none of the integrated audio backends.
if grep -Eq '(^|[[:space:]])(\./)?drivers/(audio|hda|sb|gus)/[^[:space:]]+\.o([[:space:]]|$)' "$TMP"; then
  fail "audio object leaked into Linode generated object graph"
fi
# Network + shell remain present in the generated profile.
grep -Fq '#define JTMOS_MOD_NETWORK 1' kernel32/modules.generated.h || fail "network disabled accidentally"
grep -Fq '#define JTMOS_MOD_SH 1' kernel32/modules.generated.h || fail "shell disabled accidentally"

echo "check_linode_no_audio: PASS (Linode omits audio/HDA/SB/GUS; network + SQSH remain enabled)"
