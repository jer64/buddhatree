#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "cwd-cache/cexec-context: FAIL: $*" >&2; exit 1; }

TH="$ROOT/kernel32/core/int/threads.h"
TC="$ROOT/kernel32/core/int/threads.c"
JA="$ROOT/kernel32/fs/jtmfs/jtmfsAccess.c"
FD="$ROOT/kernel32/fs/filedir.c"
API="$ROOT/kernel32/fs/api.c"
CP="$ROOT/kernel32/core/cp/centralprocess.c"
CPM="$ROOT/kernel32/core/cp/centralprocessMain.c"
AM="$ROOT/kernel32/mm/ApplicationModule_cexec.c"

for f in "$TH" "$TC" "$JA" "$FD" "$API" "$CP" "$CPM" "$AM"; do
  [ -f "$f" ] || fail "missing ${f#$ROOT/}"
done

grep -q '#define THREAD_CWD_CACHE_MAX 256' "$TH" || fail "cwd cache maximum missing"
! grep -q 'thread_cwd_cache\[N_MAX_THREADS\]\[THREAD_CWD_CACHE_MAX\]' "$TH" || fail "cwd strings returned to fixed BSS"
grep -q 'static char \*thread_cwd_cache\[N_MAX_THREADS\]' "$TC" || fail "cwd cache is not lazy pointer storage"
grep -q 'static DWORD thread_cwd_cache_generation\[N_MAX_THREADS\]' "$TC" || fail "cwd cache generation metadata missing"
grep -q 'procmalloc(THREAD_CWD_CACHE_MAX,mm_kernel_persistent_owner(),"ThreadCWDCache")' "$TC" || fail "cwd cache is not lazily allocated outside fixed BSS"
grep -q 'ReleaseThreadCWDCache(pid)' "$TC" || fail "cwd cache heap storage is not released on thread teardown"
grep -q 'SetThreadCWDContext' "$TC" || fail "atomic DNR/DB setter missing"
grep -q 'CopyThreadCWDContext' "$TC" || fail "cwd context inheritance missing"
grep -q 'InvalidateThreadCWDCache(pid)' "$TC" || fail "legacy DNR/DB setters do not invalidate cache"

grep -q 'GetThreadCWDCache(pid,generation,path,max_len)' "$JA" || fail "getcwd does not consult cache"
grep -q 'SetThreadCWDCache(pid,path,generation)' "$JA" || fail "getcwd does not populate cache"
grep -q 'SetThreadCWDContext(GetCurrentThread(), dnr, db)' "$JA" || fail "chdir commits DNR/DB separately"
grep -q 'FileDirNamespaceChanged' "$JA" || fail "directory mutations do not invalidate path cache generation"

grep -q 'filedir_path_generation' "$FD" || fail "namespace generation storage missing"
grep -q 'FileDirPathGeneration' "$FD" || fail "namespace generation getter missing"

grep -q 'pid=cexec(cmd,path)' "$API" || fail "_system does not pass workDir directly to cexec"
! sed -n '/int _system(/,/^}/p' "$API" | grep -Eq '^[[:space:]]*getcwd[[:space:]]*\(' || fail "_system still reverse-converts cwd"
! sed -n '/int _system(/,/^}/p' "$API" | grep -Eq '^[[:space:]]*chdir[[:space:]]*\(' || fail "_system still mutates caller cwd"

grep -q 'jtmfs_GetThreadCWD(requesterPID' "$CP" || fail "exact exec inheritance does not use requester cwd cache for display"
grep -q 'SetThreadCWDCache(pid,centralprocess.runPath' "$CP" || fail "child cwd cache is not primed"
grep -q 'SetThreadCWDContext(GetCurrentThread(),service_dnr,service_db)' "$CPM" || fail "CP permanent cwd is not restored"

grep -q 'req->pid!=current' "$AM" || fail "ApplicationModule cexec permits foreign PID stack ownership"
grep -q 'argc<0' "$AM" || fail "ApplicationModule argc validation missing"
grep -q 'v>0xFFFFFFFFUL-add' "$AM" || fail "ApplicationModule stack rounding overflow guard missing"
grep -q 'Build the cdecl argument frame in the private stack' "$AM" || fail "private-stack cdecl frame hardening missing"

echo "cwd-cache/cexec-context: PASS"
