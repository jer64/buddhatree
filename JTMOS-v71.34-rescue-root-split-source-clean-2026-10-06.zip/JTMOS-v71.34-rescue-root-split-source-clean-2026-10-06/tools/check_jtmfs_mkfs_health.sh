#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
I="$ROOT/kernel32/fs/jtmfs/jtmfsIntegrity.c"
H="$ROOT/kernel32/fs/jtmfs/jtmfsIntegrity.h"
fail() { echo "check_jtmfs_mkfs_health: FAIL: $*" >&2; exit 1; }

[ -f "$I" ] || fail "missing jtmfsIntegrity.c"
grep -q 'jtmfat_infoblock_uses_lazyfat(&c->info)' "$I" || fail "fsck ignores lazy FAT contract"
grep -q 'jtmfat_lazyfat_materialized_pages(&c->info)' "$I" || fail "fsck does not honor persisted FAT prefix"
grep -q 'expected=length/c->unit_bs;' "$I" || fail "file chain size still uses physical sector size or unsafe addition"
grep -q 'if(length%c->unit_bs) expected++;' "$I" || fail "file chain size does not round up safely"
grep -q 'check_apply_media_geometry(&c)' "$I" || fail "fsck still trusts live cached allocation geometry"
grep -q 'check_unit_to_lba(c,block)' "$I" || fail "directory reads still map through live JTMFAT cache"
grep -q 'lazy-zero FAT volumes' "$H" || fail "public checker contract not documented"

# A tiny model of the central regression: stale bytes past the authoritative
# lazy prefix must never become allocations during a physical fsck.
python3 - <<'PY'
SECTOR_ENTRIES=128
materialized_pages=1
# page 0 is authoritative; pages 1..3 deliberately contain stale garbage.
physical=[[0]*SECTOR_ENTRIES,
          [0x12345678]*SECTOR_ENTRIES,
          [0xFFFFFFF7]*SECTOR_ENTRIES,
          [0xFFFFFFF8]*SECTOR_ENTRIES]

def fsck_get(entry):
    page=entry//SECTOR_ENTRIES
    idx=entry%SECTOR_ENTRIES
    if page>=materialized_pages:
        return 0
    return physical[page][idx]

physical[0][0]=0xFFFFFFF7
physical[0][1]=0xFFFFFFF8
assert fsck_get(0)==0xFFFFFFF7
assert fsck_get(1)==0xFFFFFFF8
for e in (128,129,255,256,383,511):
    assert fsck_get(e)==0, (e,hex(fsck_get(e)))
# Clustered length accounting: 9000 bytes on an 8192-byte allocation unit is
# two units, not eighteen 512-byte sectors.
length=9000
unit_bs=8192
assert (length+unit_bs-1)//unit_bs == 2
print('check_jtmfs_mkfs_health model: PASS')
PY

echo "check_jtmfs_mkfs_health: PASS"
