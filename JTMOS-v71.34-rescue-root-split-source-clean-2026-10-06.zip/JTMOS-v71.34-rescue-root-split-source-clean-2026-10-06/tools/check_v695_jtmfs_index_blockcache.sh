#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.5 JTMFS index/block-cache: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 69.5|69.[6-9]|69.[1-9][0-9]*|7[0-9].*) ;; *) fail "VERSION predates 69.5" ;; esac
I="$ROOT/kernel32/fs/jtmfs/diskcache/jtmfsIndex.c"
D="$ROOT/kernel32/drivers/driver_rw.c"
grep -Fq '#define JTMFS_INDEX_BLOOM_WORDS 8' "$I" || fail "bloom front filter missing"
grep -Fq 'index_bloom_add(idx,keys[j].hash)' "$I" || fail "base-tree bloom population missing"
grep -Fq 'index_bloom_add(idx,jtmfs_index_hash_name(fe->name))' "$I" || fail "delta bloom update missing"
grep -Fq 'if(n->key[mid].hash<hash) lo=mid+1; else hi=mid;' "$I" || fail "binary B+tree descent missing"
( awk '/^#define DAPI_CACHE_HASH_BUCKETS/ { if ($3+0 >= 512) ok=1 } END { exit ok?0:1 }' "$D" || grep -Fq 'dapi_cache_hash_buckets' "$D" ) || fail "DAPI hash buckets missing/smaller than 512 or dynamic hash missing"
grep -Fq 'cache_hash_remove_locked((int)(e-dapi_cache))' "$D" || fail "victim hash unlink missing"
grep -Eq '^#define DAPI_CACHE_READAHEAD_BLOCKS[[:space:]]+32$' "$D" || fail "16 KiB read-ahead missing"
grep -Fq 'physical_readblocks((int)dnr,block_nr,dapi_readahead_buffer,run)' "$D" || fail "read-ahead is not multi-block"
grep -Eq '^#define DAPI_CACHE_DIRECT_READ_BLOCKS[[:space:]]+64$' "$D" || fail "direct read threshold missing"
grep -Eq '^#define DAPI_CACHE_DIRECT_WRITE_BLOCKS[[:space:]]+128$' "$D" || fail "write-back direct threshold missing"
grep -Eq '^#define DAPI_CACHE_WRITEBACK_HIGH_BLOCKS[[:space:]]+128$' "$D" || fail "64 KiB write-back high-water missing"
python3 "$ROOT/tests/jtmfs_index_blockcache_v695.py"
echo "V69.5 JTMFS index/block-cache regression: PASS"
