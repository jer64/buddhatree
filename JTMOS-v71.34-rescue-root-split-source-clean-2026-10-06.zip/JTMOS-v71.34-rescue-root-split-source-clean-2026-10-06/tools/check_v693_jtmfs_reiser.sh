#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.3 JTMFS Reiser optimization: FAIL: $*" >&2; exit 1; }
INDEX="$ROOT/kernel32/fs/jtmfs/diskcache/jtmfsIndex.c"
WALK="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbWalk.c"
FIND="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbFind.c"
ADD="$ROOT/kernel32/fs/jtmfs/fsadd.c"

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in 69.3|69.[4-9]|69.[1-9][0-9]*|7[0-9].*) ;; *) fail "VERSION predates 69.3" ;; esac
grep -Fq '#define JTMFS_INDEX_DELTA_MAX 64' "$INDEX" || fail "delta batch missing"
grep -Fq 'index_delta_contains(idx,n->key[i].entry)' "$INDEX" || fail "base shadowing missing"
(grep -Fq 'n->key[i+1].hash<hash' "$INDEX" || grep -Fq 'if(n->key[mid].hash<hash) lo=mid+1; else hi=mid;' "$INDEX") || fail "collision-safe hash descent missing"
grep -Fq 'jtmfs_index_note_namespace_change' "$WALK" || fail "namespace delta hook missing"
grep -Fq 'jtmfs_index_get_free_entry' "$ADD" || fail "indexed free-slot placement missing"
grep -Fq 'jtmfs_index_lookup(dir,fname,&indexed_entry)' "$FIND" || fail "indexed getsize missing"
[ "$(grep -h 'JTMFS_DIRENT_METADATA_ONLY' "$ROOT/kernel32/fs/jtmfs/fsaddblocks.c" "$ROOT/kernel32/fs/jtmfs/jtmfs.c" | wc -l)" -ge 7 ] || fail "metadata-only paths incomplete"
python3 "$ROOT/tests/jtmfs_reiser_delta_v693.py"
echo "V69.3 JTMFS Reiser optimization regression: PASS"
