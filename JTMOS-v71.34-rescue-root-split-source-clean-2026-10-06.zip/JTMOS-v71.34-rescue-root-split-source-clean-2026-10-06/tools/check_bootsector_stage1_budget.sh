#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
B="$ROOT/boot32pm/bootmod.inc"

grep -q 'mov byte \[cs:runtime_bootdrive\],dl' "$B"
grep -q 'cmp al,1' "$B"
grep -q 'jbe Loader_1.44M' "$B"
grep -q 'mov bx,0x0300' "$B"
grep -q 'mov cx,0x0002' "$B"
grep -q 'mov ax,0x0211' "$B"
block=$(sed -n '/^Loader_1\.44M:/,/^try_again:/p' "$B")
if printf '%s\n' "$block" | grep -q 'mov ax,0x07B0'; then
    echo 'FAIL: Loader_1.44M redundantly reloads ES=0x07B0' >&2
    exit 1
fi
grep -Fq 'TIMES 446-($-$$) DB 0xBD' "$B"
grep -q 'signature:.*DW 0xAA55' "$B"
echo 'PASS: compact stage-1 preserves bootdrive and MBR byte-446 boundary'
