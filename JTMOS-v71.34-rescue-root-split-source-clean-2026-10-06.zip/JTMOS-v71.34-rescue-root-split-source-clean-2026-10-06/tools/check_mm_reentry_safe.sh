#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
M="$ROOT/kernel32/mm/mmap.c"
fail(){ echo "check_mm_reentry_safe: FAIL: $*" >&2; exit 1; }

grep -q 'MM_PROCESS_MAP_RESERVED' "$M" || fail 'RESERVED state missing'
grep -q 'MM_PROCESS_MAP_ACTIVE' "$M" || fail 'ACTIVE state missing'
grep -q 'MM_PROCESS_MAP_REMOVING' "$M" || fail 'REMOVING state missing'
grep -q 'reservation_id' "$M" || fail 'reservation token missing'
grep -q 'mm_process_range_available_nolock' "$M" || fail 'registry-aware range reservation missing'
grep -q 'slot->state=MM_PROCESS_MAP_RESERVED' "$M" || fail 'mmap does not publish reservation before backing allocation'
grep -q 'slot->reservation_id!=reservation_id' "$M" || fail 'mmap commit lacks ABA token validation'
grep -q 'm->state=MM_PROCESS_MAP_REMOVING' "$M" || fail 'munmap does not claim mapping before teardown'
grep -q 'm->state!=MM_PROCESS_MAP_ACTIVE' "$M" || fail 'translation does not restrict visibility to ACTIVE mappings'
grep -q 'mmflags=mmCriticalEnter()' "$M" || fail 'MM critical section missing'
grep -q 'Transactional failure: never expose a partially installed' "$M" || fail 'process PTE map rollback missing'
grep -q 'Validate the complete range first so protection changes are atomic' "$M" || fail 'atomic protect validation missing'

echo 'check_mm_reentry_safe: PASS (reservation states + ABA token + atomic process-PTE metadata)'
