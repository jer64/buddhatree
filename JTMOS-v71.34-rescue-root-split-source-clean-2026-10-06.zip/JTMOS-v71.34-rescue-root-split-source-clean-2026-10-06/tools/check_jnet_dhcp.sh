#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
J="$ROOT/kernel32/drivers/tcpip/jnet.c"
H="$ROOT/kernel32/drivers/tcpip/jnet.h"
D="$ROOT/kernel32/drivers/tcpip/jnet_dhcp.c"
U="$ROOT/kernel32/drivers/tcpip/uipMain.c"
E="$ROOT/kernel32/drivers/tcpip/ethdev.c"
W="$ROOT/kernel32/drivers/tcpip/jt_httpd.c"
N="$ROOT/kernel32/sh/networkapp.c"
T="${TMPDIR:-/tmp}/jtmos-jnet-dhcp-$$"
THTTP="${TMPDIR:-/tmp}/jtmos-httpd-policy-$$"
trap 'rm -f "$T" "$THTTP"' EXIT HUP INT TERM
fail(){ echo "check_jnet_dhcp: FAIL: $*" >&2; exit 1; }

grep -q 'JNET_DHCP_RENEWING' "$H" || fail "DHCP lease states missing"
grep -q 't1_seconds' "$H" || fail "T1/T2 lease metadata missing"
grep -q 'JNET_DHCP_INITIAL_TRIES 3' "$J" || fail "initial DHCP retry policy missing"
grep -q 'jnet_dhcp_parse_reply' "$J" || fail "validated DHCP codec not used"
grep -q 'dhcp_renew_once' "$J" || fail "lease renewal path missing"
grep -q 'jnet_maintenance' "$U" || fail "network worker does not run lease maintenance"
grep -q 'jnet_input_ethernet' "$U" || fail "network owner does not demux JNET UDP"
if grep -q 'static BYTE frame\[1600\]' "$J"; then fail "shared JNET scratch frame returned"; fi
# jnet_recv must consume the owner-thread queue, never steal directly from NIC.
awk '/int jnet_recv\(/,/^}/' "$J" | grep -q 'ethdev_receive' && fail "jnet_recv still reads NIC directly"
grep -q 'jnet_owner_attach' "$U" || fail "network owner not registered"
awk '/int jnet_send\(/,/^}/' "$J" | grep -q 'ethdev_receive' && fail "jnet_send still reads NIC directly"
grep -q 'send_pending' "$J" || fail "UDP send owner queue missing"
grep -q 'while((int)(o-d)<300)' "$D" || fail "DHCP minimum payload padding missing"
grep -q 'for(i=0;i<4;i++)' "$J" || fail "four-octet subnet comparison missing"
grep -q 'valid_netmask' "$J" || fail "DHCP netmask validation missing"
grep -q 'owner_forward_frame' "$J" || fail "control waits still drop unrelated uIP traffic"
grep -q 'ipv4_frame_view' "$J" || fail "ICMP/DNS IPv4 validation missing"
grep -q 'ping_icmp_error' "$J" || fail "ICMP unreachable/time-exceeded handling missing"
grep -q 'io_owner' "$E" || fail "Ethernet backend serialization missing"
grep -q 'uip_ethernet_ipv4_length' "$U" || fail "Ethernet padding is not trimmed before uIP"
grep -q 'uip_sync_ipv4_services' "$U" || fail "configured IPv4 state is not synchronized to passive services"
grep -q 'nc && nc->configured && ethdev_link_up()' "$U" || fail "passive services still depend on DHCP instead of usable IPv4"
grep -q 'static volatile int httpd_auto_enabled = 1' "$W" || fail "DHCP HTTP autostart is not the boot default"
grep -q 'httpd_requested_port=JT_HTTP_DEFAULT_PORT' "$W" || fail "DHCP HTTP autostart does not select the configured default port"
grep -q 'jnet_host_request(target,3000,&host_result)' "$N" || fail "ping hostname resolution missing"

cc -std=gnu89 -Wall -Wextra -Werror -I"$ROOT/kernel32/drivers/tcpip" \
   "$ROOT/tests/jnet_dhcp_codec_test.c" "$D" -o "$T"
"$T"
cc -std=gnu89 -Wall -Wextra -Werror -I"$ROOT/tests/httpd_stubs" \
   "$ROOT/tests/jt_httpd_policy_test.c" -o "$THTTP"
"$THTTP"
python3 "$ROOT/tests/network_dhcp_ping_http_v681651.py"
echo "check_jnet_dhcp: PASS"
