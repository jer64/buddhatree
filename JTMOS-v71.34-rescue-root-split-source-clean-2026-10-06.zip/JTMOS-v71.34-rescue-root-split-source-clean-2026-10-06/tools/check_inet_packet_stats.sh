#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_inet_packet_stats: FAIL: $*" >&2; exit 1; }
APP="$ROOT/kernel32/sh/networkapp.c"
MAIN="$ROOT/kernel32/drivers/tcpip/uipMain.c"
MAINH="$ROOT/kernel32/drivers/tcpip/uipMain.h"
UIP="$ROOT/kernel32/drivers/tcpip/uip.c"
UIPH="$ROOT/kernel32/drivers/tcpip/uip.h"
JN="$ROOT/kernel32/drivers/tcpip/jnet.c"
JNH="$ROOT/kernel32/drivers/tcpip/jnet.h"
ETH="$ROOT/kernel32/drivers/tcpip/ethdev.c"
ETHH="$ROOT/kernel32/drivers/tcpip/ethdev.h"
SQSH="$ROOT/libc/apps/sqsh.c"
HELP="$ROOT/kernel32/sh/helpapp.c"

grep -Fq 'rx_frames_seen, rx_frames_accepted, rx_frames_rejected' "$MAINH" || fail "ingress accepted/rejected counters missing"
grep -Fq 'rx_reject_ethertype, rx_reject_ipv4' "$MAINH" || fail "reject reason counters missing"
grep -Fq 'uip_rx_accept(&uip_driver_stats.rx_ipv4_accepted)' "$MAIN" || fail "IPv4 ingress accepted accounting missing"
grep -Fq 'uip_rx_reject(&uip_driver_stats.rx_reject_ethertype)' "$MAIN" || fail "EtherType reject accounting missing"
grep -Fq 'uip_driver_stats.reset_tick=GetTickCount()' "$MAIN" || fail "statistics epoch timestamp missing"

grep -Fq 'void uip_reset_stats(void)' "$UIPH" || fail "uIP core reset declaration missing"
grep -Fq 'uip_reset_stats(void)' "$UIP" || fail "uIP core reset implementation missing"
grep -Fq 'int uip_is_listening(u16_t port)' "$UIPH" || fail "uIP listener diagnostic declaration missing"
grep -Fq 'uip_is_listening(u16_t port)' "$UIP" || fail "uIP listener diagnostic implementation missing"

grep -Fq 'void jnet_reset_stats(void)' "$JNH" || fail "JNET counter reset declaration missing"
grep -Fq 'void jnet_reset_stats(void)' "$JN" || fail "JNET counter reset implementation missing"
grep -Fq 'void ethdev_reset_stats(void)' "$ETHH" || fail "Ethernet counter reset declaration missing"
grep -Fq 'void ethdev_reset_stats(void)' "$ETH" || fail "Ethernet counter reset implementation missing"

grep -Fq 'if(!strcmp(action,"stats"))' "$APP" || fail "inet stats action missing"
grep -Fq 'Usage: inet stats [reset]' "$APP" || fail "inet stats reset usage missing"
grep -Fq 'INET packet statistics: since reset' "$APP" || fail "since-reset report missing"
grep -Fq 'TCP:  accepted=' "$APP" || fail "TCP accepted/rejected report missing"
grep -Fq 'closed-port-SYN=' "$APP" || fail "closed port SYN diagnostic missing"
grep -Fq 'uIP-listen=%s' "$APP" || fail "actual uIP listener diagnostic missing"
grep -Fq 'internet_reset_packet_stats();' "$APP" || fail "counter reset helper is not used"
grep -Fq 'Internet: packet statistics reset.' "$APP" || fail "inet reset does not reset diagnostic epoch"
grep -Fq 'inet [status|stats [reset]|reset|start|stop]' "$SQSH" || fail "SQSH help lacks inet stats"
grep -Fq 'stats [reset]' "$HELP" || fail "SMSH help lacks inet stats"


echo "check_inet_packet_stats: PASS (accepted/rejected RX/TCP/ICMP counters + reset epoch + HTTP listener diagnostics)"
