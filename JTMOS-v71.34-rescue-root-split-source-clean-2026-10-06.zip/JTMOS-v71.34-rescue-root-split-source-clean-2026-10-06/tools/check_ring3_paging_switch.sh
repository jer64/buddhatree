#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_ring3_paging_switch: FAIL: $*" >&2; exit 1; }

grep -q 'void MapApplicationMemory(void)' kernel32/core/cp/scheduler.c || fail "MapApplicationMemory missing"
grep -q 'mov %%cr3,%0' kernel32/core/cp/scheduler.c || fail "CR3 read missing after userspace PDE switch"
grep -q 'mov %0,%%cr3' kernel32/core/cp/scheduler.c || fail "CR3 reload/TLB flush missing"
grep -q 'DWORD mm_get_process_pte' kernel32/mm/mm.h || fail "PID PTE API declaration missing"
grep -q 'DWORD mm_get_process_pte' kernel32/mm/mmap.c || fail "PID PTE API implementation missing"
grep -q 'elf32_verify_process_image' kernel32/core/cp/LaunchApp.c || fail "ELF PT_LOAD PTE verifier missing"
grep -q 'mm_get_process_pte(pid, va)' kernel32/core/cp/LaunchApp.c || fail "ELF verifier is not checking target PID PTEs"
grep -q 'Ring3 paging: PDE' kernel32/core/cp/gpf.c || fail "ring3 page-fault diagnostic missing"
grep -q 'mm_get_process_pte(pid, fault)' kernel32/core/cp/gpf.c || fail "page-fault diagnostic does not use PID PTE"

echo "check_ring3_paging_switch: PASS (shared CR3 PDE switch flushes TLB; PID PTEs verified)"
