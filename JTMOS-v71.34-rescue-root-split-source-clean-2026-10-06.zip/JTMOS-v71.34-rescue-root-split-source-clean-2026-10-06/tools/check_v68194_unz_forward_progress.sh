#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68194_unz_forward_progress: FAIL: $*" >&2; exit 1; }
for H in "$ROOT/libc/apps/nzip.h" "$ROOT/kernel32/sh/nzip.h" "$ROOT/tools/nzip.h"; do
  grep -Fq '#define NZIP2_OUTPUT_CHUNK   (1024U * 1024U)' "$H" || fail "$H lacks 1 MiB decode output chunk"
done
for C in "$ROOT/libc/apps/nzip.c" "$ROOT/kernel32/sh/nzip.c" "$ROOT/tools/nzip.c"; do
  grep -Fq 'nzip_progress_set_done(o->produced);' "$C" || fail "$C lacks decoded-output progress"
  grep -Fq 'malloc(NZIP2_OUTPUT_CHUNK)' "$C" || fail "$C lacks 1 MiB output allocation"
  grep -Fq 'NZIP2 decoded size %lu bytes' "$C" || fail "$C lacks decoded size diagnostic"
done
grep -Fq '#define NZIP2_JTMOS_WRITE_SLICE (128U * 1024U)' "$ROOT/libc/apps/nzip.c" || fail 'external UNZ lacks bounded JTMFS write slice'
grep -Fq 'rv=write(fd,o->buffer+done,(int)slice);' "$ROOT/libc/apps/nzip.c" || fail 'external UNZ does not use bounded direct write'
grep -Fq '#define JTMOS_LOCK_TRACE_ACQUIRE_RELEASE 0' "$ROOT/kernel32/core/int/lock.h" || fail 'verbose lock tracing still default-on'
grep -Fq 'fs_lock=logging_fs_try_enter(logging_root_dnr);' "$ROOT/kernel32/core/int/logging.c" || fail 'background logger does not defer on busy JTMFS'
grep -Fq 'jtmfs_mutation_trylock(dnr)' "$ROOT/kernel32/core/int/logging.c" || fail 'logger try-lock helper missing'
echo 'check_v68194_unz_forward_progress: PASS'
