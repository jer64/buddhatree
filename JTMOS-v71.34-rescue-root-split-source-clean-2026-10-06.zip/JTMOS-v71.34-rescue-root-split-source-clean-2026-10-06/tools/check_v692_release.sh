#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.2 release: FAIL: $*" >&2; exit 1; }
[ "$(cat "$ROOT/VERSION")" = "69.2" ] || fail "VERSION mismatch"
grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.2"' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
grep -Fq 'Current release: **V69.2**.' "$ROOT/VERSIONING.md" || fail "VERSIONING current release mismatch"
grep -Fq 'Current normal release: **V69.2**.' "$ROOT/VERSIONING.md" || fail "VERSIONING normal release mismatch"
[ -f "$ROOT/RELEASE-V69.2.txt" ] || fail "release notes missing"
grep -Fq 'JTMOS V69.2' "$ROOT/RELEASE-V69.2.txt" || fail "release note identity mismatch"
"$ROOT/tools/check_v692_du_terminal_path.sh"
echo "V69.2 release: PASS"
