#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.226 SQA auto-NZIP/media restore: FAIL: $*" >&2; exit 1; }
K="$ROOT/kernel32/sh/sqa.c"
A="$ROOT/libc/apps/sqa.c"
M="$ROOT/libc/apps/sqa.mak"
B="$ROOT/tools/build_install_image.sh"
S="$ROOT/kernel32/sh/sh.c"
for f in "$K" "$A"; do
    grep -Fq '#include "nzip.h"' "$f" || fail "$f does not link NZIP API"
    grep -Fq 'sqa_expand_compressed_image' "$f" || fail "$f lacks compressed image expansion"
    grep -Fq 'nzip_uncompress(nz_path,img_path)' "$f" || fail "$f does not call internal NZIP decoder"
    grep -Fq 'extract_archive_ex(img_path,"",dst,0,quiet)' "$f" || fail "$f does not extract decoded image"
    grep -Fq '(void)remove(nz_path);' "$f" || fail "$f leaves .nz temporary"
    grep -Fq '(void)remove(img_path);' "$f" || fail "$f leaves .img temporary"
done
grep -Fq 'nzip-sqa.o' "$M" || fail "sqa.bin does not link nzip decoder"
! grep -Fq '"unz",' "$S" || fail "SMSH bootstrap still launches separate unz"
G="$ROOT/kernel32/init/graos_boot.c"
! grep -Fq 'nzip_uncompress("/bin/install.img.nz","/bin/install.img")' "$G" || fail "GraOS bootstrap still decompresses install.img.nz a second time"
grep -Fq 'sqa_main(5,outer_argv)' "$G" || fail "GraOS bootstrap no longer delegates payload ownership to SQA"
grep -Fq 'for f in "$PAYLOAD"/*.sqa' "$B" || fail "SQA-only outer media staging missing"
for pkg in core.sqa graos.sqa interpreters.sqa demos.sqa media.sqa network.sqa tests.sqa docs.sqa boot.sqa; do
    grep -Fq "$pkg" "$B" || fail "missing $pkg media restoration"
done
echo "V68.226 SQA auto-NZIP/media restore: PASS"
