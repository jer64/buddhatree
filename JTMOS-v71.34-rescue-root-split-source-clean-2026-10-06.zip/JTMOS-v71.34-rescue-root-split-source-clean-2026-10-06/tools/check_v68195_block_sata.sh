#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

ver=$(cat VERSION)
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=195){ok=1} END{exit ok?0:1}' || fail version-too-old

grep -q 'cached_block_count' kernel32/drivers/driver_sys.h || fail geometry-cache-fields
grep -q 'int dirty,int \*was_hit' kernel32/drivers/driver_rw.c || fail dapi-single-lookup
grep -q 'driver_geometry_get_size' kernel32/drivers/driver_api.c || fail geometry-cache-fastpath
grep -q 'driver_geometry_get_block_size' kernel32/drivers/driver_api.c || fail geometry-blocksize-cache-fastpath
grep -q 'driver_geometry_seed(dnr,ahd.sectors,512)' kernel32/drivers/sata/ahci.c || fail ahci-geometry-seed
grep -q 'AHCI_PRDT_MAX             40' kernel32/drivers/sata/ahci.c || fail ahci-prdt-table
grep -q 'ahci_build_direct_prdt' kernel32/drivers/sata/ahci.c || fail ahci-direct-prdt
grep -q 'PRDT zero-copy enabled' kernel32/drivers/sata/ahci.c || fail ahci-zero-copy-report
grep -q 'ahci_hda_max_transfer_sectors' kernel32/drivers/partsup/partsup.c || fail partsup-ahci-bigfoot
grep -q 'PARTSUP_MCP61_PARENT_SECTORS 64' kernel32/drivers/partsup/partsup.c || fail partsup-mcp61-batch-cap
grep -q 'PARTSUP_LEGACY_PARENT_SECTORS 128' kernel32/drivers/partsup/partsup.c || fail partsup-legacy-batch-cap
grep -q 'inportsw(mcpd.cmd,buf+off,256)' kernel32/drivers/sata/mcp61.c || fail mcp61-rep-insw
grep -q 'outportsw(mcpd.cmd,buf+off,256)' kernel32/drivers/sata/mcp61.c || fail mcp61-rep-outsw
grep -q 'MCP61_SAFE_PIO_SECTORS' kernel32/drivers/sata/mcp61.c || fail mcp61-bounded-pio
grep -q 'driver_enableDAPIWriteBackCache(dnr)' kernel32/drivers/sata/mcp61.c || fail mcp61-writeback-enabled
pass 'V68.195 block/SATA structural regression'
