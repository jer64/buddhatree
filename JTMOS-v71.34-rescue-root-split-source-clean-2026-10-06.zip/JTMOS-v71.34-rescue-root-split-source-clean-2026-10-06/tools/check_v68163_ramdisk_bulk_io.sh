#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
C=kernel32/fs/jtmfs/createfat.c
FH=kernel32/fs/jtmfs/diskcache/flexFat.h
FC=kernel32/fs/jtmfs/diskcache/flexFat.c
S=libc/libc/modern/stdio.c
KS=kernel32/fs/file.c
T=tests/ramdisk_bulk_io_v68163.py
fail(){ echo "check_v68163_ramdisk_bulk_io: FAIL: $*" >&2; exit 1; }

grep -F 'DWORD ram_cluster=4096UL/(DWORD)blocksize;' "$C" >/dev/null || fail 'ram: 4 KiB cluster policy missing'
grep -F '!strcmp(devname,"ram")' "$C" >/dev/null || fail 'ram: device gate missing'
grep -F 'last_lookup_page' "$FH" >/dev/null || fail 'FlexFAT hot-page fields missing'
grep -F 'f->last_lookup_page==fat_sector' "$FC" >/dev/null || fail 'FlexFAT hot-page lookup missing'
grep -F '#define JTMOS_STDIO_BULK_CHUNK (256U * 1024U)' "$S" >/dev/null || fail 'Ring3 stdio 256 KiB bulk chunk missing'
grep -F '#define JTMOS_KERNEL_STDIO_BULK_CHUNK (256UL * 1024UL)' "$KS" >/dev/null || fail 'kernel stdio 256 KiB bulk chunk missing'
for h in kernel32/sh/nzip.h libc/apps/nzip.h tools/nzip.h graos-host/apps/nzip.h graos-host/kernel32/sh/nzip.h graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps/nzip.h; do
    grep -F '#define NZIP_IO_CHUNK        (256U * 1024U)' "$h" >/dev/null || fail "NZIP chunk not synchronized in $h"
done
python3 "$T"
echo 'check_v68163_ramdisk_bulk_io: PASS'
