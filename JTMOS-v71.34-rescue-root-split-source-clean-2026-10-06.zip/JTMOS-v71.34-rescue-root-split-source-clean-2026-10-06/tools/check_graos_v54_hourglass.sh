#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V69.11 hourglass: FAIL: $*" >&2; exit 1; }
python3 - "$(cat VERSION)" <<'PYVER' || fail "VERSION predates V69.11"
import sys
v=tuple(int(x) for x in sys.argv[1].split('.'))
raise SystemExit(0 if v >= (69,11) else 1)
PYVER
grep -Eq '#define GRAOS_VERSION "V(54|5[5-9]|[6-9][0-9])"' libc/apps/gui/graos.h || fail "GraOS version predates V54"
grep -Fq 'GRAOS_BUSY_OWNER_SLOTS 16' libc/apps/gui/graos.h || fail "busy owner slots missing"
grep -Fq 'guiBuildHourglass' libc/apps/gui/guiArrow.c || fail "hourglass renderer missing"
grep -Fq 'GRAOS_BUSY_DELAY_MS 150UL' libc/apps/gui/guiArrow.c || fail "anti-flicker delay missing"
grep -Fq 'busy_owner_depth' libc/apps/gui/guiArrow.c || fail "nested owner tracking missing"
grep -Fq 'guiBusyClearOwner' libc/apps/gui/guiServer.c || fail "dead-client busy reap missing"
grep -Fq 'JtmosGraOSSetBusy(1)' libc/apps/filer.c || fail "Filer busy integration missing"
grep -Fq 'JtmosGraOSSetBusy(0)' libc/apps/filer.c || fail "Filer busy release missing"
# Preserve the prior GraOS V53 stability gates.
./tools/check_graos_apps.sh
./tools/check_graos_win98_ui.sh
./tools/check_graos_raw_navigation.sh
echo 'V69.11 / GraOS V54 graphical hourglass: PASS'
