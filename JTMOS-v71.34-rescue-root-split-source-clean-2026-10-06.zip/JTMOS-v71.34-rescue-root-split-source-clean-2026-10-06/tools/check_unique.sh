#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC="$ROOT/libc/apps/unique/unique.c"
MAIN="$ROOT/libc/apps/unique/unique_main.c"
TMP=${TMPDIR:-/tmp}/jtmos-unique-check-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
fail(){ echo "check_unique: FAIL: $*" >&2; exit 1; }

[ -f "$SRC" ] || fail "missing pure-C runtime"
[ -f "$MAIN" ] || fail "missing CLI main"
! grep -R -E 'class[[:space:]]+CUniScript|#include[[:space:]]*<windows|static_cast|new[[:space:]]+CUniScript' "$ROOT/libc/apps/unique" >/dev/null || fail "C++/Win32 dependency remains"
grep -Fq 'typedef struct UniContext' "$ROOT/libc/apps/unique/unique.h" || fail "UniContext struct missing"
grep -Fq 'unique.bin' "$ROOT/libc/apps/Makefile" && : || grep -Fq 'writing unique' "$ROOT/libc/apps/Makefile" || fail "unique missing from release apps"
grep -Fq 'boot.uni' "$ROOT/libc/apps/sqsh.c" || fail "SQSH does not prefer Unique boot scripts"
grep -Fq 'dot && !strcmp(dot,".uni")' "$ROOT/libc/apps/sqsh.c" || fail "SQSH direct .uni dispatch missing"
grep -Fq '{"unique", unique_builtin}' "$ROOT/kernel32/sh/sh.c" || fail "SMSH unique builtin missing"
# Kernel SMSH is freestanding and does not link libc snprintf().  Guard the
# V16.68 build-break regression in unique_builtin specifically.
if sed -n '/static int unique_builtin/,/^}/p' "$ROOT/kernel32/sh/sh.c" | grep -Fq 'snprintf('; then
    fail "SMSH unique builtin depends on unavailable kernel snprintf"
fi
grep -Fq 'memcpy(command+used,argv[i],arglen)' "$ROOT/kernel32/sh/sh.c" || fail "SMSH unique bounded argv append missing"
grep -Fq 'ksetglobalenv("SCRIPT","unique.bin",1)' "$ROOT/kernel32/core/environment/envint.c" || fail "system SCRIPT environment default missing"

cc -std=gnu89 -O2 -I"$ROOT/libc/apps/unique" "$SRC" "$MAIN" -lm -o "$TMP/unique"
"$TMP/unique" "$ROOT/share/unique/examples/hello.uni" > "$TMP/out"
grep -Fq 'Unique running on JTMOS' "$TMP/out" || fail "function/interpolation test failed"
grep -Fq 'product: Altse' "$TMP/out" || fail "array/foreach test failed"
grep -Fq 'company=JTMOS Corporation' "$TMP/out" || fail "hash test failed"
"$TMP/unique" "$ROOT/share/unique/examples/legacy.uni" > "$TMP/legacy"
grep -Fq 'legacy Unique: credits=0' "$TMP/legacy" || fail "legacy syntax test failed"
"$TMP/unique" -e '$x=1; sub f { my $x=9; say "inner=$x"; } f(); say "outer=$x";' > "$TMP/scope"
grep -Fq 'inner=9' "$TMP/scope" || fail "local scope test failed"
grep -Fq 'outer=1' "$TMP/scope" || fail "global scope test failed"
"$TMP/unique" -e 'my $x=1; while($x < 4){ $x += 1; } if($x == 4){ say "loop-ok"; }' | grep -Fq loop-ok || fail "while/if test failed"


# Real Perl-like my/our scoping regression tests.
"$TMP/unique" -e 'our $x=1; { my $x=2; say "inner=$x"; { our $x; $x=3; say "our=$x"; } say "inner2=$x"; } say "global=$x";' > "$TMP/myour"
grep -Fq 'inner=2' "$TMP/myour" || fail "my block shadowing failed"
grep -Fq 'our=3' "$TMP/myour" || fail "our package binding failed"
grep -Fq 'inner2=2' "$TMP/myour" || fail "our binding leaked over lexical my"
grep -Fq 'global=3' "$TMP/myour" || fail "our assignment did not update global storage"
"$TMP/unique" -e 'my $u; say "defined=" . defined($u); my @a; my %h; say "sizes=" . @a . ":" . %h;' > "$TMP/uninit"
grep -Fq 'defined=0' "$TMP/uninit" || fail "uninitialized my scalar is not undef"
grep -Fq 'sizes=0:0' "$TMP/uninit" || fail "uninitialized my array/hash is not empty"
"$TMP/unique" -e 'my $file=5; sub h { say "file=$file"; say "caller=" . defined($caller); } sub g { my $caller=7; h(); } g();' > "$TMP/frame"
grep -Fq 'file=5' "$TMP/frame" || fail "file lexical capture failed"
grep -Fq 'caller=0' "$TMP/frame" || fail "callee can see caller lexical frame"
"$TMP/unique" -e 'foreach my $i (1,2,3) { my $tmp=$i; say "$i:$tmp"; } say "after=" . defined($i);' > "$TMP/foreachmy"
grep -Fq '3:3' "$TMP/foreachmy" || fail "foreach my lexical failed"
grep -Fq 'after=0' "$TMP/foreachmy" || fail "foreach my variable leaked after loop"
"$TMP/unique" -e 'our @a=(1,2); our %h=("k"=>7); { my @a=(9); my %h=("k"=>8); say $a[0] . ":" . $h{"k"}; } say $a[0] . ":" . $h{"k"};' > "$TMP/collections"
grep -Fq '9:8' "$TMP/collections" || fail "my array/hash shadowing failed"
grep -Fq '1:7' "$TMP/collections" || fail "our array/hash storage failed"

# The historical user-supplied scripts must at least lex and register their
# legacy sub blocks even though game-engine callbacks are not part of JTMOS.
for f in "$ROOT/share/unique/legacy-examples"/*.uni; do "$TMP/unique" -c "$f" >/dev/null; done

echo "check_unique: PASS (pure C, real my/our lexical/package scoping + legacy .uni)"
