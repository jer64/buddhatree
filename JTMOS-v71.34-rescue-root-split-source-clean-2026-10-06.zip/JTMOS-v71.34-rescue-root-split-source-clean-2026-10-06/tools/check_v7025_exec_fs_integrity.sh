#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.25" ] || { echo "V70.25 integrity: FAIL: VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7025_exec_fs_integrity.py"
