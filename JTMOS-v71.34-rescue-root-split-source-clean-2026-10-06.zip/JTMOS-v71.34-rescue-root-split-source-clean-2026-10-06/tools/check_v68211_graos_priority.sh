#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
H="$ROOT/libc/apps/gui/graos.h"
D="$ROOT/libc/apps/gui/windowDraw.c"
L="$ROOT/libc/apps/gui/guiLoop.c"
S="$ROOT/libc/apps/gui/guiStart.c"
fail(){ echo "V68.211 GraOS priority: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.211|68.212|68.213|68.214|68.215|68.216|68.217|68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|7[0-9].*) ;; *) fail "VERSION is not V68.211-compatible" ;; esac
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
GRAOS_VERSION=$(sed -n 's/.*#define[[:space:]]*GRAOS_VERSION[[:space:]]*"V\([0-9][0-9]*\)".*/\1/p' "$H" | sed -n '1p')
[ -n "$GRAOS_VERSION" ] && [ "$GRAOS_VERSION" -ge 46 ] || fail "GraOS V46 priority base missing"
grep -Fq 'if(a<=2) return d;' "$L" || fail "1x precision tier missing"
grep -Fq 'if(a<=6) return d+(d/2);' "$L" || fail "1.5x acceleration tier missing"
grep -Fq 'if(a<=16) return d*2;' "$L" || fail "2x acceleration tier missing"
grep -Fq 'return d*3;' "$L" || fail "3x acceleration tier missing"
grep -Fq 'MilSleep(mouse_hot?2:10);' "$L" || fail "active mouse latency path missing"
grep -Fq 'DWORD paint_serial;' "$ROOT/libc/apps/gui/window.h" || fail "window paint generation missing"
grep -Fq 'compositor_window_paint_signature' "$D" || fail "content-aware cache signature missing"
grep -Fq 'sig=compositor_mix(sig,w->paint_serial);' "$D" || fail "paint generation not hashed"
! grep -Fq 'frame_counter%GRAOS_' "$D" || fail "stale frame-modulo cache refresh returned"
! grep -Fq 'near_window_cache=(GRAOS_PIXEL*)malloc' "$S" || fail "second 3 MiB startup cache returned"
grep -Fq 'if(front) draw_window_range(v,front_z,GRAOS_Z_MAX);' "$D" || fail "focus full-rate missing"
grep -Fq 'guiMoveCursorOnly(v);' "$L" || fail "cursor-only compositor path missing"
grep -Fq 'cursor_under[32*32]' "$H" || fail "cursor backing store missing"
# Cursor must remain after all window/popup/debug drawing and immediately before present.
python3 - "$L" <<'PY2'
import sys
s=open(sys.argv[1]).read()
a=s.index('drawWindowFrame(v);')
b=s.index('guiDrawCursor(v);',a)
c=s.index('guiUpdate(v)',b)
assert a < b < c
PY2
echo "V68.211 GraOS priority regression: PASS"
