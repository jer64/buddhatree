#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68101_restored_features: FAIL: $*" >&2; exit 1; }
VER=$(cat "$ROOT/VERSION")
MAJOR=${VER%%.*}
RELEASE=${VER#*.}
case "$MAJOR:$RELEASE" in
    *[!0-9:]*|:*) fail "invalid public VERSION '$VER'" ;;
esac
[ "$MAJOR" -eq 68 ] && [ "$RELEASE" -ge 101 ] || fail "requires V68.101 or newer (got $VER)"
[ -f "$ROOT/libc/apps/bwbasic.mak" ] || fail "bwbasic.mak missing"
[ -f "$ROOT/libc/apps/bwbasic/upstream/bwx_jtmos.c" ] || fail "BWBASIC JTMOS backend missing"
grep -q 'bwbasic' "$ROOT/libc/apps/Makefile" || fail "BWBASIC not in app list"
make --no-print-directory -s -C "$ROOT/libc/apps" list-utilities | grep -qx 'bwbasic' || fail "BWBASIC not classified utilities.iso-only"
grep -q 'UTILITIES_ONLY_APPS' "$ROOT/tools/build_install_image.sh" || fail "utilities-only packaging gate missing"
[ -f "$ROOT/kernel32/drivers/vga/nv6150.c" ] || fail "NV6150 driver missing"
grep -q 'Nv6150PrepareGraOS' "$ROOT/kernel32/init/initsystem.c" || fail "NV6150 init integration missing"
grep -q 'Nv6150SetMode' "$ROOT/kernel32/init/vesa.c" || fail "NV6150 VESA/GraOS integration missing"
[ -f "$ROOT/libc/apps/cbmvm/CHANGELOG.md" ] || fail "CBMVM changelog missing"
[ -f "$ROOT/libc/apps/cbmvm/legacy_examples/counting.asm" ] || fail "CBMVM legacy examples missing"
grep -q 'CBMVM_PRG_COUNT=0' "$ROOT/tools/build_install_image.sh" || fail "CBMVM PRG utilities packaging missing"
grep -Fq 'cp "$f" "$CBMVM_STAGE/$(basename "$f")"' "$ROOT/tools/build_install_image.sh" || fail "CBMVM PRG basename packaging missing"
echo "check_v68101_restored_features: PASS"
