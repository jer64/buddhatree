#!/bin/sh
# Publish the full JTMOS utilities CD payload as root utilities.iso.
# The source archive is SQARC data padded to an ATAPI 2048-byte boundary; it is
# intentionally not an ISO9660 filesystem.  DOSBOOT and JTMOS treat these bytes
# as the utilities archive/CD image.
set -eu

TOOLS=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$TOOLS/.." && pwd)
SRC="$TOOLS/utilities.sqa"
SQARC="$TOOLS/sqarc"
OUT="$ROOT/utilities.iso"
MIRROR="$ROOT/kernel32/utilities.iso"
TMP="$ROOT/utilities.iso.tmp.$$"

cleanup() { rm -f "$TMP"; }
trap cleanup EXIT HUP INT TERM

[ -x "$SQARC" ] || { echo "utilities.iso: missing executable $SQARC" >&2; exit 1; }
[ -s "$SRC" ] || { echo "utilities.iso: missing $SRC; packages did not produce the CD payload" >&2; exit 1; }

# Refuse to publish a superficially non-empty or mixed-format archive.
EXPECTED_PACKAGES="boot.sqa core.sqa demos.sqa docs.sqa graos.sqa interpreters.sqa media.sqa network.sqa tests.sqa"
for pkg in $EXPECTED_PACKAGES; do
    "$SQARC" --has-member "$SRC" "$pkg" || {
        echo "utilities.iso: $SRC is missing $pkg" >&2
        exit 1
    }
done
if "$SQARC" --list "$SRC" | grep -v '\.sqa$' | grep -q .; then
    echo "utilities.iso: outer archive contains a non-SQA member" >&2
    exit 1
fi

cp "$SRC" "$TMP"
bytes=$(wc -c < "$TMP")
rem=$((bytes % 2048))
if [ "$rem" -ne 0 ]; then
    pad=$((2048 - rem))
    dd if=/dev/zero bs=1 count="$pad" >> "$TMP" 2>/dev/null
fi

# The reader used by boot32pm must accept the final padded bytes, so validate
# after padding as well as before it.
for pkg in $EXPECTED_PACKAGES; do
    "$SQARC" --has-member "$TMP" "$pkg" || {
        echo "utilities.iso: padded image failed SQARC validation for $pkg" >&2
        exit 1
    }
done
if "$SQARC" --list "$TMP" | grep -v '\.sqa$' | grep -q .; then
    echo "utilities.iso: padded image contains a non-SQA member" >&2
    exit 1
fi

mv "$TMP" "$OUT"
trap - EXIT HUP INT TERM
cp "$OUT" "$MIRROR"

[ -s "$OUT" ] || { echo "utilities.iso: publication failed: $OUT is missing/empty" >&2; exit 1; }
[ -s "$MIRROR" ] || { echo "utilities.iso: mirror failed: $MIRROR is missing/empty" >&2; exit 1; }

printf 'ATAPI utilities/demo image published:\n'
ls -lh "$OUT" "$MIRROR"
