#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_nzip_256k_readahead: FAIL: $*" >&2; exit 1; }

for H in "$ROOT/libc/apps/nzip.h" "$ROOT/kernel32/sh/nzip.h"; do
    grep -Fq '#define NZIP_COMPRESS_READAHEAD (256U * 1024U)' "$H" || fail "$H lacks 256 KiB compression read-ahead"
    grep -Fq '#define NZIP_COMPRESS_HISTORY   NZIP_MAX_LOOKBACK' "$H" || fail "$H lacks bounded retained history"
done

for C in "$ROOT/libc/apps/nzip.c" "$ROOT/kernel32/sh/nzip.c"; do
    grep -Fq 'fread(window+history_len,1U,(size_t)NZIP_COMPRESS_READAHEAD,in)' "$C" || fail "$C does not read source through bounded window"
    grep -Fq 'malloc((size_t)NZIP_COMPRESS_HISTORY+(size_t)NZIP_COMPRESS_READAHEAD)' "$C" || fail "$C does not allocate history + 256 KiB read-ahead window"
    grep -Fq 'base_offset=consumed-(unsigned long)history_len' "$C" || fail "$C does not preserve absolute back-reference offsets across windows"
    grep -Fq 'memmove(window,window+window_len-retain_len,retain_len)' "$C" || fail "$C does not retain bounded cross-window history"
    if grep -Eq 'read_whole_file[[:space:]]*\([[:space:]]*source' "$C"; then
        fail "$C still reads the entire source file before compression"
    fi
done

cmp -s "$ROOT/libc/apps/nzip.h" "$ROOT/kernel32/sh/nzip.h" || fail "libc/kernel-shell nzip.h copies differ"

echo "check_nzip_256k_readahead: PASS (256 KiB forward input window + <=128 KiB retained history)"
