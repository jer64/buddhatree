#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V69.12 release: FAIL: $*" >&2; exit 1; }
[ "$(cat VERSION)" = "69.12" ] || fail "VERSION mismatch"
grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.12"' kernel32/include/jtmos_release.h || fail "release header mismatch"
grep -Fq 'Current release: **V69.12**.' VERSIONING.md || fail "VERSIONING mismatch"
grep -Fq '#define GRAOS_VERSION "V55"' libc/apps/gui/graos.h || fail "GraOS version mismatch"
[ -f RELEASE-V69.12.txt ] || fail "release notes missing"
./tools/check_graos_v55_startup_recovery.sh
echo 'V69.12 release: PASS'
