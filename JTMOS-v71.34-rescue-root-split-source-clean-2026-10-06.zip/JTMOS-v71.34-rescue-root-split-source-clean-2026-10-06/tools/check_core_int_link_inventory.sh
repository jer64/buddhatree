#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-core-int-generated-$$
trap 'rm -f "$TMP"' EXIT HUP INT TERM
fail(){ echo "check_core_int_link_inventory: FAIL: $*" >&2; exit 1; }

# Generate the link inventory without polluting the source tree with generated.mak.
(
    cd "$ROOT/kernel32"
    ./autogen.pl
) > "$TMP"

for obj in \
    core/int/threads.o \
    core/int/pit.o \
    core/int/debug.o \
    core/int/logging.o \
    core/int/llint.o \
    core/int/llexc.o
do
    grep -Fq "$obj" "$TMP" || fail "$obj missing from generated kernel link"
done

# Historical mirrors must be physically absent from the release tree.
for d in chiplevel iodma lowlevel; do
    [ ! -e "$ROOT/kernel32/core/$d" ] || fail "retired kernel32/core/$d exists"
done

# Historical mirrors must remain excluded, while canonical core/int must not be.
if grep -Eq '^[[:space:]]*return if \$rel =~ m\{\^core/\(\?:int\|' "$ROOT/kernel32/autogen.pl"; then
    fail "autogen.pl still excludes canonical core/int"
fi

SCS="$ROOT/kernel32/core/int/scs.c"
if grep -Eq '^[[:space:]]*#[[:space:]]*s2[[:space:]]*=' "$SCS"; then
    fail "invalid '# s2 = ...' directive returned to scs.c"
fi
grep -Fq 's2 = workdir;' "$SCS" || fail "exec workdir pass-through missing"
if grep -Eq 'jtmfs_GetCWD[[:space:]]*\([[:space:]]*s2' "$SCS"; then
    fail "scall_cexec still rewrites workdir through textual CWD"
fi

echo 'check_core_int_link_inventory: PASS (canonical core/int linked + exact workdir contract)'
