#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
SQA="$ROOT/kernel32/sh/sqa.c"
SQAH="$ROOT/kernel32/sh/sqa.h"
DFA="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.31 SQA bounded stream only: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.31|69.32|69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
! grep -Fq 'SQA_MEMBER_STAGE_MAX' "$SQAH" || fail "whole-member stage cap remains"
! grep -Fq 'malloc((size_t)e->length)' "$SQA" || fail "whole-member allocation remains"
! grep -Fq 'read_exact(fd,stage' "$SQA" || fail "staged source read remains"
! grep -Fq 'write_exact(outfd,stage' "$SQA" || fail "staged destination write remains"
grep -Fq 'read_exact(fd,buffer,chunk)' "$SQA" || fail "bounded source read missing"
grep -Fq 'write_exact(outfd,buffer,chunk)' "$SQA" || fail "bounded destination write missing"
grep -Fq 'sqa: bounded stream for %s (%u-byte chunks; EOF at close)' "$SQA" || fail "runtime path diagnostic missing"
grep -Fq 'O_TRUNC|O_JTMOS_BATCH' "$SQA" || fail "batch output missing"
grep -Fq 'jtmfs_SetSizeAfterWrite(dnr,staged_name,max_offset,db)' "$DFA" || fail "single close-time EOF commit missing"

python3 - <<'PY' || fail "bounded stream model failed"
for length in (966148, 9 * 1024 * 1024 + 317):
    capacity = 128 * 1024
    remaining = length
    reads = writes = committed = 0
    while remaining:
        amount = min(capacity, remaining)
        assert 0 < amount <= capacity
        remaining -= amount
        reads += 1
        writes += 1
        assert committed == 0
    committed = length
    assert reads == writes and committed == length
PY

echo "V69.31 SQA bounded stream only: PASS"
