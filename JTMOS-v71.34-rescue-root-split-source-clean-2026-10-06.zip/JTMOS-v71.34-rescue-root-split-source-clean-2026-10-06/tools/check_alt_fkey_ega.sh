#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
KEY="$ROOT/kernel32/drivers/keyboard/keyb.c"
TERM="$ROOT/kernel32/drivers/term/term.c"
VGA="$ROOT/kernel32/drivers/vga/vga.c"
EGA="$ROOT/kernel32/drivers/ega/ega.c"
fail(){ echo "check_alt_fkey_ega: FAIL: $*" >&2; exit 1; }

grep -Fq 'scancode < SCODE_F1 || scancode > SCODE_F7' "$KEY" || fail 'F1..F7 raw scan range missing'
grep -Fq 'kbstr.ktab[SCODE_LEFTALT]' "$KEY" || fail 'Left Alt guard missing'
grep -Fq 'SwitchEgaFunctionTerminal(function_key)' "$KEY" || fail 'terminal hotkey dispatch missing'
grep -Fq 'if(!was_down)' "$KEY" || fail 'edge-trigger guard missing'
grep -Fq 'if(!VgaEgaTextConsoleActive())' "$KEY" || fail 'text-mode guard missing'
grep -Fq 'EgaSelectFunctionWindow(function_key)' "$TERM" || fail 'term -> EGA selection missing'
grep -Fq 'SetInputTerminal(which)' "$TERM" || fail 'keyboard focus switch missing'
grep -Fq 'return dispadmin_getcurrentmode()==MODE03H;' "$VGA" || fail 'VGA text mode gate missing'
grep -Fq 'if(vesa_enabled)' "$VGA" || fail 'VESA exclusion missing'
grep -Fq 'EgaSelectWindow(which);' "$EGA" || fail 'EgaSelectWindow call missing'
grep -Fq 'which=function_key-1;' "$EGA" || fail 'F-key to zero-based EGA mapping missing'
# F4 must be consumed by the new raw hotkey before the old generic terminal/scan path.
new_line=$(grep -n 'keyb_handle_alt_function_terminal((BYTE)sc,was_down)' "$KEY" | head -1 | cut -d: -f1)
old_line=$(grep -n 'keyb_handle_terminal_hotkey((BYTE)sc,was_down)' "$KEY" | head -1 | cut -d: -f1)
[ "$new_line" -lt "$old_line" ] || fail 'Alt+F-key handler ordering is wrong'

echo 'PASS: Left Alt + F1..F7 selects EGA VT0..VT6 via EgaSelectWindow; GraOS Alt+F4 preserved outside text mode'
