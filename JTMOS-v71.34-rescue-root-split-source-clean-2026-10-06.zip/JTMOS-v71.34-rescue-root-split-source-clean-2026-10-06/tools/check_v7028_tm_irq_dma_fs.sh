#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V70.28 tm/irq/dma/fs: FAIL: $*" >&2; exit 1; }
[ "$(cat "$ROOT/VERSION")" = "70.28" ] || fail VERSION
grep -q 'GUI_APPS := terminal tm ' "$ROOT/libc/apps/gui/Makefile" || fail "tm not built"
grep -q 'GRAOS_WINDOW_TERMINAL_MONITOR' "$ROOT/libc/libc/include/jtmos/graosprotocol.h" || fail "monitor ABI missing"
grep -q 'JKEY_ALT_F1' "$ROOT/libc/libc/include/jtmos/console.h" || fail "Alt+Fn ABI missing"
grep -q 'guiTerminalMonitorHotkey' "$ROOT/libc/apps/gui/guiLoop.c" || fail "GraOS hotkey routing missing"
grep -q 'OutputTerminalKeyboardBuffer(ter' "$ROOT/libc/apps/gui/tm.c" || fail "tm keyboard/command injection missing"
grep -q 'channel==4' "$ROOT/kernel32/core/int/dma.c" || fail "DMA cascade guard missing"
grep -q 'address&0xffff0000UL' "$ROOT/kernel32/core/int/dma.c" || fail "DMA boundary guard missing"
grep -q 'local=(DMA_channel>=4)' "$ROOT/kernel32/core/int/dma.c" || fail "DMA local channel select missing"
grep -q 'pic_spurious_irq7' "$ROOT/kernel32/core/int/int.c" || fail "PIC IRQ7 spurious accounting missing"
grep -q 'pic_spurious_irq15' "$ROOT/kernel32/core/int/int.c" || fail "PIC IRQ15 spurious accounting missing"
grep -q 'apic_set_legacy_irq_mask' "$ROOT/kernel32/core/int/int.c" || fail "APIC mask backend missing"
grep -q 'jtmfs_check_device_locked' "$ROOT/kernel32/fs/jtmfs/jtmfsIntegrity.c" || fail "physical fsck engine missing"
grep -q 'check_apply_media_geometry' "$ROOT/kernel32/fs/jtmfs/jtmfsIntegrity.c" || fail "media-derived fsck geometry missing"
grep -q 'JtmfsDbRecover' "$ROOT/kernel32/fs/jtmfs/jtmfsDb.c" || fail "WAL recovery missing"
echo "V70.28 tm/irq/dma/fs regression: PASS"
