#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v6956_device_exec_resolution: FAIL: $*" >&2; exit 1; }
CP="$ROOT/kernel32/core/cp/centralprocess.c"
SH="$ROOT/kernel32/sh/sh.c"
SQ="$ROOT/libc/apps/sqsh.c"
ENV="$ROOT/kernel32/core/environment/envint.c"
PATHSRC="$ROOT/kernel32/fs/jtmfs/jtmfsPath.c"

grep -Fq 'sprintf(devbin,"%s:/bin/%s",devname,fname)' "$CP" || fail 'active-device /bin probe missing'
grep -Fq 'Exec resolver: active-device /bin match' "$CP" || fail 'active-device resolver diagnostic missing'
grep -Fq 'centralprocess_exec("unique.bin",command' "$SH" || fail 'SMSH Unique still uses rooted executable path'
! grep -Fq 'centralprocess_exec("/bin/unique.bin"' "$SH" || fail 'SMSH Unique still hard-codes namespace /bin'
grep -Fq '"unique.bin %s",s' "$SQ" || fail 'SQSH direct .uni launch is not device-neutral'
grep -Fq '"unique.bin %s",path' "$SQ" || fail 'SQSH boot Unique launch is not device-neutral'
grep -Fq 'ksetglobalenv("UNIQUE","unique.bin",1)' "$ENV" || fail 'UNIQUE environment remains namespace-rooted'
grep -Fq 'ksetglobalenv("SCRIPT","unique.bin",1)' "$ENV" || fail 'SCRIPT environment remains namespace-rooted'
# Do not change the documented leading-/ namespace semantics globally; explicit device paths remain the unambiguous syntax.
grep -Fq 'legacy_namespace_absolute=(path[0]=='"'"'/'"'"')' "$PATHSRC" || fail 'legacy / namespace semantics changed unexpectedly'
grep -Fq "strchr(fname,':')!=NULL" "$CP" || fail 'explicit device-qualified exec path recognition missing'

echo 'check_v6956_device_exec_resolution: PASS (CWD -> active-device:/bin -> PATH; explicit device paths retained)'
