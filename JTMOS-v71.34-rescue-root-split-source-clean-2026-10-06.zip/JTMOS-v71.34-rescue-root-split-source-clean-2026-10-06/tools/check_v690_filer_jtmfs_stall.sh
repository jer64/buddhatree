#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
fail(){ echo "V69.0 filer/JTMFS stall fix: FAIL: $*" >&2; exit 1; }

grep -Fq 'JTMFS_TRACE_VERBOSE' "$ROOT/kernel32/fs/jtmfs/jtmfs.h" || fail "verbose JTMFS trace gate missing"
grep -Fq '#define DIRDB_WRITE_RETRY 310' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdbAccess.h" || fail "DIRDB retry code missing"
grep -Fq 'else if(wr==DIRDB_WRITE_RETRY)' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdbAccess.c" || fail "transient DIRDB retry handling missing"
grep -Fq 'JTMFS_FIND_SNAPSHOT_MAX' "$ROOT/kernel32/fs/jtmfs/fsdos.c" || fail "stable find snapshot missing"
grep -Fq 'find_snapshot' "$ROOT/kernel32/fs/filedes.h" || fail "descriptor snapshot fields missing"
grep -Fq 'fd_release_private(f);' "$ROOT/kernel32/fs/filedes.c" || fail "snapshot cleanup missing"
grep -Fq 'Sleep(25);' "$ROOT/libc/apps/filer.c" || fail "filer poll rate not reduced"
grep -A4 -F '#ifdef JTMFS_TRACE_VERBOSE' "$ROOT/kernel32/fs/jtmfs/jtmfs.h" | grep -Fq '#define JTMFSDEBUG' || fail "JTMFSDEBUG is not verbose-only"
echo "V69.0 filer/JTMFS stall fix: PASS"
