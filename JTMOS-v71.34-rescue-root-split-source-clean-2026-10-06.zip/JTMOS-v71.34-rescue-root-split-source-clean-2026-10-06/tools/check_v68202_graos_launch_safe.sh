#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
fail(){ echo "V68.202 GraOS launch safety: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=202){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.202"
[ -f "$ROOT/RELEASE-V68.202.txt" ] || fail "release note missing"
SH="$ROOT/kernel32/sh/sh.c"
SQ="$ROOT/libc/apps/sqsh.c"
SC="$ROOT/kernel32/core/int/scs.c"
VE="$ROOT/kernel32/init/vesa.c"
GS="$ROOT/kernel32/sh/graos_shell.c"

grep -Fq 'if(!strcmp(base,"graos.bin"))' "$SH" || fail "SMSH does not recognize direct graos.bin"
grep -Fq "routing '%s' through the GraOS service launcher" "$SH" || fail "SMSH safe-route diagnostic missing"
grep -Fq 'return graos_shell_try_command("graos",1,gargv);' "$SH" || fail "SMSH direct graos.bin bypasses service launcher"
grep -Fq 'if(!strcmp(base,"graos.bin"))' "$SQ" || fail "SQSH does not recognize direct graos.bin"
grep -Fq 'return test ? 0 : sqsh_graos_command();' "$SQ" || fail "SQSH direct graos.bin bypasses GraOS bridge"

grep -Fq '/* 124 scall_graosgraphics                - long physical display transition; internal lock protects handoff */ SCALL_IRQ_ON,' "$SC" || fail "SYS_graosgraphics still globally IRQ-off"
grep -Fq 'static volatile int vesa_graos_transition = 0;' "$VE" || fail "GraOS display transition lock missing"
grep -Fq 'if(!vesa_graos_transition_begin())' "$VE" || fail "GraOS transition is not serialized"
grep -Fq 'vesa_graos_transition_end();' "$VE" || fail "GraOS transition lock is not released"
# Existing service launch contract must remain: private terminal + SERVICE bit.
grep -Fq 'ter=NewTerminal();' "$GS" || fail "GraOS private terminal allocation missing"
grep -Fq 'THREAD_TYPE_SERVICE' "$GS" || fail "GraOS SERVICE capability missing"
grep -Fq 'SetTerminalOwner(ter,pid)' "$GS" || fail "GraOS terminal ownership transfer missing"

echo "V68.202 GraOS launch safety regression: PASS"
