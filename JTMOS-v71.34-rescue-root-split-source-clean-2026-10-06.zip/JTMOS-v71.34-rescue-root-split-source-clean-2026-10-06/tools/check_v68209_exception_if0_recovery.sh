#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.209 IF=0 exception recovery: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.209|68.210|68.211|68.212|68.213|68.214|68.215|68.216|68.217|68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|7[0-9].*) ;; *) fail "VERSION is not V68.209-compatible" ;; esac
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"

# Runtime stubs must preserve the actual CPU frame before emergency-stack use.
grep -Fq '%macro SAFE_LIVE_NOERR 1' "$ROOT/kernel32/core/int/exc.mac" || fail "no-error live-frame macro missing"
grep -Fq '%macro SAFE_LIVE_ERR 1' "$ROOT/kernel32/core/int/exc.mac" || fail "error-code live-frame macro missing"
grep -Fq 'mov [exception_frame_eflags],eax' "$ROOT/kernel32/core/int/exc.mac" || fail "live EFLAGS is not captured"
grep -Fq 'SAFE_LIVE_NOERR exception_6' "$ROOT/kernel32/core/int/exc.inc" || fail "#UD does not capture no-error frame"
grep -Fq 'SAFE_LIVE_ERR exception_12' "$ROOT/kernel32/core/int/exc.inc" || fail "#SS does not capture error-code frame"
grep -Fq 'SAFE_LIVE_ERR exception_17' "$ROOT/kernel32/core/int/exc.inc" || fail "#AC does not capture error-code frame"
# Catastrophic entries must not depend on a possibly damaged ordinary stack.
grep -Fq 'SAFE exception_8' "$ROOT/kernel32/core/int/exc.inc" || fail "#DF no longer uses fail-closed SAFE entry"
grep -Fq 'SAFE exception_18' "$ROOT/kernel32/core/int/exc.inc" || fail "#MC no longer uses fail-closed SAFE entry"

# IF=0 must be an isolation policy for ordinary non-zero tasks, not global halt.
grep -Fq 'int EXCEPTION_RECOVER_IF0_NONZERO_PID= 1;' "$ROOT/kernel32/init/keropt.c" || fail "IF=0 recovery policy disabled"
grep -Fq 'live_authoritative && !(live_eflags&0x200U)' "$ROOT/kernel32/core/cp/gpf.c" || fail "recovery does not use authoritative fault-time IF"
grep -Fq 'ThreadQuarantineFromException(pid);' "$ROOT/kernel32/core/cp/gpf.c" || fail "exception does not quarantine process"
! grep -A80 -F '/* V68.209 recovery policy:' "$ROOT/kernel32/core/cp/gpf.c" | grep -Fq 'KillThreadEx(pid,KT_NO_THREAD_SWITCH);' || fail "full teardown still runs in exception context"
grep -Fq 'enable();' "$ROOT/kernel32/core/cp/gpf.c" || fail "IRQ restoration missing"
grep -Fq '? IdleThread.pid : 0;' "$ROOT/kernel32/core/cp/gpf.c" || fail "recovery does not prefer CPU_IDLE"
grep -Fq 'FATALEXCEPTION("(18) machine check")' "$ROOT/kernel32/core/int/exception.c" || fail "machine check no longer explicitly fatal"
grep -Fq 'FATALEXCEPTION("(08) double fault exception")' "$ROOT/kernel32/core/int/exception.c" || fail "double fault no longer explicitly fatal"
grep -Fq 'task_immortal' "$ROOT/kernel32/core/cp/gpf.c" || fail "immortal task protection missing"

grep -Fq 'void ThreadQuarantineFromException(int pid)' "$ROOT/kernel32/core/int/threads.c" || fail "exception quarantine helper missing"
grep -Fq 'ThreadReapQuarantined();' "$ROOT/kernel32/core/int/IdleThread.c" || fail "deferred teardown reaper missing"

echo "V68.209 IF=0 exception containment regression: PASS"
