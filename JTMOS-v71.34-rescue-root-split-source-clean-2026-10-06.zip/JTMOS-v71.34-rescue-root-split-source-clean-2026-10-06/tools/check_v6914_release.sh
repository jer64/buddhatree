#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V69.14 release: FAIL: $*" >&2; exit 1; }

[ "$(cat VERSION)" = "69.14" ] || fail "VERSION mismatch"
grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.14"' kernel32/include/jtmos_release.h || fail "release header mismatch"
grep -Fq 'Current release: **V69.14**.' VERSIONING.md || fail "VERSIONING mismatch"
grep -Fq '#define GRAOS_VERSION "V56"' libc/apps/gui/graos.h || fail "GraOS version changed unexpectedly"
[ -f RELEASE-V69.14.txt ] || fail "release notes missing"
sh ./tools/check_v6914_hdbench.sh
echo 'V69.14 release: PASS'
