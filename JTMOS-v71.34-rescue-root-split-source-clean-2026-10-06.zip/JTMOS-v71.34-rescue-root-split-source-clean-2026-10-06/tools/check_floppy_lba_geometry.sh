#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_floppy_lba_geometry: FAIL: $*" >&2; exit 1; }
B=boot32pm/bootmod.inc

grep -Fq 'FLOPPY_KERNEL_LBA         equ 36' "$B" || fail "kernel LBA36 constant missing"
grep -Fq 'stream_floppy_detect_geometry:' "$B" || fail "BIOS geometry query missing"
grep -Fq 'stream_floppy_lba_to_chs:' "$B" || fail "LBA-to-CHS routine missing"
grep -Fq 'and bl,0x3F' "$B" || fail "AH=08 sectors/track mask missing"
grep -Fq 'and ah,0x03' "$B" || fail "high cylinder bits are not bounded"
grep -Fq 'shl ah,6' "$B" || fail "high cylinder bits are not encoded into CL"

# Reference 1.44 MiB geometry: 18 sectors/track, 2 heads, 80 cylinders.
# Verify all critical boundaries around the kernel start and head/cylinder wraps.
check_lba() {
  lba=$1 exp_c=$2 exp_h=$3 exp_s=$4
  s=$((lba % 18 + 1))
  q=$((lba / 18))
  h=$((q % 2))
  c=$((q / 2))
  [ "$c" -eq "$exp_c" ] || fail "LBA$lba cylinder=$c expected=$exp_c"
  [ "$h" -eq "$exp_h" ] || fail "LBA$lba head=$h expected=$exp_h"
  [ "$s" -eq "$exp_s" ] || fail "LBA$lba sector=$s expected=$exp_s"
}
check_lba 36   1 0 1
check_lba 53   1 0 18
check_lba 54   1 1 1
check_lba 71   1 1 18
check_lba 72   2 0 1
check_lba 2879 79 1 18

echo 'check_floppy_lba_geometry: PASS (LBA36 source + 18x2 CHS boundary arithmetic)'
