#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

for f in "$ROOT/boot32pm/boot.asm" "$ROOT/boot32pm/dosboot.asm"; do
    grep -Eq '^%define[[:space:]]+BOOT_VESA_GRAPHICS[[:space:]]+0' "$f"
    grep -q '0x4F00' "$f"
    grep -q '0x4F01' "$f"
    grep -q '0x4F02' "$f"
    grep -q 'VideoModePtr' "$f"
    grep -q 'GRAOS_VESA_WIDTH 1024' "$f"
    grep -q 'GRAOS_VESA_HEIGHT 768' "$f"
    grep -q 'GRAOS_VESA_SAFE_WIDTH 640' "$f"
    grep -q 'GRAOS_VESA_SAFE_HEIGHT 480' "$f"
    grep -q 'and ax,0x0091' "$f"
    grep -q 'cmp byte \[es:di+0x19\],32' "$f"
    grep -q 'cmp byte \[es:di+0x1B\],6' "$f"
done

grep -q '^select_vesa_resolution:' "$ROOT/boot32pm/boot.asm"
grep -q '^dos_select_vesa_resolution:' "$ROOT/boot32pm/dosboot.asm"
# 800x600/0x143 may remain documented for compatibility but must not be an
# active candidate in either normal selection chain.
! grep -q 'mov cx,GRAOS_VESA_FALLBACK_MODE' "$ROOT/boot32pm/boot.asm"
! grep -q 'mov cx,GRAOS_VESA_FALLBACK_MODE' "$ROOT/boot32pm/dosboot.asm"
! grep -q 'VESA 2.0 BIOS support not found' "$ROOT/boot32pm/text.inc"
echo "check_vesa32_boot_modes: PASS (BIOS mode-list enumeration)"
