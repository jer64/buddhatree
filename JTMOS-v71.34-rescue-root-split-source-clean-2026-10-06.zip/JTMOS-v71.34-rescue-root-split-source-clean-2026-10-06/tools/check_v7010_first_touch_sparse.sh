#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python3 tests/v7010_first_touch_sparse.py
make -s -C kernel32 syntax
printf '%s\n' 'V70.10 sparse first-touch source/syntax gate: PASS'
