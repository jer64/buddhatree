#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_tcpip_hardening: FAIL: $*" >&2; exit 1; }
UIP="$ROOT/kernel32/drivers/tcpip/uip.c"
UIPA="$ROOT/kernel32/drivers/tcpip/uip_arch.c"
UIPAH="$ROOT/kernel32/drivers/tcpip/uip_arch.h"
ARP="$ROOT/kernel32/drivers/tcpip/uip_arp.c"
MAIN="$ROOT/kernel32/drivers/tcpip/uipMain.c"
JNET="$ROOT/kernel32/drivers/tcpip/jnet.c"
HTTP="$ROOT/kernel32/drivers/tcpip/jt_httpd.c"

# IPv4/TCP/ICMP structural validation.
grep -Fq 'if(uip_len < 20)' "$UIP" || fail "short IPv4 guard missing"
grep -Fq 'BUF->ipoffset[1] != 0' "$UIP" || fail "low-byte IPv4 fragment offset guard missing"
grep -Fq 'if(uip_len < 40)' "$UIP" || fail "short TCP guard missing"
grep -Fq 'if(c < 20 || c > uip_len - 20)' "$UIP" || fail "TCP data-offset bounds missing"
grep -Fq 'uip_parse_mss_option' "$UIP" || fail "bounded TCP option parser missing"
grep -Fq 'uip_icmpchksum() != 0xffff' "$UIP" || fail "ICMP checksum validation missing"
grep -Fq 'u16_t uip_icmpchksum(void);' "$UIPAH" || fail "ICMP checksum ABI missing"
grep -Fq 'reset sequence rejected' "$UIP" || fail "RST sequence hardening missing"
grep -Fq 'uip_flags = UIP_CONNECTED;' "$UIP" || fail "active-open false NEWDATA fix missing"

# ARP cache integrity and aging.
grep -Fq 'uip_ethernet_ipv4_safe_to_learn' "$MAIN" || fail "pre-learning IPv4 validation missing"
grep -Fq 'uip_arp_timer();' "$MAIN" || fail "ARP aging timer is not driven"
grep -Fq 'memset(arp_table, 0, sizeof(arp_table))' "$ARP" || fail "ARP table reset missing"
grep -Fq '(arp_table[i].ipaddr[0] | arp_table[i].ipaddr[1]) != 0' "$ARP" || fail "ARP half-zero address activity fix missing"
grep -Fq 'ARP_HWTYPE_ETH' "$ARP" || fail "ARP hardware type validation missing"
grep -Fq '!arp_ethaddr_equal(&BUF->ethhdr.src, &BUF->shwaddr)' "$ARP" || fail "ARP Ethernet/sender MAC consistency check missing"
grep -Fq 'if((ipaddr[0] | ipaddr[1]) == 0)' "$ARP" || fail "missing-gateway zero-MAC guard missing"

# JNET UDP framing and zero-length datagrams.
grep -Fq 'int rx_pending;' "$JNET" || fail "UDP pending flag missing"
grep -Fq 'if(!socks[i].rx_pending)' "$JNET" || fail "zero-length UDP receive state missing"
grep -Fq 'socks[i].rx_pending=1' "$JNET" || fail "zero-length UDP queue state missing"
grep -Fq 'ulen!=total-ihl' "$JNET" || fail "UDP/IP length consistency guard missing"
grep -Fq 'udp_checksum_valid(ip,udp,ulen)' "$JNET" || fail "nonzero UDP checksum validation missing"

# HTTP request-line reassembly.
grep -Fq 'JT_HTTP_REQUEST_LINE_MAX' "$HTTP" || fail "HTTP request line buffer missing"
grep -Fq 'http_collect_request_line' "$HTTP" || fail "HTTP request line collector missing"
grep -Fq '400 Bad Request' "$HTTP" || fail "malformed request response missing"

TMP=${TMPDIR:-/tmp}/jtmos-http-tests-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
CC=${CC:-cc}
CFLAGS='-std=gnu89 -D_GNU_SOURCE -Wall -Wextra -Wno-unused-function -Wno-unused-variable'
$CC $CFLAGS -I"$ROOT/tests/httpd_stubs" -I"$ROOT/kernel32/drivers/tcpip" "$ROOT/tests/jt_httpd_stream_test.c" -o "$TMP/stream"
"$TMP/stream" >/dev/null
$CC $CFLAGS -I"$ROOT/tests/httpd_stubs" -I"$ROOT/kernel32/drivers/tcpip" "$ROOT/tests/jt_httpd_policy_test.c" -o "$TMP/policy"
"$TMP/policy" >/dev/null

echo "check_tcpip_hardening: PASS (IPv4/TCP/ICMP bounds + RST + ARP aging/integrity + UDP zero-length/checksum + fragmented HTTP request)"
