#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.220 JTMFS DB: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|70.*) ;; *) fail "VERSION mismatch" ;; esac

DBH="$ROOT/kernel32/fs/jtmfs/jtmfsDb.h"
DBC="$ROOT/kernel32/fs/jtmfs/jtmfsDb.c"
IDX="$ROOT/kernel32/fs/jtmfs/diskcache/jtmfsIndex.c"
FAT="$ROOT/kernel32/fs/jtmfs/jtmfat.c"
ADD="$ROOT/kernel32/fs/jtmfs/fsaddblocks.c"
DIRDB="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbAccess.c"
JTMFS="$ROOT/kernel32/fs/jtmfs/jtmfs.c"

[ -s "$DBH" ] && [ -s "$DBC" ] || fail "V4 metadata core missing"
[ -s "$IDX" ] || fail "B+tree index missing"
grep -Eq '^#define JTMFS_DB_LAYOUT_VERSION[[:space:]]+4(UL)?$' "$DBH" || fail "V4 layout marker missing"
grep -Fq 'JTMFS_DB_FEATURE_REDO' "$DBH" || fail "redo feature missing"
grep -Fq 'JTMFS_DB_FEATURE_MIRROR_SUPER' "$DBH" || fail "mirrored super feature missing"
grep -Fq 'JTMFS_DB_FEATURE_BTREE_NAMES' "$DBH" || fail "B+tree feature missing"
grep -Fq 'JTMFS_DB_FEATURE_EXTENTS' "$DBH" || fail "extent feature missing"
grep -Fq 'JTMFS_DB_FEATURE_OBJECT_IDS' "$DBH" || fail "object-id feature missing"
# Reserved migration features must not be advertised by the format path yet.
! grep -A12 'st->super.features=' "$DBC" | grep -Fq 'JTMFS_DB_FEATURE_TAIL_PACKING' || fail "tail packing advertised before implementation"
! grep -A12 'st->super.features=' "$DBC" | grep -Fq 'JTMFS_DB_FEATURE_OBJECT_TREE' || fail "object tree advertised before implementation"

grep -Fq 'db_write_block_verified' "$DBC" || fail "verified metadata write missing"
grep -Fq 'JtmfsDbPrepareDirent' "$JTMFS" || fail "directory mutation does not prepare redo"
grep -Fq 'flexFlushFATChecked(device_nr) || driver_FlushDrive(device_nr)!=0' "$JTMFS" || fail "FAT prerequisite is not drained after redo"
grep -Fq 'db_entry_replayable' "$DBC" || fail "recovery does not validate FAT chain before replay"
grep -Fq 'JtmfsDbCommitDirent' "$JTMFS" || fail "directory mutation does not commit redo"
grep -Fq 'JtmfsDbRecover(dnr)' "$DIRDB" || fail "directory access does not recover redo"
grep -Fq 'jtmfs_WriteFileChain((BYTE*)&rec.entry' "$DBC" || fail "redo replay missing"

grep -Fq '#define JTMFS_INDEX_FANOUT 16' "$IDX" || fail "balanced index fanout missing"
grep -Fq 'while(count>1)' "$IDX" || fail "multi-level B+tree build missing"
grep -Fq 'prev->next=leaf' "$IDX" || fail "linked B+tree leaves missing"
grep -Fq 'jtmfs_index_lookup' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdbFind.c" || fail "lookup is not using B+tree"
grep -Fq 'jtmfs_mutation_lock(dnr)' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdbFind.c" || fail "B+tree lookup is not serialized with metadata writers"
grep -Fq 'jtmfs_mutation_trylock(dnr)' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdbFind.c" || fail "atomic B+tree lookup lacks nonblocking fallback"
grep -Fq 'LockWaitCanYield(flags)' "$DIRDB" || fail "recovery can busy-wait in atomic context"
grep -Fq 'MAX_CACHED_FILE_SIZE' "$ROOT/kernel32/fs/jtmfs/diskcache/dirdb.h" || fail "dynamic large directory ceiling missing"
grep -Fq 'dirdb_ensureBuffer' "$DIRDB" || fail "directory buffer growth missing"

grep -Fq 'int jtmfat_reserve_extent' "$FAT" || fail "extent allocator missing"
grep -Fq 'if(want>64) want=64' "$FAT" || fail "allocator lock hold bound missing"
grep -Fq 'jtmfat_reserve_extent(device_nr,request' "$ADD" || fail "write preallocation does not use extents"
# Extents must remain normal FAT chains, not a new reservation state.
grep -Fq 'v=0xFFFFFFF8UL' "$FAT" || fail "extent EOC publication missing"

grep -Fq 'DWORD JtmfsDbAllocObjectId' "$DBC" || fail "dynamic object-ID allocator missing"
python3 "$ROOT/tests/jtmfs_db_v68220.py"
echo "V68.220 JTMFS database filesystem regression: PASS"
