#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-unz-test.$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/include/jtmos"
cat > "$TMP/include/jtmos/types.h" <<'HDR'
#ifndef JTMOS_TYPES_H
#define JTMOS_TYPES_H
#include <stdint.h>
typedef uint8_t BYTE; typedef uint16_t WORD; typedef uint32_t DWORD;
#endif
HDR
cat > "$TMP/include/jtmos/dirtype.h" <<'HDR'
#ifndef JTMOS_DIRTYPE_H
#define JTMOS_DIRTYPE_H
#endif
HDR
cat > "$TMP/include/jtmos/filefind.h" <<'HDR'
#ifndef JTMOS_FILEFIND_H
#define JTMOS_FILEFIND_H
#include <stdint.h>
#include <stddef.h>
typedef struct { uint32_t _ff_reserved[5]; uint32_t ff_attrib,ff_ftime,ff_fdate,ff_fsize; char ff_name[260]; } FFBLK;
int findfirst(const char *,FFBLK *); int findnext(int,FFBLK *);
#endif
HDR

cc -std=gnu89 -O2 -DUNCOMPRESS_ALL -DJTMOS_APPLICATION=1 -Dmain=unz_source_main \
  -I"$TMP/include" -I"$ROOT/libc/apps" \
  -c "$ROOT/libc/apps/nzipMain.c" -o "$TMP/nzipMain.o"
cc -std=gnu89 -O2 -I"$TMP/include" \
  -c "$ROOT/tests/unz_noarg_test.c" -o "$TMP/test.o"
cc "$TMP/nzipMain.o" "$TMP/test.o" -o "$TMP/unz_noarg_test"
"$TMP/unz_noarg_test"

grep -q 'A2KRange(scall_ecx,(DWORD)sizeof(kff))' "$ROOT/kernel32/core/int/scs.c"
grep -q 'scall_copyin_string(scall_ebx,path,sizeof(path))' "$ROOT/kernel32/core/int/scs.c"
grep -q 'declared==(DWORD)sizeof(FFBLK)' "$ROOT/kernel32/core/int/scs.c"
grep -q 'sizeof(\*f)' "$ROOT/libc/libc/modern/jtmos_extra.c"
grep -q 'static FFBLK unz_ffblk' "$ROOT/libc/apps/nzipMain.c"
grep -q 'close(fd)' "$ROOT/libc/apps/nzipMain.c"
grep -q 'EXCEPTION_HANDLER_ACTIVE=FALSE' "$ROOT/kernel32/core/cp/gpf.c"
grep -q 'PID-PTE=n/a' "$ROOT/kernel32/core/cp/gpf.c"

echo "check_unz_directory_abi: PASS"
