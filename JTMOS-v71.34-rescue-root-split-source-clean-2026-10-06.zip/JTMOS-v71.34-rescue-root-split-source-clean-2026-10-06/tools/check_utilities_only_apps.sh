#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APPS="$ROOT/libc/apps"
BUILD="$ROOT/tools/build_install_image.sh"
fail(){ echo "check_utilities_only_apps: FAIL: $*" >&2; exit 1; }

expected="bwbasic cbmvm cwdtest fsregress float_test fpuhard fputest linuxcore10 mp3 otest runner sscanf_test mmdemand jtmfsbench wintest wintest2 wintest3 wtest"
actual=$(make --no-print-directory -s -C "$APPS" list-utilities | tr '\n' ' ' | sed 's/[[:space:]]*$//')
[ "$actual" = "$expected" ] || fail "unexpected utilities-only list: $actual"

grep -q 'UTILITIES_ONLY_APPS :=' "$APPS/Makefile" || fail "utilities-only class missing"
grep -q 'utilities-only .* missing from full CD payload' "$BUILD" || fail "full-CD presence gate missing"
grep -q 'utilities-only .* leaked into sys: payload' "$BUILD" || fail "sys exclusion gate missing"
for app in $expected; do
    grep -qw "$app" "$APPS/Makefile" || fail "$app not registered"
done

echo "check_utilities_only_apps: PASS ($expected are utilities.iso-only)"
