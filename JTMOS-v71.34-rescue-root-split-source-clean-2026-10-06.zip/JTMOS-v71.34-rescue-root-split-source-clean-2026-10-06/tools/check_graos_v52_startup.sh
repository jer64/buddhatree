#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
need(){ grep -F "$2" "$ROOT/$1" >/dev/null || { echo "FAIL: $1 missing: $2" >&2; exit 1; }; }
case "$(cat "$ROOT/VERSION")" in 69.9|69.[1-9][0-9]*) ;; *) echo 'FAIL: VERSION predates 69.9' >&2; exit 1;; esac
grep -Eq '#define GRAOS_VERSION "V(52|5[3-9]|[6-9][0-9])"' "$ROOT/libc/apps/gui/graos.h" || { echo 'FAIL: GraOS version predates V52' >&2; exit 1; }
need kernel32/drivers/vga/vboxbga.c 'active VESA console preserved'
need kernel32/drivers/vga/vboxbga.c 'VBoxBgaFramebufferMapped'
need kernel32/mm/paging.c 'identity mapping VBox/BGA future LFB'
need kernel32/init/vesa.c 'VBoxBgaFramebufferMapped()'
need kernel32/init/initsystem.c 'vesa_width!=GRAOS_VESA_WIDTH'
need make_hd_jtmos.sh 'JTMOS_HDD_MB:-512'
echo 'check_graos_v52_startup: PASS'
