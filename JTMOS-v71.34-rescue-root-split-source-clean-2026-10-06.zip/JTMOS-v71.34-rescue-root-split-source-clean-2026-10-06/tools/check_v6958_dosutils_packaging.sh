#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.58 DOSUTILS: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

has 'utilities.iso: packages host-tools' "$ROOT/Makefile" 'utilities.iso is not a first-class file target'
has 'utilscdrom: host-tools' "$ROOT/Makefile" 'utilscdrom standalone publisher target missing'
has './tools/publish_utilities_iso.sh' "$ROOT/Makefile" 'utilities.iso is not published by the transactional helper'
has 'UTILS ?= 1' "$ROOT/boot32pm/Makefile" 'plain boot32pm make does not default to full UTILS packaging'
has '$(MAKE) $(LOCAL_DOS_PACKAGE)' "$ROOT/boot32pm/Makefile" 'modern target does not sequence DOS packaging after BIOS build'
has 'building repository utilities.iso' "$ROOT/boot32pm/Makefile" 'full DOS package does not auto-build missing root utilities.iso'
has 'BOOT_DISPLAY=$(if $(filter 1,$(VESA)),vesa,text)' "$ROOT/boot32pm/Makefile" 'auto-build does not preserve loader display profile'
has 'dosboot.full.tmp' "$ROOT/boot32pm/Makefile" 'full DOS package lacks transactional staging'
has 'cp ../utilities.iso dosboot.full.tmp/utils.iso' "$ROOT/boot32pm/Makefile" 'full DOS package does not copy root ISO as utils.iso'

# Critical regression: full must not depend on minimal, because minimal commits a
# two-file directory before utilities media has been validated.
if grep -Eq '^dos-package-full:[[:space:]]+dos-package([[:space:]]|$)' "$ROOT/boot32pm/Makefile"; then
    fail 'dos-package-full still commits minimal package first'
fi

# Source-clean parse check: GNU make must accept both Makefiles without executing
# recipes.  Explicit UTILS values must remain legal.
make -s -C "$ROOT/boot32pm" -pn UTILS=0 --eval='__parsecheck: ; @:' __parsecheck >/dev/null
make -s -C "$ROOT/boot32pm" -pn UTILS=1 --eval='__parsecheck: ; @:' __parsecheck >/dev/null
make -s -C "$ROOT" -pn --eval='__parsecheck: ; @:' __parsecheck >/dev/null

echo 'V69.58 DOSUTILS packaging: PASS'
