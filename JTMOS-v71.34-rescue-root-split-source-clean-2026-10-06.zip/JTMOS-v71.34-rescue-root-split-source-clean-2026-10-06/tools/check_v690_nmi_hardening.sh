#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.0 NMI hardening: FAIL: $*" >&2; exit 1; }
C="$ROOT/kernel32/core/int/nmi.c"
H="$ROOT/kernel32/core/int/nmi.h"
A="$ROOT/kernel32/sh/nmiapp.c"
S="$ROOT/kernel32/core/int/nmi_source.c"

grep -Fq 'JTMOS_NMI_RESCUE_WRITING' "$H" || fail "internal rescue publication state missing"
grep -Fq '__sync_bool_compare_and_swap(&r->active' "$C" || fail "NMI rescue slot is not atomically reserved"
grep -Fq '__sync_bool_compare_and_swap(&nmi_rescue_prompt_claimed[i],0U,1U)' "$C" || fail "rescue prompt claim is not atomic against NMI"
grep -Fq 'source==0U && periodic_event' "$C" || fail "watchdog does not require an owned PMU NMI"
grep -Fq 'nmi_watchdog_unowned_skipped' "$C" || fail "unowned NMI skip accounting missing"
if grep -Fq 'if(!software_test && source==0U)' "$C"; then
    fail "generic unknown NMI can still drive watchdog rescue"
fi
grep -Fq 'external/unknown' "$C" || fail "unknown NMI diagnostic label missing"
grep -Fq 'nmi_rescue_state_visible(r->active)' "$C" || fail "internal WRITING rescue state can leak to commands"
grep -Fq 'unowned-NMI-skipped=' "$A" || fail "NMI status does not expose skipped unowned events"
grep -Fq '(void)lapic[LAPIC_LVTPC/4U]' "$S" || fail "LVTPC posted-write readback missing"
grep -Fq 'lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_MASKED|LAPIC_LVT_NMI;' "$S" || fail "shutdown does not mask LVTPC before PMU restore"
grep -Fq 'nmi_wrmsr(MSR_IA32_PERF_GLOBAL_OVF,1U,0);' "$S" || fail "Intel shutdown does not clear pending overflow"

echo "V69.0 NMI ownership/publication hardening: PASS"
