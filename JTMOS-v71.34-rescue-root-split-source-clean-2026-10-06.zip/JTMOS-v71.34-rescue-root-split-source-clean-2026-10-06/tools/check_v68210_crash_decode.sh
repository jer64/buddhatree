#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-crash-decode-$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
cat > "$TMP/crash.log" <<'LOG'
================ JTMOS CRASH ANALYSIS V1 ================
CRASH-ID=7 TICK=12345 EXC=14 REASON=(14) page fault
PID=12 MAGIC=abcdef01 NAME=sqsh CMD=sqsh n ping TYPE=01 STATE=1 TERM=2 DNR=0 DB=0
LIVE authoritative=1 user=0 CS:EIP=0008:0011079a ERR=00000002 EFLAGS=00000002 IF=0 ENTRY_ESP=42e4c7a4 USER_SS:ESP=0000:00000000 CR2=00000020
SC seq=100 tick=12343 nr=5 ebx=00001000 ecx=00000000 edx=00000000 esi=00000000 edi=00000000 ebp=42e4c7b0
SW seq=101 tick=12344 3->12
LK seq=102 tick=12344 action=WAIT pid=12 owner=4 lock=00102030 at=sys_open fs.c:99
PF: not-present write supervisor address=00000020
SUSPECT: near-NULL pointer access (CR2 < 0x1000).
================ END CRASH-ID 7 ================
LOG
cat > "$TMP/kernel32.map" <<'MAP'
                0x00110000                sys_open
                0x00110780                jtmfs_Open
                0x00111000                syscall_after
MAP
python3 "$ROOT/tools/crash_decode.py" "$TMP/crash.log" "$TMP/kernel32.map" > "$TMP/out"
grep -Fq 'EIP=0x0011079a -> jtmfs_Open+0x1a' "$TMP/out" || { cat "$TMP/out"; echo 'crash decoder EIP/map resolution failed' >&2; exit 1; }
grep -Fq 'EFLAGS=0x00000002 IF=0' "$TMP/out" || { cat "$TMP/out"; echo 'crash decoder IF decode failed' >&2; exit 1; }
grep -Fq 'Last syscall:' "$TMP/out" || { cat "$TMP/out"; echo 'crash decoder syscall history missing' >&2; exit 1; }
grep -Fq 'Last lock:' "$TMP/out" || { cat "$TMP/out"; echo 'crash decoder lock history missing' >&2; exit 1; }
echo 'V68.210 crash decoder regression: PASS'
