#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_boot32pm_nzip_staging_integrity: FAIL: $*" >&2; exit 1; }
B=boot32pm/bootmod.inc
A=boot32pm/boot.asm
P=boot32pm/Makefile
I=buildimage

grep -Fq 'FLOPPY_KERNEL_LBA         equ 36' "$B" || fail "floppy kernel LBA36 constant missing"
grep -Fq 'stream_floppy_lba         dw FLOPPY_KERNEL_LBA' "$B" || fail "linear floppy LBA state missing"
grep -Fq 'stream_floppy_spt         db 18' "$B" || fail "1.44M sectors/track fallback missing"
grep -Fq 'stream_floppy_heads       db 2' "$B" || fail "1.44M head-count fallback missing"
grep -Fq 'stream_floppy_detect_geometry:' "$B" || fail "BIOS floppy geometry query missing"
grep -Fq 'mov ah,0x08' "$B" || fail "INT13/AH=08 geometry call missing"
grep -Fq 'stream_floppy_lba_to_chs:' "$B" || fail "linear LBA to CHS conversion missing"
grep -Fq 'mov ax,word [cs:stream_floppy_lba]' "$B" || fail "BIOS read is not driven from linear LBA"
grep -Fq 'inc word [cs:stream_floppy_lba]' "$B" || fail "linear LBA does not advance by sector"
! grep -Fq 'stream_floppy_advance_chs:' "$B" || fail "old cumulative CHS advance remains"
grep -Fq 'stream_validate_first_kernel_sector:' "$B" || fail "first kernel-sector NZIP2 validation missing"
grep -Fq 'cmp dword [es:bx],0x32505A4E' "$B" || fail "first sector does not validate NZP2 magic"

grep -Fq 'kernel_nz_checksum equ' "$P" || fail "compressed checksum metadata generation missing"
grep -Fq 'cmp dx,kernel_nz_checksum' "$A" || fail "PM staged checksum comparison missing"
grep -Fq '.nz_err_stage_checksum: mov eax,7' "$A" || fail "PM error code 7 missing"
grep -Fq '.nz_err_first_header_magic: mov eax,10' "$A" || fail "PM magic error code 10 missing"
grep -Fq '.nz_err_first_header_size:  mov eax,11' "$A" || fail "PM raw-size error code 11 missing"
grep -Fq 'str_pm_nzip_fail_code_tens db "0"' "$A" || fail "two-digit runtime failure display missing"
grep -Fq 'str_pm_nzip_fail_disk_sum db "0000 exp="' "$A" || fail "runtime actual/expected checksum detail missing"
grep -Fq 'pmode_store_hex16_ascii32:' "$A" || fail "runtime hexadecimal checksum formatter missing"

grep -Fq 'BOOT_SECTORS=36' "$I" || fail "buildimage still accounts for one loader track"
grep -Fq 'skip=36' "$I" || fail "buildimage does not verify LBA36 payload"
grep -Fq 'cmp -s kernel32/kernel32.bin.nz -' "$I" || fail "buildimage payload byte compare missing"

echo 'check_boot32pm_nzip_staging_integrity: PASS (low-DMA bounce + LBA geometry + NZP2 magic/size diagnostics + staged checksum)'
