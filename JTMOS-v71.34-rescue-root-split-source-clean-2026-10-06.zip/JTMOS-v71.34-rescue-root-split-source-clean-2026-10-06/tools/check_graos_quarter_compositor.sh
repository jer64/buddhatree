#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
H="$ROOT/libc/apps/gui/graos.h"
D="$ROOT/libc/apps/gui/windowDraw.c"
L="$ROOT/libc/apps/gui/guiLoop.c"
S="$ROOT/libc/apps/gui/guiStart.c"
fail(){ echo "graos priority compositor: FAIL: $*" >&2; exit 1; }
grep -Fq 'GRAOS_PIXEL *back_window_cache;' "$H" || fail "underlay cache missing"
! grep -Fq 'near_window_cache' "$H" || fail "obsolete second full-frame cache remains"
! grep -Fq 'near_window_cache' "$S" || fail "obsolete second cache startup path remains"
grep -Fq 'compositor_window_paint_signature' "$D" || fail "content signature missing"
grep -Fq 'sig=compositor_mix(sig,w->paint_serial);' "$D" || fail "paint generation is not hashed"
! grep -Fq 'frame_counter%GRAOS_' "$D" || fail "timed stale cache refresh remains"
grep -Fq 'compositor_restore_cache' "$D" || fail "damage-bounded underlay restore missing"
grep -Fq 'draw_window_range(v,front_z,GRAOS_Z_MAX);' "$D" || fail "focus full-rate draw missing"
grep -Fq 'guiDrawCursor(v);' "$L" || fail "cursor composition missing"
grep -Fq 'guiMoveCursorOnly(v);' "$L" || fail "cursor-only damage path missing"
grep -Fq 'MilSleep(mouse_hot?2:10);' "$L" || fail "accelerated mouse polling missing"
grep -Fq 'guiMouseAccelerateDelta' "$L" || fail "mouse acceleration curve missing"
grep -Fq 'c->z>=z_ceiling' "$D" || fail "cache-aware occlusion ceiling missing"
echo "graos priority compositor: PASS"
