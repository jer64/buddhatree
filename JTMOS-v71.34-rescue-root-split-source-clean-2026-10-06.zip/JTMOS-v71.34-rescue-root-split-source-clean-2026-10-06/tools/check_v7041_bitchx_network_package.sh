#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
B="$ROOT/tools/build_install_image.sh"
test "$(cat "$ROOT/VERSION")" = "70.41"
test -s "$ROOT/libc/apps/bitchx/source/jtmos_console.c"
test -s "$ROOT/libc/apps/bitchx/source/jtmos_term.c"
test -s "$ROOT/libc/apps/bitchx/include/jtmos_compat.h"
test -s "$ROOT/share/network/BITCHX-R2.txt"
test -s "$ROOT/share/network/bitchx-r2-src.tgz"
grep -Fq 'for app in irc talk bitchx; do' "$B"
grep -Fq 'bitchx-r2-src.tgz' "$B"
grep -Fq 'BITCHX-R2.txt' "$B"
echo 'V70.41 BitchX/network.sqa integration: PASS'
