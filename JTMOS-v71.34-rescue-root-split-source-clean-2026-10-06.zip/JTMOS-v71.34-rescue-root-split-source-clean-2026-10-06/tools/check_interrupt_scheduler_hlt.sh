#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "interrupt scheduler/HLT: FAIL: $*" >&2; exit 1; }

CPU="$ROOT/kernel32/init/cpu.h"
SCH="$ROOT/kernel32/core/cp/scheduler.c"
SH="$ROOT/kernel32/core/cp/scheduler.h"
PIT="$ROOT/kernel32/core/int/pit.c"
TSS="$ROOT/kernel32/core/int/tss.c"
INT="$ROOT/kernel32/core/int/int.c"
TH="$ROOT/kernel32/core/int/threads.c"
TS="$ROOT/kernel32/core/int/threadSwitch.c"
DB="$ROOT/kernel32/core/int/threads_db.c"
LOCK="$ROOT/kernel32/core/int/lock.c"

# CLI/STI must also be compiler barriers around shared IRQ-visible state.
grep -Fq '__volatile__("cli" ::: "memory")' "$CPU" || fail "CLI lacks compiler memory barrier"
grep -Fq '__volatile__("sti" ::: "memory")' "$CPU" || fail "STI lacks compiler memory barrier"
# PAUSE remains i486-buildable through its architectural byte encoding.
grep -Fq '.byte 0xf3,0x90' "$CPU" || fail "PAUSE/F3 90 cpu_relax missing"
grep -Fq 'cpu_sti_hlt' "$CPU" || fail "STI;HLT primitive missing"
grep -Fq 'sti\n\thlt' "$CPU" || fail "STI;HLT must be one asm sequence"

# Default scheduling entry is an interrupt gate, not an IRQ0 task gate.
grep -Fq '#define JTMOS_INTERRUPT_GATE_SCHEDULER 1' "$SH" || fail "interrupt-gate scheduler is not default"
grep -Fq 'setint(M_VEC, pit_scheduler_ISR, SEG_CODE32, D_INT + D_PRESENT)' "$TSS" || fail "IRQ0 interrupt gate missing"
grep -Fq 'setint(0x7E, scheduler_yield_ISR, SEG_CODE32, D_INT + D_PRESENT + D_DPL3)' "$TSS" || fail "yield interrupt gate missing"
grep -Fq 'InstallPitSchedulerGate();' "$TSS" || fail "steady-state IRQ0 scheduler gate not installed"
grep -Fq 'InstallYieldSchedulerGate();' "$TSS" || fail "yield scheduler gate not installed"
grep -Fq 'SetTaskGate((TSS_GATE *)(p+8*4), 0x68);' "$TSS" || fail "double-fault task gate must remain"

# Same-task timer ticks must return by IRET without a hardware task switch.
grep -Fq 'if(nr_curthread==old_pid)' "$SCH" || fail "same-task fast path missing"
grep -Fq 'SchedulerDirectTaskSwitch(old_pid)' "$SCH" || fail "conditional TSS transfer missing"
grep -Fq 'pic_send_eoi(0);' "$SCH" || fail "IRQ0 EOI before context transfer missing"

# Lost-wakeup safe idle: IF is forced low for the runnable recheck and the
# enable+halt pair is indivisible from the compiler's point of view.
grep -Fq 'void SchedulerIdleWait(void)' "$SCH" || fail "idle helper missing"
grep -A64 -F 'void SchedulerIdleWait(void)' "$SCH" | grep -Fq 'disable();' || fail "idle recheck is not IRQ-atomic"
grep -A64 -F 'void SchedulerIdleWait(void)' "$SCH" | grep -Fq 'scheduler_runnable_nonidle_exists()' || fail "idle runnable recheck missing"
grep -A64 -F 'void SchedulerIdleWait(void)' "$SCH" | grep -Fq 'cpu_sti_hlt();' || fail "idle does not use STI;HLT"

# Lock spin loops should hint rather than execute an empty hot loop.
grep -Fq 'cpu_relax();' "$LOCK" || fail "PAUSE missing from lock backoff"

# Explicit switch target publication is atomic and PID 0 is a valid target.
grep -Fq 'int force_switch_thread_nr=-1;' "$DB" || fail "forced-switch sentinel must be -1"
grep -Fq 'static int goback=-1;' "$TS" || fail "return PID sentinel must be -1"
grep -Fq 'force_switch_thread_nr>=0' "$TS" || fail "PID 0 forced switch unsupported"
grep -A24 -F 'int SwitchToThreadEx(int pid)' "$TH" | grep -Fq 'disable();' || fail "SwitchToThreadEx target publication is not IRQ-atomic"
grep -A24 -F 'int SwitchToThreadEx(int pid)' "$TH" | grep -Fq 'idle_moment();' || fail "SwitchToThreadEx no atomic yield entry"

# PIC mask state is shared state; both software mask and both IMRs are updated
# with interrupts disabled, and C handlers use the common EOI helper.
grep -A24 -F 'void enable_irq(unsigned short irq_no)' "$INT" | grep -Fq 'disable();' || fail "enable_irq is not atomic"
grep -A24 -F 'void disable_irq(unsigned short irq_no)' "$INT" | grep -Fq 'disable();' || fail "disable_irq is not atomic"
grep -Fq 'void pic_send_eoi(unsigned short irq_no)' "$INT" || fail "PIC EOI helper missing"

# Pentium-family/newer scheduling uses a finer tick; i486 retains a lighter rate.
grep -Fq 'jtmos_cpu_info.family >= 5' "$PIT" || fail "Pentium-family PIT selection missing"
grep -Fq 'init_pit(GOOD_TIMER_FREQUENCY, 0)' "$PIT" || fail "Pentium PIT rate missing"
grep -Fq 'init_pit(FAIR_TIMER_FREQUENCY, 0)' "$PIT" || fail "i486 PIT rate missing"

echo "interrupt scheduler/HLT: PASS"
