#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.4 JTMFS atomic overwrite/jtmfsck: FAIL: $*" >&2; exit 1; }

case "$(cat "$ROOT/VERSION")" in 69.4|69.[5-9]|69.[1-9][0-9]*|7[0-9].*) ;; *) fail "VERSION predates 69.4" ;; esac
grep -Fq 'int jtmfs_atomic_replace' "$ROOT/kernel32/fs/jtmfs/jtmfs.c" || fail "atomic replace API missing"
grep -Fq 'replace_pending' "$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c" || fail "O_TRUNC staging missing"
grep -Fq 'jtmfs_repair_orphans' "$ROOT/kernel32/fs/jtmfs/jtmfsIntegrity.c" || fail "orphan repair missing"
grep -Fq '{"jtmfsck", jtmfsck_app}' "$ROOT/kernel32/sh/sh.c" || fail "jtmfsck shell command missing"
grep -Fq 'post-repair verification' "$ROOT/kernel32/sh/fsadmin.c" || fail "post-repair rescan missing"
grep -Fq 'jtmfs_atomic_replace(target_dnr,write_name,entry->name,target_db)' "$ROOT/kernel32/sh/copyall.c" || fail "copyall transaction missing"
python3 "$ROOT/tests/jtmfs_atomic_overwrite_jtmfsck_v694.py"
echo "V69.4 JTMFS atomic overwrite + jtmfsck regression: PASS"
