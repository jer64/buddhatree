#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
F="$ROOT/boot32pm/bootmod.inc"
A20="$ROOT/boot32pm/a20.inc"
DOS="$ROOT/boot32pm/dosboot.asm"

fail() { echo "check_boot32pm_floppy_irq: FAIL: $*" >&2; exit 1; }

grep -Eq '^a20[[:space:]]+cli' "$A20" || fail "a20 no longer documents/uses CLI contract"
python3 - "$F" <<'PY'
import re,sys
s=open(sys.argv[1]).read()
m=re.search(r'stream_init:\n(?P<body>.*?)(?=\n[^ ;\t].*:\n)',s,re.S)
if not m:
    raise SystemExit(2)
body=m.group('body')
pos_a20=body.find('call a20')
pos_sti=body.find('sti',pos_a20)
pos_load=body.find('call stream_clear_bounce')
if pos_a20 < 0 or pos_sti < 0 or pos_load < 0 or not (pos_a20 < pos_sti < pos_load):
    raise SystemExit(3)
PY
[ $? -eq 0 ] || fail "stream_init must re-enable IF immediately after a20 before BIOS reads"

grep -A8 -F 'call a20' "$DOS" | grep -Eq '^[[:space:]]*sti([[:space:]]|$)' || fail "DOS boot lost its matching a20/STI contract"

echo "check_boot32pm_floppy_irq: PASS (A20 CLI followed by STI before BIOS/FDC streaming)"
