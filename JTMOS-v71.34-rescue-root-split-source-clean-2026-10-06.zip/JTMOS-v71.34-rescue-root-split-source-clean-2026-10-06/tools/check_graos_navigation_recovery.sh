#!/bin/sh
set -eu
fail(){ echo "GraOS navigation recovery check: FAIL: $*" >&2; exit 1; }

grep -q 'b->count&1' kernel32/init/buffer.c || fail "WORD FIFO odd-byte recovery missing"
grep -q 'b->l_buf-b->count < 2' kernel32/init/buffer.c || fail "WORD FIFO capacity check missing"
grep -q 'if(b->count < 2)' kernel32/init/buffer.c || fail "WORD FIFO atomic pop check missing"
grep -q 'guiNormalizeKey' libc/apps/gui/guiLoop.c || fail "GraOS key normalization missing"
grep -q 'case 0xff67: return JKEY_CURSOR_UP' libc/apps/gui/guiLoop.c || fail "E0 cursor-up normalization missing"
grep -q 'case 0xff6c: return JKEY_CURSOR_DOWN' libc/apps/gui/guiLoop.c || fail "E0 cursor-down normalization missing"
grep -q 'key=guiNormalizeKey(key)' libc/apps/gui/guiLoop.c || fail "normalizer not wired before handlers"
grep -q 'return guiMoveFocus(v,w,1)' libc/apps/gui/guiFocus.c || fail "Tab focus traversal missing"
grep -q 'key==JKEY_SHIFT_TAB' libc/apps/gui/guiFocus.c || fail "Shift+Tab traversal missing"
grep -q 'SYS_keystate' libc/apps/gui/guiLoop.c || fail "raw key-state syscall not used by GraOS"
grep -q 'guiPollRawNavigationKey' libc/apps/gui/guiLoop.c || fail "raw navigation edge poller missing"
grep -q 'guiIsRawNavigationKey' libc/apps/gui/guiLoop.c || fail "translated navigation de-duplication missing"
grep -q 'JKEY_ALT_TAB' libc/apps/gui/guiLoop.c || fail "Alt+Tab task switch missing"
grep -q 'JKEY_SHIFT_ALT_TAB' libc/apps/gui/guiLoop.c || fail "Shift+Alt+Tab task switch missing"
echo "GraOS navigation recovery checks: PASS"
