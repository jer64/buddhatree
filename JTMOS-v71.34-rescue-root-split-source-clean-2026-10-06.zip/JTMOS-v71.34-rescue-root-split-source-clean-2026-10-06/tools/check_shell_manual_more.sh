#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_shell_manual_more: FAIL: $*" >&2; exit 1; }

MAN=docs/SMSH-SQSH-MANUAL.txt
MORE=libc/apps/more.c
SQSH=libc/apps/sqsh.c
SMSH=kernel32/sh/sh.c
NET=kernel32/sh/networkapp.c
BUILD=tools/build_install_image.sh

[ -s "$MAN" ] || fail "manual missing"
[ -s "$MORE" ] || fail "more.c missing"
grep -Fq 'inet|more' "$MAN" || fail "manual lacks compact inet|more example"
grep -Fq 'inet status|more' "$MAN" || fail "manual lacks no-space pipeline example"
grep -Fq "if(*p=='|')" "$SQSH" || fail "SQSH pipeline parser requires whitespace around |"
grep -Fq 'const char *action="status"' "$NET" || fail "bare inet does not default to status"
grep -Fq 'Space or F' "$MAN" || fail "manual lacks more key reference"
grep -Fq 'more [-n LINES]' "$MORE" || fail "more usage missing"
grep -Fq 'more_stream(stdin' "$MORE" || fail "more stdin/pipe mode missing"
grep -Fq 'fputs("\r--More--' "$MORE" || fail "more prompt missing"
grep -Fq 'getch();' "$MORE" || fail "more terminal control input missing"

grep -Fq 'more mv net' libc/apps/Makefile || fail "more not in canonical app release list"
grep -Fq '"more",           "more [-n LINES]' "$SQSH" || fail "SQSH help lacks more"
grep -Fq 'sh_resolve_pipeline_exe' "$SMSH" || fail "SMSH .bin pipeline resolver missing"
grep -Fq 'strcat(withbin,".bin")' "$SMSH" || fail "SMSH pipeline does not append .bin"
grep -Fq 'sh_launch_builtin_pipe_worker' "$SMSH" || fail "SMSH native builtin pipeline worker missing"
grep -Fq 'LinuxProcessExecSetup(pid,parent,stdin_fd,stdout_fd,-1)' "$SMSH" || fail "SMSH native pipeline stdio setup missing"
if grep -Fq 'sh_make_sqsh_pipe_stage_cmd' "$SMSH"; then fail "obsolete sqsh builtin bridge still present"; fi
grep -Fq 'smsh_pipeline_builtin_bridgeable(exe)' "$SMSH" || fail "SMSH network builtin pipeline routing missing"
grep -Fq '#define printf smsh_printf' "$NET" || fail "network builtin output is not pipe-aware"
grep -Fq 'KernelFileBufWrite(ctx->pid,1' "$SMSH" || fail "SMSH bridge does not write caller stdout fd"

grep -Fq 'SHELL_MANUAL="$ROOT/docs/SMSH-SQSH-MANUAL.txt"' "$BUILD" || fail "manual packaging source missing"
grep -Fq 'cp "$SHELL_MANUAL" "$PAYLOAD/SMSH-SQSH-MANUAL.txt"' "$BUILD" || fail "manual absent from install payload"
grep -Fq 'cp "$SHELL_MANUAL" "$BOOTSTRAP/SMSH-SQSH-MANUAL.txt"' "$BUILD" || fail "manual absent from outer utilities archive"

if [ -f utilities.iso ]; then
    [ $(( $(wc -c < utilities.iso) % 2048 )) -eq 0 ] || fail "utilities.iso is not 2048-byte padded"
    strings -a utilities.iso | grep -Fq 'SMSH-SQSH-MANUAL.txt' || fail "utilities.iso lacks manual filename"
    strings -a utilities.iso | grep -Fq 'more.bin' || fail "utilities.iso lacks more.bin"
fi
if [ -f tools/utilsdisk.img ]; then
    [ "$(wc -c < tools/utilsdisk.img)" -le $((1440*1024)) ] || fail "system root payload exceeds 1.44 MiB"
fi

echo "check_shell_manual_more: PASS (manual + more pager + native SMSH/SQSH pipeline routing)"
