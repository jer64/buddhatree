#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 "$ROOT/tests/hdbench_readonly_v6914.py"
make -s -C "$ROOT/libc/apps" -f hdbench.mak syntax
echo 'V69.14 hdbench syntax/read-only contract: PASS'
