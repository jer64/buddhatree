#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
S="$ROOT/libc/apps/gui/guiStart.c"
P="$ROOT/libc/apps/gui/guiStartup.c"
fail(){ echo "check_v68184_graos_first_frame: FAIL: $*" >&2; exit 1; }
ver=$(tr -d '\r\n' < "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=184){ok=1} END{exit ok?0:1}' || fail "VERSION predates 68.184"
grep -q 'drawWindowFrame(v);' "$S" || fail 'explicit initial desktop render missing'
grep -q 'guiDesktopDrawPopup(v);' "$S" || fail 'desktop popup render missing'
grep -q 'guiDrawCursor(v);' "$S" || fail 'cursor render missing'
grep -q 'if(!guiUpdate(v))' "$S" || fail 'initial present check missing'
grep -q 'initial desktop present failed' "$S" || fail 'explicit present failure diagnostic missing'
grep -q 'initial desktop frame presented' "$S" || fail 'successful first-frame diagnostic missing'
grep -q 'entering event loop' "$S" || fail 'event-loop handoff diagnostic missing'
grep -q 'splash_wait_bounded' "$P" || fail 'bounded poster wait missing'
! grep -q 'SYS_getdate' "$P" || fail 'RTC syscall remains in cosmetic splash'
! grep -q 'SwitchToThread' "$P" || fail 'scheduler yield remains in cosmetic splash'
! grep -Eq '^[[:space:]]*(if[[:space:]]*\()?[[:space:]]*usleep[[:space:]]*\(' "$P" || fail 'userspace sleep remains in splash'
echo 'V68.184 GraOS first-frame startup regression: PASS'
