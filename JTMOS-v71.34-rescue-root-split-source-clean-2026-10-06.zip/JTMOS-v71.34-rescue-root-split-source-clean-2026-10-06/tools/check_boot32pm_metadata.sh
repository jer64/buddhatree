#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_boot32pm_metadata: FAIL: $*" >&2; exit 1; }

P=boot32pm/Makefile
B=boot32pm/bootmod.inc
R=boot32pm/README.md

[ -f "$P" ] || fail "$P missing"
[ -f "$B" ] || fail "$B missing"

# V16.75: the default streaming metadata contract is byte/sector based only.
grep -q "printf 'kernel_raw_bytes equ" "$P" || fail "raw byte metadata missing"
grep -q "printf 'kernel_nz_bytes equ" "$P" || fail "compressed byte metadata missing"
grep -q "printf 'kernel_nz_sectors equ" "$P" || fail "sector metadata missing"
grep -q "printf 'kernel_nz_chunks equ" "$P" || fail "stream chunk metadata missing"
! grep -q "printf 'kernel_nz_tracks equ" "$P" || fail "legacy track metadata still emitted"
! grep -q "printf 'kernel_nz_loadlimit equ" "$P" || fail "legacy loadlimit metadata still emitted"

# Limits must fail while producing metadata, not only later in the assembler.
grep -q '\[ "\$\$raw" -le 1048576 \]' "$P" || fail "raw 1 MiB metadata guard missing"
grep -q '\[ "\$\$nz" -le 1048576 \]' "$P" || fail "compressed 1 MiB metadata guard missing"
grep -q '\[ "\$\$sectors" -le 2048 \]' "$P" || fail "2048-sector metadata guard missing"

# Streaming has a fixed 64 KiB bounce clear range.  The optional old fallback
# may still exist, but it must derive its limit from the canonical sector count.
grep -q 'LOADLIMIT[[:space:]]*equ 0x2000' "$B" || fail "stream bounce LOADLIMIT changed"
grep -Fq 'LOADLIMIT                equ (0x1000 + (((kernel_nz_sectors + 17) / 18) * 0x240))' "$B" || fail "compatibility LOADLIMIT is not derived from sectors"
! grep -q 'kernel_nz_loadlimit' "$B" || fail "bootmod still consumes removed kernel_nz_loadlimit metadata"

# Formula regression around every boundary that historically caused drift.
check_formula() {
    nz=$1
    expect_sectors=$2
    expect_chunks=$3
    sectors=$(( (nz + 511) / 512 ))
    chunks=$(( (sectors + 63) / 64 ))
    [ "$sectors" -eq "$expect_sectors" ] || fail "nz=$nz -> sectors=$sectors, expected $expect_sectors"
    [ "$chunks" -eq "$expect_chunks" ] || fail "nz=$nz -> chunks=$chunks, expected $expect_chunks"
}
check_formula 1 1 1
check_formula 512 1 1
check_formula 513 2 1
check_formula 65536 128 2
check_formula 65537 129 3
check_formula 1048576 2048 32

# The documentation must describe the exact-sector streamer, not track-rounded
# reads or whole-stream conventional-memory staging.
grep -q 'both consume exactly `kernel_nz_sectors` sectors' "$R" || fail "README exact-sector contract missing"
! grep -q 'Floppy uses track-rounded reads' "$R" || fail "README still documents obsolete track-rounded streaming"

echo "check_boot32pm_metadata: PASS (minimal sector-exact metadata contract, 1 MiB guards)"
