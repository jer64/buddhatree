#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.0 sync/kernel compatibility: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
python3 "$ROOT/tests/sync_kernel_compat_v690.py"
echo "V69.0 sync/kernel compatibility: PASS"
