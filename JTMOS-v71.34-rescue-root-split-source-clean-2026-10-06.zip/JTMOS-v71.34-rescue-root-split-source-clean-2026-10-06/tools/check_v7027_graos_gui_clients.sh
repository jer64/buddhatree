#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.27" ] || { echo 'V70.27 GUI audit: FAIL VERSION' >&2; exit 1; }
python3 "$ROOT/tests/v7027_graos_gui_clients.py"
