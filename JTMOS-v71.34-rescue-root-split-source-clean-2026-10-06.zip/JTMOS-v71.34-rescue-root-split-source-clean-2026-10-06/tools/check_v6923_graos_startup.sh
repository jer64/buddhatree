#!/bin/sh
set -eu

ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}
GS="$ROOT/kernel32/sh/graos_shell.c"
SH="$ROOT/kernel32/sh/sh.c"
TH="$ROOT/kernel32/core/int/threads.c"

fail()
{
    echo "V69.23 GraOS startup recovery: FAIL: $*" >&2
    exit 1
}

case "$(cat "$ROOT/VERSION")" in
    69.23|69.2[4-9]|69.[3-9][0-9]|[7-9][0-9].*) ;;
    *) fail "unexpected VERSION for V69.23+ GraOS feature check" ;;
esac

# A dead process keeps its name until the PID slot is reused.  Service lookup
# must ignore that zombie name so a failed GraOS can be started again.
grep -Fq "if(name==NULL || name[0]=='\\0') return -1;" "$TH" || fail "null service-name guard missing"
grep -Fq 'if(thread_states[i] && thread_name[i]!=NULL &&' "$TH" || fail "dead process names are still visible"

# Only one shell may own the create-to-register startup window.  The launcher
# must preflight graphics, use a bounded first-frame handshake, and restore the
# maintenance console if the child exits or times out.
grep -Fq 'static volatile int graos_launch_in_progress=0;' "$GS" || fail "concurrent launch guard missing"
grep -Fq 'if(!VesaGraOSAvailable())' "$GS" || fail "graphics preflight missing"
grep -Fq '#define GRAOS_START_TIMEOUT_MS 5000UL' "$GS" || fail "bounded startup timeout missing"
grep -Fq 'if(GetThreadPID("guiserver")==pid) return 0;' "$GS" || fail "first-frame service handshake missing"
grep -Fq 'thread_magic[pid]==magic' "$GS" || fail "PID generation validation missing"
grep -Fq 'KillThread(pid);' "$GS" || fail "failed child cleanup missing"
grep -Fq 'VesaTextConsoleEnable(TRUE);' "$GS" || fail "text-console rollback missing"

python3 - "$GS" "$SH" <<'PY' || fail "startup ordering contract violated"
import pathlib
import sys

gs = pathlib.Path(sys.argv[1]).read_text()
sh = pathlib.Path(sys.argv[2]).read_text()

launch_start = gs.index("static int launch_graos(void)")
launch_end = gs.index("static int join_args", launch_start)
launch = gs[launch_start:launch_end]

alloc = launch.index("ter=NewTerminal();")
exec_ = launch.index('pid=centralprocess_exec("graos.bin"')
owner = launch.index("if(SetTerminalOwner(ter,pid)!=0)")
wait = launch.index("ready=graos_wait_ready(pid,child_magic);")
focus = launch.index("if(SwitchUserTerminal(ter))")
if not alloc < exec_ < owner < wait < focus:
    raise SystemExit("GraOS terminal/focus order is unsafe")

auto_start = sh.index("static int smsh_autostart_after_root(void)")
auto_end = sh.index("int run_shell(void)", auto_start)
auto = sh[auto_start:auto_end]
extracts = [
    auto.index('media_command="sqa utils.iso"'),
    auto.index('media_command="sqa sys"'),
    auto.index('media_command="sqa cdrom"'),
]
graos = auto.index('smsh_execute_command_text("graos")')
if not max(extracts) < graos:
    raise SystemExit("GraOS is not after every payload extraction selection")

# V70.54 separated network recovery from utility/GraOS extraction.  Validate
# the actual call order in run_shell and the stronger controller restart API.
run_start = sh.index("int run_shell(void)")
run = sh[run_start:]
autostart = run.index("smsh_autostart_after_root()")
network = run.index("smsh_network_boot_autorestart(boot_root_ready)")
if not autostart < network:
    raise SystemExit("network recovery starts before storage/GraOS autostart")
net_start = sh.index("static int smsh_network_boot_autorestart")
net_end = sh.index("static int smsh_enter_interactive_terminal", net_start)
if "JtInternetRestart()" not in sh[net_start:net_end]:
    raise SystemExit("network startup no longer uses the full restart lifecycle")
PY

! grep -Fq 'smsh_execute_command_text("d0")' "$SH" || fail "debug output is disabled during autostart"
sh -n "$0" || fail "regression script syntax error"

echo "V69.23 GraOS startup recovery: PASS"
