#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
KEYB="$ROOT/kernel32/drivers/keyboard/keyb.c"
USB="$ROOT/kernel32/drivers/usb/usb_input.c"
OHCI="$ROOT/kernel32/drivers/usb/ohci.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.23 keyboard recovery: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
  69.23|69.2[4-9]|69.[3-9][0-9]|[7-9][0-9].*) ;;
  *) fail "VERSION $VERSION predates V69.23" ;;
esac
if [ "$VERSION" = "69.23" ]; then
    grep -Fq 'JTMOS_SOURCE_RELEASE "V69.23"' "$REL" || fail "release header is not V69.23"
fi

# PS/2 must repair both independent gates: the controller IRQ bit and device
# scan generation.  Do not replace this with a destructive keyboard reset.
grep -Fq 'retval=keyb_bios_preserve_enable_irq1();' "$KEYB" || fail "i8042 IRQ1 repair missing"
grep -Fq 'scanrv=keyb_device_command_ack(0xF4);' "$KEYB" || fail "PS/2 Enable Scanning command missing"
grep -Fq 'keyb_scan_enable_status=scanrv;' "$KEYB" || fail "PS/2 scan diagnostic missing"
grep -Fq '#define KEYB_FORCE_DEVICE_RESET     0' "$KEYB" || fail "keyboard hard reset unexpectedly enabled"

# Reject malformed/error usages before USB gets to promote itself over PS/2.
python3 - "$USB" <<'PY' || fail "HID rollover guard is not before USB promotion"
import pathlib, sys
text=pathlib.Path(sys.argv[1]).read_text()
start=text.index("int usb_hid_boot_keyboard_report")
end=text.index("int usb_hid_boot_mouse_report",start)
body=text[start:end]
rollover=body.index("keys[i]>=1 && keys[i]<=3")
promotion=body.index("input_policy_keyboard_event(INPUT_BACKEND_USB)")
if rollover >= promotion:
    raise SystemExit(1)
PY

# The QEMU-only fallback must survive idle periodic reports and temporary
# control errors.  Periodic TDs are rebuilt only while their ED is skipped.
grep -Fq '#define OHCI_QEMU_RETRY_USEC' "$OHCI" || fail "QEMU rescue retry backoff missing"
grep -Fq 'h->control_error_streak++' "$OHCI" || fail "QEMU rescue error tracking missing"
! grep -Fq 'control_rescue_disabled' "$OHCI" || fail "QEMU rescue still disables itself permanently"
! grep -Fq 'if(h->reports' "$OHCI" || fail "idle periodic report still disables QEMU rescue"
grep -Fq 'h->ed->flags|=OHCI_ED_SKIP;' "$OHCI" || fail "OHCI ED Skip rearm guard missing"
grep -Fq 'delay(1);' "$OHCI" || fail "OHCI one-frame rearm quiesce missing"
grep -Fq 'ohci_arm_hid(h,0);' "$OHCI" || fail "OHCI skipped TD rebuild missing"
grep -Fq 'static volatile int poll_busy=0;' "$OHCI" || fail "OHCI poll serialization missing"

for launcher in "$ROOT/run_jtmos_qemu.sh" "$ROOT/run_jtmos_qemu_sata.sh"; do
    grep -Fq 'USB_INPUT=${JTMOS_USB_INPUT:-ohci}' "$launcher" || fail "USB is not default in ${launcher##*/}"
    grep -Fq 'ohci|usb)' "$launcher" || fail "USB aliases missing in ${launcher##*/}"
    grep -Fq 'ps2|off) USB_INPUT=ps2' "$launcher" || fail "PS/2 selector missing in ${launcher##*/}"
    sh -n "$launcher" || fail "shell syntax error in ${launcher##*/}"
done

sh "$ROOT/tests/usb_keyboard_report_regression.sh"
echo "V69.23 keyboard recovery: PASS"
