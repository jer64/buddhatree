#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-v7036-pkg-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
[ "$(cat "$ROOT/VERSION")" = "70.36" ] || { echo "V70.36 pkg: FAIL VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7036_pkg.py"
mkdir -p "$TMP/inner" "$TMP/outer" "$TMP/dest"
printf 'GUI-TEST\n' > "$TMP/inner/filer.bin"
printf 'RESOURCE\n' > "$TMP/inner/filer.hlp"
cc -O2 -Wall -Wextra -std=gnu17 "$ROOT/tools/sqarc.c" -o "$TMP/sqarc"
cc -O2 -Wall -Wextra -std=gnu17 -I"$ROOT/libc/apps" \
  "$ROOT/libc/apps/pkg.c" "$ROOT/libc/apps/sqa.c" "$ROOT/libc/apps/nzip.c" -o "$TMP/pkg"
JTMOSDIR="$ROOT" "$TMP/sqarc" "$TMP/inner" "$TMP/outer/graos.sqa" >/dev/null
JTMOSDIR="$ROOT" "$TMP/sqarc" "$TMP/outer" "$TMP/utilities.iso" >/dev/null
"$TMP/pkg" list "$TMP/utilities.iso" | grep -q '^graos.sqa'
"$TMP/pkg" info graos "$TMP/utilities.iso" | grep -q '^Package: graos.sqa'
"$TMP/pkg" install graos "$TMP/dest" "$TMP/utilities.iso" >/dev/null
cmp "$TMP/inner/filer.bin" "$TMP/dest/filer.bin"
cmp "$TMP/inner/filer.hlp" "$TMP/dest/filer.hlp"
[ ! -e "$TMP/dest/graos.sqa" ] || { echo 'V70.36 pkg: staging archive leaked' >&2; exit 1; }
echo 'V70.36 pkg functional nested-SQA regression: PASS'
