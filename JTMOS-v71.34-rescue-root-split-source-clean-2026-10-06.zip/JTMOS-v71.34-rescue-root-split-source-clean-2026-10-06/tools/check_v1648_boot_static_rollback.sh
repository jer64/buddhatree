#!/bin/sh
set -eu
fail(){ echo "check_v1648_boot_static_rollback: FAIL: $*" >&2; exit 1; }

J=kernel32/fs/jtmfs/jtmfs.c
R=kernel32/drivers/ramdisk/ramdisk.c
T=kernel32/core/int/threads.c
C=kernel32/sh/copyall.c

[ -f "$J" ] || fail "missing $J"
[ -f "$R" ] || fail "missing $R"
[ -f "$T" ] || fail "missing $T"

# Keep the narrowly proven V16.46 reentrancy fix.
grep -q 'return dirdb_GetFileLength(dnr,fname,db);' "$J" || fail "reentrant file-length lookup missing"
if sed -n '/int jtmfs_getfilesize/,/^}/p' "$J" | grep -Eq '^[[:space:]]*static[[:space:]].*DIRWALK'; then
    fail "jtmfs_getfilesize regressed to shared static DIRWALK"
fi

# V68.161 superseded the old static RAM-disk request packet.  The device layer
# serializes calls, while a zeroed stack-local packet prevents the optional
# extension callback from containing stale data.
grep -Eq '^[[:space:]]*SREQ ss;' "$R" || fail "RAM-disk request is not stack-local"
grep -Fq 'memset(&ss,0,sizeof(ss));' "$R" || fail "RAM-disk request is not fully initialized"
! grep -Eq '^[[:space:]]*static[[:space:]]+SREQ ss;' "$R" || fail "RAM-disk request regressed to shared static storage"
grep -q 'static int prid;' "$T" || fail "scheduler set_thread baseline not restored"

# Preserve the V16.46 exact-copy verification behavior.
grep -q 'CONTENT EXACT' "$C" || fail "copyall exact-content diagnostic missing"
grep -q 'logical size' "$C" || fail "copyall logical-size diagnostic missing"

echo "check_v1648_boot_static_rollback: PASS"
