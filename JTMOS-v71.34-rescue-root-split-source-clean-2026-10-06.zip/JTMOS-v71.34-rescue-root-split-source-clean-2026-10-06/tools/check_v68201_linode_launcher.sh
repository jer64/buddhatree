#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V68.201 Linode launcher regression: FAIL: $*" >&2; exit 1; }
python3 - "$ROOT/VERSION" <<'PY'
import sys
v=open(sys.argv[1]).read().strip().split('.')
major=int(v[0]); rel=int(v[1])
raise SystemExit(0 if major > 68 or (major == 68 and rel >= 201) else 1)
PY
[ -x run_jtmos_linode.sh ] || fail "run_jtmos_linode.sh missing or not executable"
[ -x run_jtmos_qemu_linode.sh ] || fail "run_jtmos_qemu_linode.sh missing or not executable"
grep -Fq 'exec "$DIR/run_jtmos_qemu_linode.sh" "$@"' run_jtmos_linode.sh || fail "compatibility launcher does not delegate to maintained Linode profile"
grep -Fq 'JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}' run_jtmos_qemu_linode.sh || fail "Linode profile lost curses default"
grep -Fq 'JTMOS_USB_INPUT=${JTMOS_USB_INPUT:-off}' run_jtmos_qemu_linode.sh || fail "Linode profile lost USB-off default"
grep -Fq 'JTMOS_AUDIO=${JTMOS_AUDIO:-off}' run_jtmos_qemu_linode.sh || fail "Linode profile lost audio-off default"
grep -Fq 'JTMOS_NET_MODE=${JTMOS_NET_MODE:-user}' run_jtmos_qemu_linode.sh || fail "Linode profile lost user-network default"
grep -Fq 'JTMOS_HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-0.0.0.0}' run_jtmos_qemu_linode.sh || fail "Linode HTTP is not externally bindable"
grep -Fq 'JTMOS_HTTP_HOST_PORT=${JTMOS_HTTP_HOST_PORT:-8080}' run_jtmos_qemu_linode.sh || fail "Linode HTTP host port is not 8080"
grep -Fq 'JTMOS_TELNET_HOST_ADDR=${JTMOS_TELNET_HOST_ADDR:-127.0.0.1}' run_jtmos_qemu_linode.sh || fail "Linode telnet is not host-local"
grep -Fq 'JTMOS_TELNET_HOST_PORT=${JTMOS_TELNET_HOST_PORT:-2323}' run_jtmos_qemu_linode.sh || fail "Linode telnet host port is not 2323"
echo "V68.201 Linode launcher regression: PASS"
