#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_nzip2_fast: FAIL: $*" >&2; exit 1; }
C="$ROOT/kernel32/sh/nzip.c"
H="$ROOT/kernel32/sh/nzip.h"
B="$ROOT/boot32pm/boot.asm"
D="$ROOT/boot32pm/dosboot.asm"
K="$ROOT/tools/build_kernel_nz.sh"

for f in "$C" "$H" "$B" "$D" "$K"; do [ -f "$f" ] || fail "$f missing"; done

grep -q '#define NZIP2_WINDOW[[:space:]]*32768U' "$H" || fail "32 KiB LZ77 window missing"
grep -q '#define NZIP2_MAX_MATCH[[:space:]]*258U' "$H" || fail "DEFLATE-size max match missing"
grep -q '#define NZIP2_CHAIN_LIMIT[[:space:]]*24U' "$H" || fail "bounded hash chain missing"
grep -q 'return nzip2_compress_file(source,destination)' "$C" || fail "default fast compressor missing"
grep -q 'if(nzip2_path_is_stream(source)) return nzip2_uncompress_file' "$C" || fail "NZIP2 decoder dispatch missing"
grep -q 'src=(o.ring_pos+NZIP2_WINDOW' "$C" || fail "RAM-ring overlapping decoder missing"
grep -q 'NZIP_PROGRESS_STEPS 20U' "$C" || fail "low-overhead progress cadence missing"
grep -q '"$NZIP" --fast "$RAW"' "$K" || fail "kernel builder still emits legacy V1 stream"

grep -q 'cmp dword \[esi\],0x32505A4E' "$B" || fail "boot32pm NZP2 magic check missing"
grep -q 'movzx ecx,byte \[esi+2\]' "$B" || fail "boot32pm LZ77 length decode missing"
grep -q 'sub esi,eax' "$B" || fail "boot32pm distance copy missing"
grep -q 'rep movsb' "$B" || fail "boot32pm overlap-copy loop missing"
! awk '/^nzip_decompress_kernel32:/{f=1} f{print} /^%endif/{if(f)exit}' "$B" | grep -Eq '0xE4|nz_err_bwt|CODE_ADVPAK' || fail "boot32pm decoder still contains V1 ADVPAK/BWT hot path"
grep -q 'cmp dword \[esi\],0x32505A4E' "$D" || fail "DOS boot NZP2 magic check missing"
! grep -q '../boot32/' "$B" || fail "boot32pm BIOS source regressed to legacy boot32 include"

TMP=${TMPDIR:-/tmp}/jtmos-nzip2-fast-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
make -C "$ROOT/tools" nzip >/dev/null
python3 - "$TMP/raw.bin" <<'PY1'
from pathlib import Path
import sys
p=Path(sys.argv[1])
block=(b'JTMOS-NZIP2-FAST-'*1536)+bytes(range(256))*16+b'A'*8192
with p.open('wb') as f:
    for _ in range(160): f.write(block)
PY1
cp "$TMP/raw.bin" "$TMP/original.bin"
(cd "$TMP" && "$ROOT/tools/nzip" --fast raw.bin >/dev/null)
python3 - "$TMP/raw.bin.nz" "$TMP/boot-model.bin" <<'PY2'
from pathlib import Path
import sys,struct
z=Path(sys.argv[1]).read_bytes()
assert z[:4]==b'NZP2'
raw=struct.unpack_from('<I',z,4)[0]
p=8; out=bytearray()
while len(out)<raw:
    assert p<len(z); flags=z[p]; p+=1
    for bit in range(8):
        if len(out)>=raw: break
        if not (flags>>bit)&1:
            assert p<len(z); out.append(z[p]); p+=1
        else:
            assert p+3<=len(z)
            d=z[p] | (z[p+1]<<8); l=z[p+2]+3; p+=3
            assert not (d&0x8000)
            d=(d&0x7fff)+1
            assert 1<=d<=32768 and d<=len(out) and len(out)+l<=raw
            for _ in range(l): out.append(out[-d])
assert p==len(z)
Path(sys.argv[2]).write_bytes(out)
PY2
cmp "$TMP/original.bin" "$TMP/boot-model.bin" || fail "boot-model NZIP2 roundtrip mismatch"
rm "$TMP/raw.bin"
(cd "$TMP" && "$ROOT/tools/nzip" -d raw.bin.nz >/dev/null)
cmp "$TMP/original.bin" "$TMP/raw.bin" || fail "userspace NZIP2 roundtrip mismatch"

echo 'check_nzip2_fast: PASS (NZIP2 32KiB LZ77 + RAM decoder + independent boot32pm BIOS/DOS contract)'
