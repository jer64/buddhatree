#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
K="$ROOT/kernel32"

fail() { echo "check_jtmfs_integrity: FAIL: $*" >&2; exit 1; }

[ -f "$K/fs/jtmfs/jtmfsIntegrity.c" ] || fail "missing integrity checker"
grep -q '"fsck", fsck_app' "$K/sh/sh.c" || fail "SMSH fsck builtin missing"
grep -q 'flexFlushFATChecked' "$K/fs/jtmfs/diskcache/flexFat.c" || fail "checked FAT flush missing"
grep -q 'Crash-safe deletion ordering' "$K/fs/jtmfs/jtmfs.c" || fail "safe delete ordering missing"
grep -q 'normal standalone EOC (FFFFFFF8)' "$K/fs/jtmfs/jtmfat.c" || fail "safe FAT reservation ordering missing"

cd "$K"
./autogen.pl > generated.mak
grep -q 'fs/jtmfs/jtmfsIntegrity.o' generated.mak || fail "autogen omitted integrity checker"
make -j2 -f generated.mak \
    fs/jtmfs/jtmfsIntegrity.o \
    fs/jtmfs/jtmfs.o \
    fs/jtmfs/jtmfat.o \
    fs/jtmfs/fsaddblocks.o \
    fs/jtmfs/jtmfsAccess.o \
    fs/jtmfs/diskcache/flexFat.o \
    fs/jtmfs/diskcache/dirdb_writeDir.o \
    fs/jtmfs/publicapi/directfileaccess.o \
    sh/fsadmin.o sh/sh.o sh/helpapp.o

echo "check_jtmfs_integrity: PASS"
