#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
READ="$ROOT/kernel32/fs/jtmfs/ReadChain.c"
WRITE="$ROOT/kernel32/fs/jtmfs/WriteChain.c"
ACCESS="$ROOT/kernel32/fs/jtmfs/jtmfsAccess.c"
JTMFS="$ROOT/kernel32/fs/jtmfs/jtmfs.c"
ADD="$ROOT/kernel32/fs/jtmfs/fsaddblocks.c"
REL="$ROOT/kernel32/include/jtmos_release.h"
fail(){ echo "V69.33 JTMFS critical path: FAIL: $*" >&2; exit 1; }

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"

# Chain walkers must reject trivial cycles and have a finite volume-derived bound.
grep -Fq 'DWORD d,newd,lastd,lba,cs,units,chain_steps;' "$READ" || fail "ReadChain chain bound state missing"
grep -Fq 'newd==d' "$READ" || fail "ReadChain self-link guard missing"
grep -Fq '++chain_steps>=units' "$READ" || fail "ReadChain volume bound missing"
grep -Fq '!jtmfat_isdatablock(dnr,newd)' "$READ" || fail "ReadChain data-area validation missing"
grep -Fq 'DWORD d,newd,new_block,lastd,lba,cs,units,chain_steps;' "$WRITE" || fail "WriteChain chain bound state missing"
grep -Fq 'newd==d' "$WRITE" || fail "WriteChain self-link guard missing"
grep -Fq '++chain_steps>=units' "$WRITE" || fail "WriteChain volume bound missing"

# Zero-fill storage must be private across potentially rescheduling block I/O.
grep -Fq 'static int jtmfs_zero_reserved_unit' "$WRITE" || fail "private zero-fill helper missing"
! grep -Fq 'jtmfsAccess.rwtmp2' "$WRITE" || fail "shared rwtmp2 remains in WriteChain"
grep -Fq 'zero=(BYTE *)malloc((size_t)bsz);' "$WRITE" || fail "private zero-fill allocation missing"
grep -Fq 'free(zero);' "$WRITE" || fail "private zero-fill release missing"

# Named reads must not escape the exact visible EOF.
grep -Fq 'file_length=dw.fe->length;' "$ACCESS" || fail "named-read EOF source missing"
grep -Eq 'if\(offset>=file_length\)[[:space:]]*\{' "$ACCESS" || fail "named-read EOF offset guard missing"
grep -Fq 'if(want>file_length-offset) want=file_length-offset;' "$ACCESS" || fail "named-read length clamp missing"

# Overflow-safe allocation arithmetic.
grep -Fq 'newSize/bs + ((newSize%bs)!=0)' "$JTMFS" || fail "resize block-count overflow fix missing"
grep -Fq 'amount>(0x7fffffff-old_length)/bs' "$ADD" || fail "fsaddblocks length overflow guard missing"

echo "V69.33 JTMFS critical path: PASS"
