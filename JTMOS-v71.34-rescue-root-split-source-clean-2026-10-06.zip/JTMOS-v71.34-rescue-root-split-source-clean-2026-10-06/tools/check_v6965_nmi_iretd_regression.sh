#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "V69.65 NMI IRETD regression: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
awk -v v="$VERSION" -v base="69.65" 'BEGIN{split(v,a,"."); split(base,b,"."); ok=(a[1]+0>b[1]+0)||((a[1]+0==b[1]+0)&&(a[2]+0>=b[2]+0)); exit ok?0:1}' \
    || fail "VERSION predates 69.65"
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header/version mismatch"

python3 - "$ROOT" <<'PYCHECK' || fail "assembly NMI return invariant failed"
from pathlib import Path
import re,sys
root=Path(sys.argv[1])

def block(path,start,end):
    s=(root/path).read_text(errors='replace')
    m=re.search(rf'(?ms)^{re.escape(start)}:.*?(?=^{re.escape(end)}:)',s)
    if not m:
        raise SystemExit(f'cannot isolate {path}:{start}')
    return m.group(0)

checks=[
 ('kernel32/core/int/exc.inc','ASMexception_2','ASMexception_3',
  ('pushad','nmi_emergency_stack_top','call NmiDispatch','mov cr2,eax','iretd')),
 ('kernel32/core/int/llexc.asm','ASMllexception_2','ASMllexception_3',
  ('pushad','nmi_emergency_stack_top','call NmiDispatch','mov cr2,eax','iretd')),
 ('kernel32/core/int/exc.inc','ASMnmi_task','NmiSoftwareTrigger',
  ('cli','call NmiTaskDispatch','mov cr2,eax','iretd')),
]
for path,start,end,needles in checks:
    b=block(path,start,end)
    for needle in needles:
        if needle not in b:
            raise SystemExit(f'{path}:{start} missing {needle}')

# Prevent reintroducing the exact false-negative pattern fixed by this release.
for rel in ('tools/check_v68206_nmi.sh','tools/check_v6918_intel_nmi_rescue.sh','tools/check_v6924_nmi_guarddog.sh'):
    s=(root/rel).read_text(errors='replace')
    if re.search(r"grep\s+-A(?:[1-9][0-9]+)\s+['\"]\^ASM(?:ll)?exception_2:",s):
        raise SystemExit(f'{rel} still uses a fixed line window for vector 2')
PYCHECK

python3 "$ROOT/tools/audit_nmi_safety.py" >/dev/null || fail "NMI safety audit failed"

grep -Fq 'SchedulerGetWatchdogSnapshot(&sw)' "$ROOT/kernel32/core/int/nmi.c" || fail "NMI watchdog snapshot path missing"
! grep -Fq 'rtc_getseconds_of_day_atomic' "$ROOT/kernel32/core/int/nmi.c" || fail "NMI context touches RTC"
grep -Fq 'rtc_getseconds_of_day_atomic(&rtc_second)' "$ROOT/kernel32/core/cp/scheduler.c" || fail "scheduler RTC heartbeat missing"
grep -Fq 'cmos_set_nmi_masked(0);' "$ROOT/kernel32/core/int/nmi_source.c" || fail "shadowed NMI gate open missing"
! grep -Fq 'outportb(NMI_CMOS_INDEX_PORT' "$ROOT/kernel32/core/int/nmi_source.c" || fail "direct port-70h ownership returned"

echo "V69.65 NMI IRETD regression: PASS"
