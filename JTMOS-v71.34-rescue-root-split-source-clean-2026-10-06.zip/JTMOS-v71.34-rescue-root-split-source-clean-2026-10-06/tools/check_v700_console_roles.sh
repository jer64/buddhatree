#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V70 console roles: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

has '#define JTMOS_VT_STATUS       0' kernel32/drivers/term/term.h 'VT1 status role missing'
has '#define JTMOS_VT_BOOTLOG      1' kernel32/drivers/term/term.h 'VT2 boot role missing'
has '#define JTMOS_VT_SMSH         2' kernel32/drivers/term/term.h 'VT3 SMSH role missing'
has '#define JTMOS_VT_LAUNCHER     3' kernel32/drivers/term/term.h 'VT4 launcher role missing'
has 'TerminalAdoptBootLog(JTMOS_VT_BOOTLOG)' kernel32/init/initsystem.c 'boot log is not adopted by VT2'
has 'SetThreadTerminal(GetCurrentThread(),JTMOS_VT_BOOTLOG)' kernel32/init/initsystem.c 'init task does not remain on VT2'
has 'textbackground(BLACK)' kernel32/init/initsystem.c 'black boot background missing'
has 'KernelWriteStatusConsole();' kernel32/init/init.c 'VT1 status page missing'
has 'SetThreadTerminal(ShellThread.pid,JTMOS_VT_BOOTLOG)' kernel32/init/init.c 'SMSH bootstrap not assigned to VT2'
has 'SetThreadTerminal(pid,JTMOS_VT_SMSH)' kernel32/sh/sh.c 'interactive SMSH not assigned to VT3'
has 'SwitchUserTerminal(JTMOS_VT_SMSH)' kernel32/sh/sh.c 'VT3 not focused at prompt-ready transition'
has 'SMSH/JTMOS System Maintenance Shell v%s' kernel32/sh/sh.c 'versioned SMSH banner missing'
has 'ReportMessage("SMSH LaunchApp:' kernel32/sh/sh.c 'SMSH LaunchApp lifecycle still uses foreground console'
has 'const int launcher_terminal=JTMOS_VT_LAUNCHER;' kernel32/sh/sh.c 'launcher lifecycle not assigned to VT4'
has '#define VT_LAUNCHER_NUMBER 4' libc/apps/vt2.c 'launcher app does not expect VT4'

# The old blue default and noisy fixed-VT banners must not return.
! grep -Fq 'textbackground(BLUE); clrscr();' kernel32/init/initsystem.c || fail 'blue boot background returned'
! grep -Fq 'This is terminal 2' kernel32/drivers/term/term.c || fail 'dummy VT banners returned'
! grep -Fq 'printf("SMSH LaunchApp:' kernel32/sh/sh.c || fail 'foreground SMSH LaunchApp noise returned'

echo 'V70 console roles: PASS'
