#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
B="$ROOT/tools/build_install_image.sh"
fail(){ echo "check_system_payload_fit: FAIL: $*" >&2; exit 1; }
grep -Fq 'SYSTEM_KEEP_FILES=' "$B" || fail "B: core whitelist missing"
grep -Fq 'required B: core file missing' "$B" || fail "required-core guard missing"
grep -Fq 'sqa.bin and unz.bin are carried by the outer B: bootstrap' "$B" || fail "bootstrap de-duplication note missing"
grep -Fq 'SYS_UTIL_BYTES' "$B" || fail "final 1.44 MiB size check missing"
for name in sqsh.bin more.bin unique.bin net.bin nzip.bin mkfs.bin terminal.bin; do
    grep -Fq "$name" "$B" || fail "$name missing from B: core whitelist"
done
if [ -f "$ROOT/tools/utilsdisk.img" ]; then
    bytes=$(wc -c < "$ROOT/tools/utilsdisk.img")
    [ "$bytes" -le $((1440*1024)) ] || fail "utilsdisk.img is $bytes bytes"
fi
echo "check_system_payload_fit: PASS (CLI rescue core + terminal + 1.44 MiB guard; GraOS stays on utilities.iso)"
