#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.217 thread mutex/KAsync regression: FAIL: $*" >&2; exit 1; }
grep -Eq '^(68\.(21[7-9]|2[2-9][0-9]|[3-9][0-9][0-9])|69\.[0-9]+)$' "$ROOT/VERSION" || fail "VERSION predates 68.217"

MH="$ROOT/kernel32/core/int/mutex.h"
MC="$ROOT/kernel32/core/int/mutex.c"
SC="$ROOT/kernel32/core/cp/scheduler.c"
SW="$ROOT/kernel32/core/int/threadSwitch.c"
TC="$ROOT/kernel32/core/int/threads.c"
KA="$ROOT/kernel32/core/kasync/kasync.c"
ED="$ROOT/kernel32/drivers/tcpip/ethdev.c"

[ -s "$MH" ] && [ -s "$MC" ] || fail "mutex source/API missing"
grep -Fq 'DEFINE_MUTEX(lockname)' "$MH" || fail "DEFINE_MUTEX API missing"
grep -Fq 'mutex_trylock_at' "$MH" || fail "mutex_trylock API missing"
grep -Fq 'lock->wait_tail' "$MC" || fail "FIFO wait queue missing"
grep -Fq 'thread_blocked[pid]=1;' "$MC" || fail "scheduler-visible blocking missing"
grep -Fq 'waiter->granted=1;' "$MC" || fail "direct ownership hand-off missing"
grep -Fq 'JtSyncThreadCleanup' "$TC" || fail "thread lifecycle sync cleanup missing"
grep -Fq 'JtSyncThreadBlocked' "$SC" || fail "scheduler sync filtering missing"
grep -Fq 'JtSyncThreadBlocked' "$SW" || fail "forced-switch sync filtering missing"

grep -Fq 'static DEFINE_MUTEX(kasync_lock);' "$KA" || fail "KAsync mutex missing"
if grep -Fq 'disable();' "$KA" || grep -Fq 'get_eflags()' "$KA"; then
    fail "KAsync still masks IRQs for table serialization"
fi
grep -Fq 'kasync_expire_queued_locked' "$KA" || fail "queued deadline sweep missing"
grep -Fq 'kasync_make_free(job);' "$KA" || fail "detached slot reclamation missing"
grep -Fq 'sequence-jobs[i].sequence' "$KA" || fail "wrap-safe FIFO selection missing"
grep -Fq 'SchedulerWakeThread(workers[i].pid)' "$KA" || fail "submit does not wake workers"

grep -Fq 'DEFINE_MUTEX(ethdev_mutex)' "$ED" || fail "Ethernet mutex migration missing"
grep -Fq 'mutex_trylock(&ethdev_mutex)' "$ED" || fail "Ethernet atomic trylock missing"
python3 "$ROOT/tests/thread_mutex_kasync_v68217.py"
echo "V68.217 thread mutex/KAsync regression: PASS"
