#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 - "$ROOT" <<'PY2'
from pathlib import Path
import re, sys
root=Path(sys.argv[1])

def need(rel,text):
    s=(root/rel).read_text(errors='ignore')
    if text not in s:
        raise SystemExit('FAIL: %s missing %r' % (rel,text))

def forbid(rel,text):
    s=(root/rel).read_text(errors='ignore')
    if text in s:
        raise SystemExit('FAIL: %s still contains obsolete keropt/env bridge %r' % (rel,text))

ker=(root/'kernel32/init/keropt.c').read_text(errors='ignore')
for token in ('KerOptExportEnvironment','KerOptSyncFromEnvironment','KerOptApplyEnvironment',
              'KerOptIsEnvironmentOption','KerOptValidateEnvironment','KerOptSetInt','KerOptSetString',
              'KEROPT_ENV_INT','KEROPT_ENV_STR'):
    if token in ker:
        raise SystemExit('FAIL: keropt.c still contains '+token)

# keropt.c is again the runtime source of truth: plain globals, plain strings.
for text in ('int jtmos_debug=', 'int autostart=', 'int START_GRAOS=',
             'char *DEFAULT_SYSTEM_NAME="jtmos.info";',
             'char *DEFAULT_USER_NAME="vai";',
             'char *DEFAULT_ROOT_DEVICE="ram";'):
    need('kernel32/init/keropt.c',text)

# Environment remains available for ordinary POSIX variables and PATH only.
envi=(root/'kernel32/core/environment/envint.c').read_text(errors='ignore')
for token in ('KerOptExportEnvironment','KerOptSyncFromEnvironment','KerOptApplyEnvironment',
              'KerOptIsEnvironmentOption','KerOptValidateEnvironment'):
    if token in envi:
        raise SystemExit('FAIL: envint.c still couples ENVDB to '+token)
need('kernel32/core/environment/env.c','static char static_string_null_terminated[2]={0,0};')
need('kernel32/core/environment/env.c','if(e==NULL) return static_string_null_terminated;')
need('kernel32/core/environment/envint.c','/bin:/usr/bin:ram:/bin:hda:/bin:hda1:/bin')
need('kernel32/core/environment/envint.c','return envdb_SetVariableEx(kenv,name,value,overwrite);')

# External execution still uses caller PATH.  This is independent of keropt.c.
need('kernel32/core/cp/centralprocess.c','ProcessEnvGet(centralprocess.requesterPID,"PATH",path,sizeof(path))')
need('kernel32/core/cp/centralprocess.c','SearchThroughPath(path,fname,found)')

# Runtime writes must be direct again; no KerOptSet* call is allowed in kernel sources.
bad=[]
for p in (root/'kernel32').rglob('*'):
    if p.suffix not in ('.c','.h'): continue
    s=p.read_text(errors='ignore')
    if re.search(r'\bKerOpt(?:Set|Apply|Export|Sync|Validate|Is)',s):
        bad.append(str(p.relative_to(root)))
if bad:
    raise SystemExit('FAIL: obsolete KerOpt env bridge references: '+', '.join(sorted(bad)))

print('PASS: keropt.c is independent from getenv/setenv/ENVDB')
print('PASS: process/global POSIX environment remains available for PATH and user variables')
print('PASS: pre-init env lookup keeps the stable empty NUL-terminated string')
print('PASS: external program lookup still resolves requester PATH')
PY2
