#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
fail(){ echo "V68.203 no-autostart-d0: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=203){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.203"
[ -f "$ROOT/RELEASE-V68.203.txt" ] || fail "release note missing"
SH="$ROOT/kernel32/sh/sh.c"
KOPT="$ROOT/kernel32/init/keropt.c"
! grep -Fq 'autostart> d0' "$SH" || fail "SMSH still runs d0 during autostart"
! grep -Fq 'smsh_execute_command_text("d0")' "$SH" || fail "SMSH still dispatches d0 during autostart"
grep -Fq 'd0 remains available manually' "$SH" || fail "diagnostic bootstrap policy comment missing"
grep -Fq 'debug/report/serial enabled throughout bootstrap' "$KOPT" || fail "keropt bootstrap policy not updated"
# d0 must still exist as an explicit command.
grep -Fq '{"d0", DebugReportOffMain}' "$SH" || fail "manual d0 command was accidentally removed"
echo "V68.203 no-autostart-d0 regression: PASS"
