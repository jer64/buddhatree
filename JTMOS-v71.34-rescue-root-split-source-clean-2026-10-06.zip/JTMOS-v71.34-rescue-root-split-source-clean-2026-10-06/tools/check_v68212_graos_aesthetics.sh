#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
GUI="$ROOT/libc/apps/gui"
fail(){ echo "V68.212 GraOS aesthetics: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.212|68.213|68.214|68.215|68.216|68.217|68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
GRAOS_VERSION=$(sed -n 's/.*#define[[:space:]]*GRAOS_VERSION[[:space:]]*"V\([0-9][0-9]*\)".*/\1/p' "$GUI/graos.h" | sed -n '1p')
[ -n "$GRAOS_VERSION" ] && [ "$GRAOS_VERSION" -ge 47 ] || fail "GraOS V47 aesthetic base missing"
grep -Fq 'DrawTextEllipsis(v,w->caption' "$GUI/guiChrome.c" || fail "caption clipping missing"
grep -Fq 'caption_text_right' "$GUI/guiChrome.c" || fail "caption control reservation missing"
grep -Fq 'draw_icon_view_caption' "$GUI/guiChrome.c" || fail "icon caption wrapping missing"
grep -Fq 'DrawTextEllipsis(v,label' "$GUI/guiDesktopDraw.c" || fail "taskbar clipping missing"
grep -Fq 'DrawTextEllipsis(v,clock_text' "$GUI/guiDesktopDraw.c" || fail "tray clipping missing"
grep -Fq 'hover=menu_item_at' "$GUI/guiDesktopDraw.c" || fail "start hover missing"
grep -Fq 'two-pixel sunken frame' "$GUI/guiTextBox.c" || fail "textbox chrome fix missing"
grep -Fq 'DrawTextEllipsis(v,w->qmsg' "$GUI/windowDraw.c" || fail "qmsg clipping missing"
! grep -Fq 'DrawText(v,stat,GRAOS_WIDTH-300' "$GUI/guiLoop.c" || fail "debug overlay still visible"
grep -Fq 'compositor_window_paint_signature' "$GUI/windowDraw.c" || fail "content-aware compositor missing"
! grep -Fq 'frame_counter%GRAOS_' "$GUI/windowDraw.c" || fail "stale frame-rate compositor returned"
echo "V68.212 GraOS aesthetic regression: PASS"
