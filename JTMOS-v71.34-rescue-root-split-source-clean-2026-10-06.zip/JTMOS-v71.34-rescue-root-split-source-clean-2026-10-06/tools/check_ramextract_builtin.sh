#!/bin/sh
set -eu
S=kernel32/sh/sh.c
B=kernel32/init/bootutilsram.c
[ -f "$S" ] && [ -f "$B" ] || { echo "check_ramextract_builtin: run from project root" >&2; exit 1; }
grep -q '#include "bootutilsram.h"' "$S"
grep -q '{"ramextract", ramextract_builtin}' "$S"
grep -q 'BootUtilsRamSize()' "$S"
grep -q 'BootUtilsRamData()' "$S"
grep -q 'wrote=fwrite(image,1U,(size_t)size,out)' "$S"
! grep -q 'BootUtilsRamRead(off,buf,want)' "$S"
grep -q 'fopen(outname,"wb")' "$S"
grep -q 'JTMOS_BOOT_UTILS_RAM_BYTES' "$S"
echo "check_ramextract_builtin: PASS (SMSH builtin bulk-writes staged RAM without /bin/ramextract.bin)"
