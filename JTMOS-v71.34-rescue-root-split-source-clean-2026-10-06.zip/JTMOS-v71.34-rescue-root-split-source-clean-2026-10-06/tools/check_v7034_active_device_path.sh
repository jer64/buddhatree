#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.34" ] || { echo "V70.34 PATH: FAIL: VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7034_active_device_path.py"
echo "V70.34 active-device PATH regression: PASS"
