#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.8 JTMFS hot path: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 69.8|69.9|69.[1-9][0-9]*|7[0-9].*) ;; *) fail "VERSION predates 69.8" ;; esac
DB="$ROOT/kernel32/fs/jtmfs/jtmfsDb.c"
DA="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbAccess.c"
DR="$ROOT/kernel32/drivers/driver_rw.c"
JF="$ROOT/kernel32/fs/jtmfs/jtmfs.c"
grep -Fq 'if(st->recovery_checked && !st->pending)' "$DB" || fail "clean recovery fast path missing"
grep -Fq 'slot=(wanted-1UL)%st->super.journal_slots;' "$DB" || fail "direct recovery slot lookup missing"
! grep -Fq 'for(slot=0;slot<st->super.journal_slots;slot++)' "$DB" || fail "linear recovery journal scan remains"
grep -Fq 'driver_block_cache_invalidate_range(dnr,(long)lba,1);' "$DB" || fail "DB range invalidation missing"
grep -Fq 'void driver_block_cache_invalidate_range' "$DR" || fail "DAPI range invalidation helper missing"
grep -Fq 'jtmfs_mutation_lock(dnr);' "$DA" || fail "touchDir mutation serialization missing"
grep -Fq '!hda_family && driver_FlushDrive(device_nr)!=0' "$JF" || fail "duplicate HDA post-redo barrier remains"
python3 "$ROOT/tests/jtmfs_hotpath_v698.py"
echo "V69.8 JTMFS metadata hot-path regression: PASS"
