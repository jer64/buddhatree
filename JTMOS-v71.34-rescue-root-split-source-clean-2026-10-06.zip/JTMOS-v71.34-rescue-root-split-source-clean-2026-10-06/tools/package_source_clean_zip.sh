#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
PARENT=$(dirname -- "$ROOT")
NAME=$(basename -- "$ROOT")
DEST=${1:-$PARENT}
mkdir -p "$DEST"
DEST=$(CDPATH= cd -- "$DEST" && pwd -P)
VERSION=$(cat "$ROOT/VERSION")
OUT="$DEST/JTMOS-v${VERSION}-source-clean.zip"
SUM="$OUT.sha256"

fail(){ echo "package_source_clean_zip: FAIL: $*" >&2; exit 1; }

# Validate the actual source tree before archiving it.  This includes version /
# release-note consistency, generated-artifact rejection, symlink containment,
# duplicate-layout invariants, and the core/int NASM macro inventory.
"$ROOT/tools/check_source_clean_release.sh"

SOURCE_LINKS=$(mktemp "${TMPDIR:-/tmp}/jtmos-source-links.XXXXXXXX")
TMP=$(mktemp -d "${TMPDIR:-/tmp}/jtmos-zipcheck.XXXXXXXX")
trap 'rm -f "$SOURCE_LINKS"; rm -rf "$TMP"' EXIT HUP INT TERM
find "$ROOT" -type l -printf '%P -> %l\n' | LC_ALL=C sort > "$SOURCE_LINKS"

rm -f "$OUT" "$SUM"
# -y is mandatory: it stores Unix symbolic links as links instead of expanding
# them into duplicate physical directory trees.
( cd "$PARENT" && zip -qry "$OUT" "$NAME" -y -x "$NAME/.git/*" )
unzip -tq "$OUT" >/dev/null

unzip -q "$OUT" -d "$TMP"
EXTRACTED="$TMP/$NAME"
[ -d "$EXTRACTED" ] || fail "archive top-level directory missing"
[ "$(cat "$EXTRACTED/VERSION")" = "$VERSION" ] || fail "archive VERSION mismatch"

# Compare the complete symlink manifest, including exact relative targets.  A
# release therefore fails if zip options/platform behaviour silently expand or
# rewrite even one alias.
EXTRACTED_LINKS="$TMP/extracted-links.txt"
find "$EXTRACTED" -type l -printf '%P -> %l\n' | LC_ALL=C sort > "$EXTRACTED_LINKS"
if ! cmp -s "$SOURCE_LINKS" "$EXTRACTED_LINKS"; then
    echo "package_source_clean_zip: source/extracted symlink manifests differ" >&2
    diff -u "$SOURCE_LINKS" "$EXTRACTED_LINKS" >&2 || true
    fail "ZIP did not preserve symlink layout exactly"
fi

"$EXTRACTED/tools/check_source_clean_release.sh"

sha256sum "$OUT" | sed "s#  .*#  $(basename -- "$OUT")#" > "$SUM"
echo "package_source_clean_zip: PASS"
echo "Archive: $OUT"
echo "Symlinks preserved: $(wc -l < "$SOURCE_LINKS")"
echo "SHA-256: $(awk '{print $1}' "$SUM")"
