#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.222 Start-menu keys: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.222|68.223|68.224|68.225|68.226|68.227|69.*) ;; *) fail "VERSION mismatch" ;; esac
GRAOS_VERSION=$(sed -n 's/.*#define[[:space:]]*GRAOS_VERSION[[:space:]]*"V\([0-9][0-9]*\)".*/\1/p' "$ROOT/libc/apps/gui/graos.h" | sed -n '1p')
[ -n "$GRAOS_VERSION" ] && [ "$GRAOS_VERSION" -ge 49 ] || fail "GraOS V49 or newer missing"
KB="$ROOT/kernel32/drivers/keyboard/keyb.c"
SC="$ROOT/kernel32/drivers/keyboard/scanasc.c"
LOOP="$ROOT/libc/apps/gui/guiLoop.c"
# Ctrl+Esc must bypass ASCII/keymap translation and be edge-triggered.
grep -Fq 'if(!was_down && sc==SCODE_ESCAPE &&' "$KB" || fail "direct Ctrl+Esc make handler missing"
grep -Fq 'kb_outbuf(JKEY_START_MENU);' "$KB" || fail "Start-menu event output missing"
# Left Windows/Start must be decoded from the E0 5B scan code and a lone key
# must emit Start on release; chord suppression protects Win+R/E/M/D/X/Tab.
grep -Fq 'case 0x5b: return SCODE_LWIN;' "$KB" || fail "Left Win E0 5B mapping missing"
grep -Fq 'if(was_win && !kbstr.ktab[SCODE_LWIN] && !kbstr.ktab[SCODE_RWIN])' "$KB" || fail "Win release path missing"
grep -Fq 'if(!keyb_win_chord_used) kb_outbuf(JKEY_START_MENU);' "$KB" || fail "plain Left Win Start event missing"
# Keep translated compatibility path as a second line of defense.
grep -Fq 'mark==SCODE_ESCAPE' "$SC" || fail "Ctrl+Esc translation compatibility missing"
# GraOS must route the event to taskbar.bin or the integrated fallback menu.
grep -Fq 'if(key==JKEY_START_MENU) return open_start_menu(v);' "$LOOP" || fail "GraOS Start-menu global handler missing"
grep -Fq 'if(queue_taskbar_event(GRAOS_GSID_STARTMENU)) return 1;' "$LOOP" || fail "external taskbar Start route missing"
grep -Fq 'v->start_menu_open=!v->start_menu_open;' "$LOOP" || fail "integrated Start fallback missing"
echo "V68.222 Ctrl+Esc/Left-Win Start-menu regression: PASS"
