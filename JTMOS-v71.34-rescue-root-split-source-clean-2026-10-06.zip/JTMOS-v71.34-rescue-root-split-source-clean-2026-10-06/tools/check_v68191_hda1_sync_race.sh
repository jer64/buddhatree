#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
fail(){ echo "V68.191 hda1 sync race safety: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=191){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.191"
[ -f "$ROOT/RELEASE-V68.191.txt" ] || fail "release note missing"
D="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"
F="$ROOT/kernel32/fs/jtmfs/diskcache/flexFat.c"
R="$ROOT/kernel32/fs/jtmfs/diskcache/dirdb_writeDir.c"

python3 - "$D" <<'PY'
from pathlib import Path
import re,sys
s=Path(sys.argv[1]).read_text()
m=re.search(r'int\s+syncdev\s*\(int\s+dnr\)\s*\{(.*?)\n\}',s,re.S)
if not m: raise SystemExit('syncdev body not found')
b=m.group(1)
need=['dirdbFlushDNR(dnr)','flexFlushFATChecked(dnr)','driver_FlushDrive(dnr)']
pos=[]
for x in need:
    i=b.find(x)
    if i<0: raise SystemExit('syncdev missing '+x)
    pos.append(i)
if pos != sorted(pos): raise SystemExit('syncdev durable ordering is wrong')
PY

grep -Fq 'pages[i]=f->cache_page[order[i]];' "$F" || fail "FlexFAT page snapshot missing"
grep -Fq 'writeblocks(dnr,disk_block,io+pos*bs,run)' "$F" || fail "FlexFAT does not submit immutable snapshot"
grep -Fq 'verify[j*bs+i]!=io[(pos+j)*bs+i]' "$F" || fail "FlexFAT readback still compares against live cache"
grep -Fq 'HDA FAT page %d changed during flush; keeping it dirty.' "$F" || fail "FlexFAT concurrent-change retention missing"

grep -Fq 'memcpy(writebuf,d->buf,(size_t)l_tmp);' "$R" || fail "DIRDB immutable write snapshot missing"
grep -Fq 'jtmfs_WriteFileChain(writebuf+(int)off,d->dnr,d->db,io_bytes,(int)off)' "$R" || fail "DIRDB dirty-run path does not write immutable snapshot"
grep -Fq 'if(writebuf[(int)off+x]!=tmp[x])' "$R" || fail "DIRDB media verify is not against snapshot"
grep -Fq 'return DIRDB_WRITE_RETRY;' "$R" || fail "DIRDB live-cache change retry missing"

echo "V68.191 hda1 sync race regression: PASS"
