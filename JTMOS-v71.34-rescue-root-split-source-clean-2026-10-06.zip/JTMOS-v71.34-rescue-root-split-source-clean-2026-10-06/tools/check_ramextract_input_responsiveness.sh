#!/bin/sh
set -eu
fail(){ echo "check_ramextract_input_responsiveness: FAIL: $*" >&2; exit 1; }
S=kernel32/sh/sh.c
B=kernel32/init/bootutilsram.c
R=kernel32/drivers/ramdisk/ramdisk.c
O=kernel32/drivers/usb/ohci.c
U=libc/apps/ramextract.c

grep -q 'BootUtilsRamData()' "$S" || fail "SMSH ramextract does not use direct staged mapping"
grep -q 'fwrite(image,1U,(size_t)size,out)' "$S" || fail "SMSH ramextract is not a single bulk write"
! grep -q 'RAMEXTRACT_BUILTIN_CHUNK' "$S" || fail "old 32 KiB builtin loop remains"
grep -q 'const void \*BootUtilsRamData(void)' "$B" || fail "kernel staged-data accessor missing"
grep -q 'RAMEXTRACT_CHUNK (512UL\*1024UL)' "$U" || fail "external ramextract chunk is not 512 KiB"
grep -q 'SREQ ss;' "$R" || fail "ramdisk request packet is not call-local"
! sed -n '/int rdHandler(SREQ \*s)/,/^}/p' "$R" | grep -q 'disable();' || fail "ramdisk handler still disables IRQs around RAM copy"
! sed -n '/static void ohci_register_detected_devices/,/^}/p' "$O" | grep -q 'input_policy_keyboard_event' || fail "OHCI still promotes USB keyboard on detection"
! sed -n '/static void ohci_register_detected_devices/,/^}/p' "$O" | grep -q 'input_policy_mouse_event' || fail "OHCI still promotes USB mouse on detection"
! sed -n '/static void ohci_register_detected_devices/,/^}/p' "$O" | grep -q 'driver_removedevice' || fail "OHCI detection still removes PS2 fallback"
grep -q 'input_policy_keyboard_event(INPUT_BACKEND_USB)' kernel32/drivers/usb/usb_input.c || fail "real-report keyboard promotion missing"
grep -q 'input_policy_mouse_event(INPUT_BACKEND_USB)' kernel32/drivers/usb/usb_input.c || fail "real-report mouse promotion missing"
echo "check_ramextract_input_responsiveness: PASS"
