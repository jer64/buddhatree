#!/bin/sh
set -eu
f=libc/apps/gui/windowDraw.c
fail(){ echo "GraOS terminal block cursor check: FAIL: $*" >&2; exit 1; }
grep -q '#define GRAOS_TERM_CURSOR_BLINK_MS 500UL' "$f" || fail "500 ms blink period missing"
grep -q 'v->selwin!=w' "$f" || fail "cursor is not restricted to selected window"
grep -q 'GetTickCount()' "$f" || fail "tick-driven blink missing"
grep -q 'for(yy=0;yy<EGA_FONT_HEIGHT;yy++)' "$f" || fail "full-cell cursor row loop missing"
grep -q 'for(xx=0;xx<EGA_FONT_WIDTH;xx++)' "$f" || fail "full-cell cursor column loop missing"
grep -q '((~p)&0x00ffffffUL)' "$f" || fail "full-cell cursor inversion missing"
grep -q 'terminal_poll_tick)>=50UL' libc/apps/gui/guiLoop.c || fail "20 Hz terminal repaint missing"
echo "GraOS terminal block cursor check: PASS"
