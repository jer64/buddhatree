#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ED="$ROOT/kernel32/drivers/tcpip/ethdev.c"
EH="$ROOT/kernel32/drivers/tcpip/ethdev.h"
JN="$ROOT/kernel32/drivers/tcpip/jnet.c"
UI="$ROOT/kernel32/drivers/tcpip/uipMain.c"
NE="$ROOT/kernel32/drivers/tcpip/ne2k.c"
NF="$ROOT/kernel32/drivers/tcpip/nforce.c"

# Ethernet serialization now uses the kernel FIFO sleeping mutex.  Atomic and
# early-boot callers must use trylock rather than sleeping or busy-spinning.
grep -q '#define ETHDEV_ERR_BUSY' "$EH"
grep -q 'static int ethdev_lock(void)' "$ED"
grep -q 'DEFINE_MUTEX(ethdev_mutex)' "$ED"
grep -q 'LockWaitCanYield(flags)' "$ED"
grep -q 'mutex_lock(&ethdev_mutex)' "$ED"
grep -q 'mutex_trylock(&ethdev_mutex)' "$ED"
if grep -Eq 'ETHDEV_LOCK_(SPIN|WAIT|TIMEOUT)|UsecSleep\(ETHDEV_LOCK_WAIT_US\)' "$ED"; then
    echo 'FAIL: old Ethernet polling lock remains' >&2
    exit 1
fi

# JNET packet waits must sleep.  A raw SwitchToThread outside the two pause
# helpers would reintroduce yield-only polling.
grep -q '#define JNET_POLL_IDLE_US   5000UL' "$JN"
grep -q 'static void jnet_poll_pause(int had_frame)' "$JN"
grep -q 'UsecSleep(usec)' "$JN"
grep -q 'JNET_SEND_HARD_WAIT_MS' "$JN"
python3 - "$JN" <<'PY'
import sys
s=open(sys.argv[1]).read()
# Strip the two helper bodies and comments around them, then reject raw
# SwitchToThread calls in the remaining JNET implementation.
start=s.index('static void jnet_poll_pause(')
end=s.index('static volatile int host_pending', start)
rest=s[:start]+s[end:]
if 'SwitchToThread();' in rest:
    raise SystemExit('FAIL: yield-only JNET polling remains outside pause helpers')
for fn in ('arp_resolve','dhcp_wait','ping_now','dns_now'):
    p=s.index(fn+'(')
    frag=s[p:p+5000]
    if 'jnet_poll_pause(' not in frag:
        raise SystemExit('FAIL: '+fn+' lacks sleeping packet poll')
print('JNET sleeping poll audit: PASS')
PY

# uIP owner must sleep both when idle and after real work.
grep -q '#define UIP_BUSY_SLEEP_US        1000UL' "$UI"
grep -q '#define UIP_IDLE_SLEEP_MAX_US    10000UL' "$UI"
grep -q 'UsecSleep(UIP_BUSY_SLEEP_US)' "$UI"
grep -q 'uip_idle_sleep(idle_rounds)' "$UI"

# Both polling backends need bounded waits and a scheduler sleep.
grep -q 'NE2K_RDC_GUARD' "$NE"
grep -q 'UsecSleep(NE2K_RDC_POLL_US)' "$NE"
grep -q 'NE2K_TX_GUARD' "$NE"
grep -q 'UsecSleep(NE2K_TX_POLL_US)' "$NE"
grep -q 'NFORCE_MMIO_POLL_US' "$NF"
grep -q 'nforce_poll_pause();' "$NF"

echo 'V68.170 sleeping Ethernet/JNET polling regression: PASS'
