#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 - "$ROOT" <<'PY'
import pathlib,re,sys
root=pathlib.Path(sys.argv[1])
scs=(root/'kernel32/core/int/scs.c').read_text()
asm=(root/'kernel32/core/int/scall_handler.asm').read_text()
term=(root/'kernel32/drivers/term/term.c').read_text()
serial=(root/'kernel32/drivers/serial/serial.c').read_text()

m=re.search(r'const unsigned char scall_irq_policy\[N_MAX_SCALLS\]\s*=\s*\{(.*?)\n\};',scs,re.S)
assert m, 'scall_irq_policy table missing'
rows=re.findall(r'/\*\s*(\d+)\s+([A-Za-z0-9_]+).*?\*/\s*(SCALL_IRQ_(?:ON|OFF))\s*,',m.group(1))
assert len(rows)==159, f'expected 159 explicit policy rows, got {len(rows)}'
policy={int(n):(fn,state) for n,fn,state in rows}
assert sorted(policy)==list(range(159)), 'policy must explicitly cover syscall 0..158'
assert sum(state=='SCALL_IRQ_ON' for _,state in policy.values())==145
assert sum(state=='SCALL_IRQ_OFF' for _,state in policy.values())==14

# Calls that previously could freeze IRQ1 or depend on a device/timer IRQ.
for nr in [1,2,3,4,19,20,21,22,24,26,27,28,29,30,35,37,38,53,54,58,
           69,76,77,78,79,80,81,82,83,84,85,86,91,92,93,94,95,99,100,
           101,104,106,107,108,109,110,111,112,114,115,116,117,118,119,
           120,121,122,124,125,126,127,129,133,139,140,141,142,143,144,146,
           147,148,149,151,153,154,155,156,157,158]:
    assert policy[nr][1]=='SCALL_IRQ_ON', f'syscall {nr} {policy[nr][0]} must be IRQ-enabled'

# Calls intentionally kept atomic until their implementations gain a stronger
# transaction/locking contract.
for nr in [0,5,8,65,67,68,71,72,87,130,132,134,136,145]:
    assert policy[nr][1]=='SCALL_IRQ_OFF', f'syscall {nr} {policy[nr][0]} must stay IRQ-off'

# Dispatcher must preserve the caller's incoming IF and must not STI while
# dispatch still depends on global scratch.
pos_entry_capture=asm.index('mov eax,dword [ss:esp+12]')
pos_entry_store=asm.index('mov dword [ss:scall_entry_eflags],eax',pos_entry_capture)
pos_target=asm.index('mov edx,dword [ds:scall_tmp1]')
pos_ebp=asm.index('mov ebp,esp',pos_target)
pos_policy=asm.index('cmp byte [ds:scall_irq_policy+eax],0',pos_ebp)
pos_if_test=asm.index('test dword [ds:scall_entry_eflags],0x200',pos_policy)
pos_sti=asm.index('\n\t\tsti',pos_if_test)
pos_call=asm.index('call edx',pos_sti)
pos_cli=asm.index('\n\t\tcli',pos_call)
assert pos_entry_capture < pos_entry_store < pos_target < pos_ebp < pos_policy < pos_if_test < pos_sti < pos_call < pos_cli
assert 'extern scall_irq_policy' in asm
assert 'scall_entry_eflags dd 0' in asm

# No service may bypass the centralized policy with a bare STI.  This is what
# guarantees that a ring-0 caller which intentionally invoked INT 0x7F with
# IF=0 stays atomic even for an otherwise IRQ-capable service.
for rel in ['kernel32/core/int/scs.c','kernel32/core/int/scs2.c',
            'kernel32/core/int/scs_devices.c','kernel32/core/cp/fork.c',
            'kernel32/core/cp/linuxabi.c']:
    text=(root/rel).read_text()
    assert 'enable();' not in text, f'bare enable() bypasses syscall policy in {rel}'

# Helpers made preemptible by the policy must own their tiny shared-state
# critical sections rather than relying on INT 0x7F keeping IF clear globally.
reserve=re.search(r'int ReserveTerminal\(void\).*?\n\}',term,re.S)
assert reserve and 'disable();' in reserve.group(0) and 'set_eflags(flags);' in reserve.group(0)
rate=re.search(r'int SetSerialPortSpeedOwned\(.*?\n\}',serial,re.S)
assert rate and 'disable();' in rate.group(0) and 'set_eflags(flags);' in rate.group(0)
plane=re.search(r'DWORD scall_vgaselectplane\(SYSCALLPAR\).*?\n\}',scs,re.S)
assert plane and 'disable();' in plane.group(0) and 'set_eflags(flags);' in plane.group(0)
cursor=re.search(r'int scall_setcursortype\(SYSCALLPAR\).*?\n\}',scs,re.S)
assert cursor and 'disable();' in cursor.group(0) and 'set_eflags(flags);' in cursor.group(0)

print('PASS V68.166 syscall IRQ policy: 159 slots audited, 145 IRQ-on / 14 atomic IRQ-off; caller IF preserved')
PY
