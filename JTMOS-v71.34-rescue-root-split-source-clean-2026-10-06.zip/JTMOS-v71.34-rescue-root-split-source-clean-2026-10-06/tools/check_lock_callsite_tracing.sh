#!/bin/sh
set -eu
fail(){ echo "check_lock_callsite_tracing: FAIL: $*" >&2; exit 1; }

H=kernel32/core/int/lock.h
C=kernel32/core/int/lock.c
DH=kernel32/drivers/driver_lock.h
DC=kernel32/drivers/driver_lock.c

for f in "$H" "$C" "$DH" "$DC"; do
    [ -f "$f" ] || fail "missing $f"
done

grep -q '#define Lock(lockID)' "$H" || fail 'Lock call-site macro missing'
grep -q 'LockAt((lockID), __FUNCTION__, __FILE__, __LINE__)' "$H" || fail 'Lock macro does not pass full call site'
grep -q 'UnlockAt((lockID), __FUNCTION__, __FILE__, __LINE__)' "$H" || fail 'Unlock macro does not pass full call site'
grep -q 'JtmosFunctionLockAcquire(&__jtmos_function_lock' "$H" || fail 'LOCK macro not routed through central acquire helper'
grep -q 'JtmosFunctionLockRelease(&__jtmos_function_lock' "$H" || fail 'UNLOCK macro not routed through central release helper'

grep -q 'owner_function' "$H" || fail 'function-lock owner function metadata missing'
grep -q 'owner_file' "$H" || fail 'function-lock owner file metadata missing'
grep -q 'owner_line' "$H" || fail 'function-lock owner line metadata missing'
grep -q 'acquired_ms' "$H" || fail 'function-lock acquisition timestamp missing'

grep -q '\[LOCK\] TIMEOUT kind=function' "$C" || fail 'function-lock timeout dprintk missing'
grep -q '\[LOCK\] BAD-UNLOCK kind=function' "$C" || fail 'function-lock bad-unlock dprintk missing'
grep -q '\[LOCK\] wait kind=id' "$C" || fail 'ID-lock wait dprintk missing'
grep -q 'JTMOS_NAMED_TRACE_SLOTS 64' "$C" || fail 'compact named-lock trace table missing'
if grep -Eq '(^|[^[:alnum:]_])printk[[:space:]]*\(' "$C"; then
    fail 'core lock diagnostics still use printk instead of dprintk'
fi

grep -q 'driver_lockOnAt((lockNr),__FUNCTION__,__FILE__,__LINE__)' "$DH" || fail 'driver lock-on macro does not pass call site'
grep -q 'driver_lockOffAt((lockNr),__FUNCTION__,__FILE__,__LINE__)' "$DH" || fail 'driver lock-off macro does not pass call site'
grep -Eq '\[LOCK\] (SPIN-WARN|TIMEOUT) kind=driver' "$DC" || fail 'driver lock wait diagnostic missing'
grep -q '\[LOCK\] DEADLINE-WARN kind=driver' "$DC" || fail 'driver live-owner deadline warning missing'
grep -q '\[LOCK\] STALE-CLEAR kind=driver' "$DC" || fail 'driver stale-owner recovery dprintk missing'
if grep -q '\[LOCK\] DEADLINE-CLEAR kind=driver' "$DC"; then
    fail 'driver lock can still steal a live owner on deadline'
fi
grep -q 'driver_lock_depth' "$DC" || fail 'driver recursive depth tracking missing'
if grep -Eq '(^|[^[:alnum:]_])printk[[:space:]]*\(' "$DC"; then
    fail 'driver lock diagnostics still use printk instead of dprintk'
fi


# PID 0 is a valid early-boot owner. Keep busy/free state separate from owner.
grep -q 'driver_lock_owner_pid\[DRIVER_LOCK_COUNT\]' "$DC" || fail 'driver lock owner PID side table missing'
grep -q 'driver_lock\[lockNr\]=1;' "$DC" || fail 'driver lock acquire does not publish explicit busy flag'
grep -q 'driver_lock_owner_pid\[lockNr\]=pid;' "$DC" || fail 'driver lock acquire does not preserve PID 0 owner'
if grep -q 'driver_forceSetLock(lockNr,pid)' "$DC"; then
    fail 'driver lock still stores PID directly in zero-is-free flag'
fi

echo 'check_lock_callsite_tracing: PASS'
