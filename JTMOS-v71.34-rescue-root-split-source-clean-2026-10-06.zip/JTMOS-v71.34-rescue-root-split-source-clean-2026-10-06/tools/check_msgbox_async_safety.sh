#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
MSG="$ROOT/kernel32/core/cp/msgbox.c"
HDR="$ROOT/kernel32/core/cp/msgbox.h"
THR="$ROOT/kernel32/core/int/threads.c"

fail(){ echo "msgbox async safety: FAIL: $*" >&2; exit 1; }

[ -f "$MSG" ] && [ -f "$HDR" ] && [ -f "$THR" ] || fail "required source file missing"

grep -Fq 'box = _kmalloc(sizeof(MSGBOX), -1, "msgbox");' "$MSG" || \
    fail "mailbox is not kernel-owned"
if grep -Fq 'box = malloc(sizeof(MSGBOX));' "$MSG"; then
    fail "sender-owned mailbox allocation returned"
fi

grep -Fq 'void DestroyThreadMessageBox(int pid)' "$MSG" || \
    fail "mailbox destroy helper missing"
grep -Fq 'void DestroyThreadMessageBox(int pid);' "$HDR" || \
    fail "mailbox destroy declaration missing"
grep -Fq 'DestroyThreadMessageBox(pid);' "$THR" || \
    fail "thread teardown does not destroy mailbox"

grep -Fq 'thread_states[pid] != 0' "$MSG" || \
    fail "mailbox PID liveness check missing"

grep -Fq 'memcpy(me, &packet, sizeof(MSG));' "$MSG" || \
    fail "atomic send publication copy missing"
grep -Fq 'memcpy(&packet, &mailbox->q[ind], sizeof(packet));' "$MSG" || \
    fail "atomic receive snapshot missing"

grep -Fq 'flags = get_eflags();' "$MSG" || fail "IRQ flags save missing"
grep -Fq 'disable();' "$MSG" || fail "IRQ exclusion missing"
grep -Fq 'set_eflags(flags);' "$MSG" || fail "IRQ flags restore missing"

grep -Fq 'packet.un = msgbox_next_sequence();' "$MSG" || \
    fail "message sequence allocation is not synchronized"

# Teardown must not bypass the synchronized helper in threads.c.
if grep -Eq 'thread_msgbox\[pid\][[:space:]]*=[[:space:]]*NULL' "$THR"; then
    fail "raw mailbox detach remains in thread teardown"
fi

echo "msgbox async safety: PASS"
