#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
PIT="$ROOT/kernel32/core/int/pit.c"
PITH="$ROOT/kernel32/core/int/pit.h"
INT="$ROOT/kernel32/core/int/int.c"
INTH="$ROOT/kernel32/core/int/int.h"
HDIRQ="$ROOT/kernel32/drivers/hd/hdIRQ.c"
SHC="$ROOT/kernel32/sh/sh.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail(){ echo "V69.19 Advanced PIT: FAIL: $*" >&2; exit 1; }
[ "$(cat "$ROOT/VERSION")" = "69.19" ] || fail "VERSION is not 69.19"
grep -Fq 'JTMOS_SOURCE_RELEASE "V69.19"' "$REL" || fail "release header is not V69.19"
grep -Fq '#define' "$PITH" || fail "pit.h missing"
grep -Eq 'TMR_READBACK[[:space:]]+0xC0' "$PITH" || fail "8254 read-back base is not 0xC0"
grep -Eq 'TMR_RB_NO_COUNT[[:space:]]+0x20' "$PITH" || fail "read-back COUNT control missing"
grep -Eq 'TMR_RB_NO_STATUS[[:space:]]+0x10' "$PITH" || fail "read-back STATUS control missing"
grep -Fq 'TMR_BOTH + TMR_MD2' "$PIT" || fail "channel 0 is not programmed as mode 2"
! grep -Fq 'TMR_BOTH + TMR_MD3' "$PIT" || fail "legacy mode 3 programming remains"
grep -Fq 'pit_probe_8254_channel0' "$PIT" || fail "8254 probe missing"
grep -Fq 'pic_read_irr()' "$PIT" || fail "PIT rollover does not consult PIC IRR"
grep -Fq 'PIT_INPUT_TICK_USEC_Q16 54925UL' "$PIT" || fail "bounded fixed-point interpolation missing"
grep -Fq 'PitAdvanced8254Active' "$PIT" || fail "Advanced PIT status API missing"
grep -Fq 'WORD pic_read_irr(void)' "$INT" || fail "PIC IRR reader missing"
grep -Fq 'WORD pic_read_isr(void)' "$INT" || fail "PIC ISR reader missing"
grep -Fq 'pic_spurious_irq7++' "$INT" || fail "spurious IRQ7 accounting missing"
grep -Fq 'pic_spurious_irq15++' "$INT" || fail "spurious IRQ15 accounting missing"
grep -Fq 'enable_irq(14);' "$HDIRQ" || fail "IDE IRQ14 still bypasses PIC mask API"
grep -Fq 'enable_irq(15);' "$HDIRQ" || fail "IDE IRQ15 still bypasses PIC mask API"
! grep -Eq 'outb(_p)?\([^\n]*(0x21|0xA1)' "$HDIRQ" || fail "IDE driver still writes PIC IMR directly"
grep -Fq '{"pit", pit_builtin}' "$SHC" || fail "SMSH pit diagnostic missing"
python3 "$ROOT/tests/advanced_pit_model.py"
echo 'V69.19 Advanced PIT: PASS'
