#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V69.57 I/O/GUI/ls: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }
hasre(){ grep -Eq "$1" "$2" || fail "$3"; }

case "$(cat VERSION)" in 69.5[7-9]|69.[6-9][0-9]|7[0-9].*) ;; *) fail "VERSION predates 69.57" ;; esac

D=kernel32/drivers/driver_rw.c
M=kernel32/drivers/sata/mcp61.c
H=kernel32/drivers/hd/hdDev.c
P=kernel32/drivers/partsup/partsup.c
K=kernel32/init/keropt.c
I=kernel32/init/initsystem.c
V=kernel32/init/vesa.c
B=boot32pm/boot.asm
DB=boot32pm/dosboot.asm
SL=kernel32/sh/lsapp.c
UL=libc/apps/ls.c

# readblock/writeblock remain one-logical-block APIs.  The DAPI cache must
# absorb those calls and combine physical transfers rather than forcing one
# ATA request per 512-byte logical sector.
has 'return readblocks(dnr,b,buf,1)==1 ? 0 : 1;' "$D" "readblock no longer delegates as one logical block"
has 'return writeblocks(dnr,b,buf,1)==1 ? 0 : 1;' "$D" "writeblock no longer delegates as one logical block"
hasre '^#define DAPI_CACHE_READAHEAD_BLOCKS[[:space:]]+32$' "$D" "32-sector DAPI read-ahead missing"
hasre '^#define DAPI_CACHE_DIRECT_READ_BLOCKS[[:space:]]+64$' "$D" "DAPI read direct threshold missing"
hasre '^#define DAPI_CACHE_DIRECT_WRITE_BLOCKS[[:space:]]+128$' "$D" "DAPI write combining threshold missing"
hasre '^#define DAPI_CACHE_WRITEBACK_HIGH_BLOCKS[[:space:]]+128$' "$D" "128-sector dirty high-water missing"
has 'physical_readblocks((int)dnr,block_nr,dapi_readahead_buffer,run)' "$D" "read-ahead is not a physical multi-block read"
has 'writeblocks1(owner,first,dapi_io_buffer,run)' "$D" "dirty runs are not flushed as multi-block writes"

# eMachines/MCP61: physical requests must remain batched. Newer releases may
# use standard PCI IDE BMDMA instead of the original 4 KiB rescue-PIO window.
has '#define MCP61_SAFE_PIO_SECTORS' "$M" "MCP61 bounded PIO fallback missing"
if ! grep -Fq '#define MCP61_READAHEAD_SECTORS 32UL' "$M" &&
   ! grep -Fq 'ATA_CMD_READ_DMA_EXT' "$M"; then
    fail "MCP61 has neither historical read-ahead nor BMDMA batching"
fi
has 'driver_enableDAPIWriteBackCache(dnr)' "$M" "MCP61 write-back not enabled"
has '#define HD_READAHEAD_SECTORS 32U' "$H" "legacy IDE read-ahead missing"
has '#define PARTSUP_MCP61_PARENT_SECTORS 64' "$P" "MCP61 partition batching missing"
has '#define PARTSUP_LEGACY_PARENT_SECTORS 128' "$P" "legacy IDE partition batching missing"

# nogui is a boot presentation policy, not a ban on preparing a supported GPU.
has 'NV6150_PREPAGING_ENABLED=' "$K" "NV6150 pre-paging policy missing"
has 'JTMOS_BOOT_SAFE_DEFAULT ? 0 : 1' "$K" "nogui still disables GPU pre-paging"
has 'bootopt_token_equal(token,length,"gui") ||' "$K" "kernel gui token missing"
has 'if(NV6150_PREPAGING_ENABLED && Nv6150PrepareGraOS())' "$I" "GeForce pre-paging preparation missing"
has 'VesaSetTextGraphics(VESA_TEXT_GFX_NV6150,width,height)' "$V" "gfx GeForce mode path missing"
has 'Nv6150SetMode(GRAOS_VESA_WIDTH, GRAOS_VESA_HEIGHT' "$V" "GraOS GeForce mode setup missing"

# BIOS and FreeDOS loaders both keep runtime VESA support even when compiled
# text/nogui by default, and expose an explicit `gui` option.
has '%define BOOT_VESA_RUNTIME_SUPPORT 1' "$B" "BIOS runtime VESA support missing"
has 'str_opt_gui    db "gui"' "$B" "BIOS gui token missing"
has 'boot_gui_requested     db BOOT_VESA_GRAPHICS' "$B" "BIOS gui request state missing"
has '%define BOOT_VESA_RUNTIME_SUPPORT 1' "$DB" "DOSBOOT runtime VESA support missing"
has 'boot_gui_requested    db BOOT_VESA_GRAPHICS' "$DB" "DOSBOOT gui request state missing"
has 'mov byte [boot_gui_requested],1' "$DB" "DOSBOOT gui token does not enable graphics"

# Wildcards are implemented above the filesystem so JTMFS backend wildcard
# semantics cannot make SMSH and ls.bin diverge.
has 'static int ls_wildmatch' "$SL" "SMSH wildcard matcher missing"
has 'ls_wildmatch(pattern,ff.ff_name)' "$SL" "SMSH ls does not apply wildcard"
has 'static int ls_wildmatch' "$UL" "external ls wildcard matcher missing"
has 'ls_prepare_pattern' "$UL" "external ls wildcard path splitter missing"
has 'ls_wildmatch(pattern,ff.ff_name)' "$UL" "external ls does not apply wildcard"
has 'ls *.sqa' "$UL" "external ls wildcard help example missing"
has 'ls *BWBASIC*' "$UL" "external ls substring wildcard help example missing"

echo 'V69.57 I/O batching + runtime GUI + video mode + ls wildcard regression: PASS'
