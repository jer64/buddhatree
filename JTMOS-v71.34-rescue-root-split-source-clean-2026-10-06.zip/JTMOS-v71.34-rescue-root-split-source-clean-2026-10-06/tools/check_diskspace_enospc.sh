#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

need() {
    file=$1
    pattern=$2
    if ! grep -Fq "$pattern" "$file"; then
        echo "check_diskspace_enospc: missing '$pattern' in $file" >&2
        exit 1
    fi
}

need kernel32/fs/jtmfs/diskspace.c 'DiskSpaceFatTransition'
need kernel32/fs/jtmfs/diskspace.c 'DiskSpaceTroubleshootDevice'
need kernel32/fs/jtmfs/diskspace.c 'DISKSPACE_FLAG_FULL'
need kernel32/fs/jtmfs/diskcache/flexFat.c 'DiskSpaceFatTransition(dnr'
need kernel32/fs/jtmfs/jtmfat.c 'DiskSpaceNoteENOSPC'
need kernel32/fs/jtmfs/fsaddblocks.h '#define JTMFS_RESERVE_NOSPC 28'
need kernel32/fs/jtmfs/jtmfsAccess.c 'rv==JTMFS_RESERVE_NOSPC'
need kernel32/fs/jtmfs/publicapi/directfileaccess.c 'errno=(rv==2)?ENOSPC:EIO'
need kernel32/core/int/scs.c 'return -(errno ? errno : EIO);'
need kernel32/core/int/scs2.c 'if(rv==2) return -ENOSPC;'
need kernel32/core/int/logging.c '#define DISKSPACE_LOG_NAME "diskspace.log"'
need kernel32/core/int/logging.c 'DISKSPACE_PERSIST_INTERVAL 60UL'
need kernel32/core/int/logging.c 'DISKSPACE_LOG_RESERVE_BYTES (64*1024UL)'
need kernel32/sh/copyall.c 'no space left on device (ENOSPC)'
need kernel32/sh/sh.c '{"diskspace", diskspace_app}'
need kernel32/sh/fsadmin.c 'diskspace troubleshoot <device>'
need kernel32/sh/helpapp.c 'disk-space history: selected /logs/diskspace.log'
need kernel32/fs/jtmfs/fsaddblocks.c 'space.free_units<(DWORD)remaining'
need kernel32/fs/jtmfs/jtmfs.c 'if(new_block==-1)'
need kernel32/fs/jtmfs/jtmfs.c 'return -ENOSPC;'
need kernel32/fs/jtmfs/publicapi/directfileaccess.c 'jtmfs_rollback_failed_write_growth'
need kernel32/fs/jtmfs/publicapi/directfileaccess.c 'errno=(rv==2)?ENOSPC:EIO'
need kernel32/fs/jtmfs/diskspace.c 'geometry_suspect'
need kernel32/sh/fsadmin.c 'check ATA/AHCI IDENTIFY/geometry'

echo "check_diskspace_enospc: PASS"
