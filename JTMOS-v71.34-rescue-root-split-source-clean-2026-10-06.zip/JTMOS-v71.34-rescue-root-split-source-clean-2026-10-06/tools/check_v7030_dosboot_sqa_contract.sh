#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V70.30 DOSBOOT SQA contract: FAIL: $*" >&2; exit 1; }
awk -F. 'NF==2 && ($1>70 || ($1==70 && $2>=30)){ok=1} END{exit ok?0:1}' "$ROOT/VERSION" || fail VERSION
D="$ROOT/boot32pm/Makefile"
P="$ROOT/tools/publish_utilities_iso.sh"
EXPECTED="boot.sqa core.sqa demos.sqa docs.sqa graos.sqa interpreters.sqa media.sqa network.sqa tests.sqa"
! grep -q -- '--has-member .*install\.img\.nz' "$D" || fail "stale install.img.nz DOSBOOT requirement"
for pkg in $EXPECTED; do grep -Fq "$pkg" "$D" || fail "DOS contract missing $pkg"; grep -Fq "$pkg" "$P" || fail "publisher contract missing $pkg"; done
grep -Fq "grep -v '\\.sqa\$\$'" "$D" || fail "DOS non-SQA rejection missing"
if [ -x "$ROOT/tools/sqarc" ] && [ -s "$ROOT/utilities.iso" ]; then
  for pkg in $EXPECTED; do "$ROOT/tools/sqarc" --has-member "$ROOT/utilities.iso" "$pkg" || fail "utilities.iso missing $pkg"; done
  ! "$ROOT/tools/sqarc" --list "$ROOT/utilities.iso" | grep -v '\.sqa$' | grep -q . || fail "utilities.iso has non-SQA member"
fi
echo "V70.30 DOSBOOT SQA contract: PASS"
