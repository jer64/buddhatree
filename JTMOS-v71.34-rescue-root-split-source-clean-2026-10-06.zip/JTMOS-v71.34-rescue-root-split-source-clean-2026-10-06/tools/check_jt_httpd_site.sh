#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_jt_httpd_site: FAIL: $*" >&2; exit 1; }
HTTPD="$ROOT/kernel32/drivers/tcpip/jt_httpd.c"
BUILD="$ROOT/tools/build_install_image.sh"
for f in index.html index-en.html invest.html invest-en.html jtmos.css jtmos.js; do [ -s "$ROOT/www/$f" ] || fail "missing www/$f"; done
[ "$(wc -c < "$ROOT/www/index.html")" -gt 536 ] || fail "index page does not exercise multi-MSS send"
grep -Fq 'send_current_segment' "$HTTPD" || fail "multi-segment sender missing"
grep -Fq 'uip_acked() && st->last_len' "$HTTPD" || fail "ACK-driven offset advance missing"
grep -Fq 'uip_rexmit()' "$HTTPD" || fail "retransmit path missing"
grep -Fq 'remain>(DWORD)mss ? mss : remain' "$HTTPD" || fail "MSS cap missing"
grep -Fq '"/invest.html"' "$HTTPD" || fail "invest route missing"
grep -Fq '"/index-en.html"' "$HTTPD" || fail "English index route missing"
grep -Fq '"/invest-en.html"' "$HTTPD" || fail "English invest route missing"
grep -Fq '"/jtmos.css"' "$HTTPD" || fail "CSS route missing"
grep -Fq '"/jtmos.js"' "$HTTPD" || fail "JS route missing"
grep -Fq 'cp "$WEB/$base" "$BOOTSTRAP/$base"' "$BUILD" || fail "utilities.iso asset packaging missing"
grep -Fq 'kgetglobalenv("WWW_ROOT"' "$HTTPD" || fail "WWW_ROOT global environment lookup missing"
grep -Fq 'WriteWWWLog(line)' "$HTTPD" || fail "www.log request logging missing"
grep -Fq 'JT_HTTP_SOURCE_FILE' "$HTTPD" || fail "filesystem-backed HTTP source missing"
grep -Fq 'request_skip_query' "$HTTPD" || fail "streaming query-string discard missing"
grep -Fq 'http_open_request_path' "$HTTPD" || fail "generic WWW_ROOT path fallback missing"
grep -Fq 'http_path_segment_safe' "$HTTPD" || fail "WWW_ROOT traversal guard missing"
grep -Fq 'HEAD ' "$HTTPD" || fail "HEAD request support missing"
# Site must remain dependency-free: no CDN or remote script/style dependency.
if grep -Eqi '<(script|link)[^>]+(src|href)="https?://' "$ROOT/www/index.html" "$ROOT/www/index-en.html" "$ROOT/www/invest.html" "$ROOT/www/invest-en.html"; then
    fail "remote JS/CSS dependency found"
fi
grep -Fq '🇫🇮' "$ROOT/www/index.html" || fail "Finnish flag missing from language switch"
grep -Fq '🇬🇧' "$ROOT/www/index-en.html" || fail "UK flag missing from language switch"
grep -Fq 'hreflang="en"' "$ROOT/www/index.html" || fail "Finnish page lacks English alternate"
grep -Fq 'hreflang="fi"' "$ROOT/www/index-en.html" || fail "English page lacks Finnish alternate"
grep -Fq 'HTTP       LISTEN :8080' "$ROOT/www/index.html" || fail "site still documents old HTTP port"
TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT
cp "$ROOT/kernel32/drivers/tcpip/jt_httpd_site.inc" "$TMP"
"$ROOT/tools/gen_jt_httpd_site.py" >/dev/null
cmp -s "$TMP" "$ROOT/kernel32/drivers/tcpip/jt_httpd_site.inc" || fail "embedded site include was stale"
HOSTTEST=$(mktemp)
trap 'rm -f "$TMP" "$HOSTTEST"' EXIT
cc -std=gnu99 -Wall -Wextra -Werror -I"$ROOT/tests/httpd_stubs" "$ROOT/tests/jt_httpd_stream_test.c" -o "$HOSTTEST"
"$HOSTTEST"
echo "check_jt_httpd_site: PASS (Facebook/query canonicalization + safe WWW_ROOT static paths + multi-MSS uIP)"
