#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
cc -std=c99 -Wall -Wextra -I"$ROOT/tests/edit_host" -I"$ROOT/libc/apps" \
    -Dmain=jtmos_edit_main -c "$ROOT/libc/apps/edit.c" -o "$TMP/edit.o"
cc -std=c99 -Wall -Wextra -I"$ROOT/tests/edit_host" -I"$ROOT/libc/apps" \
    -c "$ROOT/libc/apps/editEditor.c" -o "$TMP/editEditor.o"
cc -std=c99 -Wall -Wextra -I"$ROOT/libc/apps" \
    "$ROOT/tests/edit_native_regression.c" "$TMP/edit.o" "$TMP/editEditor.o" \
    -o "$TMP/check_edit"
"$TMP/check_edit" "$TMP" >/dev/null
