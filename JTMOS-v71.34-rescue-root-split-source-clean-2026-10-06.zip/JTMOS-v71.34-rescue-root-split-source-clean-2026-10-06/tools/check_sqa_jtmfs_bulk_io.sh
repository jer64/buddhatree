#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SQA="$ROOT/kernel32/sh/sqa.c"
SQAH="$ROOT/kernel32/sh/sqa.h"
DFA="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"
ACCESS="$ROOT/kernel32/fs/jtmfs/jtmfsAccess.c"
CORE="$ROOT/kernel32/fs/jtmfs/jtmfs.c"
ADD="$ROOT/kernel32/fs/jtmfs/fsaddblocks.c"
READC="$ROOT/kernel32/fs/jtmfs/ReadChain.c"
WRITEC="$ROOT/kernel32/fs/jtmfs/WriteChain.c"
COPYALL="$ROOT/kernel32/sh/copyall.c"
FCNTL="$ROOT/kernel32/init/fcntlbits.h"
fail(){ echo "check_sqa_jtmfs_bulk_io: FAIL: $*" >&2; exit 1; }

grep -q 'jtmfs_reserve_blocks_for_write' "$ADD" || fail 'hidden write reservation API missing'
grep -q 'dw.fe->length=old_length' "$ADD" || fail 'write reservation changes visible EOF'
grep -q 'jtmfs_reserve_blocks_for_write(dnr,r.name,db,required_blocks,cursor)' "$ACCESS" || fail 'writer does not reserve complete span'
grep -q 'jtmfs_setsize_mode(device_nr,OldName,newSize,dirblock,0)' "$CORE" || fail 'post-write EOF mode missing'
grep -q 'zero_growth && newSize>oldSize' "$CORE" || fail 'truncate zero-fill is not separated from post-write commit'
grep -q 'jtmfs_SetSizeAfterWrite(f->dnr,f->name,exact_size,f->db)' "$DFA" || fail 'POSIX write still uses truncate-style SetSize after data'
grep -q 'jtmfs_SetSizeAfterWrite(target_dnr, write_name, entry->size, target_db)' "$COPYALL" || fail 'copyall staging EOF commit can still zero copied data'
grep -q 'jtmfs_atomic_replace(target_dnr,write_name,entry->name,target_db)' "$COPYALL" || fail 'copyall staging file is not atomically published'
grep -q '#define JTMFS_CHAIN_IO_MAX_BLOCKS 256' "$READC" || fail 'read chain batch cap is not 256 blocks'
grep -q '#define JTMFS_CHAIN_IO_MAX_BLOCKS 256' "$WRITEC" || fail 'write chain batch cap is not 256 blocks'
grep -q '#define SQA_COPY_BUFFER_SIZE 131072U' "$SQAH" || fail 'SQA target buffer is not 128 KiB'
grep -q '#define SQA_COPY_BUFFER_MIN  8192U' "$SQAH" || fail 'SQA fresh-boot fallback missing'
grep -q 'O_JTMOS_BATCH' "$FCNTL" || fail 'kernel batch-open flag missing'
grep -q '(flags & O_SYNC) &&' "$DFA" || fail 'close durability is not explicit O_SYNC'
! grep -q 'O_TRUNC|O_JTMOS_BATCH|O_SYNC' "$SQA" || fail 'SQA accidentally requests per-file O_SYNC'
grep -q 'O_TRUNC|O_JTMOS_BATCH' "$SQA" || fail 'kernel SQA does not request batch close'
grep -q 'if(sync()!=0 && rc==0)' "$SQA" || fail 'kernel SQA does not flush batch once at end'

echo 'check_sqa_jtmfs_bulk_io: PASS'
