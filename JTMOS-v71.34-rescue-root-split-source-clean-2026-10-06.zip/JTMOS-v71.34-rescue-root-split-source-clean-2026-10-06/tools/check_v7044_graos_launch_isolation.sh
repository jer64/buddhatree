#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python3 tests/v7044_graos_launch_isolation.py
python3 tests/v7042_launch_multitask.py
python3 tests/v7039_kernel_alias_copy.py
printf '%s\n' 'V70.44 GraOS LaunchApp isolation regression suite: PASS'
