#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python3 tests/v7012_sata_latency.py
echo "check_v7012_sata_latency: PASS"
