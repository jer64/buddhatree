#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_uip_tcp_payload: FAIL: $*" >&2; exit 1; }
MAIN="$ROOT/kernel32/drivers/tcpip/uipMain.c"
MAINH="$ROOT/kernel32/drivers/tcpip/uipMain.h"
UIP="$ROOT/kernel32/drivers/tcpip/uip.c"
CLIENT="$ROOT/kernel32/drivers/tcpip/jt_http_client.c"
APP="$ROOT/kernel32/sh/networkapp.c"

grep -Fq 'static int uip_linearize_output_payload(void)' "$MAIN" || fail "uIP external payload linearizer missing"
grep -Fq 'memmove(dst,(const void *)uip_appdata,bytes)' "$MAIN" || fail "external app payload is not copied into uip_buf"
grep -Fq 'uip_appdata=dst;' "$MAIN" || fail "appdata is not rebound to linear frame after copy"
grep -Fq 'if(uip_linearize_output_payload()<0)' "$MAIN" || fail "send path does not invoke linearizer"
grep -Fq 'tx_appdata_linearized, tx_appdata_bytes, tx_appdata_invalid' "$MAINH" || fail "payload TX diagnostics missing"
grep -Fq 'TCP app payload linearized=' "$APP" || fail "inet stats lacks payload-copy diagnostics"
grep -Fq 'uip_appdata = &uip_buf[UIP_LLH_LEN + 20 + c];' "$UIP" || fail "TCP appdata is not moved past TCP options"
grep -Fq 'TCP_FIN | TCP_SYN | TCP_RST | TCP_PSH | TCP_ACK | TCP_URG' "$UIP" || fail "modern ECN SYN acceptance mask missing"
grep -Fq 'uip_len=0;' "$CLIENT" || fail "HTTP client does not consume incoming uip_len"


echo "check_uip_tcp_payload: PASS (linear TCP app payload + TCP-option data pointer + client RX consume + ECN SYN)"
