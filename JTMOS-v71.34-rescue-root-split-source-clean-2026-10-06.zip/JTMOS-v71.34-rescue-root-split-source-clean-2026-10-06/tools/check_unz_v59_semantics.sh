#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
F="$ROOT/libc/apps/nzipMain.c"
M="$ROOT/libc/apps/unz.mak"
fail(){ echo "check_unz_v59_semantics: FAIL: $*" >&2; exit 1; }

# Composition must remain nzip + nzipMain + embedded sqa.
grep -q 'nzip-unz.o nzipMain-unz.o sqa-unz.o' "$M" || fail "unz link composition changed"
grep -q -- '-DUNCOMPRESS_ALL' "$M" || fail "UNCOMPRESS_ALL build flag missing"

# Historical responsibility: current-directory .nz scan, then automatic SQA on .img output.
grep -q 'findfirst("\*",&unz_ffblk)' "$F" || fail "current-directory scan missing"
grep -q 'nzip_uncompress(name,out)' "$F" || fail "nzip decompression missing"
grep -q 'has_suffix(out,".img")' "$F" || fail "decompressed .img detection missing"
grep -q 'extract_archive_ex(out,"","",0,0)' "$F" || fail "automatic SQA extraction missing"

# unz must not become an installer/media-discovery policy engine again.
! grep -q 'getdevicename' "$F" || fail "device-root discovery returned"
! grep -q 'install_path' "$F" || fail "installer special-case returned"
! grep -q 'fexist("install.img.nz")' "$F" || fail "install.img.nz special-case returned"
! grep -q 'chdir(' "$F" || fail "automatic cwd switching returned"
! grep -q 'remove(out)' "$F" || fail "decompressed .img must be retained"
! grep -q 'JTMOS installer starting' "$F" || fail "installer startup policy returned"

for mirror in kernel32/sh/nzipMain.c tools/nzipMain.c graos-host/apps/nzipMain.c graos-host/kernel32/sh/nzipMain.c; do
  [ -f "$ROOT/$mirror" ] || continue
  cmp -s "$F" "$ROOT/$mirror" || fail "$mirror differs from canonical nzipMain.c"
done

echo "check_unz_v59_semantics: PASS"
