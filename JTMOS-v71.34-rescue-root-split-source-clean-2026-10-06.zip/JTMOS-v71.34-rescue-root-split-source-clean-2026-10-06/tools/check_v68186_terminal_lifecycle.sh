#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68186_terminal_lifecycle: FAIL: $*" >&2; exit 1; }

ver=$(tr -d '\r\n' < "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=186){ok=1} END{exit ok?0:1}' || fail "VERSION predates 68.186"
[ -f "$ROOT/RELEASE-V68.186.txt" ] || fail "release note missing"

for h in \
    "$ROOT/kernel32/core/int/syscallcodes.h" \
    "$ROOT/libc/include/jtmos/k_syscallcodes.h" \
    "$ROOT/libc/include/jtmos/syscallcodes.h" \
    "$ROOT/libc/libc/include/jtmos/syscallcodes.h" \
    "$ROOT/libc/libc/include2026/jtmos/syscallcodes.h"
do
    grep -Eq '^#define[[:space:]]+SYS_freeterminal[[:space:]]+158$' "$h" || fail "SYS_freeterminal ABI missing in ${h#$ROOT/}"
done

S="$ROOT/kernel32/core/int/scs.c"
grep -q '158 scall_freeterminal' "$S" || fail "syscall IRQ policy entry missing"
grep -q 'owner!=GetCurrentThread()' "$S" || fail "caller ownership check missing"
grep -q 'return -EPERM' "$S" || fail "foreign-terminal rejection missing"
grep -q 'rv=FreeTerminal(id)' "$S" || fail "kernel terminal release missing"
count=$(sed -n 's/.*nr_scall_func[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$S" | tail -1)
[ -n "$count" ] && [ "$count" -ge 159 ] || fail "syscall count is below terminal ABI minimum 159"

P="$ROOT/libc/libc/modern/process_console.c"
H="$ROOT/libc/libc/include/jtmos/process.h"
G="$ROOT/libc/apps/gui/guiStart.c"
grep -Fq 'int FreeTerminal(int t){return(int)jtmos_syscall7(SYS_freeterminal' "$P" || fail "libc FreeTerminal wrapper missing"
grep -Eq '^int FreeTerminal\(int\);$' "$H" || fail "public FreeTerminal declaration missing"
[ "$(grep -c 'FreeTerminal(ter)' "$G")" -ge 1 ] || fail "GraOS launch-failure terminal cleanup missing"
grep -q 'exec failed; released terminal' "$G" || fail "exec-failure cleanup diagnostic missing"
grep -q 'graos_bgexec_owned_ex_command(program,cwd,ter)' "$G" || fail "atomic child terminal-owner transfer missing"

# V68.185 diagnostics are part of the base and must survive this lifecycle fix.
GRAOS_VERSION=$(sed -n 's/.*#define[[:space:]]*GRAOS_VERSION[[:space:]]*"V\([0-9][0-9]*\)".*/\1/p' "$ROOT/libc/apps/gui/graos.h" | sed -n '1p')
[ -n "$GRAOS_VERSION" ] && [ "$GRAOS_VERSION" -ge 45 ] || fail "GraOS V45 diagnostics base missing"
grep -Fq '#define GRAOS_DLOG(...) jtmos_dprintk(__VA_ARGS__)' "$ROOT/libc/apps/gui/graos.h" || fail "GRAOS_DLOG bridge missing"
grep -q 'five-second heartbeat' "$ROOT/RELEASE-V68.185.txt" || fail "V68.185 heartbeat diagnostics note missing"
grep -q 'initial desktop frame presented' "$G" || fail "first-frame diagnostic missing"

echo "V68.186 owner-safe terminal lifecycle regression: PASS"
