#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "launchapp/exec-context: FAIL: $*" >&2; exit 1; }

LA="$ROOT/kernel32/core/cp/LaunchApp.c"
LH="$ROOT/kernel32/core/cp/LaunchApp.h"
CP="$ROOT/kernel32/core/cp/centralprocess.c"
CH="$ROOT/kernel32/core/cp/centralprocess.h"
ID="$ROOT/kernel32/core/cp/exeidentificationmodule.c"
IH="$ROOT/kernel32/core/cp/exeidentificationmodule.h"
SCS="$ROOT/kernel32/core/int/scs.c"
CRT="$ROOT/libc/libc/modern/crt0.S"
PC="$ROOT/libc/libc/modern/process_console.c"
STDLIB="$ROOT/libc/libc/modern/stdlib.c"

for f in "$LA" "$LH" "$CP" "$CH" "$ID" "$IH" "$SCS" "$CRT" "$PC" "$STDLIB"; do
    [ -f "$f" ] || fail "missing ${f#$ROOT/}"
done

grep -q 'LaunchAppExContext' "$LA" || fail "authoritative context launcher missing"
grep -q 'LaunchAppValidateImage' "$LA" || fail "central image validator missing"
grep -q 'verifyExeBinary' "$LA" || fail "LaunchApp bypasses executable identity verifier"
grep -q 'JTMOS_EXE_MAGIC1[[:space:]]*0xFCE2E37B' "$IH" || fail "numeric FCE2E37B identity missing"
grep -q '\[JTMOS EXE ABI TAG V1\]' "$CRT" || fail "new libc ABI-tag marker missing"
grep -q '\.long 0xFCE2E37B' "$CRT" || fail "new libc numeric magic missing"
grep -q 'tag_v1_found && !tag_valid' "$ID" || fail "V1 tag is not enforced"
grep -q 'ph->p_type!=PT_LOAD' "$ID" || fail "identity is not constrained to PT_LOAD"

grep -q 'callerDNR,callerDB' "$CH" || fail "immutable caller DNR/DB fields missing"
grep -q 'centralprocess.callerDNR=dnr' "$CP" || fail "original caller DNR snapshot is not saved"
grep -q 'centralprocess.callerDB=db' "$CP" || fail "original caller DB snapshot is not saved"
! grep -q 'GetThreadDNR(centralprocess.requesterPID)' "$CP" || fail "late requester DNR re-snapshot remains"
! grep -q 'GetThreadDB(centralprocess.requesterPID)' "$CP" || fail "late requester DB re-snapshot remains"
grep -q 'launchctx.runDNR=centralprocess.runDNR' "$CP" || fail "resolved run DNR is not passed to launcher"
grep -q 'launchctx.runDB=centralprocess.runDB' "$CP" || fail "resolved run DB is not passed to launcher"
grep -q 'cwd_fd=open(fname,O_RDONLY)' "$CP" || fail "bare executable names are not probed in caller cwd before PATH"
grep -q "strchr(fname,':')" "$CP" || fail "device-qualified executable names are not treated as explicit paths"
grep -q 'SearchThroughPath(path,fname,found)' "$CP" || fail "PATH fallback missing after cwd probe"

grep -q 'caller_dnr=GetCurrentDNR()' "$SCS" || fail "SYS_cexec does not snapshot caller DNR"
grep -q 'caller_db=GetCurrentDB()' "$SCS" || fail "SYS_cexec does not snapshot caller DB"
grep -q 'if(!scall_edx)' "$SCS" || fail "NULL workDir inheritance not supported by syscall"

grep -q 'JTMOS_EXEC_INHERIT_CWD' "$PC" || fail "modern libc does not normalize inherited cwd"
grep -q 'cexec(s,JTMOS_EXEC_INHERIT_CWD)' "$STDLIB" || fail "modern libc system() does not preserve DNR/DB"

echo "launchapp/exec-context: PASS"
