#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SQ="$ROOT/tools/sqarc"
fail(){ echo "V70.29 SQA packages: FAIL: $*" >&2; exit 1; }
python3 - "$ROOT/VERSION" <<'PY' || fail VERSION
import sys
v=tuple(int(x) for x in open(sys.argv[1]).read().strip().split('.'))
raise SystemExit(0 if v >= (70,29) else 1)
PY
[ -x "$SQ" ] || fail sqarc
[ -s "$ROOT/tools/utilities.sqa" ] || fail utilities.sqa
EXPECTED="boot.sqa core.sqa demos.sqa docs.sqa graos.sqa interpreters.sqa media.sqa network.sqa tests.sqa"
ACTUAL=$($SQ --list "$ROOT/tools/utilities.sqa" | LC_ALL=C sort | tr '\n' ' ' | sed 's/ $//')
EXP=$(printf '%s\n' $EXPECTED | LC_ALL=C sort | tr '\n' ' ' | sed 's/ $//')
[ "$ACTUAL" = "$EXP" ] || fail "outer member set: $ACTUAL"
$SQ --list "$ROOT/tools/utilities.sqa" | grep -v '\.sqa$' | grep -q . && fail "non-SQA outer member"
# Every built release binary must occur in exactly one content package.
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT HUP INT TERM
{ make --no-print-directory -s -C "$ROOT/libc/apps" list-binaries; make --no-print-directory -s -C "$ROOT/libc/apps/gui" list-binaries; } | LC_ALL=C sort -u > "$TMP/expected"
: > "$TMP/actual"
for p in core graos interpreters demos media network tests; do
  $SQ --list "$ROOT/tools/install_payload/$p.sqa" | grep '\.bin$' >> "$TMP/actual" || true
done
LC_ALL=C sort "$TMP/actual" > "$TMP/actual.sorted"
[ "$(wc -l < "$TMP/expected")" -eq "$(wc -l < "$TMP/actual.sorted")" ] || fail "binary count/duplication"
cmp "$TMP/expected" "$TMP/actual.sorted" >/dev/null || fail "release binary package coverage"
# GraOS package owns the server/system GUI clients. Media applications use the
# public GraOS API but are intentionally owned by media.sqa.
for f in "$ROOT/libc/apps/gui"/*.bin; do $SQ --has-member "$ROOT/tools/install_payload/graos.sqa" "$(basename "$f")" || fail "GraOS gui binary $(basename "$f")"; done
for app in filer iview taskbar winshell wintest wintest2 wintest3 cbmvm; do $SQ --has-member "$ROOT/tools/install_payload/graos.sqa" "$app.bin" || fail "GraOS client $app.bin"; done
for app in mp3 mpeg1 sound rawplay aud; do $SQ --has-member "$ROOT/tools/install_payload/media.sqa" "$app.bin" || fail "media client $app.bin"; done
for res in jtmos_poster.raw mousecursor.raw squirrel16.raw title_close98.raw title_minimize98.raw filer.hlp; do $SQ --has-member "$ROOT/tools/install_payload/graos.sqa" "$res" || fail "GraOS resource $res"; done
# No GraOS binary may leak to core.
for f in $($SQ --list "$ROOT/tools/install_payload/graos.sqa" | grep '\.bin$'); do ! $SQ --has-member "$ROOT/tools/install_payload/core.sqa" "$f" || fail "GraOS/core duplicate $f"; done
grep -Fq 'sqa core.sqa' "$ROOT/kernel32/sh/sh.c" || fail autostart-core
grep -Fq 'sqa graos.sqa' "$ROOT/kernel32/sh/sh.c" || fail autostart-graos
echo "V70.29 SQA packages: PASS ($(wc -l < "$TMP/expected") release binaries, 9 outer packages)"
