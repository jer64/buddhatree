#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "shell tab/history: FAIL: $*" >&2; exit 1; }

SMSH="$ROOT/kernel32/sh/sh.c"
SQSH="$ROOT/libc/apps/sqsh.c"
MAN="$ROOT/docs/SMSH-SQSH-MANUAL.txt"

grep -Fq '#define SH_HISTORY_MAX 32' "$SMSH" || fail 'SMSH history size'
grep -Fq '#define SQSH_HISTORY_MAX 32' "$SQSH" || fail 'SQSH history size'
grep -Fq 'sh_complete_file(line,capacity,&used)' "$SMSH" || fail 'SMSH TAB completion hook'
grep -Fq 'sqsh_complete_file(line,capacity,&used)' "$SQSH" || fail 'SQSH TAB completion hook'
grep -Fq 'resolveFileNamePath(token,&dnr,&db,&resolved)' "$SMSH" || fail 'SMSH path-aware completion'
grep -Fq 'findfirst("*",&ff)' "$SQSH" || fail 'SQSH directory completion'
grep -Fq 'key==0xFF48 || key==0x4800' "$SMSH" || fail 'SMSH Up key encodings'
grep -Fq 'key==0xFF50 || key==0x5000' "$SMSH" || fail 'SMSH Down key encodings'
grep -Fq 'key==JKEY_CURSOR_UP || key==0xFF48' "$SQSH" || fail 'SQSH Up key encodings'
grep -Fq 'key==JKEY_CURSOR_DOWN || key==0xFF50' "$SQSH" || fail 'SQSH Down key encodings'
grep -Fq 'restore the unfinished line' "$MAN" || fail 'manual history behavior'
grep -Fq 'key==18' "$SMSH" || fail 'SMSH Ctrl+R hook missing'
grep -Fq 'key==18' "$SQSH" || fail 'SQSH Ctrl+R hook missing'
grep -Fq 'sh_reverse_isearch(line,capacity,&used)' "$SMSH" || fail 'SMSH reverse-i-search call missing'
grep -Fq 'sqsh_reverse_isearch(line,capacity,&used)' "$SQSH" || fail 'SQSH reverse-i-search call missing'
grep -Fq '(reverse-i-search)`' "$SMSH" || fail 'SMSH reverse search prompt missing'
grep -Fq '(reverse-i-search)`' "$SQSH" || fail 'SQSH reverse search prompt missing'
grep -Fq 'key==7' "$SMSH" || fail 'SMSH Ctrl+G abort missing'
grep -Fq 'key==7' "$SQSH" || fail 'SQSH Ctrl+G abort missing'
grep -Fq 'Ctrl+R starts a Bash/Readline-' "$MAN" || fail 'manual reverse search behavior'
grep -Fq 'complete the current file or directory name' "$MAN" || fail 'manual completion behavior'

echo 'shell tab/history: PASS'
