#!/bin/sh
set -eu
fail(){ echo "GraOS raw navigation check: FAIL: $*" >&2; exit 1; }

grep -q 'SYS_keystate[[:space:]]*152' kernel32/core/int/syscallcodes.h || fail "kernel syscall code missing"
grep -q 'SYS_keystate[[:space:]]*152' libc/libc/include/jtmos/syscallcodes.h || fail "libc syscall code missing"
grep -q 'scall_keystate' kernel32/core/int/scs.c || fail "kernel key-state syscall missing"
nr=$(sed -n 's/.*nr_scall_func[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' kernel32/core/int/scs.c | head -n 1)
[ -n "$nr" ] && [ "$nr" -ge 153 ] || fail "syscall table size not extended past raw-navigation ABI"
grep -q 'guiPollRawNavigationKey' libc/apps/gui/guiLoop.c || fail "GraOS raw navigation poller missing"
grep -q 'GRAOS_SC_TAB' libc/apps/gui/guiLoop.c || fail "physical Tab state missing"
grep -q 'JKEY_SHIFT_ALT_TAB' libc/apps/gui/guiLoop.c || fail "reverse Alt+Tab synthesis missing"
grep -q 'JKEY_CURSOR_UP' libc/apps/gui/guiLoop.c || fail "cursor navigation synthesis missing"
grep -q 'guiIsRawNavigationKey' libc/apps/gui/guiLoop.c || fail "FIFO navigation duplicate filter missing"
grep -q 'guiDispatchKey' libc/apps/gui/guiLoop.c || fail "single navigation dispatch path missing"
echo "GraOS raw navigation checks: PASS"
