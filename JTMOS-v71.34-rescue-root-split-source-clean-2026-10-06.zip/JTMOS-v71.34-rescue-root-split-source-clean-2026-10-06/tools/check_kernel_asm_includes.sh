#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT/kernel32"
TMP=${TMPDIR:-/tmp}/jtmos-asm-includes-$$
trap 'rm -f "$TMP"' EXIT HUP INT TERM

# NASM is run with kernel32/ as its working directory, so quoted includes such
# as core/int/exc.mac must resolve from here.  Catch stale mirror names
# before NASM turns one missing include into dozens of undefined-macro errors.
find . -type f \( -name '*.asm' -o -name '*.mac' -o -name '*.inc' \) -exec \
    grep -h '^[[:space:]]*%include[[:space:]]*"' {} \; 2>/dev/null |
    sed -n 's/^[[:space:]]*%include[[:space:]]*"\([^"]*\)".*/\1/p' |
    sort -u > "$TMP"

missing=0
while IFS= read -r inc; do
    [ -n "$inc" ] || continue
    case "$inc" in
        ../*) continue ;;
    esac
    if [ ! -f "$inc" ]; then
        echo "check_kernel_asm_includes: FAIL: missing NASM include: $inc" >&2
        missing=1
    fi
done < "$TMP"

for stale in core/chiplevel core/lowlevel core/iodma; do
    if grep -R -n -E "%include[[:space:]]+\"$stale/" . \
        --include='*.asm' --include='*.mac' --include='*.inc' >/dev/null 2>&1; then
        echo "check_kernel_asm_includes: FAIL: stale NASM include directory $stale" >&2
        missing=1
    fi
done

[ "$missing" -eq 0 ] || exit 1
echo 'check_kernel_asm_includes: PASS (all active NASM include paths resolve)'
