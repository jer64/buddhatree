#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.227 dprintk routing: FAIL: $*" >&2; exit 1; }

case "$(cat "$ROOT/VERSION")" in 68.227|69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
grep -Eq '^#define[[:space:]]+JTMOS_SOURCE_RELEASE[[:space:]]+"V(68\.227|69\.[0-9]+|7[0-9]\.[0-9]+)"$' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
K="$ROOT/kernel32/init/kernel32.h"
grep -Eq '^#define[[:space:]]+printk[[:space:]]+dprintk$' "$K" || fail "printk is not routed to dprintk"
grep -Eq '^#define[[:space:]]+TRACE[[:space:]]+dprintk$' "$K" || fail "TRACE is not routed to dprintk"
! grep -Eq '^#define[[:space:]]+printk[[:space:]]+printf$' "$K" || fail "legacy printk->printf alias remains"
grep -Fq '#ifdef JTMOSKERNEL' "$ROOT/kernel32/drivers/hd/hd.h" || fail "HD portability guard missing"
grep -Fq '#define printk dprintk' "$ROOT/kernel32/drivers/hd/hd.h" || fail "kernel HD printk route missing"
grep -Eq '^#define[[:space:]]+printk[[:space:]]+dprintk$' "$ROOT/graos-host/init/kernel32.h" || fail "GraOS-host kernel printk route missing"

# Normal console APIs must remain real console APIs; only diagnostics are redirected.
grep -Fq 'int printf(const char *fmt, ...)' "$ROOT/kernel32/core/dataproc/printf.c" || fail "kernel printf missing"
grep -Fq 'void print(const char *s)' "$ROOT/kernel32/drivers/term/term.c" || fail "kernel print console helper missing"

# Representative legacy raw debug prints moved to dprintk.
grep -Fq 'dprintk("scall_write: Invalid file descriptor.\n");' "$ROOT/kernel32/fs/_write.c" || fail "scall_write diagnostic not moved"
grep -Fq 'dprintk("Detected/managed RAM top: %dM\n", i/(1024*1024));' "$ROOT/kernel32/mm/scanmem.c" || fail "scanmem diagnostic not atomic dprintk"
grep -Fq 'dprintk("{%d}",jtmfs_structure.try);' "$ROOT/kernel32/fs/jtmfs/jtmfs.c" || fail "JTMFS try diagnostic not moved"
grep -Fq 'dprintk("syskeyb.c/kbwait: error, timeout occured\n");' "$ROOT/kernel32/drivers/keyboard/keyb.c" || fail "keyboard timeout diagnostic not moved"
for f in vga/vga.c ega/ega.c serial/serial_dev.c lpt/lpt.c zero/zero.c; do
    grep -Fq 'dprintk("cannot register device' "$ROOT/kernel32/drivers/$f" || fail "$f registration diagnostic not moved"
done

# Explicit interactive dump output should still use print(), proving no global print macro hijack.
grep -Fq 'print("End of IDT dump.\n");' "$ROOT/kernel32/core/int/int.c" || fail "interactive IDT dump no longer uses console print"
grep -Fq 'print("> [ Hit any key or [ESC] to break ]\r");' "$ROOT/kernel32/core/dataproc/hexdump.c" || fail "interactive hexdump no longer uses console print"
grep -Fq 'printf("ls: cannot read directory\n");' "$ROOT/kernel32/sh/lsapp.c" || fail "built-in ls errors are not user-visible"
! grep -Fq 'printk("%s", name);' "$ROOT/kernel32/sh/lsapp.c" || fail "built-in ls names are still routed to debug-only printk"
grep -Fq 'fd=findfirst("*",&ff);' "$ROOT/kernel32/sh/lsapp.c" || fail "built-in ls is not using snapshot directory API"

echo "V68.227 dprintk routing: PASS"
