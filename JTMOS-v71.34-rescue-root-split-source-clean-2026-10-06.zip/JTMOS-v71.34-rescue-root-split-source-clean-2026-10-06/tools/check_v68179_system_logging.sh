#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.179 system logging regression: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in
    68.179|68.18[0-9]|68.19[0-9]|68.[2-9][0-9][0-9]*|69.*|7[0-9].*) ;;
    *) fail "VERSION predates 68.179" ;;
esac
[ -f "$ROOT/RELEASE-V68.179.txt" ] || fail "release note missing"
LOG="$ROOT/kernel32/core/int/logging.c"
OPT="$ROOT/kernel32/init/keropt.c"
grep -Fq 'open(logging_syslog_path,O_WRONLY|O_CREAT|O_APPEND' "$LOG" || fail "system.log is not opened writable+append"
grep -Fq 'driver_getdevicenrbyname(dev)' "$LOG" || fail "target device lookup missing"
grep -Fq 'logging_activate_root("hda1:/",1)' "$LOG" || fail "hda1 JTMFS preference missing"
grep -Fq 'jtmfs_isDriveReady(dnr)' "$LOG" || fail "JTMFS readiness check missing"
grep -Fq 'SYSTEMLOGGING_FLUSH_SECONDS' "$LOG" || fail "configurable flush interval missing"
grep -Fq 'SYSTEMLOG_PRESSURE_BYTES' "$LOG" || fail "FIFO pressure flush missing"
grep -Fq 'int SYSTEMLOGGING_HDA1=' "$OPT" || fail "hda1 logging switch missing"
grep -Fq 'char *SYSTEMLOGGING_TARGET_ROOT=' "$OPT" || fail "target root option missing"
grep -Fq 'int SYSTEMLOGGING_FLUSH_SECONDS=' "$OPT" || fail "flush option missing"
echo "V68.179 RAM-buffered system logging regression: PASS"
