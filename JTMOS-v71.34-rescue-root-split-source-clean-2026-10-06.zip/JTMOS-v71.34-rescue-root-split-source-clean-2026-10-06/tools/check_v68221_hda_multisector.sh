#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.221 HDA multisector: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*) ;; *) fail "VERSION mismatch" ;; esac

M="$ROOT/kernel32/drivers/sata/mcp61.c"
H="$ROOT/kernel32/drivers/hd/hdDev.c"
P="$ROOT/kernel32/drivers/partsup/partsup.c"
DB="$ROOT/kernel32/fs/jtmfs/jtmfsDb.c"

# MCP61 must no longer deliberately emit one ATA command per sector.
grep -Fq '#define MCP61_SAFE_PIO_SECTORS' "$M" || fail "MCP61 bounded PIO fallback missing"
grep -Fq 'chunk=left>MCP61_SAFE_PIO_SECTORS ? MCP61_SAFE_PIO_SECTORS : left;' "$M" || fail "MCP61 bounded multi-sector chunking missing"
! grep -Fq 'if(write) chunk=1UL;' "$M" || fail "old one-sector write splitter remains"
grep -Fq 'if(!write && count==1 && first+1UL<mcpd.sectors)' "$M" || fail "MCP61 one-sector read-ahead missing"
grep -Fq 'memcpy(caller_buf,mcp61_read_ahead,512U);' "$M" || fail "MCP61 read-ahead does not return requested sector"
grep -Fq 'if(write && ata_flush()) return 1;' "$M" || fail "write-through flush lost"
grep -Fq '#define MCP61_READAHEAD_SECTORS 32UL' "$M" || fail "MCP61 16 KiB read-ahead window missing"
grep -Fq 'driver_enableDAPIWriteBackCache(dnr)' "$M" || fail "MCP61 DAPI write-back policy missing"

# Legacy IDE one-sector reads should also use a small sequential physical read.
grep -Fq '#define HD_READAHEAD_SECTORS 32U' "$H" || fail "legacy IDE 16 KiB read-ahead window missing"
grep -Fq 'if(rw==READ && chunk==1U && units==1' "$H" || fail "legacy IDE single-read widening missing"
grep -Fq 'sector+=chunk;' "$H" || fail "legacy IDE LBA progression missing"

grep -Fq '#define PARTSUP_MCP61_PARENT_SECTORS 64' "$P" || fail "partition MCP61 32 KiB logical batch missing"
grep -Fq '#define PARTSUP_LEGACY_PARENT_SECTORS 128' "$P" || fail "partition legacy 64 KiB logical batch missing"
grep -Fq 'done+=chunk;' "$P" || fail "partition LBA progression missing"

# V4 arena formatting was another real N x 1-sector write source.
grep -Fq 'writeblocks1(dnr,(long)start,zero,(int)blocks)' "$DB" || fail "V4 arena clear is not one multi-block request"
! grep -A8 'zero=(BYTE\*)malloc' "$DB" | grep -Fq 'writeblocks1(dnr,(long)(start+i),zero,1)' || fail "V4 arena still writes one sector at a time"

python3 "$ROOT/tests/hda_multisector_v68221.py"
echo "V68.221 HDA multisector/read-ahead regression: PASS"
