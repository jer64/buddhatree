#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "app layout: $*" >&2; exit 1; }

# V16.94: JTMOS native userspace has one physical source location only.
for p in apps tools/apps kernel32/apps gui tools/gui tools/gr tools/something tools/testi; do
    [ ! -e "$p" ] && [ ! -L "$p" ] || fail "$p must not exist; use libc/apps or libc/gui"
done
[ -d libc/apps ] || fail "libc/apps missing"
[ -d libc/apps/gui ] || fail "libc/apps/gui missing"
[ -d libc/gui ] || fail "libc/gui missing"
[ -f libc/apps/gui/terminal.c ] || fail "terminal source missing"
[ -f libc/apps/gui/controlpanel.c ] || fail "control panel source missing"
[ -f libc/apps/gui/launcher.c ] || fail "launcher source missing"
[ -f libc/apps/filer.c ] || fail "filer source missing"
[ -f libc/apps/sqsh.c ] || fail "SQSH source missing"
echo "canonical libc-only JTMOS application layout: PASS"
