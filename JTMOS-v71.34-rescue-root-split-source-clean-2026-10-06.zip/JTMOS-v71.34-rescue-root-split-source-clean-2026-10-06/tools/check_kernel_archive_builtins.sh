#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SH="$ROOT/kernel32/sh/sh.c"
SQ="$ROOT/libc/apps/sqsh.c"
PKG="$ROOT/tools/build_install_image.sh"
fail(){ echo "check_kernel_archive_builtins: FAIL: $*" >&2; exit 1; }

for cmd in sqa sqarc nzip; do
    grep -Fq "{\"$cmd\"," "$SH" || fail "$cmd missing from SMSH builtin table"
    grep -Eq "\"$cmd\".*NULL|\"$cmd\"," "$SH" || fail "$cmd missing from SMSH userspace whitelist"
    grep -Eq "\"$cmd\".*NULL|\"$cmd\"," "$SQ" || fail "$cmd missing from SQSH bridge list/help"
done

grep -Fq '"sqa","sqarc","nzip",NULL' "$SQ" || fail "SQSH does not route all archive commands through kernel bridge"
grep -Fq '"sqa","sqarc","nzip",NULL' "$SH" || fail "SMSH userspace whitelist missing archive command trio"
! grep -Fq 'sqa / unz / nzip   JTMOS archive/compression utilities' "$SQ" || fail "SQSH still documents sqa/nzip as external"

# V70.29+: utilities.iso is a package repository, never a mixed direct-bin root.
grep -Fq 'for f in "$PAYLOAD"/*.sqa' "$PKG" || fail "package-only outer staging loop missing"
grep -Fq 'EXPECTED_PACKAGES="core.sqa graos.sqa interpreters.sqa demos.sqa media.sqa network.sqa tests.sqa docs.sqa boot.sqa"' "$PKG" || fail "nine-package outer contract missing"
grep -Fq 'find "$BOOTSTRAP" -maxdepth 1 -type f ! -name' "$PKG" || fail "non-SQA outer rejection missing"
! grep -Fq 'OUTER_BIN_COUNT=' "$PKG" || fail "obsolete direct-bin outer accounting restored"
grep -Fq 'cbmvm-examples.sqa' "$PKG" || fail "CBMVM PRGs not grouped into nested archive"
! grep -Fq '$BOOTSTRAP/cbm-$(basename "$f")' "$PKG" || fail "PRGs copied to outer utilities root"

echo "check_kernel_archive_builtins: PASS (SMSH+SQSH builtins + SQA-only nine-package outer repository)"
