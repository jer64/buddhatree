#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)

python3 "$ROOT/tests/v704_nmi_cli_rescue.py"
python3 "$ROOT/tools/audit_nmi_safety.py"
sh "$ROOT/tools/check_v701_buildfix3_nmi_dosboot.sh"
sh -n "$ROOT/run_jtmos_qemu.sh"

echo "V70.4 NMI CLI rescue regression: PASS"
