#!/usr/bin/env bash
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python3 tests/bochsrc_v7026.py
bash -n run_jtmos_bochs.sh
printf 'PASS bash -n run_jtmos_bochs.sh\n'
