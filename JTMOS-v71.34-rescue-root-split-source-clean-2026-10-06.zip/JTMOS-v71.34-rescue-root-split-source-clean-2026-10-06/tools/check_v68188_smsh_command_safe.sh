#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
fail(){ echo "V68.188 SMSH command safety: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=188){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.188"
[ -f "$ROOT/RELEASE-V68.188.txt" ] || fail "release note missing"
S="$ROOT/kernel32/sh/sh.c"
grep -q 'src = line;' "$S" || fail "shared external dispatcher does not accept ordinary commands"
grep -Fq "if(*src == ':')" "$S" || fail "explicit colon stripping missing"
grep -q 'rc=smsh_launch_external(text);' "$S" || fail "noninteractive SMSH still bypasses direct launch"
grep -q 'if (smsh_launch_external(line) != 0)' "$S" || fail "interactive unknown command not direct-launched"
grep -q 'repaired IF=0 at command safe point' "$S" || fail "interactive IF safe point missing"
grep -q 'external dispatch repaired IF=0' "$S" || fail "external launch IF repair missing"
grep -q '__asm__ __volatile__("cld"' "$S" || fail "DF normalization missing"
# JTMOS fallback must not directly use system(line).  Host fallback may remain
# under #else for Linux testing, so require it to occur only after the JTMOS
# direct branch marker.
python3 - "$S" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
marker='Native SMSH then launches directly through Central Process.'
pos=s.find(marker)
assert pos >= 0
frag=s[pos:pos+700]
assert '#ifdef JTMOS' in frag and 'smsh_launch_external(line)' in frag
assert '#else' in frag and 'system(line)' in frag
# The old unconditional noninteractive fallback must be gone.
assert 'rc=system(text);' not in s
PY
echo "V68.188 SMSH command safety regression: PASS"
