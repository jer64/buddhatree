#!/bin/sh
set -eu
fail(){ echo "check_graos_maximize_terminal_session: FAIL: $*" >&2; exit 1; }

PROTO=libc/libc/include/jtmos/graosprotocol.h
GUI=libc/apps/gui

grep -q 'GRAOS_WINDOW_MAXIMIZE_BUTTON 1024' "$PROTO" || fail "maximize window flag missing"
grep -q 'GRAOS_WINDOW_STANDARD.*GRAOS_WINDOW_MAXIMIZE_BUTTON' "$PROTO" || fail "standard windows do not include maximize"
grep -q 'GRAOS_GSID_WINDOW_MAXIMIZED 46' "$PROTO" || fail "maximize event ABI missing"
grep -q 'char maximized;' "$GUI/window.h" || fail "WINDOW maximized state missing"
grep -q 'GRAOS_INTERNAL_MAXIMIZE_ID' "$GUI/window.h" || fail "maximize caption id missing"
grep -q 'GRAOS_WINDOW_MAXIMIZE_BUTTON)guiCreateButton' "$GUI/wdb.c" || fail "maximize caption control not created"
grep -q 'GRAOS_WINDOW_MAXIMIZE_BUTTON).*width-36' "$GUI/wdb.c" || fail "maximize caption hit box missing"
grep -q 'guiToggleMaximizeWindow' "$GUI/windowFunc.c" || fail "maximize handler missing"
grep -q 'GRAOS_GSID_WINDOW_MAXIMIZED' "$GUI/windowFunc.c" || fail "maximize event not queued"
grep -q 'w->tiled||w->maximized' "$GUI/windowDraw.c" || fail "terminal maximize scaling missing"
grep -q '~p).*0x00ffffffUL' "$GUI/windowDraw.c" || fail "full-cell block cursor inversion missing"
grep -q 'ctrl_c=ctrl&&c' "$GUI/guiLoop.c" || fail "raw Ctrl+C state missing"
grep -q 'if(ctrl_c && !old_ctrl_c) key=3' "$GUI/guiLoop.c" || fail "raw Ctrl+C edge not converted to ETX"
grep -q 'OutputTerminalKeyboardBuffer(w->terminal_id,3)' "$GUI/windowFunc.c" || fail "internal terminal close does not interrupt foreground child"
grep -q 'OutputTerminalKeyboardBuffer(ter,3)' "$GUI/terminal.c" || fail "external terminal close does not interrupt foreground child"
grep -q 'key==3.*JKEY_F10' libc/apps/editEditor.c || fail "edit.bin ETX/F10 exit handler missing"
grep -q 'THREAD_TYPE_SERVICE' kernel32/init/graos_boot.c || fail "boot GraOS lacks cross-process framebuffer capability"
grep -q 'THREAD_TYPE_SERVICE' kernel32/sh/graos_shell.c || fail "shell-launched GraOS lacks cross-process framebuffer capability"
grep -q '4UL \* 1024UL \* 1024UL' kernel32/core/int/scs.c || fail "copyfromthread framebuffer limit changed unexpectedly"

echo "check_graos_maximize_terminal_session: PASS (maximize + block cursor + terminal Ctrl+C/session + BGI service capability)"
