#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "V69.62/V70 launcher regression: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

has 'int autostart=' kernel32/init/keropt.c 'autostart setting missing'
has 'int VT2_BOOT_LAUNCHER_ENABLED=' kernel32/init/keropt.c 'legacy launcher enable setting missing'
has 'static int smsh_ensure_vt_launcher(int verbose)' kernel32/sh/sh.c 'independent VT launcher helper missing'
has '(void)smsh_ensure_vt_launcher(1);' kernel32/sh/sh.c 'boot/autostart launcher point missing'
has '(void)smsh_ensure_vt_launcher(0);' kernel32/sh/sh.c 'launcher prompt retry point missing'
has 'smsh_find_vt_launcher_executable' kernel32/sh/sh.c 'device-aware launcher resolver missing'
has 'const int launcher_terminal=JTMOS_VT_LAUNCHER;' kernel32/sh/sh.c 'launcher is not assigned to VT4 role'
has 'GetTerminalOwner(launcher_terminal)' kernel32/sh/sh.c 'launcher owner guard missing'
has 'SetTerminalOwner(launcher_terminal,pid)' kernel32/sh/sh.c 'launcher ownership publish missing'
has '#define VT_LAUNCHER_NUMBER 4' libc/apps/vt2.c 'launcher payload does not expect VT4'
has 'VT_LAST  7' libc/apps/vt2.c 'launcher terminal range changed unexpectedly'
has 'bgexecEx("sqsh.bin","",terminal)' libc/apps/vt2.c 'launcher no longer starts SQSH'
has 'vt2.bin' tools/build_install_image.sh 'legacy vt2.bin payload not retained in compact image'

# Critical regression: launch must not be gated solely by the broad autostart
# block. The first ensure call must occur before the `if(autostart...)` section.
python3 - "$ROOT/kernel32/sh/sh.c" <<'PY'
import sys
s=open(sys.argv[1]).read()
root=s.find('(void)smsh_ensure_vt_launcher(1);', s.find('int run_shell(void)'))
gate=s.find('if(autostart && !boot_ctrl_smsh_override)', s.find('int run_shell(void)'))
if root < 0 or gate < 0 or root > gate:
    raise SystemExit('recovery launcher remains gated by broad autostart')
PY

echo 'V69.62/V70 launcher regression: PASS (legacy payload, VT4 recovery role)'
