#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 - "$ROOT/VERSION" <<'PY' || { echo "V70.31 SQA program inventory: FAIL: VERSION" >&2; exit 1; }
import sys
v=tuple(int(x) for x in open(sys.argv[1]).read().strip().split('.'))
raise SystemExit(0 if v >= (70,31) else 1)
PY
[ -x "$ROOT/tools/sqarc" ] || { echo "V70.31 SQA program inventory: FAIL: sqarc missing" >&2; exit 1; }
for p in core graos interpreters demos media network tests; do
  [ -s "$ROOT/tools/install_payload/$p.sqa" ] || { echo "V70.31 SQA program inventory: FAIL: $p.sqa missing" >&2; exit 1; }
done
exec "$ROOT/tools/check_v7031_complete_sqa_programs.py" \
  --payload "$ROOT/tools/install_payload" --apps "$ROOT/libc/apps" --gui "$ROOT/libc/apps/gui"
