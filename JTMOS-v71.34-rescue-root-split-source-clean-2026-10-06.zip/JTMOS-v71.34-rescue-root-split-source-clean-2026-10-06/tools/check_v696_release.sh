#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.6 release: FAIL: $*" >&2; exit 1; }
[ "$(cat "$ROOT/VERSION")" = "69.6" ] || fail "VERSION mismatch"
grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.6"' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
grep -Fq 'Current release: **V69.6**.' "$ROOT/VERSIONING.md" || fail "VERSIONING current release mismatch"
grep -Fq 'Current normal release: **V69.6**.' "$ROOT/VERSIONING.md" || fail "VERSIONING normal release mismatch"
[ -f "$ROOT/RELEASE-V69.6.txt" ] || fail "release notes missing"
"$ROOT/tools/check_v692_du_terminal_path.sh"
"$ROOT/tools/check_v693_jtmfs_reiser.sh"
"$ROOT/tools/check_v694_jtmfs_atomic_jtmfsck.sh"
"$ROOT/tools/check_v695_jtmfs_index_blockcache.sh"
"$ROOT/tools/check_v696_ring3_containment.sh"
echo "V69.6 release: PASS"
