#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APPS="$ROOT/libc/apps"

# One canonical Ring3 userspace tree. libc/apps/gui contains GraOS itself and
# the native Terminal/Control Panel/Launcher clients.
${MAKE:-make} --no-print-directory -C "$APPS" clean
${MAKE:-make} --no-print-directory -C "$APPS" check

for f in unz.bin sqa.bin pkg.bin nzip.bin ls.bin cp.bin df.bin du.bin hdbench.bin edit.bin filer.bin iview.bin top.bin sound.bin irqdma.bin unique.bin irc.bin; do
    [ -s "$APPS/$f" ] || { echo "build_release_apps: $f was not built" >&2; exit 1; }
done

# These applications are intentionally CD-ROM utilities only.  Keep the gate
# here so a successful release build guarantees utilities.iso can contain them.
for app in $(${MAKE:-make} --no-print-directory -s -C "$APPS" list-utilities); do
    f="$app.bin"
    [ -s "$APPS/$f" ] || { echo "build_release_apps: utilities-only $f was not built" >&2; exit 1; }
done
for f in graos.bin terminal.bin tm.bin controlpanel.bin graosctl.bin launcher.bin labeldemo.bin bitmapdemo.bin graostaskbar.bin textboxdemo.bin; do
    [ -s "$APPS/gui/$f" ] || { echo "build_release_apps: gui/$f was not built" >&2; exit 1; }
done
