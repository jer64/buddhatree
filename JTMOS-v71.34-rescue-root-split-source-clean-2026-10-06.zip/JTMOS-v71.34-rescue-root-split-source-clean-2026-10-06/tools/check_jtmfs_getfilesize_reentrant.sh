#!/bin/sh
set -eu
fail(){ echo "check_jtmfs_getfilesize_reentrant: FAIL: $*" >&2; exit 1; }

J=kernel32/fs/jtmfs/jtmfs.c
D=kernel32/fs/jtmfs/diskcache/dirdbFind.c
H=kernel32/fs/jtmfs/diskcache/dirdbFind.h

grep -Fq 'return dirdb_GetFileLength(dnr,fname,db);' "$J" || fail "jtmfs_getfilesize does not use atomic DirDB metadata lookup"
if sed -n '/int jtmfs_getfilesize/,/^}/p' "$J" | grep -Eq '^[[:space:]]*static[[:space:]]+DIRWALK'; then
    fail "jtmfs_getfilesize still has shared static DIRWALK"
fi
grep -Fq 'int dirdb_GetFileLength(int dnr, const char *fname, int db)' "$D" || fail "DirDB file-length helper missing"
grep -Fq 'dir=dbGiveDir(dnr,db,DIRDB_KIND_DIRECTORY);' "$D" || fail "atomic cache re-acquire missing"
grep -Fq 'flags=get_eflags();' "$D" || fail "single-CPU critical section missing"
grep -Fq 'set_eflags(flags);' "$D" || fail "critical section does not restore flags"
grep -Fq 'int dirdb_GetFileLength(int dnr, const char *fname, int db);' "$H" || fail "DirDB helper prototype missing"

echo "check_jtmfs_getfilesize_reentrant: PASS (no shared DIRWALK size race)"
