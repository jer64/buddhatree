#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.210 crash analysis: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.210|68.211|68.212|68.213|68.214|68.215|68.216|68.217|68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|7[0-9].*) ;; *) fail "VERSION is not V68.210-compatible" ;; esac
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"

C="$ROOT/kernel32/core/int/crash_analysis.c"
H="$ROOT/kernel32/core/int/crash_analysis.h"
[ -f "$C" ] && [ -f "$H" ] || fail "crash analysis source/header missing"

# The immediate exception-side capture must be fixed-RAM only.
grep -Fq 'void CrashAnalysisCaptureException(' "$C" || fail "capture entry missing"
CAP=$(sed -n '/^void CrashAnalysisCaptureException(/,/^}/p' "$C")
printf '%s\n' "$CAP" | grep -Fq 'crash_records[slot]' || fail "fixed crash slots not used"
! printf '%s\n' "$CAP" | grep -Eq '\b(malloc|calloc|realloc|free|open|write|close|Lock|WaitFor)\s*\(' || fail "capture path performs allocation/filesystem/ordinary lock operation"
grep -Fq 'crash_serial_snapshot(r);' "$C" || fail "fatal-safe serial snapshot missing"

# Exception handler must capture before disposition and retain V68.209 containment.
grep -Fq 'CrashAnalysisCaptureException(s,exception.code,pid,&crash_frame,ts);' "$ROOT/kernel32/core/cp/gpf.c" || fail "exception capture hook missing"
grep -Fq 'CrashAnalysisSetDisposition(pid,CRASH_DISPOSITION_FATAL);' "$ROOT/kernel32/core/cp/gpf.c" || fail "fatal disposition hook missing"
grep -Fq 'CrashAnalysisSetDisposition(pid,CRASH_DISPOSITION_QUARANTINE);' "$ROOT/kernel32/core/cp/gpf.c" || fail "quarantine disposition hook missing"
grep -Fq 'ThreadQuarantineFromException(pid);' "$ROOT/kernel32/core/cp/gpf.c" || fail "V68.209 containment missing"

# Causal history hooks.
grep -Fq 'CrashAnalysisTraceSyscall(' "$ROOT/kernel32/core/int/scs.c" || fail "syscall history hook missing"
grep -Fq 'CrashAnalysisTraceSwitch(old_pid,new_pid);' "$ROOT/kernel32/core/cp/scheduler.c" || fail "context-switch history hook missing"
grep -Fq 'CrashAnalysisTraceLock(' "$ROOT/kernel32/core/int/lock.c" || fail "lock history hook missing"

# The exception path already copies task metadata into fixed crash_records.
# Reap resource owners before persistence so storage/JTMFS locks cannot remain
# owned by the quarantined task while the snapshot writer runs.
FLUSH_LINE=$(grep -n 'CrashAnalysisFlushPending();' "$ROOT/kernel32/core/int/IdleThread.c" | head -1 | cut -d: -f1)
REAP_LINE=$(grep -n 'ThreadReapQuarantined();' "$ROOT/kernel32/core/int/IdleThread.c" | head -1 | cut -d: -f1)
[ -n "$FLUSH_LINE" ] && [ -n "$REAP_LINE" ] || fail "idle flush/reap hooks missing"
[ "$REAP_LINE" -lt "$FLUSH_LINE" ] || fail "quarantined resources are not reaped before crash persistence"

# Dedicated persistent log and emergency serial fallback.
grep -Fq '#define CRASHLOG_NAME "crash.log"' "$ROOT/kernel32/core/int/logging.c" || fail "dedicated crash.log missing"
grep -Fq 'ksetglobalenv("CRASH_LOG",logging_crashlog_path,1)' "$ROOT/kernel32/core/int/logging.c" || fail "CRASH_LOG environment export missing"
grep -Fq 'int WriteCrashLogRaw(' "$ROOT/kernel32/core/int/logging.c" || fail "crash log writer missing"
for marker in '[CRASH-BEGIN]' '[CRASH-FRAME]' '[CRASH-REGS]' '[CRASH-SC]' '[CRASH-SW]' '[CRASH-LK]' '[CRASH-END-SNAPSHOT]' '[CRASH-DISPOSITION]'; do
    grep -Fq "$marker" "$C" || fail "serial marker missing: $marker"
done

grep -Fq 'SUSPECT: near-NULL pointer access' "$C" || fail "page-fault near-NULL heuristic missing"
grep -Fq 'fault occurred with IF=0' "$C" || fail "IF=0 heuristic missing"
grep -Fq 'MAP-HINT:' "$C" || fail "map hint missing"
[ -f "$ROOT/tools/crash_decode.py" ] || fail "host crash decoder missing"
[ -f "$ROOT/docs/CRASH-ANALYSIS.md" ] || fail "crash analysis documentation missing"
sh "$ROOT/tools/check_v68210_crash_decode.sh"

echo "V68.210 crash analysis regression: PASS"
