#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 "$ROOT/tests/v7015_smallfile_pipeline.py"
make -C "$ROOT/libc/apps" -f jtmfsbench.mak syntax >/dev/null
echo "check_v7015_smallfile_pipeline: PASS"
