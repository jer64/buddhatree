#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-copyall-recursive-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/src/a/b" "$TMP/dst"
printf 'root-file\n' > "$TMP/src/root.txt"
printf 'nested-a\n' > "$TMP/src/a/a.txt"
printf 'nested-b\n' > "$TMP/src/a/b/b.txt"
: > "$TMP/src/a/empty.bin"
cat > "$TMP/main.c" <<'EOC'
#include <stdio.h>
int copyall_main(int argc,char **argv);
int main(int argc,char **argv){ return copyall_main(argc,argv); }
EOC
cc -std=gnu89 -Wall -Wextra -O2 -o "$TMP/copyall-host" \
   "$TMP/main.c" "$ROOT/kernel32/sh/copyall.c"
(
  cd "$TMP/dst"
  "$TMP/copyall-host" -r "$TMP/src"
)
cmp "$TMP/src/root.txt" "$TMP/dst/root.txt"
cmp "$TMP/src/a/a.txt" "$TMP/dst/a/a.txt"
cmp "$TMP/src/a/b/b.txt" "$TMP/dst/a/b/b.txt"
test -f "$TMP/dst/a/empty.bin"
test ! -s "$TMP/dst/a/empty.bin"
# Without -r, only top-level regular files are copied.
rm -rf "$TMP/dst" && mkdir "$TMP/dst"
(
  cd "$TMP/dst"
  "$TMP/copyall-host" "$TMP/src"
)
cmp "$TMP/src/root.txt" "$TMP/dst/root.txt"
test ! -e "$TMP/dst/a"
echo "check_copyall_recursive: PASS (-r preserves nested directories/files; default remains non-recursive)"
