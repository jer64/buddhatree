#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
python3 "$ROOT/tests/mm_multitask_mutex_v691.py"
echo "V69.1 MM/multitasking mutex gate: PASS"
