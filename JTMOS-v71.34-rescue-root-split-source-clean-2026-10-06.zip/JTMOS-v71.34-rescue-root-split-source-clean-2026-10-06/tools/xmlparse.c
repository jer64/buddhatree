/* XML init parser/generator for JTMOS. */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#define XMLPARSE_BUFSIZE 8192

static int getStringInsideDefinition(const char *str, char *funcName,
    size_t funcNameSize, char definitionChar)
{
    size_t i, i2, l;

    if (str == NULL || funcName == NULL || funcNameSize == 0)
        return -1;

    l = strlen(str);
    for (i = 1, i2 = 0;
         i < l && str[i] != definitionChar && i2 + 1 < funcNameSize;
         ++i, ++i2) {
        funcName[i2] = str[i];
    }
    funcName[i2] = '\0';

    if (i >= l || str[i] != definitionChar)
        return -1;
    return 0;
}


static int valid_c_identifier(const char *s)
{
    size_t i;
    unsigned char c;
    if(s==NULL || s[0]=='\0') return 0;
    c=(unsigned char)s[0];
    if(!(isalpha(c) || c=='_')) return 0;
    for(i=1; s[i]; ++i) {
        c=(unsigned char)s[i];
        if(!(isalnum(c) || c=='_')) return 0;
    }
    return 1;
}

static int parse_file(const char *fname, int verbose)
{
    FILE *f;
    char str[XMLPARSE_BUFSIZE];
    char tmp[XMLPARSE_BUFSIZE];
    char str2[XMLPARSE_BUFSIZE];
    char funcName[XMLPARSE_BUFSIZE];
    int element_nr = 0;
    int l_element_nr = 0;

    if (fname == NULL)
        return 1;

    f = fopen(fname, "rb");
    if (f == NULL)
        return 2;

    while (fgets(tmp, sizeof(tmp), f) != NULL) {
        str[0] = '\0';
        str2[0] = '\0';
        (void)sscanf(tmp, "%8191s %8191s", str, str2);

        if (verbose >= 1)
            fprintf(stderr, "str=%s, str2=%s\n", str, str2);

        if (str[0] == '<' && str[1] != '\0' &&
            isalnum((unsigned char)str[1])) {
            l_element_nr = element_nr;
            ++element_nr;

            if (verbose >= 1)
                fprintf(stderr, "element_nr=%d, l_element_nr=%d\n",
                    element_nr, l_element_nr);

            if (element_nr == 2 && l_element_nr == 1) {
                if (getStringInsideDefinition(str, funcName,
                    sizeof(funcName), '>') != 0) {
                    fclose(f);
                    return 3;
                }
                if (!valid_c_identifier(funcName)) {
                    fprintf(stderr, "xmlparse: invalid init function name: %s\n", funcName);
                    fclose(f);
                    return 6;
                }
                fprintf(stdout,
                    "static int %s_once;\n"
                    "//\nint %s(void)\n{\n"
                    "\tif(%s_once) return 0;\n"
                    "\t%s_once=1;\n",
                    funcName, funcName, funcName, funcName);
            }

            if (element_nr == 3) {
                if (getStringInsideDefinition(str, funcName,
                    sizeof(funcName), '>') != 0) {
                    fclose(f);
                    return 3;
                }
                if (!valid_c_identifier(funcName)) {
                    fprintf(stderr, "xmlparse: invalid init step name: %s\n", funcName);
                    fclose(f);
                    return 6;
                }
                fprintf(stdout, "\t%s();\n", funcName);
            }
        }

        if (str[0] == '<' && str[1] == '/') {
            l_element_nr = element_nr;
            --element_nr;
            if (element_nr < 0) {
                fclose(f);
                return 4;
            }

            if (element_nr == 1 && l_element_nr == 2)
                fprintf(stdout, "\treturn 0;\n}\n\n");
        }
    }

    fclose(f);
    return element_nr == 0 ? 0 : 5;
}

int main(int argc, char **argv)
{
    int verbose = 0;
    int i;

    if (argc < 2) {
        fprintf(stderr, "Usage: xmlparse [-v|-vv|-vvv] xml-file > output.c\n");
        return 1;
    }

    for (i = 1; i < argc && argv[i][0] == '-'; ++i) {
        if (strcmp(argv[i], "-v") == 0)
            verbose = 1;
        else if (strcmp(argv[i], "-vv") == 0)
            verbose = 2;
        else if (strcmp(argv[i], "-vvv") == 0)
            verbose = 3;
        else {
            fprintf(stderr, "xmlparse: unknown option: %s\n", argv[i]);
            return 1;
        }
    }

    if (i >= argc) {
        fprintf(stderr, "xmlparse: missing XML input file\n");
        return 1;
    }

    return parse_file(argv[i], verbose);
}
