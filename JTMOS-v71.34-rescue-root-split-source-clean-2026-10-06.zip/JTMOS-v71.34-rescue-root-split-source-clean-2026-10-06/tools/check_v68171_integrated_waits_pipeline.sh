#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

python3 "$ROOT/tests/integrated_waits_pipeline_v68171.py"

# Source-level guardrails for the release-critical fixes.
grep -q 'sh_launch_builtin_pipe_worker(command,stdin_fd,stdout_fd,&pid)' "$ROOT/kernel32/sh/sh.c"
grep -q 'smsh_pipe_worker_for_stack(esp)' "$ROOT/kernel32/sh/sh.c"
grep -q 'kgetglobalenv("PATH",envpath,sizeof(envpath))' "$ROOT/kernel32/sh/sh.c"
grep -q 'void SchedulerWaitPause(DWORD usec)' "$ROOT/kernel32/core/cp/scheduler.c"
grep -q 'pci_set_intx_disabled(d,1)' "$ROOT/kernel32/drivers/tcpip/nforce.c"
grep -q 'jnet_irq_snapshot("ping-pre-tx")' "$ROOT/kernel32/drivers/tcpip/jnet.c"

echo 'V68.171 integrated waits/pipeline/netdiag regression: PASS'
