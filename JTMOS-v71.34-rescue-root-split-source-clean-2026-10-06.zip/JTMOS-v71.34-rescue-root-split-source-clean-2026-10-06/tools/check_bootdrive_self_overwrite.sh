#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
F="$ROOT/boot32pm/bootmod.inc"
H="$ROOT/boot32/header.inc"
fail(){ echo "check_bootdrive_self_overwrite: FAIL: $*" >&2; exit 1; }

grep -Fq 'bootdrive_header_default db 0x80' "$H" || fail "historical header bootdrive byte missing/renamed unexpectedly"
grep -Fq 'mov byte [cs:runtime_bootdrive],dl' "$F" || fail "BIOS DL is not captured into stage1 runtime state"
! grep -Fq '[cs:bootdrive]' "$F" || fail "legacy header bootdrive is still used for runtime I/O"
python3 - "$F" <<'PY2'
import re,sys
s=open(sys.argv[1]).read()
# The runtime byte itself must physically belong to the MBR-resident stage1,
# not merely be referenced from it.  Sector 2..18 loads overwrite everything
# after the first sector, so a later variable cannot preserve BIOS DL.
r=s.find('runtime_bootdrive:')
b=s.find('TIMES 446-($-$$)')
if r < 0: raise SystemExit('runtime_bootdrive label missing')
if b < 0: raise SystemExit('MBR TIMES 446 boundary missing')
if r >= b: raise SystemExit('runtime_bootdrive is not resident before byte 446')

m=re.search(r'Loader_1\.44M:(.*?)(?=\n;[-]+\nprhex16:)',s,re.S)
if not m: raise SystemExit('floppy stage1 block missing')
fb=m.group(1)
for x in ('mov bx,0x0300','mov cx,0x0002','mov ax,0x0211'):
    if x not in fb: raise SystemExit('missing '+x)
for x in ('mov bx,0x0100','mov cx,0x0001','mov ax,0x0212'):
    if x in fb: raise SystemExit('floppy still rereads resident sector 1: '+x)
if not re.search(r'xor ax,ax\s+mov dl,byte \[cs:runtime_bootdrive\]\s+int 0x13',fb):
    raise SystemExit('floppy reset does not use stage1 runtime bootdrive')

# HDD self-copy rereads sector 1 and therefore must explicitly preserve the
# stage1 runtime byte around the copy.
h=re.search(r'nerr100:(.*?)(?=\n\s*; The first track now contains)',s,re.S)
if not h: raise SystemExit('HDD self-copy block missing')
hb=h.group(1)
for x in ('mov al,byte [cs:runtime_bootdrive]','push ax','pop ax','mov byte [cs:runtime_bootdrive],al'):
    if x not in hb: raise SystemExit('HDD self-copy missing '+x)

# Every current runtime disk-I/O reference in the maintained file must use the
# resident byte.  The historical header field remains only as on-disk data.
if '[cs:bootdrive]' in s:
    raise SystemExit('legacy bootdrive runtime reference remains')
PY2

echo "check_bootdrive_self_overwrite: PASS (runtime DL is stage1-resident before byte 446; later loader sectors cannot overwrite it)"
