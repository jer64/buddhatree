#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

list=${TMPDIR:-/tmp}/jtmos-restore-exec.$$.list
trap 'rm -f "$list"' EXIT HUP INT TERM
find . -type f -print | LC_ALL=C sort > "$list"
count=0
while IFS= read -r f; do
    sig=$(dd if="$f" bs=2 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
    [ "$sig" = 2321 ] || continue
    chmod a+x "$f"
    count=$((count + 1))
done < "$list"
echo "restored executable mode on $count shebang files"
