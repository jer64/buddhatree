#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.182 RTC/I-O deadline regression: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=182){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.182"
[ -f "$ROOT/RELEASE-V68.182.txt" ] || fail "release note missing"
[ -f "$ROOT/docs/RTC-IO-DEADLINES-V68.182.md" ] || fail "deadline document missing"

grep -q 'typedef struct.*RTC_IO_DEADLINE' "$ROOT/kernel32/drivers/cmos/rtc.h" 2>/dev/null || \
  grep -q 'RTC_IO_DEADLINE' "$ROOT/kernel32/drivers/cmos/rtc.h" || fail "RTC_IO_DEADLINE missing"
grep -q 'rtc_io_deadline_expired' "$ROOT/kernel32/drivers/cmos/rtc.c" || fail "deadline implementation missing"
grep -q 'rtc_io_deadline_expired(&deadline)' "$ROOT/kernel32/drivers/floppy/fdc.c" || fail "FDC not protected"
grep -q 'KernelInitIRQCheckpoint("FDC")' "$ROOT/kernel32/init/init.c" || fail "FDC IRQ checkpoint missing"
grep -q 'KernelInitIRQCheckpoint("ATA/SATA")' "$ROOT/kernel32/init/init.c" || fail "ATA/SATA IRQ checkpoint missing"
grep -q 'KernelInitIRQCheckpoint("ATAPI")' "$ROOT/kernel32/init/init.c" || fail "ATAPI IRQ checkpoint missing"
grep -q 'UsecSleep: early/storage-safe timeout' "$ROOT/kernel32/core/int/pit.c" || fail "UsecSleep hard timeout missing"
for f in \
  kernel32/drivers/hd/hdDetect.c \
  kernel32/drivers/hd/hdMisc.c \
  kernel32/drivers/hd/hdReset.c \
  kernel32/drivers/atapi/atapi.c \
  kernel32/drivers/sata/ahci.c \
  kernel32/drivers/sata/mcp61.c \
  kernel32/drivers/keyboard/keyb.c \
  kernel32/drivers/serial/serial.c \
  kernel32/drivers/sb/sb.c \
  kernel32/drivers/tcpip/ne2k.c \
  kernel32/drivers/tcpip/nforce.c \
  kernel32/drivers/lpt/lpt.c
do
  grep -q 'rtc_io_deadline_' "$ROOT/$f" || fail "$f has no RTC I/O deadline"
done

# V68.217 replaced ethdev's private timed polling lock with the common Linux-
# style mutex. Hardware polling deadlines remain in both concrete backends;
# atomic ethdev callers use trylock and therefore remain bounded.
grep -q 'DEFINE_MUTEX(ethdev_mutex)' "$ROOT/kernel32/drivers/tcpip/ethdev.c" || fail "ethdev mutex missing"
grep -q 'mutex_trylock(&ethdev_mutex)' "$ROOT/kernel32/drivers/tcpip/ethdev.c" || fail "ethdev atomic trylock missing"

echo "V68.182 RTC/I-O deadline regression: PASS"
