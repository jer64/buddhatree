#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
K="$ROOT/kernel32/drivers/keyboard/keyb.c"
T="$ROOT/kernel32/drivers/term/term.c"
E="$ROOT/kernel32/drivers/ega/ega.c"
V="$ROOT/kernel32/drivers/vga/vga.c"
D="$ROOT/kernel32/core/dispadmin/dispadmin.c"
fail(){ echo "check_alt_fn_text_vt: FAIL: $*" >&2; exit 1; }

# Fresh BIOS/non-VBE boot must already be known as native 80x25 mode 03h.
grep -Eq 'static DISPADMIN ds[[:space:]]*=[[:space:]]*\{[[:space:]]*0x03,[[:space:]]*80,[[:space:]]*25,[[:space:]]*4[[:space:]]*\}' "$D" || fail "DISPADMIN does not default to VGA mode 03h"

# Raw IRQ1 MAKE handling must use Left Alt and the contiguous F1..F7 set,
# before normal translation/GraOS Alt+F4 routing.
grep -q 'keyb_handle_alt_function_terminal' "$K" || fail "Alt+Fn raw handler missing"
grep -q 'kbstr.ktab\[SCODE_LEFTALT\]' "$K" || fail "Left Alt state is not checked"
grep -q 'scancode < SCODE_F1 || scancode > SCODE_F7' "$K" || fail "F1..F7 range guard missing"
grep -q 'SwitchEgaFunctionTerminal(function_key)' "$K" || fail "raw handler does not switch function-key VT"
line_hot=$(grep -n 'keyb_handle_alt_function_terminal((BYTE)sc,was_down)' "$K" | head -1 | cut -d: -f1)
line_xlt=$(grep -n 'translate_keyboard_situation();' "$K" | head -1 | cut -d: -f1)
[ "$line_hot" -lt "$line_xlt" ] || fail "Alt+Fn is handled after normal key translation"

# Native mode-03h and virtual VGA/LFB text rendering must both accept Alt+Fn.
grep -q 'int VgaFunctionTerminalHotkeysActive(void)' "$V" || fail "generic text-console hotkey guard missing"
grep -q 'if(vesa_enabled)' "$V" || fail "VESA ownership guard missing"
grep -q 'vesa_text_console_enabled ? 1 : 0' "$V" || fail "virtual VGA/LFB text guard missing"
grep -q 'if(graphicModeActive)' "$V" || fail "non-VESA graphics guard missing"
# V68.165 deliberately does not require dispadmin_getcurrentmode()==MODE03H
# here: BIOS/HDD handoff metadata may lag the console that actually owns VGA.

# F1..F7 map exactly to terminal indexes 0..6. Native mode uses CRTC pages;
# virtual VGA changes the logical visible terminal and refreshes the LFB.
grep -q 'which=function_key-1' "$E" || fail "F-key to VT index mapping missing"
grep -q 'EgaSelectWindow(which)' "$E" || fail "EGA function selector does not select hardware page"
grep -q 'which=function_key-1' "$T" || fail "terminal focus mapping differs from EGA mapping"
grep -q 'if(VgaEgaTextConsoleActive())' "$T" || fail "native EGA branch missing"
grep -q 'r=SetVisibleTerminal(which)' "$T" || fail "virtual VGA/LFB visible-terminal switch missing"
grep -q 'SetInputTerminal(which)' "$T" || fail "keyboard focus does not follow selected VT"
grep -q 'if(vesa_enabled)' "$T" || fail "VESA visible-terminal refresh guard missing"
grep -q 'VesaTextConsoleRefresh()' "$T" || fail "virtual VGA/LFB repaint missing"

echo "check_alt_fn_text_vt: PASS (Left Alt+F1..F7 => VT1..VT7 in native EGA and virtual VGA/LFB text consoles)"
