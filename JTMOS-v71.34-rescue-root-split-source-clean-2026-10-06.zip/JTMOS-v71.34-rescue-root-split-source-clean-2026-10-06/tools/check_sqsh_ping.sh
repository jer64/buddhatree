#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_sqsh_ping: FAIL: $*" >&2; exit 1; }
SQSH=libc/apps/sqsh.c
SH=kernel32/sh/sh.c
NET=kernel32/sh/networkapp.c
JNET=kernel32/drivers/tcpip/jnet.c

grep -Eq '"lspci".*"ping"' "$SQSH" || fail "SQSH does not recognize ping as an internal command"
grep -Fq '"ping","internet","inet"' "$SQSH" || fail "SQSH does not expose Internet status/control"
grep -Fq '"www","host","nutget","copyall"' "$SQSH" || fail "SQSH does not expose WWW/DNS status commands"
grep -Fq 'ping [-c COUNT] [HOST|IPv4|gateway]' "$SQSH" || fail "SQSH help lacks host/IPv4/gateway ping syntax"
grep -Fq 'ping -c 4 example.com  test DHCP, DNS, routing and ICMP Echo' "$SQSH" || fail "SQSH getting-started help lacks end-to-end Internet test"

grep -Eq '"graos".*"gui".*"ping"' "$SH" || fail "restricted kernel builtin whitelist does not export ping"
grep -Fq '"ping","internet"' "$SH" || fail "restricted kernel builtin whitelist does not export network controls"
grep -Eq '"inet".*"www".*"host".*"nutget".*"copyall"' "$SH" || fail "restricted kernel builtin whitelist does not export WWW/DNS controls"
grep -Fq 'SetTerminalForegroundProcess(terminal,GetCurrentThread())' "$NET" || fail "ping builtin does not own task-terminal foreground work"
! grep -Fq 'SetTerminalForegroundProcess(input_terminal,GetCurrentThread())' "$NET" || fail "ping must not capture active input-terminal foreground"
! grep -Fq 'ping_drain_terminal_keys' "$NET" || fail "ping still drains/discards ordinary keyboard input"
grep -Fq 'SetTerminalForegroundProcess(terminal,saved_foreground>0?saved_foreground:0)' "$NET" || fail "task-terminal foreground PID is not restored after ping"

grep -Fq 'if(!nc->configured)' "$NET" || fail "ping does not check active DHCP/static IPv4 configuration"
grep -Fq 'if(!strcmp(target,"gateway"))' "$NET" || fail "configured gateway target support missing"
grep -Fq 'jnet_host_request(target,3000,&host_result)' "$NET" || fail "ping hostname does not use DHCP-provided DNS resolver"
grep -Fq 'jnet_ping_request_ex(ip,2000,(WORD)seq,&rtt,&ttl)' "$NET" || fail "ping does not use JNET ICMP request API"
grep -Fq 'icmp_seq=%d ttl=%u time=%lu ms' "$NET" || fail "reply output lacks seq/ttl/rtt"
grep -Fq 'ping statistics' "$NET" || fail "ping summary missing"
grep -Fq 'ping_interrupted(&eof_requested)' "$NET" || fail "Ctrl+C/Ctrl+D handling missing"
grep -Fq 'ip[9]=1' "$JNET" || fail "JNET ping packet is not ICMP"
grep -Fq 'ic[0]=8' "$JNET" || fail "JNET packet is not ICMP Echo Request"
grep -Fq 'static int route_hop' "$JNET" || fail "shared IPv4 route helper missing"
grep -Fq 'if(same_subnet(target,cfg.ip,cfg.mask))' "$JNET" || fail "route helper does not apply configured netmask"
grep -Fq 'memcpy(hop,cfg.gateway,4)' "$JNET" || fail "off-subnet target does not route through configured gateway"

echo "check_sqsh_ping: PASS (SQSH builtin -> DHCP/DNS/JNET/uIP ICMP + routing + Ctrl+C)"
