#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_console_profile_config: FAIL: $*" >&2; exit 1; }

M=Makefile
A=kernel32/autogen.pl
K=kernel32/init/keropt.c
H=kernel32/console_profile.generated.h
TMP=${TMPDIR:-/tmp}/jtmos-console-profile-$$.mak
trap 'rm -f "$TMP" kernel32/generated.mak kernel32/modules.generated.h kernel32/console_profile.generated.h kernel32/init/keropt.o' EXIT HUP INT TERM

# Top-level profile mapping and explicit Linode target.
grep -Fq 'KERNEL_SERIAL_CONSOLE_REDIRECT ?= 0' "$M" || fail "text profile serial redirect default is not 0"
grep -Fq 'KERNEL_VESA_EARLY_SERIAL_ONLY ?= 0' "$M" || fail "text profile VESA serial-only default is not 0"
grep -Fq 'KERNEL_SERIAL_CONSOLE_REDIRECT ?= 1' "$M" || fail "VESA profile serial redirect default is not 1"
grep -Fq 'KERNEL_VESA_EARLY_SERIAL_ONLY ?= 1' "$M" || fail "VESA profile VESA serial-only default is not 1"
grep -Fq 'image-linode:' "$M" || fail "image-linode target missing"
grep -Eq 'image-linode:|KERNEL_SERIAL_CONSOLE_REDIRECT=0.*KERNEL_VESA_EARLY_SERIAL_ONLY=0.*image' "$M" || fail "image-linode target/0/0 console defaults missing"
grep -Eq 'KERNEL_SERIAL_CONSOLE_REDIRECT=0.*KERNEL_VESA_EARLY_SERIAL_ONLY=0.*KERNEL_MODULE_CONFIG=modules\.linode\.conf.*rootimage rootdisk utilscdrom' "$M" || fail "image-linode does not lock 0/0 console defaults with Linode module profile"

grep -Fq '#include "console_profile.generated.h"' "$K" || fail "keropt does not consume generated console profile"
grep -Fq 'JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT' "$K" || fail "serial_console_redirect is still hard-coded"
grep -Fq 'JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT' "$K" || fail "vesa_early_serial_only is still hard-coded"
grep -Fq "init/keropt.c') ? ' console_profile.generated.h'" "$A" || fail "keropt object does not depend on generated profile header"

# Exercise autogen's actual profile contract.
(
    cd kernel32
    JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT=0 JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT=0 ./autogen.pl > "$TMP"
)
grep -Fq '#define JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT 0' "$H" || fail "headless serial default not generated as 0"
grep -Fq '#define JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT 0' "$H" || fail "headless VESA serial-only default not generated as 0"
grep -Fq 'init/keropt.o: init/keropt.c modules.generated.h include/memory_layout.h console_profile.generated.h' "$TMP" || fail "generated keropt dependency missing"

(
    cd kernel32
    JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT=1 JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT=1 ./autogen.pl > "$TMP"
)
grep -Fq '#define JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT 1' "$H" || fail "VESA serial default not generated as 1"
grep -Fq '#define JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT 1' "$H" || fail "VESA serial-only default not generated as 1"

if (cd kernel32 && JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT=2 ./autogen.pl >/dev/null 2>&1); then
    fail "invalid console boolean was accepted"
fi

# Restore the source-release/headless generated state for callers that inspect it.
(
    cd kernel32
    JTMOS_SERIAL_CONSOLE_REDIRECT_DEFAULT=0 JTMOS_VESA_EARLY_SERIAL_ONLY_DEFAULT=0 ./autogen.pl > "$TMP"
)

echo "check_console_profile_config: PASS (Linode/text 0/0; VESA 1/1; profile-dependent keropt rebuild)"
