#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
LOCKH="$ROOT/kernel32/core/int/lock.h"
LOCKC="$ROOT/kernel32/core/int/lock.c"
SYSC="$ROOT/kernel32/core/int/system_call.c"
SCS="$ROOT/kernel32/core/int/scs.c"
JTMFS="$ROOT/kernel32/fs/jtmfs/jtmfs.c"
JTMFAT="$ROOT/kernel32/fs/jtmfs/jtmfat.c"
DIRDB="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbAccess.c"
DLOCK="$ROOT/kernel32/drivers/driver_lock.c"

fail(){ echo "check_syscall_lock_yield: FAIL: $*" >&2; exit 1; }

grep -q 'setint(SCALL_INT_NR, scall_handler, SEG_CODE32, 0xEE00)' "$SYSC" || fail 'INT 0x7F interrupt-gate contract missing'
grep -A5 'void scall_relaxthread' "$SCS" | grep -q 'SwitchToThread();' || fail 'syscall cooperative switch contract missing'
grep -q 'int LockWaitCanYield(int saved_eflags)' "$LOCKH" || fail 'LockWaitCanYield declaration missing'
grep -q 'thread_scall_active\[pid\]' "$LOCKC" || fail 'IF=0 syscall discrimination missing'
grep -q 'JtmosFunctionLockAcquire(&__jtmos_function_lock' "$LOCKH" || fail 'generic LOCK is not routed through central acquire helper'
grep -q 'if(LockWaitCanYield(flags))' "$LOCKC" || fail 'generic LOCK still lacks syscall-aware wait policy'
grep -q 'SchedulerWaitPause(1000UL)' "$LOCKC" || fail 'generic LOCK does not use sleeping process-context waits'
grep -q 'LockWaitCanYield(flags)' "$JTMFS" || fail 'JTMFS mutation lock not syscall-yield aware'
grep -q 'LockWaitCanYield(flags)' "$JTMFAT" || fail 'JTMFAT allocator lock not syscall-yield aware'
grep -q 'LockWaitCanYield(flags)' "$DIRDB" || fail 'DirDB wait not syscall-yield aware'
[ "$(grep -c 'LockWaitCanYield(flags)' "$DLOCK")" -ge 2 ] || fail 'DAPI locks not syscall-yield aware'

echo 'check_syscall_lock_yield: PASS'
