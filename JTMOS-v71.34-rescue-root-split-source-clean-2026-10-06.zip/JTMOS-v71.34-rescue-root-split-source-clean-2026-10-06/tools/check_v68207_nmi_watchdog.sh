#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.207 NMI watchdog: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header/version mismatch"

grep -Fq 'volatile DWORD thread_rtc_seconds_without_task_switch[N_MAX_THREADS];' "$ROOT/kernel32/core/int/nmi.c" || fail "per-thread RTC no-switch counter missing"
grep -Fq 'frame->eflags|=0x200U;' "$ROOT/kernel32/core/int/nmi.c" || fail "NMI rescue does not force IF on"
grep -Fq 'nmi_thread_suspended[pid]=1;' "$ROOT/kernel32/core/int/nmi.c" || fail "hung PID quarantine missing"
grep -Fq 'if(frame->eflags&0x200U) return 0;' "$ROOT/kernel32/core/int/nmi.c" || fail "IF=1 false-positive guard missing"
grep -Fq 'stall<nmi_watchdog_threshold' "$ROOT/kernel32/core/int/nmi.c" || fail "RTC stall threshold missing"
grep -Fq 'SchedulerGetWatchdogSnapshot(&sw)' "$ROOT/kernel32/core/int/nmi.c" || fail "scheduler heartbeat sample missing"
! grep -Fq 'rtc_getseconds_of_day_atomic' "$ROOT/kernel32/core/int/nmi.c" || fail "NMI context must not touch RTC/CMOS ports"
grep -Fq 'rtc_getseconds_of_day_atomic(&rtc_second)' "$ROOT/kernel32/core/cp/scheduler.c" || fail "scheduler RTC heartbeat sample missing"

grep -Fq 'static volatile int cmos_nmi_masked=1;' "$ROOT/kernel32/drivers/cmos/cmos.c" || fail "shadowed CMOS/NMI gate state missing"
grep -Fq 'restore_mask=cmos_nmi_masked?0x80:0x00;' "$ROOT/kernel32/drivers/cmos/cmos.c" || fail "CMOS transaction does not restore prior NMI mask"
grep -Fq 'void cmos_set_nmi_masked(int masked)' "$ROOT/kernel32/drivers/cmos/cmos.c" || fail "shared CMOS/NMI gate API missing"
grep -Fq 'int rtc_getseconds_of_day_atomic(DWORD *seconds)' "$ROOT/kernel32/drivers/cmos/rtc.c" || fail "stable RTC second-of-day helper missing"

grep -Fq 'if(current>=0 && current<nr_threads && nmi_thread_suspended[current]) return 1;' "$ROOT/kernel32/core/cp/scheduler.c" || fail "suspended current PID is not force-preempted"
grep -Fq 'nmi_thread_suspended[pid]' "$ROOT/kernel32/core/cp/scheduler.c" || fail "scheduler quarantine filter missing"
grep -Fq 'thread_rtc_seconds_without_task_switch[nr_curthread]=' "$ROOT/kernel32/core/cp/scheduler.c" || fail "normal once-per-second per-thread RTC age update missing"
grep -Fq 'NmiSystemBootInit();' "$ROOT/kernel32/init/init.c" || fail "NMI boot policy initialization missing"
grep -Fq 'NmiRescueInit();' "$ROOT/kernel32/core/int/nmi.c" || fail "rescue worker on-demand startup missing"
grep -Fq 'IdentifyThread(me,"KNMI-RESCUE")' "$ROOT/kernel32/core/int/nmi_rescue.c" || fail "rescue worker missing"
grep -Fq '[C] Continue with IRQs enabled' "$ROOT/kernel32/core/int/nmi_rescue.c" || fail "interactive rescue choices missing"
grep -Fq 'watchdog will ask again if it wedges again' "$ROOT/kernel32/core/int/nmi_rescue.c" || fail "repeat rescue behaviour missing"
grep -Fq 'nmi rescue [status|continue|suspend|kill]' "$ROOT/kernel32/sh/nmiapp.c" || fail "SMSH rescue controls missing"
grep -Fq 'nmi watchdog [status|on|off|seconds N|' "$ROOT/kernel32/sh/nmiapp.c" || fail "SMSH watchdog controls missing"

echo "V68.207 NMI RTC watchdog/rescue regression: PASS"
