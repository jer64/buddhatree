#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "GraOS V53 stability: FAIL: $*" >&2; exit 1; }

[ "$(cat VERSION)" = "69.10" ] || fail "VERSION mismatch"
grep -Fq '#define GRAOS_VERSION "V53"' libc/apps/gui/graos.h || fail "GraOS version mismatch"

grep -Fq 'graos_server_is_same' libc/libc/modern/graos_compat.c || fail "client server-liveness guard missing"
grep -Fq 'm.sndPID!=expected_pid' libc/libc/modern/graos_compat.c || fail "sync reply sender validation missing"
grep -Fq 'm.sndPID!=graos_pid' libc/libc/modern/graos_compat.c || fail "async event sender validation missing"
grep -Fq 'event_count=0;' libc/libc/modern/graos_compat.c || fail "restart event queue reset missing"

grep -Fq 'guiServerReapDeadClients(v);' libc/apps/gui/guiLoop.c || fail "dead-client reaper not scheduled"
grep -Fq 'GetThreadMemoryUsage(w->pid)!=0' libc/apps/gui/guiServer.c || fail "dead-client liveness check missing"
grep -Fq 'w->pid=0;' libc/apps/gui/guiServer.c || fail "dead PID is not cleared before window teardown"
grep -Fq 'guiSetBusyState(v,0,0);' libc/apps/gui/guiServer.c || fail "orphan busy-state cleanup missing"
grep -Fq 'now-last_reap_tick)<250UL' libc/apps/gui/guiServer.c || fail "dead-client scan is not throttled"

grep -Fq 'Nv6150IsPrepared() && Nv6150FramebufferMapped()' kernel32/init/vesa.c || fail "NV6150 startup mapping guard missing"
grep -Fq 'VBoxBgaIsPrepared() && VBoxBgaFramebufferMapped()' kernel32/init/vesa.c || fail "VBox/BGA startup mapping guard missing"

nr=$(sed -n 's/.*nr_scall_func[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' kernel32/core/int/scs.c | head -n 1)
[ -n "$nr" ] && [ "$nr" -ge 153 ] || fail "syscall table too small for GraOS navigation ABI"

echo 'GraOS V53 stability: PASS'
