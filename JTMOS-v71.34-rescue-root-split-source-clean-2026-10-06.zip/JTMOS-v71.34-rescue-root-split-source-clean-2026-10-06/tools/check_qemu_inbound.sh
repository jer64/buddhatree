#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_qemu_inbound: FAIL: $*" >&2; exit 1; }
for Q in run_jtmos_qemu.sh run_jtmos_qemu_sata.sh; do
  grep -Fq 'NET_MODE=${JTMOS_NET_MODE:-user}' "$Q" || fail "$Q lacks selectable network backend"
  grep -Fq 'HTTP_HOST_PORT=${JTMOS_HTTP_HOST_PORT:-8080}' "$Q" || fail "$Q lacks unprivileged HTTP host-forward default"
  grep -Fq 'hostfwd=tcp:${HTTP_HOST_ADDR}:${HTTP_HOST_PORT}-:8080' "$Q" || fail "$Q does not forward host TCP to guest port 8080"
  grep -Fq 'hostfwd=tcp:${TELNET_HOST_ADDR}:${TELNET_HOST_PORT}-:2323' "$Q" || fail "$Q does not forward telnet development port"
  grep -Fq 'bridge,id=jtmosnet,br=$BRIDGE' "$Q" || fail "$Q lacks bridge mode for real inbound ICMP"
  grep -Fq 'tap,id=jtmosnet,ifname=$TAP_IF,script=no,downscript=no' "$Q" || fail "$Q lacks preconfigured TAP mode"
  grep -Fq 'inbound ICMP:    unavailable with QEMU user-mode networking' "$Q" || fail "$Q does not explain SLIRP inbound ICMP limitation"
  grep -Fq -- '-device ne2k_isa,netdev=jtmosnet,iobase=0x300,irq=9' "$Q" || fail "$Q changed the known-good NE2000 ISA wiring"
done

L=run_jtmos_qemu_linode.sh
[ -x "$L" ] || fail "$L missing or not executable"
grep -Fq 'JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}' "$L" || fail "Linode profile is not curses/headless"
grep -Fq 'JTMOS_HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-0.0.0.0}' "$L" || fail "Linode HTTP is not externally bindable by default"
grep -Fq 'JTMOS_TELNET_HOST_ADDR=${JTMOS_TELNET_HOST_ADDR:-127.0.0.1}' "$L" || fail "Linode telnet is not host-local by default"

echo "check_qemu_inbound: PASS (user hostfwd TCP/8080+2323 + bridge/TAP modes + NE2000 ISA preserved)"
