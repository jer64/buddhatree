#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}
U="$ROOT/kernel32/drivers/usb/usb_input.c"
H="$ROOT/kernel32/drivers/usb/usb_input.h"
K="$ROOT/kernel32/drivers/keyboard/keyb.c"
M="$ROOT/kernel32/drivers/mouse/mouse.c"
I="$ROOT/kernel32/init/init.c"
S="$ROOT/kernel32/sh/sh.c"
fail(){ echo "V69.26 USB input worker: FAIL: $*" >&2; exit 1; }

grep -Fq 'static void usb_input_worker_main(void)' "$U" || fail "worker main missing"
grep -Fq 'IdentifyThread(me,"KUSB-HID")' "$U" || fail "worker identity missing"
grep -Fq 'SchedulerWaitPause(USB_INPUT_WORKER_POLL_USEC);' "$U" || fail "bounded sleeping poll loop missing"
grep -Fq 'events=usb_input_poll();' "$U" || fail "worker does not pump HID"
grep -Fq 'if(!Multitasking || PitStorageSafeActive()) return 2;' "$U" || fail "storage-safe scheduler guard missing"
grep -Fq 'int usb_input_worker_start(void);' "$H" || fail "worker API missing"
grep -Fq 'if(usb_input.transport_ready)' "$I" || fail "boot does not conditionally start USB worker"
grep -Fq 'int usbwrv=usb_input_worker_start();' "$I" || fail "boot worker start call missing"
grep -Fq 'SchedulerWakeThread(target_pid);' "$K" || fail "keyboard FIFO does not wake foreground reader"
grep -Fq 'if(!usb_input_worker_running()) (void)usb_input_poll();' "$K" || fail "keyboard path still performs normal synchronous USB polling"
grep -Fq 'if(!usb_input_worker_running() &&' "$M" || fail "mouse path still performs normal synchronous USB polling"
grep -Fq 'keyb_service();' "$K" || fail "synchronous recovery service hook was removed"
grep -Fq 'USBworker=%d pid=%d wpolls=%lu' "$S" || fail "SMSH worker diagnostics missing"

echo "V69.26 USB input worker: PASS"
