#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.18 Intel NMI rescue: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
# This is both the 69.18 release check and a feature-regression check for later releases.
awk -v v="$VERSION" -v base="69.18" 'BEGIN{split(v,a,"."); split(base,b,"."); ok=(a[1]+0>b[1]+0)||((a[1]+0==b[1]+0)&&(a[2]+0>=b[2]+0)); exit ok?0:1}' \
    || fail "VERSION predates 69.18"
if [ "$VERSION" = "69.18" ]; then
    grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.18"' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
fi
N="$ROOT/kernel32/core/int/nmi.c"
S="$ROOT/kernel32/core/int/nmi_source.c"
H="$ROOT/kernel32/core/int/nmi_source.h"
E="$ROOT/kernel32/core/int/exception.c"
X="$ROOT/kernel32/core/int/exc.inc"
SH="$ROOT/kernel32/sh/sh.c"
NZ="$ROOT/kernel32/sh/nzipMain.c"
FPRINTF="$ROOT/kernel32/fs/fprintf.c"
PIT="$ROOT/kernel32/core/int/pit.c"
RUN="$ROOT/run_jtmos_qemu.sh"
# Intel architectural NMI rules.
grep -Fq 'lapic[LAPIC_LVTPC/4U]=LAPIC_LVT_NMI;' "$S" || fail "LVTPC is never software-unmasked after PMI"
grep -Fq 'MSR_IA32_PERF_GLOBAL_OVF' "$S" || fail "architectural PMU overflow clear missing"
grep -Fq 'NMI_SRC_INTEL_ARCH1' "$S" || fail "architectural PMU v1 support missing"
grep -Fq 'INTEL_P6_EVT_UNHALTED_CYCLES 0x00530079UL' "$S" || fail "P6 event 79h support missing"
grep -Fq 'intel_width=40U;' "$S" || fail "P6 40-bit counter width missing"
grep -Fq 'if((a&0xffU)!=0U) return -1;' "$S" || fail "P6 fallback can steal an enumerated architectural PMU"
grep -Fq 'LAPIC has no LVTPC' "$S" || fail "LAPIC LVT capability validation missing"
# NMI must return with IRETD so Intel NMI blocking is released.
sed -n '/^ASMexception_2:/,/^ASMexception_3:/p' "$X" | grep -Fq 'iretd' || fail "vector-2 fallback handler does not IRETD"
grep -Fq 'setint( 2,  ASMexception_2,  SEG_CODE32, 0x8E00 );' "$ROOT/kernel32/core/int/exception.c" || fail "vector 2 is not a present interrupt gate"
# QEMU hard watchdog must be host-clocked and independent of guest IF/PIT progress.
grep -Fq 'IB700_WDT_START     0x443U' "$S" || fail "IB700 watchdog start port missing"
grep -Fq 'IB700_WDT_4SEC      0x0dU' "$S" || fail "IB700 4-second selector missing"
grep -Fq 'NmiPeriodicSourceHeartbeat();' "$PIT" || fail "IRQ0 watchdog heartbeat missing"
grep -Fq -- '-device ib700 -watchdog-action inject-nmi' "$RUN" || fail "QEMU NMI watchdog launch option missing"
grep -Fq 'NmiPeriodicSourceHardExpiry' "$H" || fail "hard-expiry API missing"
# Internal nzip must not run on the immortal/long-lived SMSH thread.
grep -Fq 'return name!=NULL && !strcmp(name,"nzip");' "$SH" || fail "nzip not classified as guarded builtin"
grep -Fq 'IdentifyThread(pid,userspace_bridge?"smsh-u-bridge":"smsh-guarded");' "$SH" || fail "guarded worker missing"
grep -Fq 'NmiWatchdogSetThreadAutokill(pid,1)' "$SH" || fail "guarded worker is not NMI fail-stop eligible"
grep -Eq 'frame->eflags\|=0x(100|300)U;' "$N" || fail "NMI does not arm TF kill trap"
grep -Fq 'NmiWatchdogKillTrapPending(pid)' "$E" || fail "#DB watchdog trap containment missing"
# Kernel stdio must not dereference the legacy NULL stderr/stdout objects.
grep -Fq 'console_stream=(fd==NULL || fd==stderr || fd==stdout);' "$FPRINTF" || fail "kernel fprintf still dereferences NULL standard streams"
grep -Fq 'if(!console_stream && fd->readonly)' "$FPRINTF" || fail "kernel fprintf checks FILE fields before console-stream validation"
# Kernel nzip usage avoids the FILE* stderr path entirely.  The current shared
# front-end prints usage through the console-safe printf path and only gates
# the Ring3 metadata helper with the inverse build conditional.
grep -A8 'static void nzip_usage' "$NZ" | grep -Fq 'printf("Usage:' || fail "kernel nzip usage still uses stdio FILE* path"
echo "V69.18 Intel NMI rescue regression: PASS"
