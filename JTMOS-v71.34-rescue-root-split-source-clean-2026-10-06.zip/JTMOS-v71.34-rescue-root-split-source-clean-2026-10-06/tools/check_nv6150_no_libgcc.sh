#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC="$ROOT/kernel32/drivers/vga/nv6150.c"
fail(){ echo "check_nv6150_no_libgcc: FAIL: $*" >&2; exit 1; }
[ -f "$SRC" ] || fail "nv6150.c missing"
if grep -Eq 'unsigned[[:space:]]+long[[:space:]]+long|uint64_t|[0-9A-Fa-f]ULL' "$SRC"; then
    fail "NV6150 PLL path still uses 64-bit arithmetic"
fi
grep -q 'num=crystal_khz\*4UL\*(DWORD)n' "$SRC" || fail "32-bit PLL numerator missing"
grep -q 'out=num/denom' "$SRC" || fail "32-bit PLL division missing"
echo "check_nv6150_no_libgcc: PASS"
