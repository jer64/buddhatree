#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ENV="$ROOT/kernel32/core/environment/envint.c"
CP="$ROOT/kernel32/core/cp/centralprocess.c"
GUI="$ROOT/libc/apps/gui/guiStart.c"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

# Kernel options are no longer environment variables at all.  GraOS child
# environments therefore clone the ordinary POSIX environment directly.
! grep -Fq 'KerOpt' "$ENV" || fail 'ENVDB still coupled to keropt.c'
grep -Fq 'envdb_CloneVariableDatabase(src)' "$ENV" || fail 'ordinary process environment clone missing'
pass 'GraOS child environment is plain POSIX env; keropt.c is separate'

# Explicit paths such as /bin/filer.bin and ram:/bin/filer.bin must be handled
# before any PATH lookup.  Compare source line numbers to catch regressions.
abs_line=$(grep -n "if(strchr(fname,'/')!=NULL" "$CP" | head -1 | cut -d: -f1 || true)
path_line=$(grep -n 'ProcessEnvGet(centralprocess.requesterPID,"PATH"' "$CP" | head -1 | cut -d: -f1 || true)
[ -n "$abs_line" ] || fail 'absolute executable path fast path missing'
[ -n "$path_line" ] || fail 'requester PATH lookup missing'
[ "$abs_line" -lt "$path_line" ] || fail 'PATH is consulted before explicit executable paths'
grep -Fq 'kgetglobalenv("PATH",path,sizeof(path))' "$CP" || fail 'global PATH fallback missing'
pass 'absolute GraOS executable paths bypass PATH; bare names retain PATH search'

# A best-effort environment snapshot may not kill an otherwise valid GUI child.
block=$(sed -n '/ProcessEnvInherit(pid,centralprocess.requesterPID)<0)/,/^\t}/p' "$CP")
printf '%s\n' "$block" | grep -Fq 'ProcessEnvRelease(pid);' || fail 'lazy environment fallback missing'
if printf '%s\n' "$block" | grep -Fq 'KillThreadEx'; then
    fail 'environment inheritance failure still kills launched child'
fi
pass 'environment inheritance failure degrades to lazy defaults'

# Keep the four external GraOS tools on explicit executable paths.  Control
# Panel is intentionally internal and therefore does not exercise this path.
grep -Fq '"/bin/sqsh.bin"' "$GUI" || fail 'Terminal executable path missing'
grep -Fq '"/bin/filer.bin"' "$GUI" || fail 'File Manager executable path missing'
grep -Fq '"/bin/edit.bin"' "$GUI" || fail 'Text Editor executable path missing'
grep -Fq '"/bin/top.bin"' "$GUI" || fail 'Task Manager executable path missing'
pass 'GraOS external tool launch targets are present'

echo 'GraOS exec/environment regression checks passed.'
