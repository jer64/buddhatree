#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68172_topic_packages_bwbasic: FAIL: $*" >&2; exit 1; }
B="$ROOT/tools/build_install_image.sh"
U="$ROOT/libc/apps/bwbasic/upstream"

grep -Eq '^(68\.(17[2-9]|1[89][0-9]|[2-9][0-9][0-9])|69\.[0-9]+|7[0-9]\.[0-9]+)$' "$ROOT/VERSION" || fail "VERSION predates 68.172"
[ -f "$ROOT/libc/apps/unique/unique.c" ] || fail "Unique pure-C runtime missing"
[ -f "$ROOT/share/unique/examples/hello.uni" ] || fail "Unique hello example missing"
[ -f "$ROOT/share/unique/examples/myour.uni" ] || fail "Unique my/our example missing"
[ -f "$ROOT/share/unique/legacy-examples/GameInit.uni" ] || fail "historical Unique example missing"
! find "$ROOT/libc/apps/unique" -type f \( -name '*.cpp' -o -name '*.cc' -o -name '*.cxx' \) | grep -q . || fail "Unique regained a C++ runtime dependency"

grep -Fq 'interpreters.sqa' "$B" || fail "interpreters.sqa packaging missing"
grep -Fq 'demos.sqa' "$B" || fail "demos.sqa packaging missing"
grep -Fq 'tests.sqa' "$B" || fail "tests.sqa packaging missing"
grep -Fq 'media.sqa' "$B" || fail "media.sqa packaging missing"
grep -Fq 'network.sqa' "$B" || fail "network.sqa packaging missing"
! grep -Fq 'mv "$PAYLOAD/unique.bin"' "$B" || fail "Unique core runtime moved out of core.sqa"
grep -Fq 'mv "$PAYLOAD/$app.bin" "$INTERPRETER_STAGE/$app.bin"' "$B" || fail "optional interpreter move missing"
grep -Fq 'unique.bin' "$B" || fail "Unique is not retained as core system language"
grep -Fq 'BWBASIC_EXAMPLES' "$B" || fail "bwBASIC examples are not packaged"
grep -Fq 'UNIQUE_LEGACY_EXAMPLES' "$B" || fail "historical Unique examples are not packaged"

# The old direct example layout must not consume the compact rescue payload.
keep=$(sed -n '/^SYSTEM_KEEP_FILES="/,/^"$/p' "$B")
printf '%s\n' "$keep" | grep -qx 'unique.bin' || fail "unique.bin missing from rescue/core set"
if printf '%s\n' "$keep" | grep -Eq '^unique-(hello|myour|system|legacy)\.uni$'; then
    fail "Unique examples still leak directly into rescue payload"
fi

# Concrete bwBASIC crash fixes requested after historical target segfaults.
! grep -Eq 'lhs->type[[:space:]]*=[[:space:]]*NUMBER' "$U/bwb_var.c" || fail "SWAP assignment corruption remains"
grep -Fq 'BWB_DEVICE_VALID' "$U/bwbasic.h" || fail "device bounds helper missing"
! grep -Fq 'fgets( tbuf, MAXSTRINGSIZE + 2' "$U/bwb_inp.c" || fail "LINE INPUT overflow remains"
grep -Fq 'bwb_jump_ready == FALSE' "$U/bwb_prn.c" || fail "early longjmp/state guard missing"
grep -Fq 'MAXFILENAMESIZE 1024' "$U/bwbasic.h" || fail "path buffer is still DOS-sized"

# Host-side SQA smoke test: topic archives are nested SQA files, not special
# media formats, and the restored Unique example names fit the archive ABI.
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cc -O2 -std=gnu17 -Wall -Wextra -Wpedantic -o "$tmp/sqarc" "$ROOT/tools/sqarc.c"
mkdir "$tmp/topic"
cp "$ROOT/share/unique/examples/hello.uni" "$tmp/topic/unique-hello.uni"
cp "$ROOT/share/unique/examples/myour.uni" "$tmp/topic/unique-myour.uni"
JTMOSDIR="$ROOT" "$tmp/sqarc" "$tmp/topic" "$tmp/interpreters.sqa" >/dev/null 2>&1
JTMOSDIR="$ROOT" "$tmp/sqarc" --has-member "$tmp/interpreters.sqa" unique-hello.uni >/dev/null 2>&1 || fail "SQA example member lookup failed"
JTMOSDIR="$ROOT" "$tmp/sqarc" --has-member "$tmp/interpreters.sqa" unique-myour.uni >/dev/null 2>&1 || fail "SQA my/our member lookup failed"

echo "check_v68172_topic_packages_bwbasic: PASS (Unique restored + topic SQA layout + bwBASIC hardening)"
