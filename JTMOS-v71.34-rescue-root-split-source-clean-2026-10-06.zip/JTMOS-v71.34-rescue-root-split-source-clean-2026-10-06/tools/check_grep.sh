#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_grep: FAIL: $*" >&2; exit 1; }
GREP=libc/apps/grep.c
[ -s "$GREP" ] || fail "libc/apps/grep.c missing"
grep -Fq 'grep [-ivncqHh]' "$GREP" || fail "usage/options missing"
grep -Fq 'grep_stream(stdin' "$GREP" || fail "stdin pipeline mode missing"
grep -Fq "case 'i': opt.ignore_case=1" "$GREP" || fail "-i missing"
grep -Fq "case 'v': opt.invert=1" "$GREP" || fail "-v missing"
grep -Fq "case 'n': opt.line_numbers=1" "$GREP" || fail "-n missing"
grep -Fq "case 'c': opt.count_only=1" "$GREP" || fail "-c missing"
grep -Fq "case 'q': opt.quiet=1" "$GREP" || fail "-q missing"
grep -Fq 'SYSMEMREQ(APPRAM_256K)' "$GREP" || fail "small SYSMEMREQ missing"
[ -s libc/apps/grep.mak ] || fail "libc/apps/grep.mak missing"
grep -q '[[:space:]]grep[[:space:]]' libc/apps/Makefile || fail "canonical libc/apps Makefile does not build grep"
grep -Fq 'grep.bin' tools/build_install_image.sh || fail "grep absent from B:/install packaging"
grep -Fq 'cat hda1:/logs/system.log | grep -i dhcp | more' docs/SMSH-SQSH-MANUAL.txt || fail "manual log pipeline missing"
grep -Fq 'cat hda1:/logs/system.log|grep -i dhcp|more' libc/apps/sqsh.c || fail "SQSH help example missing"
echo "check_grep: PASS (streaming grep + -i/-v/-n/-c/-q + pipeline/package integration)"
