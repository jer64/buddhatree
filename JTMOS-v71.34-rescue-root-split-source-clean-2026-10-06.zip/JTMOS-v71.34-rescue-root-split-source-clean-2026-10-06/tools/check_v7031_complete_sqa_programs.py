#!/usr/bin/env python3
"""V70.31 authoritative JTMOS program/SQA completeness audit."""
from pathlib import Path
import argparse, re, subprocess, sys

EXCLUDED_ACTIVE = {
    "idler": "legacy raw-NASM application; explicitly not converted to ELF32 crt0/libc ABI",
    "listen": "archival placeholder; active source file is absent",
    "rf": "archival placeholder; active source file is absent",
    "sqarc": "host-side archive creator source; JTMOS runtime uses sqa.bin extractor",
    "test": "archival placeholder; active test source is not a supported release application",
}
EXCLUDED_DIRS = {
    "old": "historical pre-ELF32 application tree",
    "tmp": "historical temporary installer tree",
    "ar": "historical legacy raw application subproject",
}
PROGRAM_PACKAGES = ["core.sqa","graos.sqa","interpreters.sqa","demos.sqa","media.sqa","network.sqa","tests.sqa"]

def run(*args):
    return subprocess.check_output(args, text=True).splitlines()

def make_binary_inventory(path: Path):
    """Return only machine-readable *.bin records from make list-binaries.

    A top-level parallel make exports MAKEFLAGS (including print-directory /
    jobserver state) to this audit.  GNU make diagnostics must never become
    release inventory entries, so validate the producer output here rather
    than trusting arbitrary stdout.
    """
    env = dict(__import__("os").environ)
    # This is a standalone query, not a recursive build participant.  Dropping
    # inherited MAKEFLAGS also avoids stale jobserver descriptors/warnings.
    env.pop("MAKEFLAGS", None)
    env.pop("MFLAGS", None)
    lines = subprocess.check_output(
        ["make", "--no-print-directory", "-s", "-C", str(path), "list-binaries"],
        text=True, env=env
    ).splitlines()
    rx = re.compile(r"^[A-Za-z0-9_.+~-]+\.bin$")
    bad = [x for x in lines if x.strip() and not rx.fullmatch(x.strip())]
    if bad:
        print("V70.31 SQA audit: ignored non-inventory make output: " +
              " | ".join(bad), file=sys.stderr)
    return {x.strip() for x in lines if rx.fullmatch(x.strip())}

def appnames_from_mak(apps: Path):
    found=[]
    rx=re.compile(r"(?m)^APPNAME\s*=\s*([^\s#]+)")
    for p in apps.rglob("*.mak"):
        m=rx.search(p.read_text(errors="ignore"))
        if m: found.append((m.group(1),p))
    return found

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--payload", required=True)
    ap.add_argument("--apps", required=True)
    ap.add_argument("--gui", required=True)
    ns=ap.parse_args()
    payload=Path(ns.payload); apps=Path(ns.apps); gui=Path(ns.gui)
    root=apps.parents[1]; sqarc=root/"tools"/"sqarc"
    expected_root=make_binary_inventory(apps)
    expected_gui=make_binary_inventory(gui)
    expected=expected_root|expected_gui
    owners={x:[] for x in expected}
    unknown=[]
    for pkg in PROGRAM_PACKAGES:
        pp=payload/pkg
        if not pp.is_file():
            raise SystemExit(f"V70.31 SQA audit: missing package {pkg}")
        for member in run(str(sqarc),"--list",str(pp)):
            if not member.endswith(".bin"): continue
            if member in owners: owners[member].append(pkg)
            else: unknown.append((member,pkg))
    missing=[x for x,v in owners.items() if not v]
    duplicate=[(x,v) for x,v in owners.items() if len(v)!=1]
    if missing or duplicate or unknown:
        if missing: print("MISSING:"," ".join(sorted(missing)),file=sys.stderr)
        for x,v in duplicate: print("DUPLICATE:",x," ".join(v),file=sys.stderr)
        for x,p in unknown: print("UNKNOWN:",x,p,file=sys.stderr)
        raise SystemExit("V70.31 SQA audit: program ownership failure")

    # Independent makefile census. Every active APPNAME outside release lists must
    # have an explicit reason; no silent target omissions are permitted.
    release_names={x[:-4] for x in expected}
    unexplained=[]; exclusions=[]
    for name,p in appnames_from_mak(apps):
        rel=p.relative_to(apps)
        top=rel.parts[0] if len(rel.parts)>1 else ""
        if name in release_names: continue
        if top in EXCLUDED_DIRS:
            exclusions.append((name,str(rel),EXCLUDED_DIRS[top])); continue
        if name in EXCLUDED_ACTIVE:
            exclusions.append((name,str(rel),EXCLUDED_ACTIVE[name])); continue
        unexplained.append((name,str(rel)))
    if unexplained:
        for x,p in unexplained: print("UNCLASSIFIED TARGET:",x,p,file=sys.stderr)
        raise SystemExit("V70.31 SQA audit: APPNAME target absent from release inventory")

    out=root/"tools"/"PROGRAM-INVENTORY.txt"
    lines=["JTMOS V70.31 program inventory","="*31,"",f"PACKAGED PROGRAMS: {len(expected)}"]
    for b in sorted(expected): lines.append(f"PACKAGED {b} -> {owners[b][0]}")
    lines += ["",f"EXPLICITLY EXCLUDED MAKE TARGETS: {len(exclusions)}"]
    seen=set()
    for name,p,why in sorted(exclusions):
        key=(name,p)
        if key in seen: continue
        seen.add(key); lines.append(f"EXCLUDED {name} [{p}] - {why}")
    out.write_text("\n".join(lines)+"\n")
    print(f"V70.31 SQA audit: PASS: {len(expected)} release binaries, exactly one package each")
    print(f"V70.31 SQA audit: inventory -> {out}")
if __name__ == "__main__": main()
