#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68177_reconciled_release: FAIL: $*" >&2; exit 1; }
S="$ROOT/libc/apps/gui/guiStart.c"
line_of(){ awk -v pat="$1" '$0 ~ pat { print NR; exit }' "$S"; }
[ -f "$ROOT/RELEASE-V68.177.txt" ] || fail "release note missing"

grep -Eq '#define SCHED_IDLE_HLT_BURST +(64|[1-9][0-9][0-9]+)U' "$ROOT/kernel32/core/cp/scheduler.h" || fail "HLT64-or-larger scheduler burst missing"
grep -q 'for(i=0; i<SCHED_IDLE_HLT_BURST; ++i)' "$ROOT/kernel32/core/cp/scheduler.c" || fail "race-safe idle burst loop missing"
grep -q 'cpu_sti_hlt();' "$ROOT/kernel32/core/cp/scheduler.c" || fail "STI;HLT idle primitive missing"
grep -q 'PIT_ATHLON_II_SCHEDULER_HZ=250' "$ROOT/kernel32/init/keropt.c" || fail "Athlon-II PIT default is not 250 Hz"
grep -q 'PIT_MODERN_X86_SCHEDULER_HZ=250' "$ROOT/kernel32/init/keropt.c" || fail "modern x86 PIT default is not 250 Hz"
grep -q 'PIT_MODERN_X86_SCHEDULER_HZ:250U' "$ROOT/kernel32/core/int/pit.c" || fail "250 Hz PIT fallback missing"
grep -q 'SchedulerWaitPause(1000000UL)' "$ROOT/kernel32/init/init.c" || fail "PID0 one-second idle sleep missing"
grep -q 'SchedulerWaitPause(10000UL)' "$ROOT/kernel32/drivers/serial/serial.c" || fail "serial idle sleep missing"

(grep -q 'MilSleep(10);' "$ROOT/libc/apps/gui/guiLoop.c" || grep -Fq 'MilSleep(mouse_hot?2:10);' "$ROOT/libc/apps/gui/guiLoop.c") || fail "GraOS idle/event pointer-poll sleep missing"
(grep -q 'usleep((useconds_t)usec)' "$ROOT/libc/apps/gui/guiStartup.c" || grep -Eq 'splash_wait_(turns|bounded)' "$ROOT/libc/apps/gui/guiStartup.c") || fail "bounded GraOS splash delay missing"
! grep -q 'GetTickCount()-start' "$ROOT/libc/apps/gui/guiStartup.c" || fail "old timer/yield splash spin remains"
wdb_line=$(line_of '^[[:space:]]*wdbInit[(][)][;]')
layout_line=$(line_of '^[[:space:]]*guiLayoutInit[(]v[)][;]')
server_line=$(line_of '^[[:space:]]*guiServerInit[(][)][;]')
[ -n "$wdb_line" ] && [ -n "$layout_line" ] && [ -n "$server_line" ] || fail "GraOS window core startup calls missing"
[ "$wdb_line" -lt "$layout_line" ] && [ "$layout_line" -lt "$server_line" ] || fail "GraOS window core startup order changed"
! grep -q 'guiStartupShowPoster(v)' "$ROOT/libc/apps/gui/guiStart.c" || fail "optional poster returned to the critical startup path"
grep -q 'classic solid desktop ready without asset I/O' "$ROOT/libc/apps/gui/guiStart.c" || fail "built-in desktop fallback missing"

grep -q 'stack=%s, Ethernet' "$ROOT/kernel32/sh/networkapp.c" || fail "native Ethernet inet status cleanup missing"
grep -q 'entries\[cpu.idle_pid\].cpu_per_mille=0' "$ROOT/libc/apps/top.c" || fail "top idle accounting fix missing"
grep -q 'dprintk("IDTPTR' "$ROOT/kernel32/core/int/int.c" || fail "IDT quiet-boot conversion missing"
grep -q 'dprintk("Paging initializing' "$ROOT/kernel32/mm/paging.c" || fail "paging quiet-boot conversion missing"
grep -q 'dprintk("OHCI: stage 1/5' "$ROOT/kernel32/drivers/usb/ohci.c" || fail "OHCI quiet-boot conversion missing"
grep -q 'dprintk("PCI %d:%d.%d' "$ROOT/kernel32/drivers/pci/pci.c" || fail "PCI quiet-boot conversion missing"

echo "V68.177 reconciled-lineage regression: PASS"
