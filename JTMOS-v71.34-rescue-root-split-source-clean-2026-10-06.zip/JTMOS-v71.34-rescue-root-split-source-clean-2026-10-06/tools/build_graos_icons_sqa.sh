#!/bin/sh
set -eu
ROOT=${JTMOSDIR:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
OUT=${1:-"$ROOT/graos-icons.sqa"}
if [ ! -x "$ROOT/tools/sqarc" ]; then
    make -C "$ROOT/tools" sqarc
fi
[ -d "$ROOT/share/icons" ] || { echo "build_graos_icons_sqa: missing $ROOT/share/icons" >&2; exit 1; }
"$ROOT/tools/sqarc" "$ROOT/share/icons" "$OUT"
echo "GraOS icon package: $OUT"
