#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_unz_streaming: FAIL: $*" >&2; exit 1; }
for C in "$ROOT/libc/apps/nzip.c" "$ROOT/kernel32/sh/nzip.c"; do
    grep -Fq 'stream_backref' "$C" || fail "$C lacks streaming back-reference decoder"
    grep -Fq 'fopen(destination,"w+b")' "$C" || fail "$C does not stream to destination file"
    ! grep -Fq 'write_buffer_file(destination,out.data,out.size)' "$C" || fail "$C still buffers whole decoded output"
done
grep -Fq 'SYSMEMREQ(APPRAM_12288K)' "$ROOT/libc/apps/nzip.c" || fail "nzip/unz lost 12 MiB SYSMEMREQ working reservation"
grep -Fq '#define NZIP_MAX_DECODE_OUTPUT 0x7fffffffUL' "$ROOT/libc/apps/nzip.h" || fail "safe streaming decode file-size bound missing"
echo "check_unz_streaming: PASS (12 MiB SYSMEMREQ working set + streamed decode + legacy absolute backrefs)"
