#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
VERSION=$(cat "$ROOT/VERSION" 2>/dev/null || true)

fail()
{
    echo "source-clean release: FAIL: $*" >&2
    exit 1
}

case "$VERSION" in
    ''|*[!0-9.]*|*.*.*) fail "invalid VERSION '$VERSION' (expected MAJOR.RELEASE)" ;;
    *.*) ;;
    *) fail "invalid VERSION '$VERSION' (expected MAJOR.RELEASE)" ;;
esac

MAJOR=${VERSION%%.*}
RELEASE=${VERSION#*.}
[ -n "$MAJOR" ] && [ -n "$RELEASE" ] || fail "invalid VERSION '$VERSION'"
case "$MAJOR$RELEASE" in *[!0-9]*) fail "VERSION components must be decimal integers" ;; esac

NOTE="$ROOT/RELEASE-V${VERSION}.txt"
[ -f "$NOTE" ] || fail "missing RELEASE-V${VERSION}.txt"
grep -Fq "JTMOS V${VERSION}" "$NOTE" || \
    fail "RELEASE-V${VERSION}.txt does not identify JTMOS V${VERSION}"

# A source-clean release must not carry output from the compiler, linker,
# image builders, compressors, or generated kernel inventory steps.  Source
# assets such as .prg are intentionally not included in this list.
ARTIFACTS=$(find "$ROOT" -type f \( \
    -name '*.o' -o -name '*.a' -o -name '*.map' -o -name '*.sym' -o -name '*.elf' -o \
    -name '*.bin' -o -name '*.com' -o -name '*.img' -o -name '*.iso' -o \
    -name '*.nz' -o -name 'generated.mak' -o -name 'modules.generated.h' -o \
    -name 'console_profile.generated.h' -o -name '.generated.syntax.*.mak' -o \
    -name '.modules.syntax.*' \
\) -print)
if [ -n "$ARTIFACTS" ]; then
    printf '%s\n' "$ARTIFACTS" >&2
    fail "build/generated artifacts remain in source tree"
fi

[ ! -e "$ROOT/.git" ] && [ ! -L "$ROOT/.git" ] || fail ".git must not be shipped"

# Extensionless host helper binaries are build outputs too.  They are easy to
# miss with suffix-only filters and must never leak into a source-clean ZIP.
for generated_host in "$ROOT/img" "$ROOT/imgsrc/img" "$ROOT/tools/nzip" "$ROOT/tools/sqarc"; do
    [ ! -f "$generated_host" ] || fail "extensionless host build artifact remains: ${generated_host#$ROOT/}"
done

# V68.111 release archives intentionally contain symlink aliases.  Every link
# must be relative, non-dangling, and resolve back inside this release tree.
find "$ROOT" -type l -print | while IFS= read -r link; do
    target=$(readlink "$link")
    case "$target" in
        /*) fail "absolute symlink is not release-safe: ${link#$ROOT/} -> $target" ;;
    esac
    [ -e "$link" ] || fail "dangling symlink: ${link#$ROOT/} -> $target"
    resolved=$(readlink -f "$link")
    case "$resolved" in
        "$ROOT"|"$ROOT"/*) ;;
        *) fail "symlink escapes source tree: ${link#$ROOT/} -> $target" ;;
    esac
done

"$ROOT/tools/check_duplicate_layout.sh"
"$ROOT/tools/check_kernel_asm_includes.sh"
"$ROOT/tools/check_core_int_canonical.sh"
"$ROOT/tools/check_core_int_macro_recovery.sh"
"$ROOT/tools/check_msgbox_async_safety.sh"
"$ROOT/tools/check_launchapp_exec_context.sh"
"$ROOT/tools/check_cwd_cache_cexec_context.sh"
"$ROOT/tools/check_alt_fn_text_vt.sh"
"$ROOT/tools/check_gfx_vt_command.sh"
"$ROOT/tools/check_graos_quarter_compositor.sh"
"$ROOT/tools/check_boot32pm_vesa_default.sh"
"$ROOT/tests/jtmfs_atomic_resize_regression.sh"
python3 "$ROOT/tests/mkfs_rootinstall_partition_sequence.py"
sh "$ROOT/tools/check_jtmfs_fresh_format_health.sh"
"$ROOT/tools/check_interrupt_scheduler_hlt.sh"
"$ROOT/tools/check_unz_v59_semantics.sh"
"$ROOT/tools/check_unz_directory_abi.sh"
"$ROOT/tools/check_kernel_archive_builtins.sh"
"$ROOT/tools/check_sqa_fresh_boot_hardening.sh"
"$ROOT/tools/check_sqa_jtmfs_bulk_io.sh"
sh "$ROOT/tools/check_v68172_topic_packages_bwbasic.sh"
sh "$ROOT/tools/check_v68179_system_logging.sh"
sh "$ROOT/tools/check_v68186_terminal_lifecycle.sh"
sh "$ROOT/tools/check_v68187_fpu_context_safe.sh"
sh "$ROOT/tools/check_v68188_smsh_command_safe.sh"
sh "$ROOT/tools/check_v68189_missing_exec_safe.sh"
sh "$ROOT/tools/check_v68190_sqa_copy_integrity.sh"
sh "$ROOT/tools/check_v68191_hda1_sync_race.sh"
sh "$ROOT/tools/check_v68192_copyall_forward_progress.sh"
sh "$ROOT/tools/check_v68193_jtmfs_single_writer.sh"
sh "$ROOT/tools/check_v68198_logging_forward_progress.sh"
sh "$ROOT/tools/check_v68201_linode_launcher.sh"
sh "$ROOT/tools/check_v68202_graos_launch_safe.sh"
sh "$ROOT/tools/check_v68203_no_autostart_d0.sh"
sh "$ROOT/tools/check_v68204_unz_lock_order.sh"
sh "$ROOT/tools/check_v68205_locktop.sh"
sh "$ROOT/tools/check_v68206_nmi.sh"
sh "$ROOT/tools/check_v68207_nmi_watchdog.sh"
sh "$ROOT/tools/check_cmos_sleep.sh"
sh "$ROOT/tools/check_v68208_core_hardening.sh"
sh "$ROOT/tools/check_v68209_exception_if0_recovery.sh"
sh "$ROOT/tools/check_v68210_crash_analysis.sh"
sh "$ROOT/tools/check_v68211_graos_priority.sh"
sh "$ROOT/tools/check_v68212_graos_aesthetics.sh"
sh "$ROOT/tools/check_v68213_ramdisk_bootstrap_space.sh"
sh "$ROOT/tools/check_v68214_partition_builtin.sh"
sh "$ROOT/tools/check_v68215_linux_mm_lite.sh"
sh "$ROOT/tools/check_v68216_klogger_pf_sqa.sh"
sh "$ROOT/tools/check_v68227_dprintk_routing.sh"
sh "$ROOT/tools/check_v690_release.sh"
sh "$ROOT/tools/check_v690_mm_mutex_hardening.sh"
sh "$ROOT/tools/check_v690_sync_kernel_compat.sh"
sh "$ROOT/tools/check_v690_kernel_stress_hardening.sh"
sh "$ROOT/tools/check_v690_nmi_hardening.sh"
# V69.8's release wrapper intentionally pins the public VERSION to 69.8.  A
# later source-clean release must retain its feature gates without re-running
# historical release metadata assertions.
sh "$ROOT/tools/check_v692_du_terminal_path.sh"
sh "$ROOT/tools/check_v693_jtmfs_reiser.sh"
sh "$ROOT/tools/check_v694_jtmfs_atomic_jtmfsck.sh"
sh "$ROOT/tools/check_v695_jtmfs_index_blockcache.sh"
sh "$ROOT/tools/check_v6957_io_gui_ls.sh"
sh "$ROOT/tools/check_v696_ring3_containment.sh"
sh "$ROOT/tools/check_v697_ring3_api.sh"
sh "$ROOT/tools/check_v698_jtmfs_hotpath.sh"
sh "$ROOT/tools/check_v6914_hdbench.sh"
sh "$ROOT/tools/check_v6918_intel_nmi_rescue.sh"
JTMOS_APIC_FEATURE_ONLY=1 sh "$ROOT/tools/check_v6920_apic.sh"
sh "$ROOT/tools/check_v6923_keyboard_recovery.sh"
sh "$ROOT/tools/check_v6923_graos_startup.sh"
sh "$ROOT/tools/check_v6924_nmi_guarddog.sh"
sh "$ROOT/tools/check_v6925_boot_media_autostart.sh"
sh "$ROOT/tools/check_v6926_usb_input_worker.sh"
sh "$ROOT/tools/check_v6927_usb_ohci_hardening.sh"
sh "$ROOT/tools/check_v6928_ohci_dma_quiesce.sh"
sh "$ROOT/tools/check_v6929_sqa_single_commit.sh"
sh "$ROOT/tools/check_v6930_sqa_stream_eof_commit.sh"
sh "$ROOT/tools/check_v6931_sqa_bounded_stream_only.sh"
sh "$ROOT/tools/check_v6932_manual_bootstrap.sh"
sh "$ROOT/tools/check_v6933_jtmfs_critical_path.sh"
sh "$ROOT/tools/check_diskspace_enospc.sh"
sh "$ROOT/tools/check_native_ai.sh"
python3 "$ROOT/tests/v7129_native_ai_doctor.py"
python3 "$ROOT/tests/v7130_term_ncurses_signals.py"
python3 "$ROOT/tests/v7131_terminal_output.py"
sh "$ROOT/tools/check_v704_nmi_cli_rescue.sh"
sh "$ROOT/tools/check_v7012_sata_latency.sh"
sh "$ROOT/tools/check_v7013_jtmfs_smallfile_latency.sh"
sh "$ROOT/tools/check_v7014_test_repo_hygiene.sh"
sh "$ROOT/tools/check_v7015_smallfile_pipeline.sh"

# Keep this checker read-only.  Some broader regression scripts intentionally
# generate console_profile.generated.h or other temporary build inventories and
# therefore belong to `make check`, not to release-clean validation.

# Recheck forbidden output after the layout checks so a future check script
# cannot silently dirty the tree and still let packaging continue.
ARTIFACTS=$(find "$ROOT" -type f \( \
    -name '*.o' -o -name '*.a' -o -name '*.map' -o -name '*.sym' -o -name '*.elf' -o \
    -name '*.bin' -o -name '*.com' -o -name '*.img' -o -name '*.iso' -o \
    -name '*.nz' -o -name 'generated.mak' -o -name 'modules.generated.h' -o \
    -name 'console_profile.generated.h' -o -name '.generated.syntax.*.mak' -o \
    -name '.modules.syntax.*' \
\) -print)
[ -z "$ARTIFACTS" ] || fail "release checks generated build artifacts"

"$ROOT/tools/check_pagefault_live_frame.sh"
sh "$ROOT/tools/check_utils_install_payload.sh"
sh "$ROOT/tools/check_v6934_klogger_hda1_header_gate.sh"
sh "$ROOT/tools/check_v6935_ohci_sof_rearm_hard_recovery.sh"
sh "$ROOT/tools/check_v6964_cli_brand_posix.sh"
sh "$ROOT/tools/check_v6965_nmi_iretd_regression.sh"
echo "source-clean release: PASS (V${VERSION})"
