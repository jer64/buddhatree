#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.32" ] || { echo "V70.32 theme fix: FAIL VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7032_graos_theme_linefix.py"
