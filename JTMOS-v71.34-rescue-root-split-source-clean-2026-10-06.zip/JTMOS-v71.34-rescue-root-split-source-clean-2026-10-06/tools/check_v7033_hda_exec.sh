#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.33" ] || { echo "V70.33 HDA exec: FAIL: VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7033_hda_exec.py"
echo "V70.33 HDA/GraOS exec regression: PASS"
