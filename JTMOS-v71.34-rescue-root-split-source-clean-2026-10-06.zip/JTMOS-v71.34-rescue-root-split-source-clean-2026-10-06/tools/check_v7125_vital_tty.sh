#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
grep -q 'JTMOS_SOURCE_RELEASE "V71.' kernel32/include/jtmos_release.h
grep -q 'cfsetspeed' libc/libc/include/termios.h
grep -q 'case.*i' libc/libc/modern/termcap.c
grep -q 'wgetnstr' libc/libc/modern/curses.c
grep -q 'winsdelln' libc/libc/modern/curses.c
make -C libc/libc clean >/dev/null
make -C libc/libc application >/dev/null
cat > /tmp/jtmos-v7125-tty-smoke.c <<'EOF'
#include <termios.h>
#include <termcap.h>
#include <curses.h>
int main(void){struct termios t;char b[32];short f,g;if(tcgetattr(0,&t)<0)return 1;cfsetspeed(&t,B38400);cfmakeraw(&t);tcsetattr(0,TCSANOW,&t);tgetent(0,"jtmos");(void)tgoto(tgetstr("cm",0),1,1);if(!initscr())return 2;cbreak();noecho();keypad(stdscr,TRUE);wtimeout(stdscr,1);start_color();init_pair(1,COLOR_WHITE,COLOR_BLUE);pair_content(1,&f,&g);wborder(stdscr,0,0,0,0,0,0,0,0);scrollok(stdscr,TRUE);winsdelln(stdscr,1);wgetnstr(stdscr,b,0);endwin();return 0;}
EOF
make -C libc/libc app SRC=/tmp/jtmos-v7125-tty-smoke.c OUT=/tmp/jtmos-v7125-tty-smoke.bin >/dev/null
LC_ALL=C readelf -h /tmp/jtmos-v7125-tty-smoke.bin | grep -q 'Class:.*ELF32'
LC_ALL=C readelf -h /tmp/jtmos-v7125-tty-smoke.bin | grep -q 'Machine:.*Intel 80386'
echo 'JTMOS V71.25 vital TTY APIs: PASS'
