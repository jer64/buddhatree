#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.0 MM/mutex hardening: FAIL: $*" >&2; exit 1; }

case "$(cat "$ROOT/VERSION")" in 69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
python3 "$ROOT/tests/mm_mutex_hardening_v690.py"
echo "V69.0 MM/mutex hardening: PASS"
