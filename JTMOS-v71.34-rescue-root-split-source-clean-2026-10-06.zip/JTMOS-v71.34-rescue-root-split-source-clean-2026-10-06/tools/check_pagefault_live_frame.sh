#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
EXC="$ROOT/kernel32/core/int/exc.inc"
HDR="$ROOT/kernel32/core/int/exception.h"
GPF="$ROOT/kernel32/core/cp/gpf.c"
grep -q 'pushad' "$EXC"
grep -q 'mov eax,\[esi+52\].*interrupted EIP' "$EXC"
grep -q 'pf_frame_eip' "$EXC"
grep -q 'push ds' "$EXC"
grep -q 'call mm_handle_page_fault' "$EXC"
grep -q 'mov eax,\[esi+60\].*interrupted EFLAGS' "$EXC"
grep -q 'pf_frame_user_esp' "$EXC"
grep -q 'JTMOS_PF_FRAME_MAGIC' "$HDR"
grep -q 'LIVE #PF: CS:EIP=' "$GPF"
grep -q 'TSS snapshot below is scheduler state and may have a stale EIP' "$GPF"
echo 'pagefault live frame: PASS'
