#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_v692_du_terminal_path: FAIL: $*" >&2; exit 1; }
VERSION=$(cat VERSION)
case "$VERSION" in 69.2|69.[3-9]|69.[1-9][0-9]*|7[0-9].*) ;; *) fail "VERSION predates 69.2" ;; esac
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" kernel32/include/jtmos_release.h || fail "release header"
grep -Eq '(^|[[:space:]])du([[:space:]\\]|$)' libc/apps/Makefile || fail "du missing from app list"
[ -s libc/apps/du.c ] && [ -s libc/apps/du.mak ] || fail "du sources missing"
grep -Fq "case 'c': opt->total=1" libc/apps/du.c || fail "du -c missing"
grep -Fq "case 'h': opt->human=1" libc/apps/du.c || fail "du -h missing"
grep -Fq "case 's': opt->summarize=1" libc/apps/du.c || fail "du -s missing"
grep -Fq "for(i=1;arg[i];++i)" libc/apps/du.c || fail "combined short options missing"
grep -Fq 'JKEY_CTRL_SHIFT_N 0x0f0d' libc/include/jtmos/console.h || fail "new terminal key code missing"
grep -Fq 'mark==SCODE_N' kernel32/drivers/keyboard/scanasc.c || fail "Ctrl+Shift+N encoding missing"
grep -Fq 'key==JKEY_CTRL_SHIFT_N' libc/apps/gui/guiLoop.c || fail "GraOS shortcut missing"
grep -Fq 'guiStartTerminalProgram(v,"/bin/sqsh.bin"' libc/apps/gui/guiLoop.c || fail "SQSH spawn missing"
grep -Fq 'ksetglobalenv("PATH","/bin;/usr/bin;ram:/bin",1)' kernel32/core/environment/envint.c || fail "semicolon PATH default missing"
grep -Fq 'ProcessEnvEnsureDeviceBin(pid,GetThreadDNR(pid))' kernel32/core/environment/envint.c || fail "active-device bin PATH missing"
grep -Fq "return path[pos]==';' ? 1 : 0;" kernel32/fs/api.c || fail "semicolon-only PATH parser missing"
echo "check_v692_du_terminal_path: PASS"
