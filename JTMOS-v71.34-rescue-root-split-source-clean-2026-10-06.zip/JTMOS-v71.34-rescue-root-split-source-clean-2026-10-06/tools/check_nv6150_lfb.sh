#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
C="$ROOT/kernel32/drivers/vga/nv6150.c"
H="$ROOT/kernel32/drivers/vga/nv6150.h"
V="$ROOT/kernel32/init/vesa.c"
I="$ROOT/kernel32/init/initsystem.c"
D="$ROOT/docs/NVIDIA-6150SE-MCP61.md"

fail() { echo "check_nv6150_lfb: FAIL: $*" >&2; exit 1; }
need() { grep -Fq "$2" "$1" || fail "missing '$2' in ${1#$ROOT/}"; }
for f in "$C" "$H" "$V" "$I" "$D"; do [ -f "$f" ] || fail "missing ${f#$ROOT/}"; done

need "$H" 'NV6150_PCI_VENDOR          0x10DE'
need "$H" 'NV6150_PCI_DEVICE          0x03D0'
need "$H" 'NV6150_GRAOS_WIDTH         1024'
need "$H" 'NV6150_GRAOS_HEIGHT        768'
need "$H" 'NV6150_FALLBACK_WIDTH      640'
need "$H" 'NV6150_FALLBACK_HEIGHT     480'
need "$H" 'NV6150_BPP                 32'
need "$H" 'NV6150_NATIVE_PLL          1'

need "$C" '#define NV_PCRTC_START           0x00600800UL'
need "$C" '#define NV_PCRTC_CONFIG          0x00600804UL'
need "$C" '#define NV_PCRTC_CONFIG_NON_VGA  0x00000001UL'
need "$C" '#define NV_PRAMDAC_VPLL          0x00680508UL'
need "$C" '#define NV_PRAMDAC_PLLSEL        0x0068050CUL'
need "$C" '#define NV_PRAMDAC_VPLL_B        0x00680578UL'
need "$C" '#define NV_PRAMDAC_GENERAL       0x00680600UL'
need "$C" 'NV_PRAMDAC_GENERAL_32BPP 0x20100130UL'
need "$C" 'NV_PLLSEL_USE_VPLL2       0x00000004UL'
need "$C" 'NV_PLLSEL_SOURCE_VPLL     0x00000200UL'
need "$C" 'NV_PLLSEL_VCLK_RATIO_DB2  0x10000000UL'

# BAR1 is the pre-NV50 LFB aperture and must enter the shared paging contract.
need "$C" 'bar1=nv_bar_phys(PCI_BAR1_REG);'
need "$C" 'nv6150_lfb_phys=bar1;'
need "$C" 'vesa_frame_buf=(BYTE *)nv6150_lfb_phys;'
need "$C" 'vesa_frame_buf_bytes=NV6150_REQUIRED_LFB_BYTES;'
need "$C" 'pg_mapio((int)(phys/4096UL),pages)'

# Native prepare must remain non-destructive: only an explicit GraOS transition sets a mode.
PREP=$(sed -n '/int Nv6150PrepareGraOS(void)/,/^}/p' "$C")
printf '%s\n' "$PREP" | grep -Fq 'vesa_boot_graphics=FALSE' || fail 'prepare must retain VGA text mode'
if printf '%s\n' "$PREP" | grep -Fq 'Nv6150SetMode('; then
    fail 'prepare must not program a native mode'
fi

# MCP61/C61 two-stage VPLL constraints and fixed second stage from nvidiafb.
need "$C" 'if(vco<400000UL || vco>1000000UL) continue;'
need "$C" '*pll_a=((DWORD)bp<<16) | ((DWORD)bn<<8) | (DWORD)bm;'
need "$C" '*pll_b=0x80000401UL;'
# C61 fixed FIFO arbitration0=256, arbitration1=0x0480.
need "$C" 'nv_crtc_write(0x1b,0x00);'
need "$C" 'nv_crtc_write(0x20,0x80);'
need "$C" 'nv_crtc_write(0x47,0x04);'
# Curie/NV4x packed-pixel/timing extensions.
for r in 0x19 0x25 0x28 0x2d 0x41 0x42 0x85 0x86; do
    grep -Fq "nv_crtc_write($r" "$C" || fail "missing CRTC $r programming"
done

# VBE remains visible at boot, but native NVIDIA must still be prepared alongside
# it so protected-mode `gfx geforce` can take over after paging.
need "$I" 'if(VesaBootHandoffPresent())'
need "$I" 'if(NV6150_PREPAGING_ENABLED && Nv6150PrepareGraOS())'
need "$C" 'preserve_boot_vesa = vesa_boot_graphics && vesa_frame_buf!=NULL'
need "$C" 'Nv6150SetFramebufferMapped(int mapped)'
need "$H" 'DWORD Nv6150GetFramebufferBytes(void);'
need "$H" 'int Nv6150FramebufferMapped(void);'
need "$I" 'NV6150/MCP61 prepared alongside BIOS VESA'
need "$I" 'else if(NV6150_PREPAGING_ENABLED &&'
need "$I" 'VBoxBgaPrepareGraOS())'
need "$V" 'if(Nv6150IsPrepared() && Nv6150FramebufferMapped() &&'
need "$V" 'if(Nv6150IsPrepared() || Nv6150IsActive()) {'
need "$V" 'Nv6150SetMode(GRAOS_VESA_WIDTH, GRAOS_VESA_HEIGHT,'

# Validate both hard-coded 60 Hz modes and the two-stage PLL search numerically.
python3 - <<'PY'
modes = [
    (640,480,656,752,800,490,492,525,25175),
    (1024,768,1048,1184,1344,771,777,806,65000),
]
for m in modes:
    w,h,hs,he,ht,vs,ve,vt,clk=m
    assert w % 8 == 0 and ht % 8 == 0
    assert w < hs < he < ht
    assert h < vs < ve < vt
    # VGA CRTC fields plus NVIDIA extension bits cover these values.
    vals=[(w>>3)-1,(hs>>3)+1,(he>>3)+1,(ht>>3)-5,h-1,vs-1,ve-1,vt-2]
    assert all(0 <= x < 4096 for x in vals)
    for crystal in (13500,14318,27000):
        best=None
        for p in range(7):
            vco=clk << p
            if not 400000 <= vco <= 1000000:
                continue
            for mm in range(1,14):
                for n in range(5,256):
                    out=(crystal*4*n)//(mm*(1<<p))
                    err=abs(out-clk)
                    if best is None or err < best[0]: best=(err,out,p,mm,n)
        assert best is not None
        assert best[0] <= clk//100
print('check_nv6150_lfb: PLL/timing arithmetic PASS')
PY

echo 'check_nv6150_lfb: PASS (10DE:03D0 BAR1 LFB + C61 native 640/1024x32 fallback)'
