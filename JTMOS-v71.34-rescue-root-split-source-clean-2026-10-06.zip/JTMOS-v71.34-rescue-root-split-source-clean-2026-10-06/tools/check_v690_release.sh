#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.0 release: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in 69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
grep -Fq "Current release: **V${VERSION}**." "$ROOT/VERSIONING.md" || fail "VERSIONING current release mismatch"
[ -f "$ROOT/RELEASE-V69.0.txt" ] || fail "release notes missing"
sh "$ROOT/tools/check_v68227_dprintk_routing.sh" >/dev/null
echo "V69.0 release: PASS"
