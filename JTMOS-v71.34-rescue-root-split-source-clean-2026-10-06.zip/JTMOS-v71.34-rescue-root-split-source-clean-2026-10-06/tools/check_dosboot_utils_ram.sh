#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_dosboot_utils_ram: FAIL: $*" >&2; exit 1; }
grep -q "JTMOS_BOOT_UTILS_RAM_PHYS.*0x01100000" kernel32/include/memory_layout.h || fail "RAM base"
grep -q "JTMOS_BOOT_UTILS_RAM_BYTES.*0x02000000" kernel32/include/memory_layout.h || fail "RAM capacity"
grep -q "utils_filename.*'UTILS.ISO'" boot32pm/dosboot.asm || fail "DOS filename"
grep -q "mov ax,0x4202" boot32pm/dosboot.asm || fail "DOS size seek"
grep -q "mov ah,0x3F" boot32pm/dosboot.asm || fail "DOS read"
grep -q "call pmode_stream_copy" boot32pm/dosboot.asm || fail "PM copy"
grep -q "BootUtilsRamInit" kernel32/init/initsystem.c || fail "kernel reservation hook"
grep -q "mmTryReserveRegionAD" kernel32/init/bootutilsram.c || fail "collision-safe allocator reservation"
grep -q "#define SYS_bootutils.*151" kernel32/core/int/syscallcodes.h || fail "syscall code"
grep -q "ramextract" libc/apps/Makefile || fail "app list"
grep -q "exceeds 32 MiB RAM-bank capacity" boot32pm/dosboot.asm || fail "DOSBOOT size diagnostic"
grep -q "cmp ax,49152" boot32pm/dosboot.asm || fail "DOSBOOT 48 MiB extended-memory guard"
grep -q "needs at least 49 MiB physical RAM" boot32pm/dosboot.asm || fail "DOSBOOT physical-RAM diagnostic"
grep -q "RAMEXTRACT_MAX_BYTES (32UL\*1024UL\*1024UL)" libc/apps/ramextract.c || fail "external ramextract 32 MiB cap"
grep -q "DOSBOOT_UTILS_MAX_BYTES=\$((32 \* 1024 \* 1024))" tools/build_install_image.sh || fail "build-time 32 MiB guard"
[ -f libc/apps/ramextract.c ] || fail "app source"

grep -q "JTMOS_BOOT_UTILS_HANDOFF_PHYS.*0x00003300" kernel32/include/memory_layout.h || fail "dedicated handoff base"
grep -q "UTILS_HANDOFF_ADDR    JTMOS_BOOT_UTILS_HANDOFF_PHYS" boot32pm/dosboot.asm || fail "DOSBOOT canonical handoff"
grep -q "BootUtilsRamReserveEarly" kernel32/mm/mm.c || fail "pre-allocation RAM-bank reservation"
grep -q "staged pages already allocated/reserved" kernel32/init/bootutilsram.c || fail "diagnostic reason"
echo "DOSBOOT UTILS.ISO RAM-bank checks: PASS"
