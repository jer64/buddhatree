#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68178_idle_hlt512: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in
    68.178|68.179|68.1[89][0-9]|68.[2-9][0-9][0-9]*) ;;
    *) fail "VERSION predates 68.178" ;;
esac
[ -f "$ROOT/RELEASE-V68.178.txt" ] || fail "release note missing"
grep -q '#define SCHED_IDLE_HLT_BURST 512U' "$ROOT/kernel32/core/cp/scheduler.h" || fail "512-HLT idle burst missing"
grep -q 'for(i=0; i<SCHED_IDLE_HLT_BURST; ++i)' "$ROOT/kernel32/core/cp/scheduler.c" || fail "idle burst loop missing"
grep -q 'cpu_sti_hlt();' "$ROOT/kernel32/core/cp/scheduler.c" || fail "STI;HLT primitive missing"
grep -q 'scheduler_runnable_nonidle_exists()' "$ROOT/kernel32/core/cp/scheduler.c" || fail "runnable recheck missing"
grep -q '512-entry HLT burst' "$ROOT/kernel32/core/int/IdleThread.c" || fail "IdleThread documentation not updated"
echo "V68.178 HLT512 idle regression: PASS"
