#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_gpf_cp_if_recovery: FAIL: $*" >&2; exit 1; }

grep -q 'JTMOS_GP_FRAME_MAGIC' kernel32/core/int/exception.h || fail "live #GP frame ABI missing"
grep -q 'mov \[gp_frame_eip\],eax' kernel32/core/int/exc.inc || fail "#GP EIP capture missing"
grep -q 'mov \[gp_frame_cs\],eax' kernel32/core/int/exc.inc || fail "#GP CS capture missing"
grep -q 'mov \[gp_frame_eflags\],eax' kernel32/core/int/exc.inc || fail "#GP EFLAGS capture missing"
grep -q 'mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP' kernel32/core/int/exc.inc || fail "exception-stack handoff missing"
# The old generic SAFE macro destroyed the #GP CPU frame before C could inspect it.
awk '/^ASMexception_13:/{p=1} /^ASMexception_14:/{p=0} p{print}' kernel32/core/int/exc.inc | grep -q 'gp_frame_valid' || fail "#GP still lacks dedicated frame capture"
! awk '/^ASMexception_13:/{p=1} /^ASMexception_14:/{p=0} p{print}' kernel32/core/int/exc.inc | grep -q 'SAFE exception_13' || fail "#GP still uses frame-destroying SAFE macro"

grep -Eq 'GPF_RECOVER_NONZERO_PID=.*1' kernel32/init/keropt.c || fail "non-zero PID #GP recovery default is not enabled"
grep -q 'recover_kernel_gp' kernel32/core/cp/gpf.c || fail "non-zero PID #GP recovery path missing"
grep -q 'enable();' kernel32/core/cp/gpf.c || fail "exception recovery does not restore IF"
grep -q 'SwitchToThreadEx(0)' kernel32/core/cp/gpf.c || fail "exception recovery does not force transfer to PID0"

grep -q 'Only the shared request publication itself needs to be atomic' kernel32/core/cp/centralprocess.c || fail "CP IF fix missing"
# No historical one-line CLI + blocking wait pattern may return.
! grep -q 'flags=get_eflags(); disable();' kernel32/core/cp/centralprocess.c || fail "CP still has legacy broad CLI region"
grep -q 'enabling IRQs for blocking wait' kernel32/core/cp/centralprocess.c || fail "CP IF=0 blocking fallback missing"
grep -q 'IF was clear on shell entry; enabling interrupts' kernel32/sh/sh.c || fail "SMSH IF defensive recovery missing"

echo 'check_gpf_cp_if_recovery: PASS (live #GP frame + nonzero task recovery + CP wait IF fix)'
