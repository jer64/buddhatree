#!/bin/sh
set -eu
fail(){ echo "check_kernel_warning_policy: FAIL: $*" >&2; exit 1; }
SET=kernel32/settings.txt
[ -f "$SET" ] || fail "missing $SET"
ACTIVE=$(sed '/^[[:space:]]*#/d' "$SET")
if printf '%s\n' "$ACTIVE" | grep -Eq '(^|[[:space:]])-w([[:space:]\\]|$)'; then
    fail "kernel build still suppresses GCC warnings with -w"
fi
PROFILES=$(printf '%s\n' "$ACTIVE" | grep -E '^(CFLAGS|CFLAGS2|CFLAGS3|TURBO)=' || true)
[ -n "$PROFILES" ] || fail "no kernel CFLAGS profiles found"
# The default kernel policy is -Os; reject accidental -O2/-O3 in active settings.
printf '%s\n' "$ACTIVE" | grep -Eq '(^|[[:space:]])-O[23]([[:space:]\\]|$)' && \
    fail "active kernel settings contain -O2/-O3; JTMOS kernel policy is -Os"
grep -q -- '-Os -march=i486 -m32' "$SET" || fail "default -Os/-march=i486/-m32 kernel profile missing"
printf '%s\n' "$PROFILES" | grep -q -- '-Wall' || fail "kernel CFLAGS missing -Wall"
printf '%s\n' "$PROFILES" | grep -q -- '-Wextra' || fail "kernel CFLAGS missing -Wextra"
echo "check_kernel_warning_policy: PASS (-Wall/-Wextra active; -w absent; -Os policy active)"
