#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_nzip_32k_transport: FAIL: $*" >&2; exit 1; }
B=boot32pm/bootmod.inc
A=boot32pm/boot.asm
M=Makefile
L=run_jtmos_qemu_linode.sh

grep -Fq 'STREAM_SECTORS_PER_CHUNK equ 16' "$B" || fail "streamer is not 8 KiB/16 sectors"
grep -Fq 'STREAM_SEG_BUFFER        equ 0x0520' "$B" || fail "streamer is not using low-DMA segment 0x0520"
grep -Fq 'STREAM_BUFFER_PHYS       equ 0x00005200' "$B" || fail "PM copy source is not 0x5200"
grep -Fq 'stream_checksum_current_sector:' "$B" || fail "BIOS-side exact checksum missing"
grep -Fq 'stream_disk_sum' "$B" || fail "BIOS-side checksum state missing"
grep -Fq 'stream_exact_remaining' "$B" || fail "exact-byte accounting missing"
grep -Fq 'stream_copy_error' "$B" || fail "PM copy error state missing"
grep -Fq 'repe cmpsb' "$A" || fail "PM byte-for-byte copy verification missing"
grep -Fq '.nz_err_disk_checksum:  mov eax,8' "$A" || fail "NZIP code 8 missing"
grep -Fq '.nz_err_copy_checksum:  mov eax,9' "$A" || fail "NZIP code 9 missing"
grep -Fq '.nz_err_first_header_magic: mov eax,10' "$A" || fail "NZIP magic code 10 missing"
grep -Fq '.nz_err_first_header_size:  mov eax,11' "$A" || fail "NZIP raw-size code 11 missing"
grep -Fq 'KERNEL_MODULE_CONFIG=modules.linode.conf rootimage rootdisk utilscdrom' "$M" || fail "image-linode does not build complete root media"
grep -Fq 'JTMOS Linode root media missing. Run: make image-linode' "$L" || fail "Linode runner root-media hint missing"

echo 'check_nzip_32k_transport: PASS (8 KiB low-DMA chunks + integrity codes 8/9/10/11 + complete Linode media)'
