#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

list=${TMPDIR:-/tmp}/jtmos-exec-modes.$$.list
trap 'rm -f "$list"' EXIT HUP INT TERM
find . -type f -print | LC_ALL=C sort > "$list"

count=0
while IFS= read -r f; do
    sig=$(dd if="$f" bs=2 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
    [ "$sig" = 2321 ] || continue
    count=$((count + 1))
    if [ ! -x "$f" ]; then
        echo "release-exec: missing +x: $f" >&2
        exit 1
    fi
done < "$list"

[ "$count" -gt 0 ] || { echo "release-exec: no shebang files found" >&2; exit 1; }
echo "PASS: $count release shebang files retain executable mode"
