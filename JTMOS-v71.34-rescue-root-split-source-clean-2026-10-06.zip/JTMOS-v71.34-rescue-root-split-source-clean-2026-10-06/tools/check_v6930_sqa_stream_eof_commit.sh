#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
SQA="$ROOT/kernel32/sh/sqa.c"
SQAH="$ROOT/kernel32/sh/sqa.h"
DFA="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"
FCNTL="$ROOT/kernel32/init/fcntlbits.h"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.30 SQA streamed EOF commit: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.30|69.31|69.32|69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
if [ "$VERSION" = "69.30" ]; then
    grep -Fq '#define SQA_MEMBER_STAGE_MAX (1U * 1024U * 1024U)' "$SQAH" || fail "1 MiB staging bound missing"
else
    ! grep -Fq 'SQA_MEMBER_STAGE_MAX' "$SQAH" || fail "obsolete staging cap remains"
fi
grep -Fq 'O_TRUNC|O_JTMOS_BATCH' "$SQA" || fail "SQA does not request batch output"
grep -Fq 'defer_eof=((f->flags&O_JTMOS_BATCH) || f->lazy_trunc) && !(f->flags&O_APPEND);' "$DFA" || fail "write-time EOF deferral missing"
grep -Fq 'if(defer_eof && f->max_offset_peek>old_size)' "$DFA" || fail "pending logical size is not retained"
grep -Fq 'if(!defer_eof && exact_size>old_size &&' "$DFA" || fail "chunk writes still publish EOF"
grep -Fq 'jtmfs_SetSizeAfterWrite(dnr,staged_name,max_offset,db)' "$DFA" || fail "close-time EOF commit missing"
grep -Fq 'defer_eof=((flags&O_JTMOS_BATCH) || lazy_trunc) && !(flags&O_APPEND);' "$DFA" || fail "append exclusion missing at close"
grep -Fq 'publish the final size once at' "$FCNTL" || fail "batch flag contract not documented"

python3 - <<'PY' || fail "streamed EOF model failed"
length = 9 * 1024 * 1024 + 317
chunk = 128 * 1024
visible = 0
pending = 0
commits = 0
offset = 0
while offset < length:
    amount = min(chunk, length - offset)
    pending = max(pending, offset + amount)
    offset += amount
    assert visible == 0
assert commits == 0
visible = pending
commits += 1
assert visible == length and commits == 1
PY

echo "V69.30 SQA streamed EOF commit: PASS"
