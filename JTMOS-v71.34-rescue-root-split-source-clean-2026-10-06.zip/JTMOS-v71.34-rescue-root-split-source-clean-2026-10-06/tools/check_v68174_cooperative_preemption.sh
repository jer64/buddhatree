#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.174 cooperative-preemption regression: FAIL: $*" >&2; exit 1; }

case "$(cat "$ROOT/VERSION")" in 68.174|68.17[5-9]|68.1[89][0-9]|68.[2-9][0-9][0-9]*) ;; *) fail "VERSION predates 68.174" ;; esac
S="$ROOT/kernel32/core/cp/scheduler.c"
H="$ROOT/kernel32/core/cp/scheduler.h"

grep -Fq 'int SchedulerCanCooperate(void)' "$S" || fail "SchedulerCanCooperate missing"
grep -Fq '!systemStarted || !Multitasking || PitStorageSafeActive()' "$S" || fail "runtime/storage-safe guard missing"
grep -Fq 'flags&0x200UL' "$S" || fail "IF guard missing"
grep -Fq 'void SchedulerCooperate(void)' "$S" || fail "SchedulerCooperate missing"
grep -Fq 'SwitchToThread();' "$S" || fail "cooperative helper does not yield"
grep -Fq 'scheduler_coop_suppressed' "$S" || fail "suppressed checkpoint stats missing"
grep -Fq 'cooperative: requests=%u yields=%u suppressed=%u' "$S" || fail "SchedulerDump cooperative stats missing"
grep -Fq 'void SchedulerCooperateEvery(DWORD iteration,DWORD interval);' "$H" || fail "public cooperative API missing"

# The guarded helper must not manufacture an interrupt-enabled state.
start=$(grep -n 'int SchedulerCanCooperate(void)' "$S" | head -1 | cut -d: -f1)
end=$((start+35))
if sed -n "${start},${end}p" "$S" | grep -Eq '(^|[^A-Za-z_])enable[[:space:]]*\('; then
    fail "cooperative helper enables interrupts"
fi

# Filesystem and generic block I/O.
grep -Fq '(iteration & 0x0FUL)' "$ROOT/kernel32/fs/jtmfs/jtmfs.c" || fail "JTMFS 16-iteration checkpoint missing"
grep -Fq 'jtmfs_cooperative_yield(++coop_work)' "$ROOT/kernel32/fs/jtmfs/WriteChain.c" || fail "JTMFS write-chain checkpoint missing"
grep -Fq 'jtmfs_cooperative_yield((unsigned long)run)' "$ROOT/kernel32/fs/jtmfs/ReadChain.c" || fail "JTMFS read extent checkpoint missing"
grep -Fq 'SchedulerCooperate();' "$ROOT/kernel32/drivers/driver_rw.c" || fail "generic block I/O checkpoint missing"

# Storage polling must be cooperative in process context.
for f in drivers/sata/ahci.c drivers/sata/mcp61.c drivers/hd/hdMisc.c; do
    grep -Fq 'SchedulerCooperate();' "$ROOT/kernel32/$f" || fail "$f cooperative polling missing"
done

# Core I/O / process and shell work.
for f in fs/filebuf.c core/cp/centralprocess.c sh/copyall.c sh/findapp.c sh/lsapp.c sh/rmwildcard.c; do
    grep -Fq 'SchedulerCooperate();' "$ROOT/kernel32/$f" || fail "$f checkpoint missing"
done

# CPU-heavy/archive builtins.
grep -Fq '#define SQA_COOPERATE() SchedulerCooperate()' "$ROOT/kernel32/sh/sqa.c" || fail "SQA cooperative macro missing"
grep -Fq '#define NZIP_COOPERATE() SchedulerCooperate()' "$ROOT/kernel32/sh/nzip.c" || fail "NZIP cooperative macro missing"
grep -Fq '#define SQARC_COOPERATE() SchedulerCooperate()' "$ROOT/kernel32/sh/sqarc.c" || fail "SQARC cooperative macro missing"

refs=$(grep -R 'SchedulerCooperate' "$ROOT/kernel32" --include='*.c' --include='*.h' | wc -l | tr -d ' ')
[ "$refs" -ge 40 ] || fail "too few cooperative references ($refs)"

echo "V68.174 cooperative-preemption regression: PASS ($refs SchedulerCooperate references)"
