#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.200 post-storage network boot: FAIL: $*" >&2; exit 1; }
I="$ROOT/kernel32/init/init.c"
S="$ROOT/kernel32/sh/sh.c"
N="$ROOT/kernel32/drivers/tcpip/networkControl.c"
python3 - "$ROOT/VERSION" <<'PYV'
import sys
v=open(sys.argv[1]).read().strip().split('.')
major=int(v[0]); rel=int(v[1])
raise SystemExit(0 if major > 68 or (major == 68 and rel >= 200) else 1)
PYV
! grep -q 'StartSerialNetworkProcesses' "$I" || fail "KernelInit still owns network startup helper"
! grep -q 'JtInternetStart(' "$I" || fail "KernelInit still starts uIP/network"
grep -q 'nForce/uIP autostart deferred until SMSH storage/bootstrap completes' "$I" || fail "boot defer diagnostic missing"
grep -q 'static int smsh_autostart_after_root(void)' "$S" || fail "SMSH post-root bootstrap missing"
grep -q 'storage/bootstrap complete; Ethernet/uIP start requested' "$S" || fail "post-bootstrap start diagnostic missing"
grep -q 'JtInternetStart(SLIP_COM_PORT_N,DefaultSlipBPS)' "$S" || fail "network is not started after successful SMSH bootstrap"
# The start must occur after the final SQA automatic installer step in the same function.
python3 - "$S" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a=s.index('static int smsh_autostart_after_root(void)')
b=s.index('\n}\n#endif', a)
f=s[a:b]
if f.index('"sqa utils.iso"') >= f.index('JtInternetStart(SLIP_COM_PORT_N,DefaultSlipBPS)'):
    raise SystemExit('network start is not after SQA/bootstrap')
if 'return rc;' not in f:
    raise SystemExit('failed bootstrap no longer aborts before network startup')
PY
grep -q 'V68.200 starts the native Ethernet/uIP owner only after the SMSH storage/' "$N" || fail "network lifecycle documentation stale"
echo "V68.200 post-storage network boot: PASS"
