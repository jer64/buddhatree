#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_rootinstall_image: FAIL: $*" >&2; exit 1; }
CF="$ROOT/kernel32/fs/jtmfs/createfat.c"
CH="$ROOT/kernel32/fs/jtmfs/createfat.h"
FS="$ROOT/kernel32/sh/fsadmin.c"
BUILD="$ROOT/tools/build_install_image.sh"
MAKE="$ROOT/Makefile"
MAN="$ROOT/docs/SMSH-SQSH-MANUAL.txt"

[ -s "$CF" ] && [ -s "$FS" ] || fail "rootinstall sources missing"
grep -Fq 'int CopyKernelImage(const char *srcimage, const char *dst)' "$CF" || fail "CopyKernelImage implementation missing"
grep -Fq 'CopyKernelImage(const char *srcimage, const char *dst);' "$CH" || fail "CopyKernelImage declaration missing"
grep -Fq 'JTMOS_FLOPPY_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES' "$CF" || fail "raw image source offset does not use floppy layout contract"
grep -Fq 'fseek(image,(long)byte_offset,SEEK_SET)' "$CF" || fail "image source does not seek by byte offset"
grep -Fq 'fread(buf,1,(size_t)nbytes,image)' "$CF" || fail "image source does not use bounded fread"
grep -Fq 'buf[510]!=0x55 || buf[511]!=0xAA' "$CF" || fail "boot signature validation missing"
grep -Fq 'CopyKernelInstallPartitionedBootTrack' "$CF" || fail "partitioned-HDD boot-track installer missing"
grep -Fq 'JTMFS_MBR_PARTITION_BYTE_OFFS' "$CF" || fail "MBR partition-table preservation missing"
grep -Fq 'JTMFS_BOOT_RUNTIME_MAGIC' "$CF" || fail "partition-safe runtime metadata missing"
grep -Fq 'if(!partitioned)' "$CF" || fail "whole-disk checksum fallback missing"
grep -Fq 'SetKernelChecksum(dnr,source_raw_checksum)' "$CF" || fail "legacy whole-disk checksum publication missing"

grep -Fq 'Usage: rootinstall [target] [floppy-device|floppy-image]' "$FS" || fail "new rootinstall syntax missing"
grep -Fq 'rootinstall hda jtm32.img' "$FS" || fail "image example missing"
grep -Fq 'source_is_device' "$FS" || fail "source device/file discriminator missing"
grep -Fq 'r=CopyKernelImage(source,target);' "$FS" || fail "rootinstall does not call image installer"
grep -Fq 'r=CopyKernel(source,target);' "$FS" || fail "physical floppy compatibility missing"
grep -Fq 'rootinstall TARGET [floppy:|IMAGE]' "$ROOT/libc/apps/sqsh.c" || fail "canonical SQSH lacks rootinstall image help"

grep -Fq 'BOOT_FLOPPY_IMAGE="$ROOT/jtm32.img"' "$BUILD" || fail "jtm32 packaging source missing"
grep -Fq 'cp "$BOOT_FLOPPY_IMAGE" "$BOOT_STAGE/jtm32.img"' "$BUILD" || fail "jtm32 absent from boot.sqa staging"
grep -Fq 'packages: host-tools apps image' "$MAKE" || fail "packages do not require boot image first"
grep -Fq 'image: kernel-nz boot host-tools' "$MAKE" || fail "image target still depends on packages/cycles"
grep -Fq 'MIRROR="$ROOT/kernel32/utilities.iso"' "$ROOT/tools/publish_utilities_iso.sh" || fail "kernel32/utilities.iso mirror missing"

grep -Fq 'rootinstall hda jtm32.img' "$MAN" || fail "manual lacks image-source installation"
grep -Fq 'sqa cdrom' "$MAN" || fail "manual lacks USB/ATAPI extraction path"

if [ -f "$ROOT/utilities.iso" ]; then
    strings -a "$ROOT/utilities.iso" | grep -Fq 'jtm32.img' || fail "built utilities.iso lacks jtm32.img"
fi
if [ -f "$ROOT/kernel32/utilities.iso" ] && [ -f "$ROOT/utilities.iso" ]; then
    cmp -s "$ROOT/utilities.iso" "$ROOT/kernel32/utilities.iso" || fail "kernel32 utilities mirror differs"
fi

echo "check_rootinstall_image: PASS (image/device source + partition-safe HDD MBR + utilities jtm32 payload)"
