#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
C="$ROOT/kernel32/drivers/tcpip/uipMain.c"
H="$ROOT/kernel32/drivers/tcpip/uipMain.h"
I="$ROOT/kernel32/core/int/IdleThread.c"
S="$ROOT/kernel32/core/cp/scheduler.c"
V=$(cat "$ROOT/VERSION")
case "$V" in
  68.*) rel=${V#68.}; [ "$rel" -ge 105 ] || { echo "FAIL: uIP idle fix requires V68.105+, got V$V"; exit 1; } ;;
  *) echo "FAIL: uIP idle fix checker expects V68.105+, got V$V"; exit 1 ;;
esac
grep -q 'SchedulerIdleWait();' "$I" || { echo "FAIL: CPU_IDLE no longer enters scheduler idle wait"; exit 1; }
grep -q 'cpu_sti_hlt();' "$S" || { echo "FAIL: scheduler idle wait no longer executes STI;HLT"; exit 1; }
grep -q 'UIP_IDLE_SLEEP_FAST_US   2000UL' "$C" || exit 1
grep -q 'UIP_IDLE_SLEEP_MEDIUM_US 5000UL' "$C" || exit 1
grep -q 'UIP_IDLE_SLEEP_MAX_US    10000UL' "$C" || exit 1
grep -q 'uip_idle_sleep(idle_rounds)' "$C" || exit 1
grep -q 'if(UsecSleep(usec)!=0)' "$C" || exit 1
grep -q 'idle_sleep_calls' "$H" || exit 1
# The owner loop must not end every pass with an unconditional yield anymore.
python3 - "$C" <<'PY2'
import sys
s=open(sys.argv[1]).read()
a=s.index('int UipProcess(void)')
b=s.index('return 0;',a)
body=s[a:b]
assert 'if(did_work)' in body
assert 'uip_idle_sleep(idle_rounds);' in body
PY2
echo "check_uip_idle_cpu: PASS (scheduler STI;HLT idle + adaptive 2/5/10ms uIP sleep)"
