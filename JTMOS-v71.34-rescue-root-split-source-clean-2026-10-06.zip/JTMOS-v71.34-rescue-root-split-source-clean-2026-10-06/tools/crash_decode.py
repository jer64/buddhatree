#!/usr/bin/env python3
"""Decode JTMOS V68.210 crash.log or emergency serial crash records.

Usage: crash_decode.py LOG [kernel32.map]
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

HEX = r"(?:0x)?[0-9A-Fa-f]+"

def parse_int(text: str) -> int:
    text=text.strip()
    return int(text,16 if text.lower().startswith('0x') or re.search(r'[a-fA-F]',text) else 10)

def load_symbols(path: Path):
    syms=[]
    # GNU ld map variants commonly contain either "0xADDR symbol" or
    # "ADDR symbol". Ignore section names and assignment expressions.
    for raw in path.read_text(errors='replace').splitlines():
        m=re.match(r'^\s*(?:0x)?([0-9A-Fa-f]{6,16})\s+([^\s=]+)\s*$', raw)
        if not m:
            m=re.match(r'^\s*(?:0x)?([0-9A-Fa-f]{6,16})\s+([^\s=]+)\s+.*$', raw)
        if not m: continue
        name=m.group(2)
        if name.startswith('.') or name in {'*fill*','LOAD'}: continue
        try: addr=int(m.group(1),16)
        except ValueError: continue
        syms.append((addr,name))
    syms.sort()
    # Deduplicate exact addr/name pairs while preserving address order.
    out=[]; seen=set()
    for item in syms:
        if item not in seen:
            seen.add(item); out.append(item)
    return out

def resolve(syms,eip):
    lo=0; hi=len(syms)
    while lo<hi:
        mid=(lo+hi)//2
        if syms[mid][0] <= eip: lo=mid+1
        else: hi=mid
    if lo==0: return None
    addr,name=syms[lo-1]
    return name,eip-addr,addr

def persistent_blocks(text):
    pat=re.compile(r'=+ JTMOS CRASH ANALYSIS V\d+ =+\n(.*?)=+ END CRASH-ID \d+ =+',re.S)
    return [m.group(1) for m in pat.finditer(text)]

def serial_blocks(text):
    pat=re.compile(r'\[CRASH-BEGIN\](.*?\[CRASH-END-SNAPSHOT\](?:\s*\[CRASH-DISPOSITION\][^\n]*)?)',re.S)
    return [m.group(1) for m in pat.finditer(text)]

def field_hex(block,key):
    m=re.search(r'\b'+re.escape(key)+r'=(?:0x)?([0-9A-Fa-f]+)',block,re.I)
    return int(m.group(1),16) if m else None

def field_dec(block,key):
    m=re.search(r'\b'+re.escape(key)+r'=(-?\d+)',block)
    return int(m.group(1)) if m else None

def summarize(block,idx,syms,serial=False):
    # Persistent format uses CS:EIP=cccc:eeeeeeee. Parse that first so the
    # CS half cannot be mistaken for a standalone EIP value.
    m=re.search(r'CS:EIP=[0-9A-Fa-f]+:([0-9A-Fa-f]+)',block)
    eip=int(m.group(1),16) if m else field_hex(block,'eip')
    pid=field_dec(block,'PID')
    if pid is None: pid=field_hex(block,'pid')
    exc=field_dec(block,'EXC')
    if exc is None: exc=field_hex(block,'exc')
    eflags=field_hex(block,'eflags')
    cr2=field_hex(block,'cr2')
    print(f'Crash #{idx}: PID={pid if pid is not None else "?"} EXC={exc if exc is not None else "?"}')
    if eip is not None:
        line=f'  EIP=0x{eip:08x}'
        if syms:
            r=resolve(syms,eip)
            if r:
                name,off,addr=r
                line += f' -> {name}+0x{off:x} (symbol 0x{addr:08x})'
        print(line)
    if eflags is not None:
        print(f'  EFLAGS=0x{eflags:08x} IF={(eflags >> 9) & 1}')
    if cr2 is not None and cr2 != 0:
        print(f'  CR2=0x{cr2:08x}' + ('  [near-NULL]' if cr2 < 0x1000 else ''))
    suspects=re.findall(r'^(?:SUSPECT(?:-CONTEXT)?|ANALYSIS-WARN|PF:|GP:).*$',block,re.M)
    for s in suspects[-8:]: print('  '+s)
    sc=re.findall(r'^(?:SC |\[CRASH-SC\]).*$',block,re.M)
    lk=re.findall(r'^(?:LK |\[CRASH-LK\]).*$',block,re.M)
    sw=re.findall(r'^(?:SW |\[CRASH-SW\]).*$',block,re.M)
    if sc: print('  Last syscall: '+sc[-1].strip())
    if lk: print('  Last lock:    '+lk[-1].strip())
    if sw: print('  Last switch:  '+sw[-1].strip())
    disp=re.findall(r'\[CRASH-DISPOSITION\].*',block)
    if disp: print('  '+disp[-1].strip())


def main(argv):
    if len(argv) not in (2,3):
        print('usage: crash_decode.py LOG [kernel32.map]',file=sys.stderr); return 2
    log=Path(argv[1]); text=log.read_text(errors='replace')
    syms=load_symbols(Path(argv[2])) if len(argv)==3 else []
    blocks=persistent_blocks(text)
    serial=False
    if not blocks:
        blocks=serial_blocks(text); serial=True
    if not blocks:
        print('No JTMOS V68.210 crash blocks found.',file=sys.stderr); return 1
    for i,b in enumerate(blocks,1):
        if i>1: print()
        summarize(b,i,syms,serial)
    return 0

if __name__=='__main__':
    raise SystemExit(main(sys.argv))
