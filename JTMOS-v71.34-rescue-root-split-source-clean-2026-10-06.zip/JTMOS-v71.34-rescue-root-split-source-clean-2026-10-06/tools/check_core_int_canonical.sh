#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_core_int_canonical: FAIL: $*" >&2; exit 1; }

CANON="$ROOT/kernel32/core/int"
[ -d "$CANON" ] || fail "kernel32/core/int missing"

for f in threads.c pit.c debug.c logging.c scs.c llint.asm llexc.asm; do
    [ -s "$CANON/$f" ] || fail "canonical core/int/$f missing"
done

# These were historical copies/aliases of the same low-level implementation.
# Keeping them physically absent prevents three diverging kernels from being
# edited independently again.
for d in chiplevel iodma lowlevel; do
    [ ! -e "$ROOT/kernel32/core/$d" ] || fail "retired kernel32/core/$d exists"
done

# autogen must link core/int and must defensively reject all retired mirror names
# if one is accidentally recreated in a developer tree.
grep -Fq 'core/(?:chiplevel|iodma|lowlevel)' "$ROOT/kernel32/autogen.pl" || \
    fail "autogen.pl lacks retired-mirror exclusion"
if grep -Eq 'return if .*\^core/\(\?:int\|' "$ROOT/kernel32/autogen.pl"; then
    fail "autogen.pl excludes canonical core/int"
fi

TMP=${TMPDIR:-/tmp}/jtmos-core-int-canonical-$$
trap 'rm -f "$TMP"' EXIT HUP INT TERM
(
    cd "$ROOT/kernel32"
    JTMOS_AUTOGEN_DRYRUN=1 ./autogen.pl
) > "$TMP"
for obj in core/int/threads.o core/int/pit.o core/int/debug.o core/int/logging.o core/int/llint.o core/int/llexc.o; do
    grep -Fq "$obj" "$TMP" || fail "$obj missing from generated link"
done

# Active release checks must also use the canonical tree.  Two inventory tests
# intentionally contain the retired names above, so exclude those validators.
for f in "$ROOT"/tools/*.sh; do
    case "$(basename "$f")" in
        check_core_int_canonical.sh|check_kernel_asm_includes.sh) continue ;;
    esac
    if grep -Eq 'kernel32/core/(chiplevel|iodma|lowlevel)|core/(chiplevel|iodma|lowlevel)/' "$f"; then
        fail "stale retired-core reference in ${f#$ROOT/}"
    fi
done

echo 'check_core_int_canonical: PASS (core/int is the only native low-level core)'
