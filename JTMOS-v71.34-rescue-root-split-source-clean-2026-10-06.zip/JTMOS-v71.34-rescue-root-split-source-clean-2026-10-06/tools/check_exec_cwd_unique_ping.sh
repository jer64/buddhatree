#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_exec_cwd_unique_ping: FAIL: $*" >&2; exit 1; }
CP=kernel32/core/cp/centralprocess.c
CPH=kernel32/core/cp/centralprocess.h
UNIQUE=libc/apps/unique/unique.c
PING=kernel32/sh/networkapp.c
APPS=libc/apps/Makefile
BUILD=tools/build_install_image.sh

grep -Fq 'int inheritCWD;' "$CPH" || fail 'CP request does not preserve exact-CWD inheritance mode'
grep -Fq 'GetThreadDNR(centralprocess.requesterPID)' "$CP" || fail 'child cwd does not late-snapshot parent DNR'
grep -Fq 'GetThreadDB(centralprocess.requesterPID)' "$CP" || fail 'child cwd does not late-snapshot parent DB'
grep -Fq 'GetThreadDNR(pid)!=centralprocess.runDNR' "$CP" || fail 'child DNR is not verified after launch'
grep -Fq 'SetThreadDB(pid,centralprocess.runDB)' "$CP" || fail 'child DB repair is missing'
grep -Fq 'SYSMEMREQ(APPRAM_1024K)' "$UNIQUE" || fail 'Unique has no interpreter heap reservation'
grep -Fq 'pwd=getenv("PWD")' "$UNIQUE" || fail 'Unique relative-script compatibility fallback missing'
grep -Fq 'ping_drain_terminal_keys' "$PING" || fail 'ping does not drain foreground terminal input'
grep -Fq "key==27 || key=='q' || key=='Q'" "$PING" || fail 'ping Esc/q termination missing'
grep -Fq 'memconfig mkdir mkfs more mv net ping partition' "$APPS" || fail 'ping.bin is not a release app'
grep -Fq 'ping.bin' "$BUILD" || fail 'ping.bin is not in system payload'

echo 'check_exec_cwd_unique_ping: PASS (exact child DNR/DB + Unique relative files + nonlocking ping input)'
