#!/bin/sh
set -eu
fail(){ echo "check_tcp_rx_inbound: FAIL: $*" >&2; exit 1; }
CLIENT=kernel32/drivers/tcpip/jt_http_client.c
CLIENTH=kernel32/drivers/tcpip/jt_http_client.h
UIP=kernel32/drivers/tcpip/uip.c
ARP=kernel32/drivers/tcpip/uip_arp.c
MAIN=kernel32/drivers/tcpip/uipMain.c
NET=kernel32/sh/networkapp.c

grep -Fq '#define JT_HTTP_CLIENT_RX_HIGH' "$CLIENT" || fail "high water missing"
grep -Fq '#define JT_HTTP_CLIENT_RX_LOW' "$CLIENT" || fail "low water missing"
grep -Fq 'uip_stop();' "$CLIENT" || fail "zero-window stop missing"
grep -Fq 'uip_restart();' "$CLIENT" || fail "window reopen missing"
grep -Fq 'client_resume_pending=1' "$CLIENT" || fail "reader-to-owner resume request missing"
grep -Fq 'client_stats.overflow_errors++' "$CLIENT" || fail "overflow visibility missing"
grep -Fq 'flow_stops' "$CLIENTH" || fail "flow stats ABI missing"
grep -Fq 'HTTP client RX queued=' "$NET" || fail "inet flow stats missing"
grep -Fq 'uip_arp_update(uip_draddr, &(IPBUF->ethhdr.src))' "$ARP" || fail "routed reverse-next-hop learning missing"
grep -Fq 'third handshake packet is allowed to carry application data' "$UIP" || fail "final ACK payload fix missing"
grep -Fq 'ip[9]!=6' "$MAIN" || fail "linearization not restricted to TCP"


echo "check_tcp_rx_inbound: PASS (zero-window backpressure + reverse-next-hop ARP + handshake data)"
