#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_dosboot_nzip: FAIL: $*" >&2; exit 1; }
D=boot32pm/dosboot.asm
M=boot32/Makefile
T=Makefile

[ -f "$D" ] || fail "$D missing"
[ -f "$M" ] || fail "$M missing"

grep -q '^%define BOOT_VESA_GRAPHICS 0' "$D" || fail "DOS boot must default to text/curses"
grep -q '^%define DOS_READ_HALF_CHUNK 0x8000' "$D" || fail "32 KiB DOS sub-read size missing"
grep -q '^%define DOS_CHUNK_BYTES[[:space:]]*0x10000' "$D" || fail "64 KiB completed chunk size missing"
# A .COM file begins at its first emitted byte.  a20.inc/e820.inc contain real
# code, so begin:jmp start must precede both includes or DOSBOOT silently runs
# a20() and RETs through the PSP instead of reaching the banner.
entry_line=$(grep -n -m1 '^begin:' "$D" | cut -d: -f1 || true)
a20_inc_line=$(grep -n -m1 '^%include "a20.inc"' "$D" | cut -d: -f1 || true)
e820_inc_line=$(grep -n -m1 '^%include "e820.inc"' "$D" | cut -d: -f1 || true)
[ -n "$entry_line" ] || fail "COM begin label missing"
[ -n "$a20_inc_line" ] || fail "a20.inc include missing"
[ -n "$e820_inc_line" ] || fail "e820.inc include missing"
[ "$entry_line" -lt "$a20_inc_line" ] || fail "a20.inc emits code before COM entry"
[ "$entry_line" -lt "$e820_inc_line" ] || fail "e820.inc emits code before COM entry"
grep -Fq 'COM_ENTRY_OFFSET equ (begin - $$)' "$D" || fail "assembler COM-entry offset scalar missing"
grep -Fq 'times -COM_ENTRY_OFFSET db 0' "$D" || fail "assembler COM-entry offset assertion missing"
if [ -f boot32/dosboot.com ]; then
    first_byte=$(od -An -tx1 -N1 boot32/dosboot.com | tr -d ' \n')
    case "$first_byte" in
        e9|eb) : ;;
        *) fail "DOSBOOT.COM first opcode is 0x$first_byte, expected entry JMP (E9/EB)" ;;
    esac
fi
grep -q 'mov ah,0x3F' "$D" || fail "DOS AH=3F file read missing"
grep -q 'smsw ax' "$D" || fail "real-mode/protected-host SMSW guard missing"
grep -q 'test al,1' "$D" || fail "CR0.PE guard missing"
! grep -q 'pushfd' "$D" || fail "PUSHFD V86 probe regression present"
# Regression: V86 must be detected before the loader executes CLI.  FreeDOS
# commonly runs under JEMM386/EMM386, where an early CLI faults before DOSBOOT
# can print a diagnostic and appears to return silently to the command prompt.
v86_line=$(grep -n -m1 'test al,1' "$D" | cut -d: -f1)
cli_line=$(grep -n -m1 '^[[:space:]]*cli\([[:space:];]\|$\)' "$D" | cut -d: -f1 || true)
[ -n "$v86_line" ] || fail "CR0.PE guard line missing"
[ -z "$cli_line" ] || [ "$cli_line" -gt "$v86_line" ] || \
    fail "privileged CLI executes before V86 guard (silent FreeDOS exit regression)"
grep -q 'MOV SS inhibits external' "$D" || fail "V86-safe atomic loader stack switch documentation missing"
grep -q 'mov dx,DOS_READ_HALF_CHUNK' "$D" || fail "upper 32 KiB half read missing"
grep -q '^pmode_stream_copy:' "$D" || fail "real->PM chunk copy entry missing"
grep -q '^pmode_stream_copy32:' "$D" || fail "32-bit chunk copier missing"
grep -q 'mov edi,dword \[fs:stream_high_dest\]' "$D" || fail "PM copy does not use high destination"
grep -q 'JTMOS_BOOT_NZIP_STAGING_PHYS' "$D" || fail "shared 16 MiB nzip staging constant missing"
grep -q '^nzip_decompress_kernel32:' "$D" || fail "protected-mode nzip decoder missing"
grep -q 'cmp dword \[esi\],0x32505A4E' "$D" || fail "DOS NZIP2 magic check missing"
grep -q 'rep movsb' "$D" || fail "DOS NZIP2 overlapping LZ77 copy missing"
grep -q 'mov edi,JTMOS_KERNEL_LOAD_PHYS' "$D" || fail "nzip output is not the canonical 1 MiB kernel address"
grep -q 'jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS' "$D" || fail "flat final kernel jump missing"
grep -q 'mov word \[es:0x1000\],kchecksum' "$D" || fail "expected raw checksum handoff missing"
grep -q 'mov word \[es:0x1004\],ax' "$D" || fail "DOS boot-drive handoff missing"
grep -q 'mov word \[es:0x7DFE\],0xAA55' "$D" || fail "legacy loader signature handoff missing"
grep -q '^dos_stack:' "$D" || fail "dedicated COM loader stack missing"
grep -Fq 'DOS_PROGRAM_PARAS equ (((program_end - $$) + 0x10F) >> 4)' "$D" || fail "NASM 3 scalar-safe COM paragraph calculation missing"
! grep -Eq 'DOS_PROGRAM_PARAS[[:space:]]+equ[[:space:]]+\(\(program_end[[:space:]]*\+' "$D" || fail "relocatable program_end shift regression present"
grep -q 'cmp dx,\[cs:0x0002\]' "$D" || fail "PSP conventional-memory bound check missing"
grep -q 'mov dword \[stream_remaining\],kernel_nz_bytes' "$D" || fail "exact compressed byte count is not used"
grep -q '^dos_v86_unsupported:' "$D" || fail "V86 rejection target label missing"
grep -q 'push cx[[:space:]]*; DOS may clobber general registers' "$D" || fail "DOS first-read count is not preserved across INT 21h"
grep -q '^dos_long_read:' "$D" || fail "oversized/stale KERNEL32.NZ rejection missing"
grep -q '^dos_staging_overflow:' "$D" || fail "high staging runtime bound guard missing"
grep -q 'msg_close_failed' "$D" || fail "DOS close error handling missing"

# DOS package uses legal 8.3 names and the exact boot32pm NZIP2 stream.
grep -q '^all: modern' "$M" || fail "boot32 default target must route to modern loaders"
grep -q '^modern:' "$M" || fail "boot32 modern default target missing"
grep -q '\$(MAKE) -C \.\. boot' "$M" || fail "boot32 default does not delegate to boot32pm path"
grep -q '^dosboot.com:' "$M" || fail "DOSBOOT.COM build target missing"
grep -q 'invalid COM entry opcode' "$M" || fail "DOSBOOT.COM build-time first-opcode guard missing"
grep -q '^kernel32.nz: ../kernel32/kernel32.bin.nz' "$M" || fail "KERNEL32.NZ is not sourced from canonical kernel32.bin.nz"
grep -q 'cp dosboot.com dosboot/DOSBOOT.COM' "$M" || fail "DOSBOOT.COM package copy missing"
grep -q 'cp kernel32.nz dosboot/KERNEL32.NZ' "$M" || fail "KERNEL32.NZ package copy missing"
grep -q '^dosboot: kernel-nz' "$T" || fail "top-level dosboot target missing"

# Ensure the DOS path did not regress to the old raw 0x10000 staging model.
! grep -Eq 'kernel_raw_loadlimit|mov[[:space:]]+esi,0x00010000' "$D" || \
    fail "legacy whole-raw low-memory staging remains in DOS boot"

echo 'check_dosboot_nzip: PASS (COM entry -> DOS 64 KiB bounce -> PM high staging -> NZIP2 LZ77 @ 1 MiB)'
