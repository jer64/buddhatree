#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}
SH="$ROOT/kernel32/sh/sh.c"
REL="$ROOT/kernel32/include/jtmos_release.h"
fail(){ echo "V69.25 boot-media autostart: FAIL: $*" >&2; exit 1; }

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
  69.2[5-9]|69.[3-9][0-9]|[7-9][0-9].*) ;;
  *) fail "VERSION $VERSION predates V69.25" ;;
esac
if [ "$VERSION" = "69.25" ]; then
  grep -Fq '#define JTMOS_SOURCE_RELEASE "V69.25"' "$REL" || fail "release header not V69.25"
fi
grep -Fq 'if(BootUtilsRamSize()!=0U)' "$SH" || fail "DOSBOOT handoff detection missing"
grep -Fq 'media_command="sqa utils.iso";' "$SH" || fail "DOSBOOT staged-media path missing"
grep -Fq 'driver_getdevicebyname("sys")!=NULL' "$SH" || fail "sys: media detection missing"
grep -Fq 'media_command="sqa sys";' "$SH" || fail "direct sys: extraction path missing"
grep -Fq 'driver_getdevicebyname("cdrom")!=NULL' "$SH" || fail "ATAPI fallback detection missing"
grep -Fq 'media_command="sqa cdrom";' "$SH" || fail "direct cdrom extraction fallback missing"

python3 - "$SH" <<'PY'
import pathlib,sys
s=pathlib.Path(sys.argv[1]).read_text()
a=s.index('static int smsh_autostart_after_root(void)')
b=s.index('int run_shell(void)',a)
f=s[a:b]
# The failure in the 2026-09-23 boot log was an unconditional ramextract.
# It must now be nested only below a positive BootUtilsRamSize() branch.
cond=f.index('if(BootUtilsRamSize()!=0U)')
ram=f.index('smsh_execute_command_text("ramextract utils.iso")')
sys_=f.index('media_command="sqa sys"')
cd=f.index('media_command="sqa cdrom"')
exec_media=f.index('smsh_execute_command_text(media_command)')
graos=f.index('smsh_execute_command_text("graos")')
assert cond < ram < sys_ < cd < exec_media < graos
# Network recovery was separated from the extraction helper in V70.54.  It
# must still run after autostart, and it now uses a full controller restart.
run=s[s.index('int run_shell(void)'):]
assert run.index('smsh_autostart_after_root()') < run.index('smsh_network_boot_autorestart(boot_root_ready)')
net=s[s.index('static int smsh_network_boot_autorestart'):
      s.index('static int smsh_enter_interactive_terminal')]
assert 'JtInternetRestart()' in net
# There must be no ramextract in the fixed unconditional root step table.
rt0=f.index('static const char *root_steps[]')
rt1=f.index('};',rt0)
root_table=f[rt0:rt1]
if 'ramextract' in root_table:
    raise SystemExit('ramextract remains unconditional')
PY

sh -n "$0" || fail "checker syntax error"
echo "V69.25 boot-media autostart: PASS"
