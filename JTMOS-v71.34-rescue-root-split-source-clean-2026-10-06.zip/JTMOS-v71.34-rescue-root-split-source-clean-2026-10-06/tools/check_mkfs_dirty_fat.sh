#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_mkfs_dirty_fat: FAIL: $*" >&2; exit 1; }
C=kernel32/fs/jtmfs/createfat.c
F=kernel32/fs/jtmfs/format.c
H=kernel32/fs/jtmfs/jtmfat.h
X=kernel32/fs/jtmfs/diskcache/flexFat.c
U=libc/apps/mkfs.c
K=kernel32/sh/formatapp.c
grep -q 'JtmfsInitializeDirtyFat' "$C" || fail 'dirty FAT initializer missing'
grep -q 'exact dirty-block commit' "$C" || fail 'information block is not exact-block committed'
! grep -q 'info-window' "$C" || fail 'legacy 8-block info window still present'
! grep -q 'JtmfsBigfootInitializeFat' "$C" || fail 'whole-FAT Bigfoot formatter still present'
grep -q 'JTMFS_LAZY_FAT_FLAG' "$H" || fail 'lazy FAT on-disk marker missing'
grep -q 'fat_sector>=f->lazy_materialized_pages' "$X" || fail 'lazy-zero read path missing'
grep -q 'jtmfat_lazyfat_set_materialized_pages' "$X" || fail 'lazy prefix persistence missing'
grep -q 'flexFlushFATChecked(device_nr)' "$F" || fail 'final mkfs does not flush dirty FAT only'
grep -q 'dirty FAT only' "$U" || fail 'external mkfs help/status not updated'
grep -q 'dirty FAT only' "$K" || fail 'internal mkfs status not updated'
if grep -Eq 'writing FAT.*65|verifying FAT|full FAT physical write\+readback' "$C"; then fail 'whole-FAT write/verify progress remains'; fi
echo 'check_mkfs_dirty_fat: PASS'
