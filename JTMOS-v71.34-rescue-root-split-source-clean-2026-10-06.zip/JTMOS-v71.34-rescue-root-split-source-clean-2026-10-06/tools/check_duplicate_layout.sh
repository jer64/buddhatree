#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "duplicate layout: $*" >&2; exit 1; }

expect_link()
{
    path=$1
    target=$2
    [ -L "$path" ] || fail "$path must be a symbolic link"
    actual=$(readlink "$path")
    [ "$actual" = "$target" ] || fail "$path points to '$actual', expected '$target'"
    [ -e "$path" ] || fail "$path is a dangling symbolic link"
}

# Native source namespaces have one physical implementation only.
[ ! -e tools/kernel32 ] || fail "tools/kernel32 must not exist"
[ ! -e kernel32/irq ] || fail "kernel32/irq is a retired physical IRQ-driver mirror; use kernel32/drivers"
for p in apps tools/apps kernel32/apps gui tools/gui tools/gr tools/something tools/testi kernel32/LaunchApp; do
    [ ! -e "$p" ] && [ ! -L "$p" ] || fail "$p is a forbidden duplicate/legacy source tree"
done

[ -f kernel32/core/cp/LaunchApp.c ] || fail "canonical LaunchApp.c missing"
[ -f kernel32/core/cp/LaunchApp.h ] || fail "canonical LaunchApp.h missing"
[ -f kernel32/core/cp/elf32.h ] || fail "canonical elf32.h missing"
[ -f libc/libc/jtmos_elf32.ld ] || fail "canonical application linker script missing"
[ -f docs/legacy/LaunchApp/README_ELF32_POSIX_MMAP.txt ] || fail "LaunchApp historical README was not preserved"
[ -f docs/legacy/LaunchApp/POSIX_MMAP_CHANGES.patch ] || fail "LaunchApp historical patch was not preserved"

# Exact source clones are aliases, never dereferenced physical copies.
# drv/ and libc/drv/ remain separate build roots because their makefiles use
# different build contexts, but byte-identical old/cache source subtrees share
# one canonical physical copy below libc/drv/.
expect_link drv/hd/old ../../libc/drv/hd/old
expect_link drv/hd/cache ../../libc/drv/hd/cache
expect_link drv/tcp/old ../../libc/drv/tcp/old
expect_link drv/slip/old ../../libc/drv/slip/old

# Native GraOS adapter overlay: graos-native-overlay is canonical.
expect_link graos-host/kernel32/sh/graos ../../../graos-native-overlay/graos
expect_link graos-host/kernel32/sh/postman ../../../graos-native-overlay/postman

# graos-host/apps is intentionally NOT one big alias: host-specific files have
# diverged from libc/apps.  Only subtrees proven byte-identical at V68.110 are
# shared.  This keeps host-port changes while preventing unchanged mirrors from
# drifting independently.
for d in ar ega iview mkan mpeg1 old tmp vid; do
    expect_link "graos-host/apps/$d" "../../libc/apps/$d"
    expect_link "graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps/$d" "../../../../libc/apps/$d"
done
expect_link graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps/gui ../../../apps/gui

# The active kernel generator must remain insulated from any accidentally
# reintroduced legacy IRQ mirror even though that directory is forbidden above.
grep -Fq 'return if $rel =~ m{^irq/};' kernel32/autogen.pl || \
    fail "kernel32/autogen.pl lost the defensive irq/ exclusion"

VERSION=$(cat VERSION 2>/dev/null || echo unknown)
echo "canonical duplicate-directory layout: PASS (V${VERSION} symlink aliases preserved)"
