#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}
OHCI="$ROOT/kernel32/drivers/usb/ohci.c"
REL="$ROOT/kernel32/include/jtmos_release.h"
fail(){ echo "V69.35 OHCI SOF/hard recovery: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in 69.35|7[0-9].*) ;; *) fail "VERSION predates 69.35" ;; esac
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
grep -Fq '#define OHCI_INTR_UE' "$OHCI" || fail "UE status bit missing"
grep -Fq 'static int ohci_hid_rearm(OHCI_HID *h)' "$OHCI" || fail "fallible HID rearm missing"
grep -Fq 'ohci_wait_next_frame(OHCI_PERIODIC_QUIESCE_MS)' "$OHCI" || fail "SOF-synchronized rearm missing"
grep -Fq 'static int ohci_hard_recover(const char *reason)' "$OHCI" || fail "hard recovery helper missing"
grep -Fq 'ohci_w32(OHCI_REG_COMMAND_STATUS,OHCI_CMD_HCR);' "$OHCI" || fail "HostControllerReset missing"
grep -Fq 'if(intr&OHCI_INTR_UE)' "$OHCI" || fail "UE polling missing"
grep -Fq 'HC left Operational state' "$OHCI" || fail "HCFS health check missing"
grep -Fq 'frame counter stopped' "$OHCI" || fail "frame-stall reset path missing"
python3 - "$OHCI" <<'PY'
import pathlib,re,sys
s=pathlib.Path(sys.argv[1]).read_text()
m=re.search(r'static int ohci_hid_rearm\(OHCI_HID \*h\)\n\{(.*?)\n\}',s,re.S)
if not m: raise SystemExit('rearm missing')
b=m.group(1)
if 'delay(1);' in b: raise SystemExit('unsafe fixed-delay TD reuse remains')
if b.index('ohci_wait_next_frame(OHCI_PERIODIC_QUIESCE_MS)') > b.index('ohci_arm_hid(h,0)'):
    raise SystemExit('TD rewrite occurs before SOF fence')
m=re.search(r'static int ohci_hard_recover\(const char \*reason\)\n\{(.*?)\n\}',s,re.S)
if not m: raise SystemExit('hard recovery missing')
b=m.group(1)
if b.index('OHCI_CMD_HCR') > b.index('memset(ohci.dma,0,OHCI_DMA_BYTES)'):
    raise SystemExit('DMA memory reused before HCR ownership barrier')
PY
echo "V69.35 OHCI SOF/hard recovery: PASS"
