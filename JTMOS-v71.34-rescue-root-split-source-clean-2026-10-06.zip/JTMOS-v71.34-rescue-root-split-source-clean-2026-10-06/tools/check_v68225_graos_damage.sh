#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
GUI="$ROOT/libc/apps/gui"
KSC="$ROOT/kernel32/core/int/scs.c"
VESA="$ROOT/kernel32/init/vesa.c"
fail(){ echo "V68.225 GraOS damage: FAIL: $*" >&2; exit 1; }

case "$(cat "$ROOT/VERSION")" in 68.225|68.226|68.227|69.*) ;; *) fail "VERSION mismatch" ;; esac
grep -Eq '#define JTMOS_SOURCE_RELEASE "V68\.(225|226|227)"' "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
grep -Fq '#define GRAOS_VERSION "V51"' "$GUI/graos.h" || fail "GraOS V51 missing"

# Startup must reach a complete built-in desktop without a fourth 3 MiB
# allocation or optional filesystem reads.
! grep -Fq 'near_window_cache=(GRAOS_PIXEL*)malloc' "$GUI/guiStart.c" || fail "near cache still allocated"
! grep -Fq 'guiStartupShowPoster(v)' "$GUI/guiStart.c" || fail "poster remains on critical startup path"
grep -Fq 'v->desktop_solid=1;' "$GUI/guiStart.c" || fail "solid fail-open desktop missing"
! grep -Fq 'guiOpenResource' "$GUI/guiChrome.c" || fail "chrome still probes disk during startup"
grep -Fq 'guiCreateWelcome(v)' "$GUI/guiStart.c" || fail "welcome window missing"

# Painter cache invalidation must be content-driven and never wait for a later
# frame modulo that may never arrive in an event-driven loop.
grep -Fq 'DWORD paint_serial;' "$GUI/window.h" || fail "window paint serial missing"
grep -Fq 'compositor_window_paint_signature' "$GUI/windowDraw.c" || fail "paint signature missing"
grep -Fq 'sig=compositor_mix(sig,w->paint_serial);' "$GUI/windowDraw.c" || fail "paint serial not hashed"
! grep -Fq 'frame_counter%GRAOS_' "$GUI/windowDraw.c" || fail "frame-modulo cache refresh remains"
grep -Fq 'compositor_restore_cache' "$GUI/windowDraw.c" || fail "bounded cache restore missing"
grep -Fq 'guiWindowChanged(v,w)' "$GUI/guiServer.c" || fail "IPC content damage missing"

# Region/tile damage and cursor backing must reach the kernel's bounded LFB
# conversion path while the legacy full-frame call stays available.
grep -Fq '#define GRAOS_DAMAGE_TILE 32' "$GUI/guiUpdate.c" || fail "32x32 tile damage missing"
grep -Fq 'guiMoveCursorOnly(v);' "$GUI/guiLoop.c" || fail "cursor-only loop path missing"
grep -Fq 'cursor_under[32*32]' "$GUI/graos.h" || fail "cursor backing store missing"
grep -Fq 'damage_window_move(v,v->movwin,previous_x,previous_y);' "$GUI/windowMoving.c" || fail "bounded drag damage missing"
grep -Fq 'SYS_vgadrawframe,(DWORD)v->buf,offset,bytes,x1,x2-x1+1' "$GUI/guiUpdate.c" || fail "X-bounded present missing"
grep -Fq 'A2KRange(scall_ebx+offset,bytes)' "$KSC" || fail "bounded userspace validation missing"
grep -Fq 'VesaDrawFrameRegion(src,first_row,row_count' "$KSC" || fail "kernel region dispatch missing"
grep -Fq 'int VesaDrawFrameRegion' "$VESA" || fail "VESA region converter missing"
grep -Fq 'for(x=first_column;x+3<x_end;x+=4)' "$VESA" || fail "bounded fast conversion loop missing"
grep -Fq 'return VesaDrawFrameRows(src,0,GRAOS_VESA_HEIGHT);' "$VESA" || fail "full-frame compatibility missing"

echo "V68.225 GraOS damage/region regression: PASS"
