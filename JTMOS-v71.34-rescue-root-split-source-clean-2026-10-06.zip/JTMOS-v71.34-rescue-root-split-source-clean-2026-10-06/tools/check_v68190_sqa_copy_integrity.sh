#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.190 SQA/JTMFS copy integrity: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=190){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.190"
[ -f "$ROOT/RELEASE-V68.190.txt" ] || fail "release note missing"
R="$ROOT/kernel32/fs/jtmfs/ReadChain.c"
W="$ROOT/kernel32/fs/jtmfs/WriteChain.c"
S="$ROOT/kernel32/sh/sqa.c"
! grep -Fq 'tmp=jtmfsAccess.rwtmp' "$R" || fail "ReadChain still keeps shared rwtmp across I/O"
! grep -Fq 'tmp=jtmfsAccess.rwtmp' "$W" || fail "WriteChain still keeps shared rwtmp across I/O"
grep -Fq 'BYTE *tmp=(BYTE *)malloc((size_t)bsz);' "$R" || fail "ReadChain private RMW scratch missing"
grep -Fq 'BYTE *tmp=(BYTE *)malloc((size_t)bsz);' "$W" || fail "WriteChain private RMW scratch missing"
grep -Fq 'verify_output_file(output,e,buffer,capacity)' "$S" || fail "SQA destination verification missing"
grep -Fq 'output verification failed for %s; corrupt copy removed.' "$S" || fail "SQA corrupt-copy rejection missing"
echo "V68.190 SQA/JTMFS copy integrity regression: PASS"
