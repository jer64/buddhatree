#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
OHCI="$ROOT/kernel32/drivers/usb/ohci.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail()
{
    echo "V69.28 OHCI DMA quiesce: FAIL: $*" >&2
    exit 1
}

VERSION=$(cat "$ROOT/VERSION")
case "$VERSION" in
    69.28|69.29|69.30|69.31|69.32|69.33|69.34|69.35|7[0-9].*) ;;
    *) fail "unsupported VERSION $VERSION" ;;
esac
grep -Fq "JTMOS_SOURCE_RELEASE \"V$VERSION\"" "$REL" || fail "release header mismatch"
grep -Fq 'static int ohci_wait_next_frame(int timeout_ms)' "$OHCI" || fail "SOF wait helper missing"
grep -Fq 'ohci_wait_next_frame(OHCI_CTRL_QUIESCE_MS)' "$OHCI" || fail "control list is not SOF-quiesced"
grep -Fq 'ohci_wait_next_frame(OHCI_PERIODIC_QUIESCE_MS)' "$OHCI" || fail "periodic list is not SOF-quiesced"
grep -Fq 'static int ohci_control_quiesce(DWORD control)' "$OHCI" || fail "fallible control quiesce missing"
grep -Fq 'static int ohci_stop_periodic(void)' "$OHCI" || fail "fallible periodic stop missing"
grep -Fq 'root-hub rebuild deferred until periodic DMA quiesces' "$OHCI" || fail "unsafe topology rebuild is not deferred"
grep -Fq 'static void ohci_republish_periodic_schedule(void)' "$OHCI" || fail "descriptor-preserving republish helper missing"

VERSION_ENV="$VERSION" python3 - "$OHCI" <<'PY' || fail "watchdog still recycles descriptors or writes PeriodCurrentED"
import os, pathlib, re, sys

text = pathlib.Path(sys.argv[1]).read_text()
if "ohci_w32(OHCI_REG_PERIOD_CURRENT" in text:
    raise SystemExit("HCD writes read-only HcPeriodCurrentED")
m = re.search(r"static (?:void|int) ohci_periodic_watchdog\(void\)\n\{(.*?)\n\}", text, re.S)
if not m:
    raise SystemExit("watchdog function missing")
body = m.group(1)
if "ohci_build_periodic_list" in body or "ohci_stop_periodic" in body:
    raise SystemExit("watchdog directly rebuilds or stops live descriptors")
if os.environ.get("VERSION_ENV") not in {"69.28","69.29","69.30","69.31","69.32","69.33","69.34"}:
    if "ohci_hard_recover" not in body:
        raise SystemExit("V69.35 watchdog does not reset a dead controller")
else:
    if "ohci_republish_periodic_schedule();" not in body:
        raise SystemExit("watchdog does not republish the live schedule")

m = re.search(r"static int ohci_reenumerate_root_hub\(DWORD new_bitmap\)\n\{(.*?)\n\}", text, re.S)
if not m or "if(ohci_stop_periodic())" not in m.group(1):
    raise SystemExit("topology rebuild does not guard descriptor reuse")
PY

sh "$ROOT/tests/usb_keyboard_report_regression.sh"
echo "V69.28 OHCI DMA quiesce: PASS"
