#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.204 UNZ/JTMFS lock order: FAIL: $*" >&2; exit 1; }
ver=$(cat "$ROOT/VERSION")
echo "$ver" | awk -F. '($1>68)||($1==68 && $2>=204){ok=1} END{exit ok?0:1}' || fail "VERSION is older than 68.204"
[ -f "$ROOT/RELEASE-V68.204.txt" ] || fail "release note missing"
LG="$ROOT/kernel32/core/int/logging.c"
# The logger may probe the mutation lock but must release it before any POSIX open/write.
probe=$(sed -n '/static int logging_fs_try_enter/,/^}/p' "$LG")
printf '%s\n' "$probe" | grep -Fq 'jtmfs_mutation_trylock(dnr)' || fail "logger availability probe missing"
printf '%s\n' "$probe" | grep -Fq 'jtmfs_mutation_unlock(dnr);' || fail "logger probe does not immediately release mutation lock"
! grep -Fq 'logging_fs_leave(' "$LG" || fail "logger still carries mutation lock across POSIX I/O"
for C in "$ROOT/kernel32/sh/nzip.c" "$ROOT/libc/apps/nzip.c" "$ROOT/tools/nzip.c"; do
  grep -Fq '#define NZIP2_JTMOS_WRITE_SLICE (128U * 1024U)' "$C" || fail "$C lacks 128 KiB output slice"
  grep -Fq 'rv=write(fd,o->buffer+done,(int)slice);' "$C" || fail "$C lacks bounded output write"
  ! grep -Fq 'write(fd,o->buffer+done,(int)(o->used-done))' "$C" || fail "$C still performs one full 1 MiB write"
done
SH="$ROOT/kernel32/sh/sh.c"
grep -Fq 'SMSH source release: %s (%s).' "$SH" || fail "runtime source-release marker missing"
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${ver}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header does not match VERSION"
! grep -Fq 'autostart> d0' "$SH" || fail "automatic d0 regression returned"
echo "V68.204 UNZ/JTMFS lock-order regression: PASS"
