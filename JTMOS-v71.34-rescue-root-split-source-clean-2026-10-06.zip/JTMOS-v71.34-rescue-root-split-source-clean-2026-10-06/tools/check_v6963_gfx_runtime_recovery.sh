#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.63 gfx runtime recovery: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }
NV="$ROOT/kernel32/drivers/vga/nv6150.c"
NVH="$ROOT/kernel32/drivers/vga/nv6150.h"
V="$ROOT/kernel32/init/vesa.c"
VH="$ROOT/kernel32/init/vesa.h"
SHC="$ROOT/kernel32/sh/sh.c"

has 'int Nv6150EnsureRuntimeReady(void)' "$NV" 'runtime GeForce recovery helper missing'
has 'map=pg_mapio((int)(base/4096UL),(int)pages);' "$NV" 'BAR1 runtime pg_mapio missing'
has 'nv6150_lfb_linear=map+offset;' "$NV" 'runtime linear framebuffer address not retained'
has 'if(!nv_map_mmio())' "$NV" 'BAR0 runtime MMIO map not enforced'
has 'Nv6150GetFramebufferLinear' "$NVH" 'public linear framebuffer diagnostic missing'
has 'Nv6150EnsureRuntimeReady()' "$V" 'gfx/GraOS does not use runtime recovery'
has 'VesaTextGraphicsLastError' "$VH" 'gfx failure reason API missing'
has 'graphics console activation failed: %s' "$SHC" 'SMSH gfx still hides the failure reason'
has 'phys=0x%x linear=0x%x' "$SHC" 'gfx diagnostics do not show physical/linear LFB state'
# The mode setter must no longer require a boot-only BAR1 mapping before trying recovery.
if grep -Fq 'mode set refused: BAR1 framebuffer was not mapped during pg_init' "$NV"; then
    fail 'old pre-paging-only refusal is still present'
fi

echo 'V69.63 gfx runtime recovery: PASS'
