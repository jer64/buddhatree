#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "gfx VT command: FAIL: $*" >&2; exit 1; }

VESA="$ROOT/kernel32/init/vesa.c"
VESAH="$ROOT/kernel32/init/vesa.h"
SH="$ROOT/kernel32/sh/sh.c"
SQSH="$ROOT/libc/apps/sqsh.c"
HELP="$ROOT/kernel32/sh/helpapp.c"
NV="$ROOT/kernel32/drivers/vga/nv6150.c"
BGA="$ROOT/kernel32/drivers/vga/vboxbga.c"

for f in "$VESA" "$VESAH" "$SH" "$SQSH" "$HELP" "$NV" "$BGA"; do
    [ -f "$f" ] || fail "missing ${f#$ROOT/}"
done

grep -Fq '#define VESA_TEXT_GFX_DEFAULT_WIDTH  640' "$VESAH" || fail '640-wide console default missing'
grep -Fq '#define VESA_TEXT_GFX_DEFAULT_HEIGHT 480' "$VESAH" || fail '480-high console default missing'
grep -Fq 'int VesaSetTextGraphics(int provider, int width, int height);' "$VESAH" || fail 'mode/provider API missing'
grep -Fq 'return VesaSetTextGraphics(VESA_TEXT_GFX_AUTO,' "$VESA" || fail 'bare gfx is not auto-provider'
grep -Fq 'VESA_TEXT_GFX_DEFAULT_WIDTH' "$VESA" || fail 'bare gfx does not use console default width'
grep -Fq 'mode_ok=Nv6150SetMode(width,height,32);' "$VESA" || fail 'NV6150 runtime geometry switch missing'
grep -Fq 'mode_ok=VBoxBgaSetMode(width,height,32);' "$VESA" || fail 'VM VGA/BGA runtime geometry switch missing'
grep -Fq 'VisibleTerminals_SetHWCopy(FALSE);' "$VESA" || fail 'legacy VGA HW-copy is not disabled'
grep -Fq 'VesaTextConsoleEnable(TRUE);' "$VESA" || fail 'VT renderer is not enabled'
grep -Fq 'VesaTextConsoleRefresh();' "$VESA" || fail 'current VT is not refreshed'

grep -Fq '{ 640,  480,' "$NV" || fail 'NV6150 640x480 timing missing'
grep -Fq 'VBoxBgaSetMode(int width, int height, int bpp)' "$BGA" || fail 'BGA programmable mode API missing'

grep -Fq '{"gfx", gfx_builtin}' "$SH" || fail 'SMSH gfx builtin missing'
grep -Fq 'strcmp(argv[1],"geforce")' "$SH" || fail 'gfx geforce parser missing'
grep -Fq 'strcmp(argv[1],"vmvga")' "$SH" || fail 'gfx vmvga parser missing'
grep -Fq 'strcmp(s,"640x480")' "$SH" || fail 'gfx 640x480 parser missing'
grep -Fq 'strcmp(s,"1024x768")' "$SH" || fail 'gfx 1024x768 parser missing'
grep -Fq 'strcmp(argv[1],"off")' "$SH" || fail 'gfx off parser missing'
grep -Fq 'strcmp(argv[1],"vt")' "$SH" || fail 'gfx vt parser missing'
grep -Fq 'SwitchUserTerminal(vt)' "$SH" || fail 'gfx vt does not switch visible+input VT'
grep -Fq 'VesaTextConsoleEnable(FALSE);' "$SH" || fail 'gfx off does not stop renderer'
grep -Eq '"gfx"([[:space:]]*,|[[:space:]]*$)' "$SH" || fail 'SQSH syscall whitelist missing gfx'
grep -Fq '"lspci","gfx","ping"' "$SQSH" || fail 'SQSH parser whitelist missing gfx'
grep -Fq 'gfx [auto|640x480|1024x768|status]' "$SQSH" || fail 'SQSH help missing new gfx syntax'
grep -Fq 'gfx [auto|640x480|1024x768]' "$HELP" || fail 'SMSH help missing new gfx syntax'

# Runtime mode changes must use only providers discovered before paging.  A
# late PCI/BGA prepare would introduce an unmapped MMIO/LFB range.
start=$(grep -n '^int VesaSetTextGraphics(int provider, int width, int height)' "$VESA" | cut -d: -f1)
end=$(awk -v s="$start" 'NR>s && /^int VesaStartTextGraphics\(void\)/ {print NR; exit}' "$VESA")
[ -n "$start" ] && [ -n "$end" ] || fail 'cannot isolate VesaSetTextGraphics'
body=$(mktemp "${TMPDIR:-/tmp}/gfx-vt.XXXXXX")
trap 'rm -f "$body"' EXIT HUP INT TERM
sed -n "${start},$((end-1))p" "$VESA" > "$body"
grep -Fq 'Nv6150PrepareGraOS' "$body" && fail 'unsafe late NV6150 prepare in gfx mode path'
grep -Fq 'VBoxBgaPrepareGraOS' "$body" && fail 'unsafe late VM-VGA prepare in gfx mode path'

# `off` deliberately must not try to force legacy VGA mode 3 from an MCP61
# protected-mode session.
off_start=$(grep -n 'strcmp(argv\[1\],"off")' "$SH" | head -1 | cut -d: -f1)
off_end=$((off_start+14))
sed -n "${off_start},${off_end}p" "$SH" | grep -Fq 'setvmode(3)' && fail 'gfx off performs unsafe hardware VGA reset'

echo 'gfx VT command: PASS (auto 640x480 + provider/mode/VT controls)'
