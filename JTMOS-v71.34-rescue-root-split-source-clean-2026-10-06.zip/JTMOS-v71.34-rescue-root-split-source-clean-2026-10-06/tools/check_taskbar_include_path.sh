#!/bin/sh
set -eu
fail(){ echo "taskbar include-path check: FAIL: $*" >&2; exit 1; }

src=libc/apps/gui/taskbar.c
hdr=libc/apps/gui/guiLaunchCompat.h
[ -f "$src" ] || fail "$src missing"
[ -f "$hdr" ] || fail "$hdr missing"
grep -q '^#include "guiLaunchCompat.h"$' "$src" || fail 'taskbar must include local guiLaunchCompat.h'
if grep -q '#include "gui/guiLaunchCompat.h"' "$src"; then
    fail 'stale gui/guiLaunchCompat.h include would resolve to libc/apps/gui/gui/guiLaunchCompat.h'
fi

echo "taskbar include-path check: PASS"
