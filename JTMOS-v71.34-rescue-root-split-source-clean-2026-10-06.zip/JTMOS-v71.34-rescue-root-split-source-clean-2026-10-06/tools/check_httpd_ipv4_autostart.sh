#!/bin/sh
set -eu
fail(){ echo "check_httpd_ipv4_autostart: FAIL: $*" >&2; exit 1; }
MAIN=kernel32/drivers/tcpip/uipMain.c
NET=kernel32/sh/networkapp.c
HTTP=kernel32/drivers/tcpip/jt_httpd.c
RUN=run_jtmos_qemu_linode.sh

grep -Fq 'static void uip_sync_ipv4_services(void)' "$MAIN" || fail "IPv4 service sync missing"
grep -Fq 'nc && nc->configured && ethdev_link_up()' "$MAIN" || fail "autostart is not based on configured IPv4 + link"
! grep -Fq 'nc->config_method==JNET_CFG_DHCP' "$MAIN" || fail "passive-service autostart is still DHCP-only"
grep -Fq 'JtHttpdDhcpLease(network_active,network_active?nc->ip:NULL);' "$MAIN" || fail "HTTP is not fed general IPv4 readiness"
grep -Fq 'JtTelnetdDhcpLease(network_active,network_active?nc->ip:NULL);' "$MAIN" || fail "telnet is not fed general IPv4 readiness"
[ "$(grep -Fc 'uip_sync_ipv4_services();' "$MAIN")" -ge 2 ] || fail "IPv4 service sync is not run after configuration and in owner loop"
grep -Fq 'IPv4-autostart=' "$NET" || fail "network status does not describe IPv4 autostart"
grep -Fq 'httpd_auto_enabled = 1' "$HTTP" || fail "HTTP auto policy default changed"
grep -Fq 'JTMOS_HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-0.0.0.0}' "$RUN" || fail "Linode host-forward is not externally bindable"
echo "check_httpd_ipv4_autostart: PASS (HTTP/telnet auto-listen on DHCP, QEMU fallback or static IPv4)"
