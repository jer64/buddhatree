#!/bin/sh
set -eu
ROOT=${1:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}
SQ="$ROOT/libc/apps/sqsh.c"
SH="$ROOT/kernel32/sh/sh.c"
API="$ROOT/kernel32/fs/api.c"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

grep -Fq '"sqsh.bin --pipe-stage-in' "$SQ" || fail "SQSH later pipe stages are not PATH-resolved workers"
grep -Fq '"sqsh.bin --pipe-stage ' "$SQ" || fail "SQSH first pipe stage is not PATH-resolved worker"
if grep -Fq '"/bin/sqsh.bin --pipe-stage' "$SQ"; then fail "hard-coded /bin/sqsh.bin pipeline worker remains"; fi
grep -Fq 'sqsh_pipe_stage_has_input' "$SQ" || fail "SQSH pipe input state missing"
grep -Fq 'sqsh_path_cmd' "$SQ" || fail "SQSH path command missing"
grep -Fq 'sqsh_path_assignment_line' "$SQ" || fail "set|path stream filter missing"
grep -Fq 'smsh_env_canonical_name' "$SH" || fail "SMSH PATH canonicalization missing"
grep -Fq '"set","setglobal","path",NULL' "$SH" || fail "SMSH set/path pipeline bridge missing"
grep -Fq 'path_builtin' "$SH" || fail "SMSH path command missing"
grep -Fq "path[pos+1]=='/'" "$API" || fail "device-qualified PATH parser regression"
pass "SQSH worker uses PATH rather than /bin"
pass "SMSH set path= canonicalizes to PATH"
pass "SMSH/SQSH set|grep and set|path pipeline hooks present"
