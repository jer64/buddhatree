#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_cbmvm_libc_app: FAIL: $*" >&2; exit 1; }
[ -f "$ROOT/libc/apps/cbmvm.mak" ] || fail "cbmvm.mak missing"
[ -f "$ROOT/libc/apps/cbmvm/cbmvm_main.c" ] || fail "canonical main missing"
[ -f "$ROOT/libc/apps/cbmvm/cbmvm_6502.c" ] || fail "6502 core missing"
[ -f "$ROOT/libc/apps/cbmvm/cbmvm_jtmos_graos.c" ] || fail "GraOS frontend missing"
grep -Eq 'UTILITIES_ONLY_APPS.*\\|^[[:space:]]*bwbasic cbmvm ' "$ROOT/libc/apps/Makefile" || fail "cbmvm not in utilities-only app list"
grep -Fq 'list-utilities' "$ROOT/tools/build_release_apps.sh" || fail "release validator does not gate utilities-only apps"
[ ! -f "$ROOT/sdl2/cbmvm/cbmvm_engine.c" ] || fail "duplicate VM core remains in sdl2/cbmvm"
grep -Fq 'CORE_DIR := ../../libc/apps/cbmvm' "$ROOT/sdl2/cbmvm/Makefile" || fail "SDL2 frontend does not use canonical core"
make -C "$ROOT/libc/apps" -f cbmvm.mak default >/dev/null
for pat in 'Class:.*ELF32' 'Machine:.*Intel 80386' 'Entry point address:.*0x80004000'; do
    LC_ALL=C readelf -h "$ROOT/libc/apps/cbmvm.bin" | grep -q "$pat" || fail "ELF validation failed: $pat"
done
echo "check_cbmvm_libc_app: PASS"
