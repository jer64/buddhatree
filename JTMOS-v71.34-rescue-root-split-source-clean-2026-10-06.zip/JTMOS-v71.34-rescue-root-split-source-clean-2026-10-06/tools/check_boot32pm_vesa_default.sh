#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
B="$ROOT/boot32pm"

# V69.52+ release default is text/nogui.  V69.57 keeps the VBE code compiled
# so `gui` can request graphics at runtime from BIOS or FreeDOS DOSBOOT.
grep -Fq 'VESA ?= $(if $(filter 0 1,$(KERNEL_PROFILE_VESA)),$(KERNEL_PROFILE_VESA),0)' "$B/Makefile"
grep -q '^%define BOOT32PM_CANDIDATE 1$' "$B/boot.asm"
grep -q '^%define BOOT32PM_NZIP_KERNEL 1$' "$B/boot.asm"
grep -q '^%define BOOT32PM_STREAM_KERNEL 1$' "$B/boot.asm"
grep -q '^%ifndef BOOT_VESA_GRAPHICS$' "$B/boot.asm"
grep -q '^%define BOOT_VESA_GRAPHICS 0$' "$B/boot.asm"
grep -q '^%ifndef BOOT_VESA_RUNTIME_SUPPORT$' "$B/boot.asm"
grep -q '^%define BOOT_VESA_RUNTIME_SUPPORT 1$' "$B/boot.asm"
grep -q 'ASMFLAGS += -DBOOT_VESA_GRAPHICS=$(VESA)' "$B/Makefile"
grep -q 'str_opt_gui    db "gui"' "$B/boot.asm"
grep -q 'mov byte \[boot_gui_requested\],1' "$B/dosboot.asm"

echo 'boot32pm display default: PASS (plain source fallback=text/nogui; runtime gui/VESA retained)'
