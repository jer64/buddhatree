#!/bin/sh
set -eu
fail(){ echo "USB OHCI HID check: FAIL: $*" >&2; exit 1; }

[ -f kernel32/drivers/usb/ohci.c ] || fail "ohci.c missing"
[ -f kernel32/drivers/usb/ohci.h ] || fail "ohci.h missing"
grep -q 'NVIDIA_MCP61_OHCI_ID.*0x03f1' kernel32/drivers/usb/ohci.c || fail "MCP61 OHCI ID missing"
grep -q 'NVIDIA_MCP61_EHCI_ID.*0x03f2' kernel32/drivers/usb/ohci.c || fail "MCP61 EHCI ID missing"
grep -q 'OHCI_PORT_PRS' kernel32/drivers/usb/ohci.c || fail "root port reset missing"
grep -q 'USB_REQ_GET_DESCRIPTOR' kernel32/drivers/usb/ohci.c || fail "USB descriptor enumeration missing"
grep -q 'USB_HID_SET_PROTOCOL' kernel32/drivers/usb/ohci.c || fail "HID boot protocol request missing"
grep -q 'PORT_OWNER -> companion OHCI' kernel32/drivers/usb/ohci.c || fail "EHCI companion handoff missing"
grep -q 'usb_hid_boot_keyboard_report' kernel32/drivers/usb/ohci.c || fail "keyboard report sink missing"
grep -q 'usb_hid_boot_mouse_report' kernel32/drivers/usb/ohci.c || fail "mouse report sink missing"
grep -q 'usb_input_transport_init' kernel32/init/initsystem.c || fail "USB transport boot hook missing"
grep -q 'PS/2 mouse fallback after USB probe' kernel32/init/initsystem.c || fail "USB-first mouse fallback order missing"
grep -q 'usb_input_poll' kernel32/drivers/keyboard/keyb.c || fail "keyboard polling hook missing"
grep -q 'usb_input_poll' kernel32/drivers/mouse/mouse.c || fail "mouse polling hook missing"
echo "USB OHCI HID checks: PASS"
