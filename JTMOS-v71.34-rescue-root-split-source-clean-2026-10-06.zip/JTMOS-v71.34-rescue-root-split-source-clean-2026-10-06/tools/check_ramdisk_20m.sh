#!/bin/sh
set -eu

K=kernel32/init/keropt.c
R=kernel32/drivers/ramdisk/ramdisk.c

grep -Eq 'RD_DEFAULT_BLOCK_SIZE=[[:space:]]*512' "$K"
grep -Eq 'RD_DEFAULT_SIZE=[[:space:]]*131072' "$K"
grep -q 'reserve = 32UL \* 1024UL \* 1024UL' "$R"
grep -q 'if(bytes > wanted)' "$R"
grep -q 'bytes = wanted;' "$R"
grep -q 'blocks<=8192UL' "$R"

blocks=$(sed -n 's/.*RD_DEFAULT_SIZE=[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$K" | head -n1)
blocksize=$(sed -n 's/.*RD_DEFAULT_BLOCK_SIZE=[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$K" | head -n1)
bytes=$((blocks * blocksize))
[ "$bytes" -eq 67108864 ]

echo "PASS: default ram: target is 64 MiB ($blocks x $blocksize bytes) with 32 MiB reserve and allocation fallback."
