#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_mcp61_safe_write: FAIL: $*" >&2; exit 1; }
M="$ROOT/kernel32/drivers/sata/mcp61.c"
P="$ROOT/kernel32/drivers/partsup/partsup.c"
[ -f "$M" ] || fail "mcp61.c missing"
! grep -q 'if(write) chunk=1UL' "$M" || fail "obsolete one-sector MCP61 write policy remains"
grep -q '#define MCP61_SAFE_PIO_SECTORS' "$M" || fail "MCP61 bounded PIO fallback missing"
grep -q 'chunk=left>MCP61_SAFE_PIO_SECTORS' "$M" || fail "MCP61 requests are not chunked as bounded multi-sector PIO"
grep -q 'if(write && ata_flush()) return 1' "$M" || fail "MCP61 write path does not flush before success"
grep -q 'driver_disableDAPIWriteBackCache(dnr)' "$M" || fail "parent hda MCP61 write-back still enabled"
! grep -A12 'static int mcp61_register_hda' "$M" | grep -q 'driver_enableDAPIWriteBackCache' || fail "MCP61 register explicitly enables write-back"
grep -q 'mcp61_sata_hda_active()' "$P" || fail "partition layer does not recognize MCP61 backend"
grep -q 'driver_disableDAPIWriteBackCache(partition_dnr\[i\])' "$P" || fail "partition DAPI write-back not disabled on MCP61"
grep -q 'PARTSUP_PARENT_SAFE_SECTORS 8' "$P" || fail "legacy/MCP61 partition safety bound changed"
grep -q 'parent_max=ahci_hda_active() ? ahci_hda_max_transfer_sectors() :' "$P" || fail "partition layer does not preserve AHCI adaptive transfer sizing"
echo "check_mcp61_safe_write: PASS (bounded multi-sector PIO + flush + parent/partition write-through)"
