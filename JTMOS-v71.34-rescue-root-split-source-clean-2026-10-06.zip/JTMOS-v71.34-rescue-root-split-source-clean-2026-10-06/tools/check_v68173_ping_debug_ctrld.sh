#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68173_ping_debug_ctrld: FAIL: $*" >&2; exit 1; }
K="$ROOT/kernel32/sh/networkapp.c"
J="$ROOT/kernel32/drivers/tcpip/jnet.c"
KB="$ROOT/kernel32/drivers/keyboard/keyb.c"
FB="$ROOT/kernel32/fs/filebuf.c"
SQ="$ROOT/libc/apps/sqsh.c"
P="$ROOT/libc/apps/ping.c"
SCS="$ROOT/kernel32/core/int/scs.c"
for f in "$K" "$J" "$KB" "$FB" "$SQ" "$P" "$SCS"; do [ -f "$f" ] || fail "$f missing"; done
grep -q 'PING/DBG: eflags=' "$K" || fail 'kernel ping EFLAGS diagnostic missing'
grep -q "getch char='%c' int=%d" "$K" || fail 'ping getch char/integer diagnostic missing'
grep -q 'PING/JNET: wait elapsed=' "$J" || fail 'JNET periodic wait diagnostic missing'
grep -q 'IF dropped by ethdev_receive' "$J" || fail 'post-RX IF guard missing'
grep -q 'sc==SCODE_D' "$KB" || fail 'Ctrl+D scan-code path missing'
grep -q 'if(c==4)' "$FB" || fail 'canonical stdin EOT handling missing'
grep -q 'Ctrl-D/EOT exits SQSH' "$SQ" || fail 'SQSH Ctrl+D exit missing'
grep -q 'if(rv<0) goto outtahere' "$SQ" || fail 'SQSH prompt ignores Ctrl+D EOF return'
grep -q 'SYS_dprintk.*157' "$ROOT/kernel32/core/int/syscallcodes.h" || fail 'SYS_dprintk ABI missing'
grep -q 'scall_dprintk' "$SCS" || fail 'kernel dprintk syscall missing'
grep -Fq 'dprintk("%s",text)' "$SCS" || fail 'dprintk syscall must not trust a userspace format string'
awk '/nr_scall_func[[:space:]]*=/ { v=$4; gsub(/;/,"",v); if ((v+0) >= 158) ok=1 } END { exit ok?0:1 }' "$SCS" || fail 'syscall count is below 158'
grep -q 'jtmos_dprintk' "$ROOT/libc/libc/modern/jtmos_extra.c" || fail 'libc dprintk wrapper missing'
grep -q 'PING/U:' "$P" || fail 'userspace ping debug wrapper missing'
echo 'check_v68173_ping_debug_ctrld: PASS'
