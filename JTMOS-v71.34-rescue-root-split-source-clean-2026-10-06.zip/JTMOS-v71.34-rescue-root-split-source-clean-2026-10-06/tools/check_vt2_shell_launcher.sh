#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_vt2_shell_launcher: FAIL: $*" >&2; exit 1; }
[ -f libc/apps/vt2.c ] || fail "vt2.c missing"
[ -f libc/apps/vt2.mak ] || fail "vt2.mak missing"
grep -q 'VT2_BOOT_LAUNCHER_ENABLED=.*1' kernel32/init/keropt.c || fail "boot option not enabled"
grep -q 'smsh_ensure_vt_launcher' kernel32/sh/sh.c || fail "SMSH does not own independent VT4 launcher lifecycle"
grep -q 'launcher_terminal=JTMOS_VT_LAUNCHER' kernel32/sh/sh.c || fail "launcher is not on VT4 role"
grep -q 'SetThreadTerminal(ShellThread.pid,JTMOS_VT_BOOTLOG)' kernel32/init/init.c || fail "SMSH bootstrap is not on VT2"
grep -q 'SetThreadTerminal(pid,JTMOS_VT_SMSH)' kernel32/sh/sh.c || fail "interactive SMSH does not move to VT3"
grep -q 'for(i=0;i<10;i++)' kernel32/drivers/term/term.c || fail "fixed VT owner cleanup missing"
grep -q "ch>='1' && ch<='7'" libc/apps/vt2.c || fail "launcher one-key numeric loop missing"
grep -q '#define VT_LAUNCHER_NUMBER 4' libc/apps/vt2.c || fail "launcher payload does not expect VT4"
grep -q 'bgexecEx("sqsh.bin","",terminal)' libc/apps/vt2.c || fail "launcher does not launch sqsh"
grep -q 'vt2.bin' tools/build_install_image.sh || fail "legacy launcher payload not retained in system image"
grep -q 'unique vt2' libc/apps/Makefile || fail "launcher not in app build list"
echo 'check_vt2_shell_launcher: PASS (legacy vt2.bin payload on VT4 + one-key SQSH dispatch)'
