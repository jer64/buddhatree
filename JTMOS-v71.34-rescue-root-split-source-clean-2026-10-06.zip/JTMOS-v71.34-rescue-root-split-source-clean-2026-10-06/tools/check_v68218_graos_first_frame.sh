#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.218 GraOS first-frame regression: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*) ;; *) fail "VERSION predates 68.218" ;; esac
GRAOS_VERSION=$(sed -n 's/.*#define[[:space:]]*GRAOS_VERSION[[:space:]]*"V\([0-9][0-9]*\)".*/\1/p' "$ROOT/libc/apps/gui/graos.h" | sed -n '1p')
[ -n "$GRAOS_VERSION" ] && [ "$GRAOS_VERSION" -ge 48 ] || fail "GraOS V48 or newer missing"
START="$ROOT/libc/apps/gui/guiStart.c"
SERVER="$ROOT/libc/apps/gui/guiServer.c"
MSGBOX="$ROOT/kernel32/core/cp/msgbox.c"
grep -Fq 'guiPresentEarlyFrame(v)' "$START" || fail "early frame call missing"
grep -Fq 'EARLY FRAME presented' "$START" || fail "early frame diagnostic missing"
# IPC registration must occur after the complete desktop present.
PRESENT=$(grep -n 'initial desktop frame presented' "$START" | head -1 | cut -d: -f1)
SERVERLINE=$(grep -n 'guiServerInit();' "$START" | head -1 | cut -d: -f1)
[ -n "$PRESENT" ] && [ -n "$SERVERLINE" ] && [ "$SERVERLINE" -gt "$PRESENT" ] || fail "IPC still precedes first desktop"
! sed -n '/void guiServerInit/,/^}/p' "$SERVER" | grep -Fq 'startMessageBox();' || fail "GraOS still eagerly allocates mailbox"
grep -Fq 'if(thread_msgbox[pid] == NULL)' "$MSGBOX" || fail "receive null-mailbox guard missing"
grep -Fq 'sendMessage() already' "$MSGBOX" || fail "lazy receive rationale missing"
echo "V68.218 GraOS first-frame regression: PASS"
