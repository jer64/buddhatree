#!/bin/sh
set -eu
fail(){ echo "check_graos_keyboard_navigation: FAIL: $*" >&2; exit 1; }

grep -q 'JKEY_SHIFT_TAB 0x0f00' libc/libc/include/jtmos/console.h || fail "public Shift+Tab key code missing"
grep -q 'mark==0x0f && shift' kernel32/drivers/keyboard/scanasc.c || fail "keyboard driver collapses Shift+Tab"
grep -q 'guiFocus.o' libc/apps/gui/graos.mak || fail "guiFocus not linked into GraOS"
grep -Fq 'guiMoveFocus(v,w,1)' libc/apps/gui/guiFocus.c || fail "forward Tab handler missing"
grep -q 'key==JKEY_SHIFT_TAB' libc/apps/gui/guiFocus.c || fail "reverse Tab handler missing"
grep -Fq "key==' '" libc/apps/gui/guiFocus.c || fail "Space activation missing"
grep -q 'onButtonClick(v,w,b)' libc/apps/gui/guiFocus.c || fail "keyboard Button activation missing"
grep -q 'guiEnsureFocus(v,v->selwin)' libc/apps/gui/guiLoop.c || fail "active window does not receive a focus target"
grep -q 'guiHandleNavigationKey' libc/apps/gui/guiLoop.c || fail "keyboard navigation not in event loop"
grep -q 'guiFocusButton(v,bw,b)' libc/apps/gui/windowMoving.c || fail "mouse click does not transfer Button focus"
grep -q 'guiWidgetIsFocused' libc/apps/gui/guiChrome.c || fail "Button focus indicator missing"
grep -q 'GRAOS_BUTTON_ICON_VIEW' libc/apps/gui/guiChrome.c || fail "IconView Button renderer missing"

grep -q 'GRAOS_INTERNAL_BUTTON_ID_BASE' libc/apps/gui/window.h || fail "internal Button id range missing"
grep -Fq 'GRAOS_INTERNAL_BUTTON_ID_BASE+w->n_buttons' libc/apps/gui/windowFunc.c || fail "internal Buttons still share one focus id"
if grep -Fq 'int id=0;if(type&GRAOS_WINDOW_CLOSE_BUTTON)' libc/apps/gui/windowFunc.c; then
    fail "legacy id=0 Button focus collision returned"
fi
grep -q 'foreground_pid' kernel32/drivers/term/screen.h || fail "terminal foreground PID missing"
grep -Fq 'if(ch==3 && id>=0 && id<N_MAX_SCREENS && s->foreground_pid>0)' kernel32/drivers/term/term.c || fail "GraOS Ctrl+C is not routed to foreground job"
grep -Fq 'OutTermKey(GetInputTerminal(),3)' kernel32/drivers/keyboard/keyb.c || fail "hardware Ctrl+C bypasses terminal job-control routing"
grep -Fq 'SetTerminalForegroundProcess(terminal,pid)' kernel32/core/int/threads.c || fail "foreground waiter does not register its child"
grep -Fq 'ClearTerminalForegroundProcess(pid)' kernel32/core/int/threads.c || fail "foreground PID is not cleared"
grep -Fq 'if(key == 3)' kernel32/sh/sh.c || fail "SMSH prompt does not consume ETX Ctrl+C"

echo "check_graos_keyboard_navigation: PASS (unique focus ids + Tab/Shift+Tab + Enter/Space + terminal Ctrl+C routing)"
