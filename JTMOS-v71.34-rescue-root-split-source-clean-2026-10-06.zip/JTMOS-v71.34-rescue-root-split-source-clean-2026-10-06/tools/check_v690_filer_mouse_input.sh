#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
WM="$ROOT/libc/apps/gui/windowMoving.c"
GL="$ROOT/libc/apps/gui/guiLoop.c"
FILER="$ROOT/libc/apps/filer.c"
PROTO="$ROOT/libc/include/jtmos/graosprotocol.h"
MSG="$ROOT/kernel32/core/cp/msgbox.h"

grep -q 'guiQueueWindowEvent(w,GRAOS_GSID_MOUSEBUTTON,cx,cy,button)' "$WM"
grep -q 'guiQueueWindowEvent(w,GRAOS_GSID_KEYPRESSED,key,0,0)' "$GL"
grep -q 'JtmosGraOSPollEvent(window_id,&ev)' "$FILER"
grep -q 'ev.id==GRAOS_GSID_MOUSEBUTTON' "$FILER"
grep -q '#define GRAOS_GSID_MOUSEBUTTON 20' "$PROTO"
grep -q '#define N_MAX_QUEUED_MSGS.*5' "$MSG"

# Raw client input must not bypass the server's per-window event queue anymore.
awk '/static void send_window_mouse/{p=1} p{print} p && /^}/{exit}' "$WM" | grep -q 'guiQueueWindowEvent'
if awk '/static void send_window_mouse/{p=1} p{print} p && /^}/{exit}' "$WM" | grep -q 'sendMessage'; then
    echo 'FAIL: mouse delivery still uses direct Postman sendMessage' >&2
    exit 1
fi
awk '/static void send_window_key/{p=1} p{print} p && /^}/{exit}' "$GL" | grep -q 'guiQueueWindowEvent'

echo 'filer mouse/input queue: PASS'
