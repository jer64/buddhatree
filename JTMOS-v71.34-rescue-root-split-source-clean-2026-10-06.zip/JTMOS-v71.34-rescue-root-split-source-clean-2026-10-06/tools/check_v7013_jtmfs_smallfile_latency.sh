#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python3 tests/v7013_jtmfs_smallfile_latency.py
echo "check_v7013_jtmfs_smallfile_latency: PASS"
