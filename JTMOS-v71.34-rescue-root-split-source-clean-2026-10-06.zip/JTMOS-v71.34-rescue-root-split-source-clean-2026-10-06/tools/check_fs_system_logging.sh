#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_fs_system_logging: FAIL: $*" >&2; exit 1; }

LOG=kernel32/core/int/logging.c
LH=kernel32/core/int/logging.h
DF=kernel32/core/int/dfunc.c
DBG=kernel32/core/int/debug.c
FS=kernel32/sh/fsadmin.c
RB=kernel32/core/cp/reboot.c

[ -s "$LOG" ] || fail "logging.c missing"
grep -Fq '#define SYSLOG_NAME "system.log"' "$LOG" || fail "system.log basename missing"
grep -Fq 'SYSTEMLOG_FIFO_BYTES (256*1024)' "$LOG" || fail "early log FIFO is not 256 KiB"
grep -Fq 'open(logging_syslog_path,O_WRONLY|O_CREAT|O_APPEND|O_JTMOS_BATCH)' "$LOG" || fail "system.log append descriptor is not writable/batched"
grep -Fq 'logging_activate_root("hda1:/",1)' "$LOG" || fail "hda1 preferred target missing"
grep -Fq 'SYSTEMLOGGING_FLUSH_SECONDS' "$LOG" || fail "30-second configurable flush policy missing"
! grep -Fq 'remove(s)' "$LOG" || fail "persistent system.log is still deleted at storage activation"
grep -Fq 'while(!logging_storage_ready)' "$LOG" || fail "KLOGGER does not wait for explicit filesystem readiness"
grep -Fq 'jtmfs_isDriveReady(dnr)' "$LOG" || fail "storage-ready gate does not verify JTMFS"
grep -Fq 'SetThreadDNR(LoggerThread.pid,dnr)' "$LOG" || fail "KLOGGER is not rebound to selected target DNR"
grep -Fq 'SetThreadDB(LoggerThread.pid,db)' "$LOG" || fail "KLOGGER is not rebound to selected target DB"
grep -Fq 'logging_writer_is_current()' "$LOG" || fail "recursive logger suppression missing"
grep -Fq 'SystemLogFlushNow' "$LH" || fail "system log flush API missing"

grep -Fq 'WriteSystemLogStream("DEBUG",tmp)' "$DF" || fail "dprintk is not routed to FS system log"
grep -Fq 'WriteSystemLogStream("REPORT",tmp)' "$DBG" || fail "ReportMessage is not routed to FS system log"
grep -Fq 'DebugSerialRuntimeEnabled() && serial_debug_line >= 0' "$DF" || fail "dprintk serial sink is not independently gated"
grep -Fq 'DebugSerialRuntimeEnabled() && serial_debug_line >= 0' "$DBG" || fail "report serial sink is not independently gated"

grep -Fq 'SystemLoggingStorageReady();' "$FS" || fail "root activation does not release filesystem logger"
grep -Fq '(void)SystemLogFlushNow();' "$FS" || fail "sync command does not drain queued logs before filesystem sync"
grep -Fq '(void)SystemLogFlushNow();' "$RB" || fail "graceful reboot does not drain queued logs before sync"

grep -Fq 'jtmos_debug=1;' "$LOG" || fail "debug stream is not resumed after filesystem log sink is ready"
grep -Fq 'debug2=1;' "$LOG" || fail "report stream is not resumed after filesystem log sink is ready"
! grep -A12 -F 'debug2=1;' "$LOG" | grep -Fq 'DebugSerialSetRuntimeEnabled(1)' || fail "filesystem logger incorrectly re-enables slow serial debug"

echo "check_fs_system_logging: PASS (RAM FIFO + hda1:/logs JTMFS preference + DEBUG/REPORT streams)"
