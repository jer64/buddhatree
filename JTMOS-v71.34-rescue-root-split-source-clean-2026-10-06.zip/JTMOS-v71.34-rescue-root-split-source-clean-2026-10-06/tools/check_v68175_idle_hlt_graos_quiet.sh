#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_v68175_idle_hlt_graos_quiet: FAIL: $*" >&2; exit 1; }
S="$ROOT/kernel32/core/cp/scheduler.c"
SH="$ROOT/kernel32/core/cp/scheduler.h"
I="$ROOT/kernel32/core/int/IdleThread.c"
SER="$ROOT/kernel32/drivers/serial/serial.c"
GUI="$ROOT/libc/apps/gui/guiStart.c"
LOOP="$ROOT/libc/apps/gui/guiLoop.c"
SPL="$ROOT/libc/apps/gui/guiStartup.c"
TOP="$ROOT/libc/apps/top.c"

ver=$(cat "$ROOT/VERSION")
case "$ver" in
  68.175|68.176|68.17[7-9]|68.1[89][0-9]|68.[2-9][0-9][0-9]) : ;;
  *) fail "requires V68.175 or later compatible source (got $ver)" ;;
esac
grep -Eq 'SCHED_IDLE_HLT_BURST +(8|[1-9][0-9]+)U' "$SH" || fail "idle HLT burst missing"
grep -q 'scheduler_runnable_nonidle_exists()' "$S" || fail "runnable recheck missing"
grep -q 'cpu_sti_hlt();' "$S" || fail "STI;HLT missing"
grep -q 'SchedulerIdleWait();' "$I" || fail "CPU_IDLE does not use SchedulerIdleWait"
grep -q 'True CPU idle loop' "$I" || fail "CPU_IDLE documentation missing"

grep -Eq 'SchedulerWaitPause\((5000|10000|[2-9][0-9]000)UL\);' "$SER" || fail "serial idle sleep missing"
grep -q 'SchedulerWaitPause(10000UL);' "$ROOT/kernel32/drivers/sb/sb.c" || fail "SB idle sleep missing"
grep -q 'SchedulerWaitPause(10000UL);' "$ROOT/kernel32/drivers/gus/gus.c" || fail "GUS idle sleep missing"
grep -q 'SchedulerWaitPause(1000UL);' "$ROOT/kernel32/drivers/slip/slip.c" || fail "SLIP wait sleep missing"

(grep -q 'MilSleep((int)ms);' "$SPL" || grep -q 'splash_wait_turns' "$SPL") || fail "bounded splash wait missing"
! grep -q 'draw_fade_group(v,poster,ox,oy,step\*2,0)' "$SPL" || fail "splash still fades to empty rectangle"
python3 - "$GUI" <<'PY'
import sys
s=open(sys.argv[1]).read()
assert 'guiStartupShowPoster(v)' not in s
assert s.index('wdbInit();') < s.index('guiCreateWelcome(v)')
assert s.index('guiCreateWelcome(v);') < s.index('if(!guiUpdate(v))')
assert s.index('if(!guiUpdate(v))') < s.index('guiServerInit();')
PY
grep -Eq 'MilSleep\((5|10|20)\);' "$LOOP" || fail "GraOS event loop is still always-runnable"

grep -q 'entries\[cpu.idle_pid\].cpu_per_mille=0' "$TOP" || fail "top still presents idle as consumed CPU"
grep -q 'dprintk("IDTPTR' "$ROOT/kernel32/core/int/int.c" || fail "IDT verbose line still printk"
grep -q 'dprintk("Paging initializing' "$ROOT/kernel32/mm/paging.c" || fail "paging verbose block not moved to dprintk"
grep -q 'dprintk("OHCI: stage 1/5' "$ROOT/kernel32/drivers/usb/ohci.c" || fail "OHCI stages still stdout printk"
grep -q 'dprintk("PCI %d:%d.%d' "$ROOT/kernel32/drivers/pci/pci.c" || fail "PCI per-device dump still stdout printk"

echo "check_v68175_idle_hlt_graos_quiet: PASS"
