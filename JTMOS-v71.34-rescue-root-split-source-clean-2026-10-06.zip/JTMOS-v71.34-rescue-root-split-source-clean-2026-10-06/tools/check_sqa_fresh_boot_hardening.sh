#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SQA="$ROOT/kernel32/sh/sqa.c"
SQAH="$ROOT/kernel32/sh/sqa.h"
MAIN="$ROOT/kernel32/sh/sqaMain.c"
DFA="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"
ATAPI="$ROOT/kernel32/drivers/atapi/atapi.c"
fail(){ echo "check_sqa_fresh_boot_hardening: FAIL: $*" >&2; exit 1; }

grep -q 'typedef struct SQA_CONTEXT' "$SQAH" || fail "per-invocation SQA context missing"
grep -q 'extract_archive_ex' "$SQA" || fail "context extractor entry missing"
! grep -Eq '^SQDSK[[:space:]]+sqdsk|^int[[:space:]]+quiet[[:space:]]*=|^char[[:space:]]+specific|^char[[:space:]]+dstdir|^int[[:space:]]+seloffs' "$SQA" || fail "mutable extractor globals returned"
grep -q 'memset(ctx,0,sizeof(\*ctx))' "$SQA" || fail "fresh context is not initialized before cleanup"
grep -q 'int fd,rc=0' "$SQA" || fail "extractor result is not initialized"
grep -q '#define SQA_COPY_BUFFER_SIZE 131072U' "$SQAH" || fail "kernel SQA transfer target is not 128 KiB"
grep -q '#define SQA_COPY_BUFFER_MIN  8192U' "$SQAH" || fail "kernel SQA 8 KiB fallback is missing"
grep -q 'capacity>>=1' "$SQA" || fail "kernel SQA adaptive buffer fallback is missing"
grep -q 'char output\[512\]' "$SQA" || fail "bounded output-name stack buffer missing"
! grep -Eq '\[[[:space:]]*65536(U|UL)?[[:space:]]*\]' "$SQA" || fail "64 KiB stack buffer returned"
grep -q 'extract_archive_ex(archives.items\[i\],wanted,destination,0,quiet_mode)' "$MAIN" || fail "SMSH/SQSH SQA does not use invocation-local options"

grep -q 'rv=readfile(f->name,(char \*)buf,f->offset,want)' "$DFA" || fail "raw POSIX read ignores readfile status"
grep -q 'if(rv!=0)' "$DFA" || fail "raw read failure is not propagated"
grep -q 'raw_bytes-(unsigned long)(unsigned)f->offset' "$DFA" || fail "raw device EOF clamping missing"
grep -q 'rv=readblocks(d1,first_block' "$DFA" || fail "raw readblocks result is not captured"
grep -q 'if(rv!=block_count)' "$DFA" || fail "short raw block read is not rejected"

grep -q '#define ATAPI_READ_RETRIES[[:space:]]*3U' "$ATAPI" || fail "bounded ATAPI fresh-media retry missing"
grep -q 'atapi_request_sense(d)' "$ATAPI" || fail "ATAPI retry does not request sense"
grep -q 'last_sense_key==0x06' "$ATAPI" || fail "UNIT ATTENTION retry missing"
grep -q 'last_sense_key==0x02.*last_asc==0x3A' "$ATAPI" || fail "no-media termination missing"

# Exercise the portable implementation as a behavioral regression, including
# the old -u self-alias failure.  Build only under mktemp, never in the tree.
TMP=${TMPDIR:-/tmp}/jtmos-sqa-124-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/src" "$TMP/out"
printf 'fresh boot sqa\n' > "$TMP/src/hello.txt"
awk 'BEGIN { for(i=0;i<400000;i++) printf "%c", i%251 }' > "$TMP/src/data.bin"
cc -O2 "$ROOT/tools/sqarc.c" -o "$TMP/sqarc"
cc -O2 -I"$ROOT/libc/apps" "$ROOT/libc/apps/sqa.c" "$ROOT/libc/apps/sqaMain.c" "$ROOT/libc/apps/nzip.c" -o "$TMP/sqa"
JTMOSDIR="$ROOT" "$TMP/sqarc" "$TMP/src" "$TMP/archive.sqa" >/dev/null 2>&1
(
  cd "$TMP/out"
  "$TMP/sqa" ../archive.sqa -q
  cmp ../src/hello.txt hello.txt
  cmp ../src/data.bin data.bin
  rm -f hello.txt data.bin
  "$TMP/sqa" ../archive.sqa -q -u hello.txt
  test -f hello.txt
  test ! -e data.bin
)

echo "check_sqa_fresh_boot_hardening: PASS"
