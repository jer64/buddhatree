#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_utils_install_payload: FAIL: $*" >&2; exit 1; }
B=tools/build_install_image.sh
M=Makefile
D=boot32pm/Makefile
S=tools/sqarc.c
P=tools/publish_utilities_iso.sh
# The V70.29+ CD payload is package-only. The legacy system-install.img.nz remains
# an internal B:/rescue bootstrap detail and must not be required by utilities.iso.
EXPECTED="boot.sqa core.sqa demos.sqa docs.sqa graos.sqa interpreters.sqa media.sqa network.sqa tests.sqa"
grep -Fq 'sh ./tools/publish_utilities_iso.sh' "$M" || fail "utilities.iso publisher missing"
grep -Fq 'outer archive contains a non-SQA member' "$P" || fail "publisher non-SQA rejection missing"
grep -Fq 'staged utils.iso contains non-SQA members' "$D" || fail "DOS staged non-SQA rejection missing"
grep -Fq 'strcmp(argv[1],"--has-member")' "$S" || fail "sqarc --has-member inspector missing"
grep -Fq 'strcmp(argv[1],"--list")' "$S" || fail "sqarc --list inspector missing"
for pkg in $EXPECTED; do
    grep -Fq "$pkg" "$P" || fail "publisher contract missing $pkg"
    grep -Fq "$pkg" "$D" || fail "DOS package contract missing $pkg"
done
if [ -x tools/sqarc ] && [ -f utilities.iso ]; then
    for pkg in $EXPECTED; do tools/sqarc --has-member utilities.iso "$pkg" || fail "built utilities.iso lacks $pkg"; done
    ! tools/sqarc --list utilities.iso | grep -v '\.sqa$' | grep -q . || fail "built utilities.iso contains non-SQA member"
fi
if [ -x tools/sqarc ] && [ -f boot32pm/dosboot/utils.iso ]; then
    for pkg in $EXPECTED; do tools/sqarc --has-member boot32pm/dosboot/utils.iso "$pkg" || fail "built DOS utils.iso lacks $pkg"; done
    ! tools/sqarc --list boot32pm/dosboot/utils.iso | grep -v '\.sqa$' | grep -q . || fail "built DOS utils.iso contains non-SQA member"
fi
echo "check_utils_install_payload: PASS"
