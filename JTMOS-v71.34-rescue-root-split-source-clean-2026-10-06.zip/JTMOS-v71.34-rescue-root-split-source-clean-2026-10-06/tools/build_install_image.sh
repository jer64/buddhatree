#!/bin/sh
set -eu
MAKE=${MAKE:-make}
TOOLS=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$TOOLS/.." && pwd)
APPS="$ROOT/libc/apps"
GUI="$APPS/gui"
PAYLOAD="$TOOLS/install_payload"
BOOTSTRAP="$TOOLS/extended_bootstrap"
SYSTEM_PAYLOAD="$TOOLS/system_payload"
SYSTEM_BOOTSTRAP="$TOOLS/system_bootstrap"
WEB="$ROOT/www"
SHELL_MANUAL="$ROOT/docs/SMSH-SQSH-MANUAL.txt"
BOOT_FLOPPY_IMAGE="$ROOT/jtm32.img"
CBMVM_EXAMPLES="$ROOT/libc/apps/cbmvm/examples"
BWBASIC_EXAMPLES="$ROOT/libc/apps/bwbasic/tests"
UNIQUE_EXAMPLES="$ROOT/share/unique/examples"
UNIQUE_LEGACY_EXAMPLES="$ROOT/share/unique/legacy-examples"
CBMVM_ARCHIVE="$TOOLS/cbmvm-examples.sqa"
INTERPRETER_STAGE="$TOOLS/package_interpreters_payload"
DEMO_STAGE="$TOOLS/package_demos_payload"
TEST_STAGE="$TOOLS/package_tests_payload"
MEDIA_STAGE="$TOOLS/package_media_payload"
NETWORK_STAGE="$TOOLS/package_network_payload"
GRAOS_STAGE="$TOOLS/package_graos_payload"
CORE_STAGE="$TOOLS/package_core_payload"
DOCS_STAGE="$TOOLS/package_docs_payload"
BOOT_STAGE="$TOOLS/package_boot_payload"
MANIFEST="$PAYLOAD/UTILS-MANIFEST.txt"

[ -x "$TOOLS/sqarc" ] || { echo "build_install_image: tools/sqarc missing" >&2; exit 1; }
[ -x "$TOOLS/nzip" ] || { echo "build_install_image: tools/nzip missing" >&2; exit 1; }
[ -s "$APPS/unz.bin" ] || { echo "build_install_image: unz.bin missing" >&2; exit 1; }
[ -s "$APPS/sqa.bin" ] || { echo "build_install_image: sqa.bin missing" >&2; exit 1; }
[ -s "$APPS/nzip.bin" ] || { echo "build_install_image: nzip.bin missing" >&2; exit 1; }
[ -s "$BOOT_FLOPPY_IMAGE" ] || { echo "build_install_image: jtm32.img missing; build image before packages" >&2; exit 1; }

rm -rf "$PAYLOAD" "$BOOTSTRAP" "$SYSTEM_PAYLOAD" "$SYSTEM_BOOTSTRAP" \
       "$INTERPRETER_STAGE" "$DEMO_STAGE" "$TEST_STAGE" "$MEDIA_STAGE" "$NETWORK_STAGE" \
       "$GRAOS_STAGE" "$CORE_STAGE" "$DOCS_STAGE" "$BOOT_STAGE" "$TOOLS/cbmvm_examples_payload"
rm -f "$CBMVM_ARCHIVE"
mkdir -p "$PAYLOAD" "$BOOTSTRAP" "$SYSTEM_PAYLOAD" "$SYSTEM_BOOTSTRAP"
rm -f "$TOOLS/install.img" "$TOOLS/install.img.nz" \
      "$TOOLS/system-install.img" "$TOOLS/system-install.img.nz" \
      "$TOOLS/utilsdisk.img" "$TOOLS/utilities.sqa"

# Authoritative release application inventory.  Never infer the release set from
# whichever *.bin files happen to be present in the working tree: doing that made
# stale/forgotten targets silently disappear from SQA packaging.
RELEASE_APP_BINS=$($MAKE --no-print-directory -s -C "$APPS" list-binaries | tr '\n' ' ')
APP_COUNT=0
for base in $RELEASE_APP_BINS; do
    [ -s "$APPS/$base" ] || {
        echo "build_install_image: release application missing: $base" >&2
        exit 1
    }
    cp "$APPS/$base" "$PAYLOAD/$base"
    APP_COUNT=$((APP_COUNT + 1))
done
[ "$APP_COUNT" -gt 0 ] || { echo "build_install_image: empty release application inventory" >&2; exit 1; }

# A built root-level binary that is not in the authoritative inventory is never
# ignored.  Either promote it to ALL_APPS or clean it from the tree.
for f in "$APPS"/*.bin; do
    [ -f "$f" ] || continue
    base=$(basename "$f")
    case " $RELEASE_APP_BINS " in
        *" $base "*) ;;
        *) echo "build_install_image: unclassified built application: $base" >&2; exit 1 ;;
    esac
done

# Every application named by libc/apps/Makefile UTILITIES_ONLY_APPS must be in
# the complete CD payload.  The reduced sys:/B: payload is checked separately
# below to guarantee that none of these optional programs leak into it.
UTILITIES_ONLY_APPS=$($MAKE --no-print-directory -s -C "$APPS" list-utilities)
for app in $UTILITIES_ONLY_APPS; do
    [ -s "$PAYLOAD/$app.bin" ] || {
        echo "build_install_image: utilities-only $app.bin missing from full CD payload" >&2
        exit 1
    }
done

# GraOS runtime distribution.  Do NOT put source/build artifacts on the 1.44M
# utilities archive.  The whitelist deliberately includes only executable and
# runtime resource/config/help formats.  New GraOS runtime dependencies with a
# supported extension are picked up automatically.
GUI_COUNT=0
for f in "$GUI"/*; do
    [ -f "$f" ] || continue
    case "$f" in
        *.bin|*.raw|*.dat|*.cfg|*.hlp|*.txt|*.ini|*.fnt|*.font|*.pal|*.res|*.bmp|*.pcx)
            base=$(basename "$f")
            [ ! -e "$PAYLOAD/$base" ] || {
                echo "build_install_image: duplicate runtime basename: $base" >&2
                exit 1
            }
            cp "$f" "$PAYLOAD/$base"
            GUI_COUNT=$((GUI_COUNT + 1))
            ;;
        *.c|*.h|*.o|*.a|*.map|*.mak|*/Makefile|*/README)
            ;;
        *)
            # Unknown files are not silently shipped as runtime dependencies.
            ;;
    esac
done
[ -s "$PAYLOAD/graos.bin" ] || { echo "build_install_image: gui/graos.bin missing" >&2; exit 1; }

[ -s "$SHELL_MANUAL" ] || { echo "build_install_image: SMSH/SQSH manual missing" >&2; exit 1; }
cp "$SHELL_MANUAL" "$PAYLOAD/SMSH-SQSH-MANUAL.txt"

# Native GraOS clients are built and packaged from the canonical libc/apps/gui tree.
EXTGUI_COUNT=0
EXTGUI_RES_COUNT=0

# Runtime resources belonging to CLI-directory GraOS applications.
# sqfam.raw is installed with picture.bin so the windowed picture demo works from the normal root payload.
[ ! -f "$APPS/sqfam.raw" ] || cp "$APPS/sqfam.raw" "$PAYLOAD/sqfam.raw"

# Useful help/config scripts from the CLI app directory.
for f in "$APPS"/*.hlp "$APPS"/boot.sh "$APPS"/boot.uni "$APPS"/help.sh "$APPS"/setup.sh; do
    [ -f "$f" ] || continue
    cp "$f" "$PAYLOAD/$(basename "$f")"
done

# Unique is the native JTMOS system scripting language.  Ship compact examples
# as editable .uni files beside unique.bin; they are runtime documentation, not
# build/source artifacts.
for f in "$UNIQUE_EXAMPLES"/*.uni; do
    [ -f "$f" ] || continue
    cp "$f" "$PAYLOAD/unique-$(basename "$f")"
done

# Runtime external-driver material currently shipped by the tree.  These are
# data/config artifacts only; kernel-owned boot-critical drivers remain kernel
# drivers until their userspace ABI ports are complete.
find "$ROOT/libc/drv" -type f \( -name '*.sys' -o -name '*.cfg' \) -print | while IFS= read -r f; do
    cp "$f" "$PAYLOAD/$(basename "$f")"
done

cat > "$PAYLOAD/DRIVERS.txt" <<'TXT'
JTMOS V67.8 driver notes
========================
FDC, Sound Blaster, Gravis UltraSound, IDE, serial and other boot-critical
hardware remain kernel drivers unless explicitly ported through the userspace
IRQ/DMA ABI.  irqdma.bin demonstrates the userspace IRQ/DMA interface.
TXT

# ---------------------------------------------------------------------------
# V68.172 topic packages inside the full utilities payload.
# ---------------------------------------------------------------------------
# Keep the rescue/system language itself directly available: boot.uni may need
# unique.bin before any optional package is expanded.  Optional interpreters,
# examples, demos and developer tests are grouped into nested SQA archives so
# utilities.iso remains organized and each subject can be installed separately.
mkdir -p "$INTERPRETER_STAGE" "$DEMO_STAGE" "$TEST_STAGE" "$MEDIA_STAGE" "$NETWORK_STAGE" "$GRAOS_STAGE" "$CORE_STAGE" "$DOCS_STAGE" "$BOOT_STAGE"

# CBMVM examples are useful both as a historical standalone archive in the outer
# bootstrap and as interpreter material.  Build the canonical archive once and
# reuse the exact bytes in both places.
CBMVM_STAGE="$TOOLS/cbmvm_examples_payload"
rm -rf "$CBMVM_STAGE"
mkdir -p "$CBMVM_STAGE"
CBMVM_PRG_COUNT=0
for f in "$CBMVM_EXAMPLES"/*.prg; do
    [ -f "$f" ] || continue
    cp "$f" "$CBMVM_STAGE/$(basename "$f")"
    CBMVM_PRG_COUNT=$((CBMVM_PRG_COUNT + 1))
done
[ "$CBMVM_PRG_COUNT" -gt 0 ] || { echo "build_install_image: no CBMVM .prg examples found" >&2; exit 1; }
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$CBMVM_STAGE" "$CBMVM_ARCHIVE"
[ -s "$CBMVM_ARCHIVE" ] || { echo "build_install_image: cbmvm-examples.sqa creation failed" >&2; exit 1; }
rm -rf "$CBMVM_STAGE"

# GraOS package: GUI server, desktop/system GUI clients and runtime resources.
# Content applications keep semantic ownership: MP3/MPEG-1 belong to media.sqa
# even though their frontends use the public GraOS API.
GRAOS_APPS="filer iview taskbar winshell wintest wintest2 wintest3 cbmvm"
for app in $GRAOS_APPS; do
    [ -s "$PAYLOAD/$app.bin" ] || { echo "build_install_image: missing GraOS client $app.bin" >&2; exit 1; }
    mv "$PAYLOAD/$app.bin" "$GRAOS_STAGE/$app.bin"
done
RELEASE_GUI_BINS=$($MAKE --no-print-directory -s -C "$GUI" list-binaries | tr '\n' ' ')
for base in $RELEASE_GUI_BINS; do
    [ -s "$GUI/$base" ] || { echo "build_install_image: release GraOS binary missing: $base" >&2; exit 1; }
    if [ -s "$PAYLOAD/$base" ]; then
        mv "$PAYLOAD/$base" "$GRAOS_STAGE/$base"
    else
        cp "$GUI/$base" "$GRAOS_STAGE/$base"
    fi
done
for f in "$GUI"/*.bin; do
    [ -f "$f" ] || continue
    base=$(basename "$f")
    case " $RELEASE_GUI_BINS " in
        *" $base "*) ;;
        *) echo "build_install_image: unclassified built GraOS binary: $base" >&2; exit 1 ;;
    esac
done
for base in jtmos_poster.raw mousecursor.raw squirrel16.raw title_close98.raw title_minimize98.raw filer.hlp; do
    if [ -s "$PAYLOAD/$base" ]; then mv "$PAYLOAD/$base" "$GRAOS_STAGE/$base"; fi
done
cat > "$GRAOS_STAGE/GRAOS-README.txt" <<'TXT'
JTMOS GraOS package
===================
GraOS server, all release GraOS clients, Terminal Monitor and GUI resources.
Install with:
  sqa graos.sqa
TXT
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$GRAOS_STAGE" "$PAYLOAD/graos.sqa"
[ -s "$PAYLOAD/graos.sqa" ] || { echo "build_install_image: graos.sqa creation failed" >&2; exit 1; }
rm -rf "$GRAOS_STAGE"

# Interpreter package. Unique remains in core because boot.uni can require it.
# bwBASIC and language/example material are optional; CBMVM itself is in
# graos.sqa because its JTMOS release frontend is a GraOS application.
for app in bwbasic; do
    [ -s "$PAYLOAD/$app.bin" ] || { echo "build_install_image: missing interpreter $app.bin" >&2; exit 1; }
    mv "$PAYLOAD/$app.bin" "$INTERPRETER_STAGE/$app.bin"
done
for f in "$PAYLOAD"/unique-*.uni; do
    [ -f "$f" ] || continue
    mv "$f" "$INTERPRETER_STAGE/$(basename "$f")"
done
for f in "$UNIQUE_LEGACY_EXAMPLES"/*.uni; do
    [ -f "$f" ] || continue
    base=$(basename "$f")
    cp "$f" "$INTERPRETER_STAGE/unique-legacy-$base"
done
for f in "$BWBASIC_EXAMPLES"/*.bas "$BWBASIC_EXAMPLES"/index.txt; do
    [ -f "$f" ] || continue
    base=$(basename "$f")
    case "$base" in
        *.bas) cp "$f" "$INTERPRETER_STAGE/bwb-$base" ;;
        index.txt) cp "$f" "$INTERPRETER_STAGE/BWBASIC-INDEX.txt" ;;
    esac
done
cp "$CBMVM_ARCHIVE" "$INTERPRETER_STAGE/cbmvm-examples.sqa"
cat > "$INTERPRETER_STAGE/INTERPRETERS-README.txt" <<'TXT'
JTMOS interpreters package
==========================
Contents include the pure-C Perl-style Unique 2.x interpreter, Bywater BASIC
2.20 pl2 for JTMOS, Unique .uni examples, bwBASIC .bas examples and the CBMVM PRG example archive.
CBMVM itself is installed by graos.sqa because its JTMOS frontend uses GraOS.

unique.bin also remains in the core JTMOS payload because boot.uni and system
administration scripts may require it before this optional package is expanded.

Install/extract in the current directory with:
  sqa interpreters.sqa

Then, for example:
  unique.bin unique-hello.uni
  bwbasic.bin bwb-whilwend.bas
  sqa cbmvm-examples.sqa
  cbmvm.bin hello.prg
TXT
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$INTERPRETER_STAGE" "$PAYLOAD/interpreters.sqa"
[ -s "$PAYLOAD/interpreters.sqa" ] || { echo "build_install_image: interpreters.sqa creation failed" >&2; exit 1; }
rm -rf "$INTERPRETER_STAGE"

# V70.53: demos.sqa is an all-or-nothing release contract.  Publishing a
# package containing only the subset that happened to build hid broken demo
# targets on real machines.  Require every advertised program and resource.
DEMO_COUNT=0
for app in bgidemo picture plasma plasma2 snake stuntcar vgaplasma; do
    [ -s "$PAYLOAD/$app.bin" ] || { echo "build_install_image: required demos.sqa program missing: $app.bin" >&2; exit 1; }
    mv "$PAYLOAD/$app.bin" "$DEMO_STAGE/$app.bin"
    DEMO_COUNT=$((DEMO_COUNT + 1))
done
[ -s "$PAYLOAD/sqfam.raw" ] || { echo "build_install_image: required demos.sqa resource missing: sqfam.raw" >&2; exit 1; }
[ "$(wc -c < "$PAYLOAD/sqfam.raw")" -eq 256000 ] || { echo "build_install_image: sqfam.raw must be exactly 256000 bytes" >&2; exit 1; }
mv "$PAYLOAD/sqfam.raw" "$DEMO_STAGE/sqfam.raw"
cat > "$DEMO_STAGE/DEMOS-README.txt" <<'TXT'
JTMOS demos package
===================
GraOS graphics/game demonstrations. Extract with:
  sqa demos.sqa

Programs:
  bgidemo.bin    BGI/GraOS primitive and keyboard self-test
  picture.bin    Squirrel Family RGBA32 viewer (uses sqfam.raw)
  plasma.bin     windowed plasma effect
  plasma2.bin    second integer plasma effect
  snake.bin      windowed Snake game
  stuntcar.bin   BGI 3D Stunt Circuit game
  vgaplasma.bin  VGA-style plasma in a safe GraOS window

Start GraOS first with `graos`.  Normal window close and Esc are safe exit paths.
TXT
[ "$DEMO_COUNT" -eq 7 ] || { echo "build_install_image: demos.sqa requires all 7 programs" >&2; exit 1; }
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$DEMO_STAGE" "$PAYLOAD/demos.sqa"
[ -s "$PAYLOAD/demos.sqa" ] || { echo "build_install_image: demos.sqa creation failed" >&2; exit 1; }
rm -rf "$DEMO_STAGE"

# Multimedia package is an all-or-nothing semantic contract.  MP3/MPEG-1 are
# GraOS clients, but installing media.sqa must actually install the advertised
# players as well as the low-level audio tools.
MEDIA_COUNT=0
for app in mpeg1 mp3 sound rawplay aud; do
    [ -s "$PAYLOAD/$app.bin" ] || { echo "build_install_image: required media.sqa program missing: $app.bin" >&2; exit 1; }
    mv "$PAYLOAD/$app.bin" "$MEDIA_STAGE/$app.bin"
    MEDIA_COUNT=$((MEDIA_COUNT + 1))
done
cat > "$MEDIA_STAGE/MEDIA-README.txt" <<'TXT'
JTMOS media package
===================
Optional audio/video playback and sound utilities. Extract with:
  sqa media.sqa

GraOS players:
  mp3.bin [file.mp3|directory] [--loop]
  mpeg1.bin [file.mpg|directory] [--mute] [--loop]

Launching either player without a file opens its built-in file browser.
TXT
[ "$MEDIA_COUNT" -eq 5 ] || { echo "build_install_image: media.sqa requires all 5 media programs" >&2; exit 1; }
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$MEDIA_STAGE" "$PAYLOAD/media.sqa"
[ -s "$PAYLOAD/media.sqa" ] || { echo "build_install_image: media.sqa creation failed" >&2; exit 1; }
rm -rf "$MEDIA_STAGE"

# Optional interactive network applications. Core net.bin/ping.bin deliberately
# remain direct so recovery networking never depends on another archive.
NETWORK_COUNT=0
for app in irc talk bitchx; do
    if [ -s "$PAYLOAD/$app.bin" ]; then
        mv "$PAYLOAD/$app.bin" "$NETWORK_STAGE/$app.bin"
        NETWORK_COUNT=$((NETWORK_COUNT + 1))
    fi
done

# BitchX 1.2.1 JTMOS R2 is integrated with the network package even while the
# full native executable is gated on the libc BSD-socket compatibility layer.
for f in "$ROOT/share/network/BITCHX-R2.txt" "$ROOT/share/network/bitchx-r2-src.tgz"; do
    [ -s "$f" ] || { echo "build_install_image: missing BitchX network payload: $f" >&2; exit 1; }
    cp "$f" "$NETWORK_STAGE/$(basename "$f")"
done

cat > "$NETWORK_STAGE/NETWORK-README.txt" <<'TXT'
JTMOS optional network applications
===================================
Interactive/non-recovery networking programs. Core net.bin and ping.bin remain
directly available. BitchX 1.2.1 JTMOS R2 source integration is included as
bitchx-r2-src.tgz + BITCHX-R2.txt; a validated native bitchx.bin is included
automatically when present in the canonical application payload. Extract with:
  sqa network.sqa
TXT
[ "$NETWORK_COUNT" -gt 0 ] || { echo "build_install_image: no optional network programs available" >&2; exit 1; }
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$NETWORK_STAGE" "$PAYLOAD/network.sqa"
[ -s "$PAYLOAD/network.sqa" ] || { echo "build_install_image: network.sqa creation failed" >&2; exit 1; }
rm -rf "$NETWORK_STAGE"

# Developer tests/diagnostics are useful on the full utilities media but should
# not clutter a normal /bin extraction.  Move them into tests.sqa.
TEST_COUNT=0
for app in atapitest filetest cwdtest fsregress float_test fpuhard fputest keytest malloctest otest runner sscanf_test wtest performance printtest linuxcore10 jtmfsbench; do
    if [ -s "$PAYLOAD/$app.bin" ]; then
        mv "$PAYLOAD/$app.bin" "$TEST_STAGE/$app.bin"
        TEST_COUNT=$((TEST_COUNT + 1))
    fi
done
cat > "$TEST_STAGE/TESTS-README.txt" <<'TXT'
JTMOS developer tests package
=============================
Optional regression, hardware and libc test executables. Extract with:
  sqa tests.sqa
These are not required by the normal boot/rescue system.
TXT
[ "$TEST_COUNT" -gt 0 ] || { echo "build_install_image: no developer tests available for tests.sqa" >&2; exit 1; }
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$TEST_STAGE" "$PAYLOAD/tests.sqa"
[ -s "$PAYLOAD/tests.sqa" ] || { echo "build_install_image: tests.sqa creation failed" >&2; exit 1; }
rm -rf "$TEST_STAGE"

cat > "$PAYLOAD/PACKAGES-README.txt" <<'TXT'
JTMOS utilities package map
===========================
utilities.iso is an outer Squirrel archive whose root contains ONLY .sqa files:

  core.sqa         - shell, filesystem, process, memory and recovery commands
  graos.sqa        - GraOS server, desktop/system GUI clients and runtime resources
  interpreters.sqa - bwBASIC and language/example material
  demos.sqa        - non-GraOS graphics/game demonstrations
  media.sqa        - MP3/MPEG-1 players and audio/sound utilities
  network.sqa      - optional interactive network applications
  tests.sqa        - developer/hardware/libc regression executables
  docs.sqa         - manuals, help and editable JTMOS web demo assets
  boot.sqa         - current boot-only jtm32.img

Preferred package-manager workflow after core.sqa is available:
  pkg list utils.iso
  pkg install graos hda1:/bin utils.iso
  pkg install media hda1:/bin utils.iso

Legacy/manual extraction remains supported:
  sqa utils.iso
  sqa core.sqa
  sqa graos.sqa
TXT

# Documentation package. Nothing textual is left loose on utilities.iso.
for base in SMSH-SQSH-MANUAL.txt edit.hlp PACKAGES-README.txt; do
    if [ -s "$PAYLOAD/$base" ]; then mv "$PAYLOAD/$base" "$DOCS_STAGE/$base"; fi
done
for base in index.html index-en.html invest.html invest-en.html jtmos.css jtmos.js; do
    [ -s "$WEB/$base" ] || { echo "build_install_image: missing web asset $base" >&2; exit 1; }
    cp "$WEB/$base" "$DOCS_STAGE/$base"
done
cat > "$DOCS_STAGE/DOCS-README.txt" <<'TXT'
JTMOS documentation package. Extract with: sqa docs.sqa
TXT
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$DOCS_STAGE" "$PAYLOAD/docs.sqa"
rm -rf "$DOCS_STAGE"

# Boot-media package: keep the current boot image packaged rather than loose.
cp "$BOOT_FLOPPY_IMAGE" "$BOOT_STAGE/jtm32.img"
cat > "$BOOT_STAGE/BOOT-README.txt" <<'TXT'
JTMOS boot image package. Extract with: sqa boot.sqa
TXT
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$BOOT_STAGE" "$PAYLOAD/boot.sqa"
rm -rf "$BOOT_STAGE"

# Everything still loose in PAYLOAD is core runtime material. Move it into one
# package, excluding the already-created topic archives. This is the catch-all
# invariant that guarantees no release runtime file is left outside an SQA.
for f in "$PAYLOAD"/*; do
    [ -f "$f" ] || continue
    case "$f" in *.sqa) continue ;; esac
    mv "$f" "$CORE_STAGE/$(basename "$f")"
done
cat > "$CORE_STAGE/CORE-README.txt" <<'TXT'
JTMOS core utilities package
============================
Shell, filesystem, process, memory, archive and recovery commands plus runtime
configuration needed by the normal command-line environment.
pkg.bin is included here so additional SQA packages can be installed without
manually unpacking the outer utilities archive.
Extract with: sqa core.sqa
TXT
JTMOSDIR="$ROOT" "$TOOLS/sqarc" "$CORE_STAGE" "$PAYLOAD/core.sqa"
rm -rf "$CORE_STAGE"

# V70.31: every release program must be owned by exactly one program package.
# The independent checker reads the actual SQA member tables, not staging names.
"$TOOLS/check_v7031_complete_sqa_programs.py" --payload "$PAYLOAD" --apps "$APPS" --gui "$GUI"

# Hard invariant: the complete package staging root itself now contains SQA only.
if find "$PAYLOAD" -maxdepth 1 -type f ! -name '*.sqa' | grep -q .; then
    echo "build_install_image: non-SQA file remains in package root" >&2
    exit 1
fi

# Record the outer package list outside PAYLOAD so it cannot violate the SQA-only root.
MANIFEST="$TOOLS/UTILS-PACKAGES.txt"
{
    echo "JTMOS utilities package manifest"
    echo "==============================="
    echo "Outer utilities.iso members (SQA only):"
    (cd "$PAYLOAD" && find . -maxdepth 1 -type f -name '*.sqa' -printf '%f\n' | LC_ALL=C sort)
} > "$MANIFEST"

# Hard release invariant requested for the utilities archive: no C/header/object
# or static-library/map/make fragments may leak into the runtime payload.
if find "$PAYLOAD" -maxdepth 1 -type f \( \
       -name '*.c' -o -name '*.h' -o -name '*.o' -o -name '*.a' -o \
       -name '*.map' -o -name '*.mak' -o -name 'Makefile' \) | grep -q .; then
    echo "build_install_image: source/build artifact leaked into runtime payload" >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# System + CD-ROM utilities packaging
# ---------------------------------------------------------------------------
# install_payload is the complete distribution and is always placed on the
# ATAPI utilities/demo CD-ROM.  The boot floppy A: is boot-only.  The compact system archive is emitted for
# the separate 1.44 MiB B: root medium, so it is no longer constrained by the
# historical 800 KiB tail of the boot floppy.  Large demos/media/tests remain
# CD-ROM-only so the B: root image stays comfortably below 1.44 MiB.
#
# Keep this list conservative: anything removed here remains present in the
# complete CD-ROM payload below.
# V16.71.1: the fast NZIP2 stream deliberately trades some compression ratio
# for much faster decompression.  A blacklist-based B: payload therefore no
# longer has a stable size: every newly added application silently grows the
# 1.44 MiB rescue medium.  Keep B: as an explicit core/rescue system instead.
# Everything omitted here is still present in the complete utilities.iso.
#
# V70.59: graosctl.bin is likewise full-media only; the rescue image keeps the
# graphical control panel, so removing this duplicate CLI controller preserves
# functionality while restoring a useful size margin.
#
# V70.59: head/tail/wc/which are normal release applications and remain in
# utilities.iso, but are intentionally not duplicated onto the fixed 1.44 MiB
# rescue B: medium.  V70.58 added them to this whitelist and pushed utilsdisk.img
# over 1.44 MiB.  Keep this list about recovery capability, not CLI completeness.
#
# sqa.bin and unz.bin are carried by the outer B: bootstrap.
# unz.bin and sqa.bin intentionally are not duplicated in the inner payload:
# they are already files in SYSTEM_BOOTSTRAP and remain present after the
# outer SQA is extracted.  This saves about 138 KiB raw before compression.
SYSTEM_KEEP_FILES="
cat.bin
clear.bin
cp.bin
free.bin
du.bin
find.bin
grep.bin
kill.bin
lar.bin
ls.bin
mkdir.bin
mkfs.bin
more.bin
mv.bin
net.bin
ping.bin
nzip.bin
ramextract.bin
ren.bin
rm.bin
setup.bin
sqsh.bin
vt2.bin
val.bin
unique.bin
terminal.bin
boot.uni
boot.sh
help.sh
setup.sh
edit.hlp
filer.hlp
hd.sys
tcp.cfg
slip.cfg
DRIVERS.txt
jtmos_poster.raw
title_close98.raw
title_minimize98.raw
mousecursor.raw
"

# Create the reduced system payload from the already validated complete one.
# V71.17: ps.bin and top.bin intentionally remain on utilities.iso only;
# they are diagnostic conveniences, not required to boot/recover/install, and
# keeping them off the fixed 1.44 MiB B: medium restores deterministic headroom.
# Whitelisting is intentional: future large apps go to utilities.iso by default
# instead of breaking `make` by overflowing the fixed-size B: rescue medium.
# Build the B: rescue payload independently from canonical built artifacts; the
# CD package root is SQA-only and is no longer a source for raw rescue files.
for base in $SYSTEM_KEEP_FILES; do
    case "$base" in
      *.bin)
        if [ -s "$APPS/$base" ]; then cp "$APPS/$base" "$SYSTEM_PAYLOAD/$base";
        elif [ -s "$GUI/$base" ]; then cp "$GUI/$base" "$SYSTEM_PAYLOAD/$base"; fi ;;
      *)
        if [ -s "$APPS/$base" ]; then cp "$APPS/$base" "$SYSTEM_PAYLOAD/$base";
        elif [ -s "$GUI/$base" ]; then cp "$GUI/$base" "$SYSTEM_PAYLOAD/$base";
        elif [ -s "$ROOT/libc/drv/$base" ]; then cp "$ROOT/libc/drv/$base" "$SYSTEM_PAYLOAD/$base"; fi ;;
    esac
done
KEPT_COUNT=$(find "$SYSTEM_PAYLOAD" -maxdepth 1 -type f | wc -l | tr -d ' ')
MOVED_COUNT=0

# Hard split invariant: utilities-only programs belong to utilities.iso and
# must never consume space on the compact sys:/B: rescue payload.
for app in $UTILITIES_ONLY_APPS; do
    [ ! -e "$SYSTEM_PAYLOAD/$app.bin" ] || {
        echo "build_install_image: utilities-only $app.bin leaked into sys: payload" >&2
        exit 1
    }
done

# Fail early if a core program/resource was renamed or stopped building.
for base in sqsh.bin vt2.bin find.bin du.bin more.bin grep.bin unique.bin net.bin ping.bin nzip.bin mkfs.bin \
            terminal.bin boot.uni; do
    [ -s "$SYSTEM_PAYLOAD/$base" ] || {
        echo "build_install_image: required B: core file missing: $base" >&2
        exit 1
    }
done

# Accurate B: rescue manifest.
{
    echo "JTMOS system/rescue payload"
    echo "==========================="
    echo "Core files retained: $KEPT_COUNT"
    echo
    (cd "$SYSTEM_PAYLOAD" && find . -maxdepth 1 -type f -printf '%f\n' | LC_ALL=C sort)
} > "$SYSTEM_PAYLOAD/UTILS-MANIFEST.txt"

cd "$TOOLS"


# Full CD-ROM payload: the outer archive contains ONLY package archives.
rm -rf "$BOOTSTRAP"
mkdir -p "$BOOTSTRAP"
for f in "$PAYLOAD"/*.sqa; do
    [ -s "$f" ] || continue
    cp "$f" "$BOOTSTRAP/$(basename "$f")"
done
EXPECTED_PACKAGES="core.sqa graos.sqa interpreters.sqa demos.sqa media.sqa network.sqa tests.sqa docs.sqa boot.sqa"
for pkg in $EXPECTED_PACKAGES; do
    [ -s "$BOOTSTRAP/$pkg" ] || { echo "build_install_image: missing outer package $pkg" >&2; exit 1; }
done
# Enforce exact outer surface: every member is *.sqa.
if find "$BOOTSTRAP" -maxdepth 1 -type f ! -name '*.sqa' | grep -q .; then
    echo "build_install_image: outer utilities staging contains non-SQA member" >&2
    exit 1
fi
JTMOSDIR="$ROOT" ./sqarc extended_bootstrap utilities.sqa
for pkg in $EXPECTED_PACKAGES; do
    ./sqarc --has-member utilities.sqa "$pkg" || { echo "build_install_image: utilities.sqa missing $pkg" >&2; exit 1; }
done

# Reduced system payload -> system-install.img.nz -> utilsdisk.img.  The inner
# compressed archive is still named install.img.nz inside the SQA bootstrap so
# the existing unz command needs no special case.
JTMOSDIR="$ROOT" ./sqarc system_payload system-install.img
SYSTEM_INSTALL_BYTES=$(wc -c < system-install.img)
./nzip --auto system-install.img
[ -s system-install.img.nz ] || { echo "build_install_image: nzip did not create system-install.img.nz" >&2; exit 1; }

cp "$APPS/unz.bin" "$SYSTEM_BOOTSTRAP/unz.bin"
cp "$APPS/sqa.bin" "$SYSTEM_BOOTSTRAP/sqa.bin"
cp system-install.img.nz "$SYSTEM_BOOTSTRAP/install.img.nz"
cat > "$SYSTEM_BOOTSTRAP/README.txt" <<'TXT'
JTMOS V67.8 system utilities (sys:)
===================================
This compact package is the payload for the separate 1.44 MiB B: root floppy.
It contains boot/recovery/install tools and the core CLI/terminal set.
GraOS desktop applications and other non-rescue programs live on utilities.iso
so the fixed 1.44 MiB B: root medium keeps deterministic recovery headroom.
TXT
JTMOSDIR="$ROOT" ./sqarc system_bootstrap utilsdisk.img

SYS_UTIL_BYTES=$(wc -c < utilsdisk.img)
EXT_UTIL_BYTES=$(wc -c < utilities.sqa)
DOSBOOT_UTILS_MAX_BYTES=$((32 * 1024 * 1024))
if [ "$EXT_UTIL_BYTES" -gt "$DOSBOOT_UTILS_MAX_BYTES" ]; then
    echo "build_install_image: utilities.sqa exceeds DOSBOOT 32 MiB RAM-bank limit ($EXT_UTIL_BYTES bytes)" >&2
    exit 1
fi
SYSTEM_NZ_BYTES=$(wc -c < system-install.img.nz)

SYSTEM_ROOT_MAX_BYTES=$((1440 * 1024))
if [ "$SYS_UTIL_BYTES" -gt "$SYSTEM_ROOT_MAX_BYTES" ]; then
    SYSTEM_OVER_BYTES=$((SYS_UTIL_BYTES - SYSTEM_ROOT_MAX_BYTES))
    echo "build_install_image: system utilsdisk.img exceeds 1.44 MiB B: root medium ($SYS_UTIL_BYTES bytes; over by $SYSTEM_OVER_BYTES bytes)" >&2
    echo "build_install_image: largest files in compact B: payload:" >&2
    for f in "$SYSTEM_PAYLOAD"/*; do
        [ -f "$f" ] || continue
        bytes=$(wc -c < "$f" | tr -d ' ')
        printf '%10s  %s\n' "$bytes" "$(basename "$f")"
    done | LC_ALL=C sort -nr | head -12 >&2
    echo "build_install_image: keep non-rescue commands on utilities.iso instead of enlarging the 1.44 MiB root medium" >&2
    exit 1
fi

printf 'application binaries:      %s\n' "$APP_COUNT"
printf 'GraOS runtime files:        %s\n' "$GUI_COUNT"
printf 'External GraOS apps:        %s\n' "$EXTGUI_COUNT"
printf 'External GraOS resources:   %s\n' "$EXTGUI_RES_COUNT"
printf 'extended-only moved files:  %s\n' "$MOVED_COUNT"
printf 'system install SQA expanded:%s bytes\n' "$SYSTEM_INSTALL_BYTES"
printf 'system install.img.nz:      %s bytes\n' "$SYSTEM_NZ_BYTES"
printf 'tools/utilsdisk.img:        %s bytes (1.44 MiB B: root limit)\n' "$SYS_UTIL_BYTES"
printf 'tools/utilities.sqa:        %s bytes (CD-ROM payload; DOSBOOT max 32 MiB)\n' "$EXT_UTIL_BYTES"
