#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_boot32pm_handoff_trace: FAIL: $*" >&2; exit 1; }
B=boot32pm/boot.asm
Q=run_jtmos_qemu.sh
L=run_jtmos_qemu_linode.sh

grep -Fq '%if BOOT_VESA_GRAPHICS' "$B" || fail "headless typematic guard missing"
grep -Fq 'puts str_stream_prepm' "$B" || fail "final real-mode PM breadcrumb missing"
grep -Fq 'PM32 entry OK' "$B" || fail "PM entry breadcrumb missing"
grep -Fq 'PM32 NZIP2 decoding...' "$B" || fail "NZIP2 start breadcrumb missing"
grep -Fq 'PM32 NZIP2 decode + checksum OK' "$B" || fail "NZIP2 success breadcrumb missing"
grep -Fq 'PM32 jumping to kernel @ 00100000' "$B" || fail "kernel jump breadcrumb missing"
grep -Fq 'PM32 NZIP2 FAILED code=' "$B" || fail "NZIP2 failure breadcrumb missing"
grep -Fq 'out 0xE9,al' "$B" || fail "QEMU debugcon output missing"
grep -Fq 'BOOT_DEBUG_LOG=${JTMOS_BOOT_DEBUG_LOG:-off}' "$Q" || fail "generic QEMU debugcon option missing"
grep -Fq -- '-debugcon "file:$BOOT_DEBUG_LOG"' "$Q" || fail "QEMU -debugcon wiring missing"
grep -Fq 'JTMOS_BOOT_DEBUG_LOG=${JTMOS_BOOT_DEBUG_LOG:-$DIR/boot32pm_debug.log}' "$L" || fail "Linode debugcon log default missing"
sh -n "$Q"
sh -n "$L"
echo 'check_boot32pm_handoff_trace: PASS (headless typematic skip + VGA/0xE9 PM/NZIP2/final-jump breadcrumbs)'
