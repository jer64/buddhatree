#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.213 ramdisk/bootstrap-space: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.213|68.214|68.215|68.216|68.217|68.218|68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*|7[0-9].*) ;; *) fail "VERSION mismatch" ;; esac
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header mismatch"
K="$ROOT/kernel32/init/keropt.c"
R="$ROOT/kernel32/drivers/ramdisk/ramdisk.c"
S="$ROOT/kernel32/sh/sh.c"
grep -Eq 'RD_DEFAULT_SIZE=[[:space:]]*131072' "$K" || fail "64 MiB target missing"
grep -Fq 'reserve = 32UL * 1024UL * 1024UL;' "$R" || fail "32 MiB reserve missing"
grep -Fq 'blocks<=8192UL' "$R" || fail "allocation fallback floor missing"
SQ="$ROOT/kernel32/sh/sqa.c"
! grep -Fq '"unz",' "$S" || fail "autostart still invokes separate unz step"
grep -Fq 'sqa_has_suffix(fname,"/utils.iso")' "$SQ" || fail "SQA staged utils.iso reclaim missing"
grep -Fq 'sqa_expand_compressed_image' "$SQ" || fail "built-in NZIP/image expansion missing"
grep -Fq '(void)remove(nz_path);' "$SQ" || fail "compressed temporary reclaim missing"
grep -Fq '(void)remove(img_path);' "$SQ" || fail "decoded image reclaim missing"
echo "V68.213 ramdisk/bootstrap-space regression: PASS"
