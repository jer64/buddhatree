#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.61 utilscdrom/dirrename: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

M="$ROOT/Makefile"
PUB="$ROOT/tools/publish_utilities_iso.sh"
J="$ROOT/kernel32/fs/jtmfs/jtmfs.c"
A="$ROOT/kernel32/fs/jtmfs/jtmfsAccess.c"

has 'utilscdrom: host-tools' "$M" 'utilscdrom standalone publisher target missing'
has '$(MAKE) publish-utilities-iso' "$M" 'utilscdrom/utilities.iso do not invoke publisher'
has 'tools/sqarc --has-member tools/utilities.sqa core.sqa' "$M" 'utilscdrom does not validate core.sqa'
has 'tools/sqarc --has-member tools/utilities.sqa graos.sqa' "$M" 'utilscdrom does not validate graos.sqa'
has '$(MAKE) utilities.iso' "$M" 'utilscdrom lacks fresh-build fallback'
has 'publish-utilities-iso:' "$M" 'publisher target missing'
[ -f "$PUB" ] || fail 'publish_utilities_iso.sh missing'
has 'utilities.sqa' "$PUB" 'publisher does not consume tools/utilities.sqa'
has 'EXPECTED_PACKAGES=' "$PUB" 'publisher package set missing'
has '--list' "$PUB" 'publisher does not enforce SQA-only outer media'
has '2048' "$PUB" 'publisher does not ATAPI-pad image'
has 'mv "$TMP" "$OUT"' "$PUB" 'publisher does not atomically publish root utilities.iso'
has 'kernel32/utilities.iso' "$PUB" 'publisher mirror missing'

# Exercise the publisher itself without needing a full JTMOS build. A fake
# sqarc accepts the archive; the helper must pad 3001 bytes to 4096 and mirror it.
TMPROOT=$(mktemp -d)
trap 'rm -rf "$TMPROOT"' EXIT HUP INT TERM
mkdir -p "$TMPROOT/tools" "$TMPROOT/kernel32"
cp "$PUB" "$TMPROOT/tools/publish_utilities_iso.sh"
printf '#!/bin/sh\nexit 0\n' > "$TMPROOT/tools/sqarc"
chmod +x "$TMPROOT/tools/sqarc" "$TMPROOT/tools/publish_utilities_iso.sh"
dd if=/dev/zero of="$TMPROOT/tools/utilities.sqa" bs=3001 count=1 2>/dev/null
"$TMPROOT/tools/publish_utilities_iso.sh" >/dev/null
[ -s "$TMPROOT/utilities.iso" ] || fail 'publisher test did not create root utilities.iso'
[ -s "$TMPROOT/kernel32/utilities.iso" ] || fail 'publisher test did not create kernel mirror'
SZ=$(wc -c < "$TMPROOT/utilities.iso")
[ $((SZ % 2048)) -eq 0 ] || fail 'published image is not 2048-byte aligned'
cmp "$TMPROOT/utilities.iso" "$TMPROOT/kernel32/utilities.iso" >/dev/null || fail 'kernel mirror differs from root image'

# Directory rename must update both name locations. The public wrapper owns the
# mutation lock and namespace-generation bump; the low-level rename owns both
# metadata writes and rollback.
has 'is_directory=JTMFS_TYPE_IS_DIRECTORY(dw.fe->type)' "$J" 'rename does not detect directories'
has 'dirdb_ffinddirname(device_nr,NULL,child_db,&child_name)' "$J" 'rename does not locate internal DIRNAME header'
has 'strcpy(child_name.fe->name,NewName)' "$J" 'rename does not update internal directory name'
has 'JTMFS_DIRENT_METADATA_ONLY' "$J" 'internal DIRNAME write does not use metadata-only path'
has '*dw.fe=parent_before' "$J" 'rename lacks parent rollback'
has '*child_name.fe=child_before' "$J" 'rename lacks child-header rollback'
has 'jtmfs_mutation_lock(old_dnr)' "$A" 'public rename lost mutation locking'
has 'FileDirNamespaceChanged()' "$A" 'successful rename no longer invalidates canonical path cache'

echo 'V69.61 utilscdrom + directory rename: PASS'
