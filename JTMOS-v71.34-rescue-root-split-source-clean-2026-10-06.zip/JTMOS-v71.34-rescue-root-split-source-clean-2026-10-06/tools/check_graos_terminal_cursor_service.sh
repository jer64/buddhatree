#!/bin/sh
set -eu
fail(){ echo "check_graos_terminal_cursor_service: FAIL: $*" >&2; exit 1; }
for p in kernel32/core/int/scs.c; do
  grep -q 'type=GetThreadType(caller)' "$p" || fail "$p does not inspect caller capability"
  grep -q 'type&THREAD_TYPE_SERVICE' "$p" || fail "$p does not allow trusted GraOS service cursor reads"
  grep -q 'ter!=GetInputTerminal()' "$p" || fail "$p lost ordinary terminal focus restriction"
  grep -q '!screens\[ter\]\.updcur' "$p" || fail "$p ignores cursor visibility state"
done
grep -q 'GetCursorLocation(w->terminal_id)' libc/apps/gui/windowDraw.c || fail "GraOS terminal renderer does not fetch cursor metadata"
grep -q 'terminal_cursor_visible' libc/apps/gui/windowDraw.c || fail "GraOS terminal cursor blink/render policy missing"
echo "check_graos_terminal_cursor_service: PASS (SERVICE compositor may render dynamic VT cursor)"
