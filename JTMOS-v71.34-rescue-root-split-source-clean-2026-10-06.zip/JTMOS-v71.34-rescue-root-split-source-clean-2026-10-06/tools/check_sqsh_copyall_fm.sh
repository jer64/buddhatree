#!/bin/sh
set -eu
fail(){ echo "check_sqsh_copyall_fm: FAIL: $*" >&2; exit 1; }
SQSH=libc/apps/sqsh.c

grep -Fq 'if(!strcmp(sqsh.cmdpar[0],"copyall"))' "$SQSH" || fail "copyall is not dispatched as an SQSH builtin"
grep -Fq '(void)sqsh_run_smsh_builtin(s);' "$SQSH" || fail "SQSH copyall does not use the restricted SMSH bridge"
grep -Fq 'sqsh_copyall_target_placeholder()' "$SQSH" || fail "copyall namespace-placeholder guard missing"
grep -Fq 'refusing namespace placeholder target' "$SQSH" || fail "copyall placeholder diagnostic missing"
grep -Fq 'getdevicenrbyname(childdev)<0' "$SQSH" || fail "copyall placeholder detection does not validate the nested device name"
if grep -Fq 'static int sqsh_copyall_copy_verify' "$SQSH"; then
    fail "stale userspace stdio copyall implementation remains"
fi
grep -Fq '"copyall [-r] SOURCE_PATH"' "$SQSH" || fail "help lacks recursive copyall syntax"
grep -Fq 'copyall -r ram:/etc  recursively copy+verify files and subdirectories' "$SQSH" || fail "getting-started help lacks recursive copyall"
grep -Fq 'File tools include: fm FILE, copyall [-r] SOURCE_PATH' "$SQSH" || fail "--help page lacks recursive copyall documentation"

grep -Fq '"nutget","copyall"' kernel32/sh/sh.c || fail "kernel restricted SMSH whitelist does not export copyall"
grep -Fq 'jtmfs_SetSize(target_dnr, name, 0, target_db)' kernel32/sh/copyall.c || fail "SMSH copyall does not explicitly truncate targets"
grep -Fq 'jtmfs_SetSizeAfterWrite(target_dnr, entry->name, entry->size, target_db)' kernel32/sh/copyall.c || fail "SMSH copyall does not set final target size"
grep -Fq 'actual_size=jtmfs_GetFileSize(target_dnr, entry->name, target_db);' kernel32/sh/copyall.c || fail "SMSH copyall final-size readback missing"
grep -Fq 'expected=%d actual=%d' kernel32/sh/copyall.c || fail "copyall size mismatch lacks expected/actual diagnostics"
grep -Fq 'CONTENT EXACT for %d bytes' kernel32/sh/copyall.c || fail "copyall does not distinguish exact payload from logical-size mismatch"
grep -Fq 'copyall_tree(' kernel32/sh/copyall.c || fail "recursive copy engine missing"
grep -Fq 'copyall_prepare_target_dir' kernel32/sh/copyall.c || fail "recursive target-directory creation missing"
grep -Fq 'copyall_db_is_inside' kernel32/sh/copyall.c || fail "recursive self-copy ancestry guard missing"
grep -Fq 'COPYALL_MAX_DEPTH   64' kernel32/sh/copyall.c || fail "recursive depth guard missing"
grep -Fq '!strcmp(argv[1],"-r")' kernel32/sh/copyall.c || fail "-r parser missing"

grep -Fq 'static int sqsh_fm(int argc, char **argv)' "$SQSH" || fail "SQSH fm implementation missing"
grep -Fq 'SQSH_FM_PAGE_LINES 22U' "$SQSH" || fail "fm paging constant missing"
grep -Fq 'Press any key, ESC/Ctrl+C to stop' "$SQSH" || fail "fm paging/abort prompt missing"
grep -Fq 'if(key==27 || key==3) break;' "$SQSH" || fail "fm ESC/Ctrl+C abort missing"
grep -Fq 'Paged 16-byte-per-line hex/ASCII file monitor' "$SQSH" || fail "help does not describe fm as a hexdump/file monitor"
if grep -Fq 'Display file metadata known to SQSH/JTMFS.' "$SQSH"; then
    fail "stale fm metadata help text remains"
fi

echo "check_sqsh_copyall_fm: PASS (shared SMSH/SQSH copyall + recursive -r + DNR/DB safety + fm help)"
