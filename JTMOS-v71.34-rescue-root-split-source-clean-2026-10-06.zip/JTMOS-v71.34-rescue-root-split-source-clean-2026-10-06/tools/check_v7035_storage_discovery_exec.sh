#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$(cat "$ROOT/VERSION")" = "70.35" ] || { echo "V70.35: bad VERSION" >&2; exit 1; }
python3 "$ROOT/tests/v7035_storage_discovery_exec.py"
echo "V70.35 storage-discovery exec regression: PASS"
