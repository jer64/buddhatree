#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 "$ROOT/tests/ring3_api_v697.py"
make -s -C "$ROOT/libc/libc" syntax
for app in cp mv sqsh bwbasic filer; do
    make -s -C "$ROOT/libc/apps" -f "$app.mak" syntax
done
echo "V69.7 mediated Ring3 API regression: PASS"
