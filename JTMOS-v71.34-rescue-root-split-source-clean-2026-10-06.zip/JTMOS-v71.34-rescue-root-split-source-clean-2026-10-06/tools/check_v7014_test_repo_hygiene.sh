#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fail(){ echo "V70.14 test/repo hygiene: FAIL: $*" >&2; exit 1; }

[ -d "$ROOT/docs/changelog" ] || fail "docs/changelog missing"
[ -f "$ROOT/docs/changelog/README.md" ] || fail "changelog index missing"
[ -f "$ROOT/docs/changelog/V68.138_PID0_DRIVER_LOCK_FIX.md" ] || fail "representative V68 changelog was not migrated"
[ -f "$ROOT/docs/changelog/V68.8.57.10.18.16.51_TCPIP_DHCP_PING_HTTP_AUTOSTART.txt" ] || fail "representative TCP/IP changelog was not migrated"
[ ! -e "$ROOT/V68.138_PID0_DRIVER_LOCK_FIX.md" ] || fail "V68 fix note still clutters repository root"
[ ! -e "$ROOT/V68.8.57.10.18.16.51_TCPIP_DHCP_PING_HTTP_AUTOSTART.txt" ] || fail "TCP/IP fix note still clutters repository root"
[ -f "$ROOT/VERSIONING.md" ] || fail "active VERSIONING.md must remain at root"

# No historical V<digit>/JTMOS-V<digit> fix/validation note should remain at root.
left=$(find "$ROOT" -maxdepth 1 -type f \( \
    -name 'V[0-9]*.md' -o -name 'V[0-9]*.txt' -o \
    -name 'JTMOS-V[0-9]*.md' -o -name 'JTMOS-V[0-9]*.txt' -o \
    -name 'JTMOS-v[0-9]*-validation*.txt' \
\) -print)
[ -z "$left" ] || { printf '%s\n' "$left" >&2; fail "historical version documents remain at root"; }

# Active release metadata stays root-resident by design.
[ -f "$ROOT/VERSION" ] || fail "VERSION missing"
[ -f "$ROOT/RELEASE-V$(cat "$ROOT/VERSION").txt" ] || fail "active RELEASE note missing from root"

# The extended app test must exercise the new core contract suite.
grep -Fq '"$HERE/tests/test_core_contracts.sh"' "$ROOT/libc/libc/tests/test_apps.sh" || fail "test_apps.sh does not run core contracts"
[ -x "$ROOT/libc/libc/tests/test_core_contracts.sh" ] || fail "core contract runner missing/not executable"
[ -x "$ROOT/tests/v7014_core_regressions.py" ] || fail "core regression model missing/not executable"
[ -f "$ROOT/libc/libc/include/jtmos/jtmos_signal.h" ] || fail "canonical jtmos_signal.h compatibility header missing"

"$ROOT/libc/libc/tests/test_core_contracts.sh"
echo "V70.14 test/repo hygiene: PASS"
