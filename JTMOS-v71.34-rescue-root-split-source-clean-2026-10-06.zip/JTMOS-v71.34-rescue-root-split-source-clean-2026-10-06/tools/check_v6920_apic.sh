#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
APIC="$ROOT/kernel32/core/int/apic.c"
APICH="$ROOT/kernel32/core/int/apic.h"
INT="$ROOT/kernel32/core/int/int.c"
PIT="$ROOT/kernel32/core/int/pit.c"
TIMERMAC="$ROOT/kernel32/core/int/timerhandler.mac"
INIT="$ROOT/kernel32/init/initsystem.c"
SHC="$ROOT/kernel32/sh/sh.c"
REL="$ROOT/kernel32/include/jtmos_release.h"

fail(){ echo "V69.20 APIC: FAIL: $*" >&2; exit 1; }
if [ "${JTMOS_APIC_FEATURE_ONLY:-0}" = 1 ]; then
    : # Later releases retain the V69.20 feature gates without its metadata pin.
else
    [ "$(cat "$ROOT/VERSION")" = "69.20" ] || fail "VERSION is not 69.20"
    grep -Fq 'JTMOS_SOURCE_RELEASE "V69.20"' "$REL" || fail "release header is not V69.20"
fi
[ -s "$APIC" ] && [ -s "$APICH" ] || fail "APIC source/header missing"
grep -Fq 'find_madt_in_root' "$APIC" || fail "ACPI root-table parser missing"
grep -Fq '"XSDT"' "$APIC" || fail "XSDT support missing"
grep -Fq '"RSDT"' "$APIC" || fail "RSDT support missing"
grep -Fq 'ACPI_MADT_ISO' "$APIC" || fail "MADT interrupt-source override support missing"
grep -Fq 'APIC_BASE_X2APIC' "$APIC" || fail "x2APIC detection guard missing"
grep -Fq 'low=(DWORD)(M_VEC+irq)' "$APIC" || fail "legacy vector compatibility routing missing"
grep -Fq 'if(apic_active()) return apic_legacy_irr();' "$INT" || fail "IRR is not controller-neutral"
grep -Fq 'if(apic_active()) return apic_legacy_isr();' "$INT" || fail "ISR is not controller-neutral"
grep -Fq 'if(apic_active())' "$INT" || fail "IRQ controller dispatch missing"
grep -Fq 'apic_send_eoi();' "$INT" || fail "LAPIC EOI dispatch missing"
grep -Fq 'call pic_send_eoi' "$TIMERMAC" || fail "timer macro still bypasses controller-neutral EOI"
grep -Fq '"call pic_send_eoi' "$PIT" || fail "storage-safe PIT ISR still bypasses controller-neutral EOI"
! grep -Eq '"mov \$0x20, %dx|"out %al, %dx' "$PIT" || fail "direct PIC EOI remains in PIT ISR"
grep -Fq 'InitAPIC()' "$INIT" || fail "boot does not initialize APIC backend"
grep -Fq '{"apic", apic_builtin}' "$SHC" || fail "SMSH APIC diagnostic missing"
grep -Fq 'pic_read_irr()' "$PIT" || fail "Advanced PIT rollover IRR check missing"
python3 "$ROOT/tests/advanced_pit_model.py"
echo 'V69.20 APIC feature regression: PASS'
