#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
v="$ROOT/kernel32/init/vesa.c"
h="$ROOT/kernel32/init/vesa.h"
g="$ROOT/libc/apps/gui/guiStart.c"
u="$ROOT/libc/apps/gui/guiUpdate.c"
grep -q 'vesa_boot_hourglass_enabled' "$v"
grep -q 'vesa_boot_hourglass_draw' "$v"
grep -q 'vesa_boot_hourglass_pulse' "$v"
grep -q 'VesaBootHourglassStop();' "$v"
grep -q 'VesaBootHourglassStop' "$h"
grep -q 'VESA_HOURGLASS_W' "$v"
grep -q 'vesa_boot_hourglass_restore_background' "$v"
# Transparent overlay: the old opaque panel must not come back.
! grep -q 'VESA_HOURGLASS_PANEL_W' "$v"
! grep -q 'compact Win9x-style busy plaque' "$v"
# GraOS starts graphics through the syscall that reaches VesaStartGraOSGraphics().
grep -q 'guiAcquireDisplay("startup")' "$g"
grep -q 'SYS_graosgraphics' "$u"
# The overlay must be activity-driven and never require a boot-time thread/timer.
! grep -q 'CreateThread.*hourglass\|StartThread.*hourglass' "$v"
echo 'VESA boot hourglass: PASS'
