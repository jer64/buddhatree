#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

need() {
    file=$1
    pattern=$2
    if ! grep -Fq "$pattern" "$file"; then
        echo "check_native_ai: missing '$pattern' in $file" >&2
        exit 1
    fi
}

need kernel32/ai/ai_native.h '#define AI_NATIVE_VERSION 2'
need kernel32/ai/ai_native.h 'int AINativeDiagnose(AI_NATIVE_RESULT *out,int requested_domain);'
need kernel32/ai/ai_native.h 'int AINativeHealthScan(AI_NATIVE_HEALTH *out);'
need kernel32/ai/ai_native.c 'DiskSpaceGetStats'
need kernel32/ai/ai_native.c 'DiskSpacePercentUnits'
need kernel32/ai/ai_native.c 'DiskSpaceUnitsToKiB'
need kernel32/ai/ai_native.c 'mm_get_memory_stats'
need kernel32/ai/ai_native.c 'jnet_get_config'
need kernel32/ai/ai_native.c 'jnet_get_stats'
need kernel32/ai/ai_native.c 'GetRunningThreadsCount'
need kernel32/ai/ai_native.c 'SchedulerGetCpuStats'
need kernel32/ai/ai_native.c 'NmiGetStats'
need kernel32/ai/ai_native.c 'rescue_pending'
need kernel32/ai/ai_native.c 'strstr(q,"verkko")'
need kernel32/sh/aiapp.c 'JTMOS Native AI v%d'
need kernel32/sh/aiapp.c 'Recommended action:'
need kernel32/sh/sh.c '{"ai", ai_native_app}'
need kernel32/sh/sh.c '{"doctor", ai_native_app}'
need kernel32/sh/sh.c '"ai","doctor","health","set","setglobal","path"'
need kernel32/sh/sh.c '"fsck","diskspace","ai","doctor","health","keymap"'
need kernel32/sh/helpapp.c 'ai [diagnose|health|QUESTION...]'
need kernel32/drivers/tcpip/jnet.h 'void jnet_get_config(JNET_CONFIG *out);'
need kernel32/drivers/tcpip/jnet.c 'memcpy(out,&cfg,sizeof(*out))'
need kernel32/fs/jtmfs/diskspace.h 'DWORD DiskSpacePercentUnits(DWORD free_units,DWORD total_units);'
need kernel32/fs/jtmfs/diskspace.h 'DWORD DiskSpaceUnitsToKiB(DWORD units,DWORD unit_size);'

# The freestanding i486 kernel does not link libgcc.  Native AI and the
# diskspace paths it consumes must not use runtime 64-bit division.
if grep -Eq 'unsigned long long.*[/]|ULL[[:space:]]*/|/[[:space:]]*\(unsigned long long\)' \
    kernel32/ai/ai_native.c kernel32/fs/jtmfs/diskspace.c kernel32/sh/fsadmin.c; then
    echo "check_native_ai: runtime 64-bit division reintroduced into AI/diskspace path" >&2
    exit 1
fi

echo "check_native_ai: PASS"
