#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.205 locktop: FAIL: $*" >&2; exit 1; }
VERSION=$(cat "$ROOT/VERSION")
grep -Fq "#define JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" || fail "release header/version mismatch"
grep -Fq '{"locktop", locktop_app}' "$ROOT/kernel32/sh/sh.c" || fail "SMSH command missing"
grep -Fq 'int JtmosLockSnapshot' "$ROOT/kernel32/core/int/lock.c" || fail "core snapshot missing"
grep -Fq 'function_trace_add_locked(state);' "$ROOT/kernel32/core/int/lock.c" || fail "function lock registration missing"
grep -Fq 'function_trace_remove_locked(state);' "$ROOT/kernel32/core/int/lock.c" || fail "function lock removal missing"
grep -Fq 'int driver_lock_snapshot' "$ROOT/kernel32/drivers/driver_lock.c" || fail "driver snapshot missing"
grep -Fq 'STUCK?' "$ROOT/kernel32/sh/locktop.c" || fail "hold-time diagnosis missing"
grep -Fq 'ConsumeTerminalInterrupt' "$ROOT/kernel32/sh/locktop.c" || fail "Ctrl+C handling missing"
grep -Fq 'claim_scratch()' "$ROOT/kernel32/sh/locktop.c" || fail "scratch concurrency guard missing"
grep -Fq 'digit>5UL' "$ROOT/kernel32/sh/locktop.c" || fail "uint overflow guard missing"

echo "V68.205 locktop regression: PASS"
