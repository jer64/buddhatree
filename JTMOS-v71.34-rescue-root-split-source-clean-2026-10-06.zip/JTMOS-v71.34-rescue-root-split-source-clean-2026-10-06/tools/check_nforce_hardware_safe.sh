#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
NF="$ROOT/kernel32/drivers/tcpip/nforce.c"
fail(){ echo "check_nforce_hardware_safe: FAIL: $*" >&2; exit 1; }

grep -Fq '#define RX_RING 128' "$NF" || fail "MCP61 RX ring below forcedeth minimum"
grep -Fq '#define TX_RING 64' "$NF" || fail "MCP61 TX ring below forcedeth minimum"
grep -Fq '#define DMA_BYTES (512*1024)' "$NF" || fail "DMA arena not enlarged for hardware-safe rings"
grep -Fq 'wr(R_TXPAUSE,TXPAUSE_DISABLE);' "$NF" || fail "warm-reboot TX pause freeze workaround missing"
grep -Fq 'wait_set_bounded(R_UNK5,UNK5_READY' "$NF" || fail "forcedeth SetupReg5 readiness handshake missing"
grep -Fq 'wait_clear(R_RXSTAT,RXSTAT_BUSY,500)' "$NF" || fail "restart does not wait boundedly for RX idle"
grep -Fq 'wait_clear(R_TXSTAT,TXSTAT_BUSY,500)' "$NF" || fail "restart does not wait boundedly for TX idle"
grep -Fq 'guard>=500000UL' "$NF" || fail "MII/MMIO wait has no independent finite guard"
grep -Fq 'for(scan=0;scan<TX_RING;scan++)' "$NF" || fail "TX does not scan for a returned descriptor"
grep -Fq 'if(!d)' "$NF" || fail "full TX ring does not fail fast"
! grep -Fq 'TXRX_KICK|TXRX_BIT2' "$NF" || fail "ordinary TX kick contains reset BIT2"
grep -Fq 'program_link_mode(speed,duplex);' "$NF" || fail "negotiated MAC mode is not programmed"
grep -Fq 'wr(R_PHYIF,phyif);' "$NF" || fail "PHY interface speed/duplex bits are not programmed"
grep -Fq 'if(tx_running)' "$NF" || fail "TX engine is not quiesced for link-mode changes"
grep -Fq 'if(rx_running)' "$NF" || fail "RX engine is not quiesced for link-mode changes"
grep -Fq 'for(link_tries=0;link_tries<50' "$NF" || fail "initial carrier wait lacks an independent bound"

# A TX completion wait in nforce_send is forbidden: physical MCP61 hardware may
# withhold completion, and the Ethernet owner must never block the whole kernel.
SEND=$(awk '/^int nforce_send\(/{infn=1} infn{print} infn && /^}/{exit}' "$NF")
printf '%s\n' "$SEND" | grep -Eq 'while[[:space:]]*\([^)]*TX_VALID' && \
    fail "synchronous TX_VALID completion loop reintroduced"
printf '%s\n' "$SEND" | grep -Fq 'SwitchToThread()' && \
    fail "TX submission yields while holding Ethernet owner lock"

echo "check_nforce_hardware_safe: PASS (safe kicks + negotiated RGMII mode + 128/64 rings + bounded waits)"
