#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_headless_telnetd: FAIL: $*" >&2; exit 1; }
grep -q '^%define BOOT_VESA_GRAPHICS 1' boot32pm/boot.asm || fail "boot32pm physical default is not VESA"
grep -q 'VESA ?= 1' boot32pm/Makefile || fail "boot32pm VESA default missing"
grep -Fq '$(MAKE) BOOT_DISPLAY=text image' Makefile || fail "explicit image-headless/text path missing"
grep -Fq 'BOOT_VESA := 0' Makefile || fail "BOOT_DISPLAY=text no longer maps to VESA=0"
grep -q '#define JT_HTTP_DEFAULT_PORT 8080' kernel32/drivers/tcpip/jt_httpd.c || fail "HTTP default is not 8080"
grep -q 'JtTelnetdAppCall' kernel32/drivers/tcpip/uip_appcall.c || fail "uIP telnet dispatcher missing"
grep -q 'TELNETD_PASSWORD' kernel32/drivers/tcpip/jt_telnetd.c || fail "telnet password gate missing"
grep -q '#define JT_TELNET_MAX_SESSIONS 2' kernel32/drivers/tcpip/jt_telnetd.c || fail "telnet session limit missing"
grep -q 'centralprocess_exec("sqsh.bin"' kernel32/drivers/tcpip/jt_telnetd.c || fail "telnetd does not launch sqsh.bin"
grep -q '"telnetd", telnetd_app' kernel32/sh/sh.c || fail "SMSH telnetd command missing"
! grep -A10 'static const char \*steps\[\]' kernel32/sh/sh.c | grep -q '"graos"' || fail "GraOS still autostarts"
echo 'check_headless_telnetd: PASS (explicit curses/headless profile + HTTP/8080 + authenticated SQSH telnetd)'
