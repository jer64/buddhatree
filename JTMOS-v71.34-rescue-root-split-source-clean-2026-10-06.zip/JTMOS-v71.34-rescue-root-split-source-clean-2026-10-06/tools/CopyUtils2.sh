#!/bin/bash

STAGE=$(mktemp -d "${TMPDIR:-/tmp}/jtmos-stage.XXXXXX")
trap 'rm -rf "$STAGE"' EXIT HUP INT TERM

# Make LIBC
cd ../libc/libc
make
cd ../../tools

# Make disk specific tools
cd ../libc/apps

# Applications
make clean
make

# Brandy
#cd brandy/src
#make
#cd ../..

# BWBASIC
cd bwbasic
make
cd ..

cd ../../tools

# Clean up our temp dir
rm -f "$STAGE"/*
# Copy the binaries into the temp dir
#cp ../libc/apps/brandy/src/*.bin "$STAGE"
#cp ../libc/apps/bwbasic/*.bin "$STAGE"
cp ../libc/apps/sqa.bin "$STAGE"/
cp ../libc/apps/sqsh.bin "$STAGE"/
cp ../libc/apps/ls.bin "$STAGE"/
cp ../libc/apps/edit.bin "$STAGE"/
#cp ../libc/apps/*.raw "$STAGE"
#cp ../libc/apps/gui/*.bin "$STAGE"
#cp ../libc/apps/gui/*.raw "$STAGE"

# Make an archive disk image out of
# the directory's contents
./sqarc "$STAGE" > utilsdisk2.img

