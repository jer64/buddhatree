#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.64 CLI brand/POSIX: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq -- "$1" "$2" || fail "$3"; }
VERSION=$(cat "$ROOT/VERSION")
awk -v v="$VERSION" -v base="69.64" 'BEGIN{split(v,a,"."); split(base,b,"."); ok=(a[1]+0>b[1]+0)||((a[1]+0==b[1]+0)&&(a[2]+0>=b[2]+0)); exit ok?0:1}' \
    || fail "VERSION predates 69.64"
has "JTMOS_SOURCE_RELEASE \"V${VERSION}\"" "$ROOT/kernel32/include/jtmos_release.h" "release header mismatch"
has 'JTMOS_PUBLIC_VERSION ?=' "$ROOT/libc/apps/app-common.mk" "app version injection missing"
has '-DJTMOS_PUBLIC_VERSION=' "$ROOT/libc/apps/app-common.mk" "version compile definition missing"
H="$ROOT/libc/apps/cli_brand.h"
has '#define JTMOS_CLI_SUITE "JTMOS Utilities"' "$H" "suite brand missing"
has '"--version"' "$H" "--version contract missing"
has '"--info"' "$H" "--info contract missing"
has 'end option parsing' "$H" "POSIX -- documentation missing"
has 'return 2;' "$H" "usage-error status 2 helper missing"
for app in cat clear cp df du find free grep kill ls memconfig mkdir mkfs more mv net ping ps ren rm sqsh top; do
    f="$ROOT/libc/apps/$app.c"
    [ -f "$f" ] || fail "$app source missing"
    has '#include "cli_brand.h"' "$f" "$app is not using shared CLI branding"
done
has '"-p") || !strcmp(a,"--parents")' "$ROOT/libc/apps/mkdir.c" "mkdir -p/--parents missing"
has '!strcmp(a,"-s")' "$ROOT/libc/apps/kill.c" "kill -s SIGNAL missing"
has "if(a[j]=='f')" "$ROOT/libc/apps/rm.c" "grouped rm -f parsing missing"
has "else if(a[j]=='v')" "$ROOT/libc/apps/rm.c" "grouped rm -v parsing missing"
has '"--verbose"' "$ROOT/libc/apps/mv.c" "mv --verbose missing"
has '"--human-readable"' "$ROOT/libc/apps/df.c" "df --human-readable missing"
has 'jtmos_cli_is_version_arg(argv[1])' "$ROOT/libc/apps/sqsh.c" "SQSH --version/-V missing"
has 'jtmos_cli_is_info_arg(argv[1])' "$ROOT/libc/apps/sqsh.c" "SQSH --info missing"
echo 'V69.64 CLI brand/POSIX: PASS'
