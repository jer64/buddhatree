#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.180 boot init order regression: FAIL: $*" >&2; exit 1; }
[ -f "$ROOT/RELEASE-V68.180.txt" ] || fail "release note missing"
[ -f "$ROOT/docs/BOOT-INIT-DEPENDENCIES-V68.180.md" ] || fail "dependency document missing"

python3 - "$ROOT" <<'PY'
import pathlib, re, sys
root=pathlib.Path(sys.argv[1])
init=(root/'kernel32/init/init.c').read_text()
sys=(root/'kernel32/init/initsystem.c').read_text()

def body(text, name):
    m=re.search(r'\b(?:static\s+)?(?:void|int)\s+'+re.escape(name)+r'\s*\([^)]*\)\s*\{', text)
    if not m: raise SystemExit(f'missing function {name}')
    i=m.end(); depth=1
    while i < len(text) and depth:
        if text[i]=='{': depth+=1
        elif text[i]=='}': depth-=1
        i+=1
    return text[m.end():i-1]

def strip_comments(text):
    text=re.sub(r'/\*.*?\*/',' ',text,flags=re.S)
    text=re.sub(r'//.*',' ',text)
    return text

def ordered(text, names, label):
    text=strip_comments(text)
    pos=[]
    for n in names:
        p=text.find(n)
        if p<0: raise SystemExit(f'{label}: missing {n}')
        pos.append(p)
    if pos != sorted(pos):
        raise SystemExit(f'{label}: wrong order: {names}')

storage=body(init,'KernelInitStorageDevices')
ordered(storage,['ramdisk_init();','fdc_init();','hd_init();','atapi_init();',
                 'partition_table_support_init();','sysdev_init();'],'storage')
fs=body(init,'KernelInitFilesystemStack')
ordered(fs,['jtmfat_init();','dirdb_init();','jtmfs_init();'],'filesystem')
ks=body(init,'KernelInit')
ordered(ks,['PitStorageSafeBegin();','KernelInitStorageDevices();',
            'KernelInitFilesystemStack();','PitStorageSafeEnd();',
            'centralprocess_init();','systemStarted |= 1;','KernelInitLateServices();'],
        'KernelInit phases')
late=body(init,'KernelInitLateServices')
for n in ['initSystemLogging();','start_statusline();','audio_init();']:
    if n not in late: raise SystemExit(f'late services: missing {n}')
if 'JtInternetStart(' in late or 'StartSerialNetworkProcesses();' in late:
    raise SystemExit('network starts before the SMSH storage/bootstrap boundary')
# The filesystem writer thread must not be started from KernelInit outside the late helper.
if ks.count('initSystemLogging();'):
    raise SystemExit('KernelInit starts KLOGGER directly during critical boot')

isys=body(sys,'InitSystem')
ordered(isys,['InitKeyboard();','serial_init();','PitStorageSafeBegin();','pci_init();',
              'usb_input_init();','usb_input_transport_init();','ps2mouse_init();'],
        'InitSystem bus/input')
if 'audio_init();' in isys:
    raise SystemExit('audio still initialized in critical InitSystem phase')
print('V68.180 dependency ordering assertions: PASS')
PY

echo "V68.180 boot init order regression: PASS"
