#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V68.219 sync primitives: FAIL: $*" >&2; exit 1; }
case "$(cat "$ROOT/VERSION")" in 68.219|68.220|68.221|68.222|68.223|68.224|68.225|68.226|68.227|69.*) ;; *) fail "VERSION mismatch" ;; esac

test -s "$ROOT/kernel32/core/int/rwsem.c" || fail "rwsem.c missing"
test -s "$ROOT/kernel32/core/int/rwsem.h" || fail "rwsem.h missing"
test -s "$ROOT/kernel32/core/int/ksem.c" || fail "ksem.c missing"
test -s "$ROOT/kernel32/core/int/ksem.h" || fail "ksem.h missing"
test -s "$ROOT/kernel32/core/int/atomic.h" || fail "atomic.h missing"
test -s "$ROOT/kernel32/core/int/lockfree.c" || fail "lockfree.c missing"
test -s "$ROOT/kernel32/core/int/lockfree.h" || fail "lockfree.h missing"
test -s "$ROOT/kernel32/core/int/sync.c" || fail "sync.c missing"

RH="$ROOT/kernel32/core/int/rwsem.h"
RC="$ROOT/kernel32/core/int/rwsem.c"
SH="$ROOT/kernel32/core/int/ksem.h"
SC="$ROOT/kernel32/core/int/ksem.c"
AH="$ROOT/kernel32/core/int/atomic.h"
LF="$ROOT/kernel32/core/int/lockfree.c"
SYNC="$ROOT/kernel32/core/int/sync.c"
SCHED="$ROOT/kernel32/core/cp/scheduler.c"
SW="$ROOT/kernel32/core/int/threadSwitch.c"
TH="$ROOT/kernel32/core/int/threads.c"

grep -Fq 'DEFINE_RWSEM(lockname)' "$RH" || fail "DEFINE_RWSEM API missing"
grep -Fq 'rwsem_down_read_trylock' "$RH" || fail "rwsem read trylock missing"
grep -Fq 'rwsem_down_write_trylock' "$RH" || fail "rwsem write trylock missing"
grep -Fq 'waiting_writers' "$RH" || fail "rwsem writer accounting missing"
grep -Fq 'consecutive readers at the queue head' "$RC" || fail "rwsem reader batching rationale missing"
grep -Fq 'rwsem_thread_blocked[pid]=1' "$RC" || fail "rwsem scheduler blocking missing"
grep -Fq 'JtRwsemThreadCleanup' "$RC" || fail "rwsem lifecycle cleanup missing"

grep -Fq 'DEFINE_SEMAPHORE(semname,value)' "$SH" || fail "semaphore initializer missing"
grep -Fq 'semaphore_trywait' "$SH" || fail "semaphore trywait missing"
grep -Fq 'sem_thread_blocked[pid]=1' "$SC" || fail "semaphore scheduler blocking missing"
grep -Fq 'w=sem_pop_live_locked(sem)' "$SC" || fail "semaphore direct handoff missing"

grep -Fq 'lock; cmpxchgl' "$AH" || fail "atomic cmpxchg missing"
grep -Fq 'lock; xaddl' "$AH" || fail "atomic xadd missing"
grep -Fq 'atomic_ptr_xchg' "$AH" || fail "atomic pointer exchange missing"
grep -Fq 'lf_spsc_push' "$LF" || fail "SPSC queue missing"
grep -Fq 'lf_mpsc_push' "$LF" || fail "MPSC queue missing"
grep -Fq 'atomic_ptr_xchg' "$LF" || fail "MPSC is not using atomic exchange"
! grep -Fq 'disable();' "$LF" || fail "lock-free queue disables IRQs"
! grep -Fq 'SwitchToThread' "$LF" || fail "lock-free queue blocks/yields"

grep -Fq 'JtMutexThreadBlocked(pid)' "$SYNC" || fail "mutex missing from sync bridge"
grep -Fq 'JtRwsemThreadBlocked(pid)' "$SYNC" || fail "rwsem missing from sync bridge"
grep -Fq 'JtSemaphoreThreadBlocked(pid)' "$SYNC" || fail "semaphore missing from sync bridge"
grep -Fq 'JtSyncThreadBlocked' "$SCHED" || fail "scheduler does not filter sync waiters"
grep -Fq 'JtSyncThreadBlocked' "$SW" || fail "forced transfers do not filter sync waiters"
grep -Fq 'JtSyncThreadCleanup' "$TH" || fail "thread teardown does not clean sync waits/owners"

python3 "$ROOT/tests/sync_primitives_v68219.py"
echo "V68.219 sync primitives source regression: PASS"
