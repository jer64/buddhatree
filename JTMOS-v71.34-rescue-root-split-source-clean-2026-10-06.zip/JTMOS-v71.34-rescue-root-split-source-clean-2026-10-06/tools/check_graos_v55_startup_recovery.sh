#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "GraOS V55 startup recovery: FAIL: $*" >&2; exit 1; }
[ "$(cat VERSION)" = "69.12" ] || fail "VERSION mismatch"
grep -Fq '#define GRAOS_VERSION "V55"' libc/apps/gui/graos.h || fail "GraOS version mismatch"
grep -Fq 'GRAOS_DISPLAY_RETRY_COUNT 6' libc/apps/gui/guiUpdate.c || fail "bounded display retry missing"
grep -Fq 'guiAcquireDisplay("startup")' libc/apps/gui/guiStart.c || fail "startup display recovery missing"
grep -Fq 'guiAcquireDisplay("full-frame present")' libc/apps/gui/guiUpdate.c || fail "present recovery missing"
grep -Fq 'GetThreadMemoryUsage(server_pid)!=0' libc/apps/gui/graos.c || fail "live server validation missing"
grep -Fq 'ignoring stale server name' libc/apps/gui/graos.c || fail "stale server recovery missing"
grep -Fq 'Nv6150IsPrepared() && Nv6150FramebufferMapped()' kernel32/init/vesa.c || fail "NV6150 map guard missing"
grep -Fq 'VBoxBgaIsPrepared() && VBoxBgaFramebufferMapped()' kernel32/init/vesa.c || fail "VBox/BGA map guard missing"
./tools/check_graos_v54_hourglass.sh
echo 'GraOS V55 startup recovery: PASS'
