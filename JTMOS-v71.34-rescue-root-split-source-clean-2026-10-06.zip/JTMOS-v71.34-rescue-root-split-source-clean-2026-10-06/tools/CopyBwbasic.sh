#!/bin/bash

STAGE=$(mktemp -d "${TMPDIR:-/tmp}/jtmos-stage.XXXXXX")
trap 'rm -rf "$STAGE"' EXIT HUP INT TERM

# Make LIBC
cd ../libc/libc
make
cd ../../tools

# Make disk specific tools
cd ../libc/apps

# BWBASIC
cd bwbasic
make
cd ..

cd ../../tools

# Clean up our temp dir
rm -f "$STAGE"/*
# Copy the binaries into the temp dir
cp ../libc/apps/bwbasic/*.bin "$STAGE"/
cp ../libc/apps/bwbasic/seltests/*.bas "$STAGE"/
# Make an archive disk image out of
# the directory's contents
./sqarc "$STAGE" > bwbasic.img

