#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_intel_ia32_io: FAIL: $*" >&2; exit 1; }
IO=kernel32/core/int/io.h
MMIO=kernel32/core/int/mmio.h
PG=kernel32/mm/paging.c
AHCI=kernel32/drivers/sata/ahci.c
TSS=kernel32/core/int/tss.c
LEG=libc/libc/modern/legacy_hw.c
SCS=kernel32/core/int/scs.c

[ -f "$IO" ] || fail "missing canonical io.h"
grep -q 'outb %b0,%w1' "$IO" || fail "8-bit OUT width primitive missing"
grep -q 'outw %w0,%w1' "$IO" || fail "16-bit OUT width primitive missing"
grep -q 'outl %0,%w1' "$IO" || fail "32-bit OUT width primitive missing"
grep -q 'inb %w1,%b0' "$IO" || fail "8-bit IN width primitive missing"
grep -q 'inw %w1,%w0' "$IO" || fail "16-bit IN width primitive missing"
grep -q 'inl %w1,%0' "$IO" || fail "32-bit IN width primitive missing"
grep -q '"memory"' "$IO" || fail "compiler memory clobber missing"
grep -q 'lock; addl.*%%esp' "$IO" || fail "i486 full memory barrier missing"
! grep -q '^global outportd' kernel32/core/int/llint.asm || fail "duplicate NASM outportd remains"
! grep -q '^global inportd' kernel32/core/int/llint.asm || fail "duplicate NASM inportd remains"

grep -q 'io_compiler_barrier' "$MMIO" || fail "MMIO compiler ordering missing"
grep -q 'const DWORD io_pte_flags = 0x1bUL' "$PG" || fail "UC PCD/PWT pg_mapio flags missing"
grep -q 'flags=mmCriticalEnter();' "$PG" || fail "pg_mapio virtual/PTE transaction not protected"

grep -q 'io_memory_barrier();' "$AHCI" || fail "AHCI DMA full barrier missing"
grep -q '(void)p->ci;' "$AHCI" || fail "AHCI PxCI readback missing"

grep -q 't->iopb  = sizeof(TSSEG);' "$TSS" || fail "Ring3 TSS I/O bitmap deny policy missing"
grep -q 't->eflags = 0x00000202' "$TSS" || fail "Ring3 IOPL=0 initial EFLAGS missing"
grep -q 'legacy_hw_cpl0' "$LEG" || fail "legacy Ring3 port-I/O guard missing"
grep -q 'errno=EPERM' "$LEG" || fail "legacy Ring3 I/O does not fail cleanly"
grep -q 'Ring3.*SYS_irqsubscribe' "$SCS" || fail "legacy IRQ syscall privilege policy missing"

grep -q 'mmio_read32(nf.mmio+o)' kernel32/drivers/tcpip/nforce.c || fail "nforce MMIO helper not used"
grep -q 'mmio_read32(ohci.mmio+off)' kernel32/drivers/usb/ohci.c || fail "OHCI MMIO helper not used"
grep -q 'mmio_read32(hdac.mmio+o)' kernel32/drivers/hda/hda.c || fail "HDA MMIO helper not used"

echo "check_intel_ia32_io: PASS"
