#!/bin/sh
set -eu
fail(){ echo "check_kernel_warning_solutions: FAIL: $*" >&2; exit 1; }

for H in kernel32/init/basdef.h kernel32/sh/basdef.h; do
    grep -q 'JTM_PTR_TO_DWORD' "$H" || fail "$H missing pointer->DWORD ABI helper"
    grep -q 'JTM_DWORD_TO_PTR' "$H" || fail "$H missing DWORD->pointer ABI helper"
done

grep -Eq 'void[[:space:]]+\*A2K\(' kernel32/core/int/scs.h || fail "A2K is not pointer-typed"
grep -Eq 'void[[:space:]]+\*A2KRange\(' kernel32/core/int/scs.h || fail "A2KRange is not pointer-typed"
grep -q 'int total=0;' kernel32/core/random/random.c || fail "rand accumulator can be uninitialized"
grep -q 'return 0;' kernel32/core/speed/speed.c || fail "disabled CPU speed probe has no deterministic return"
grep -q 'd->errors,' kernel32/drivers/driver_sys.c || fail "device-list printk still omits errors argument"
grep -q 'if(src==NULL) return FALSE;' kernel32/drivers/floppy/fdcCache.c || fail "floppy read cache does not propagate failed track read"
grep -q 'if(buf!=NULL) memcpy(buf, src, 512);' kernel32/drivers/floppy/fdcCache.c || fail "floppy NULL geometry probe is unsafe"
grep -q 'msdos_getfilesize_path(f->dnr, f->name, f->db)' kernel32/fs/_close.c || fail "legacy FAT12 close still uses mismatched size ABI"
grep -q '#include "../core/int/debug.h"' kernel32/init/kernel32.h || fail "obsolete console/debug.h can still shadow core debug prototypes"
grep -q 'int memcmp(const void \*a, const void \*b, size_t n);' kernel32/core/dataproc/string.h || fail "memcmp prototype missing"

echo "check_kernel_warning_solutions: PASS"
