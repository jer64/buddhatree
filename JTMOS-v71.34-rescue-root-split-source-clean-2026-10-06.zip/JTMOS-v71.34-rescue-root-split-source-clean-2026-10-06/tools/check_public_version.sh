#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "check_public_version: FAIL: $*" >&2; exit 1; }
V=$(cat "$ROOT/VERSION")
printf '%s\n' "$V" | grep -Eq '^[0-9]+\.[0-9]+$' || fail "VERSION is not MAJOR.RELEASE"
grep -Fq 'JTMOS_PUBLIC_VERSION := $(shell cat VERSION 2>/dev/null || echo unknown)' "$ROOT/Makefile" || fail "Makefile does not source VERSION"
[ -f "$ROOT/RELEASE-V$V.txt" ] || fail "RELEASE-V$V.txt missing"
grep -Fq "JTMOS V$V" "$ROOT/RELEASE-V$V.txt" || fail "release note public version missing"
grep -Fq 'MAJOR.RELEASE' "$ROOT/VERSIONING.md" || fail "versioning policy missing"
echo "JTMOS public version V$V: PASS"
