#!/bin/sh
set -eu
fail(){ echo "check_ramextract_32m: FAIL: $*" >&2; exit 1; }
[ -f kernel32/include/memory_layout.h ] || fail "run from project root"
grep -Eq 'JTMOS_BOOT_UTILS_RAM_BYTES[[:space:]]+0x02000000' kernel32/include/memory_layout.h || fail "kernel C cap is not 32 MiB"
grep -Eq 'JTMOS_BOOT_UTILS_RAM_BYTES[[:space:]]+0x02000000' kernel32/include/memory_layout.inc || fail "NASM cap is not 32 MiB"
grep -Eq 'JTMOS_BOOT_UTILS_RAM_BYTES[[:space:]]+=[[:space:]]*0x02000000' kernel32/include/memory_layout.ld || fail "LD cap is not 32 MiB"
grep -q 'RAMEXTRACT_BUILTIN_MAX_BYTES JTMOS_BOOT_UTILS_RAM_BYTES' kernel32/sh/sh.c || fail "SMSH builtin is not bound to canonical cap"
grep -q 'RAMEXTRACT_MAX_BYTES (32UL\*1024UL\*1024UL)' libc/apps/ramextract.c || fail "external ramextract cap is not 32 MiB"
grep -q 'DOSBOOT_UTILS_MAX_BYTES=$((32 \* 1024 \* 1024))' tools/build_install_image.sh || fail "build guard is not 32 MiB"
grep -q 'exceeds 32 MiB RAM-bank capacity' boot32pm/dosboot.asm || fail "DOSBOOT diagnostic is not 32 MiB"
grep -q 'cmp ax,49152' boot32pm/dosboot.asm || fail "DOSBOOT minimum extended-memory guard not adjusted"
echo 'check_ramextract_32m: PASS'
