#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail(){ echo "V69.60 Ctrl+R isearch: FAIL: $*" >&2; exit 1; }
has(){ grep -Fq "$1" "$2" || fail "$3"; }

SMSH="$ROOT/kernel32/sh/sh.c"
SQSH="$ROOT/libc/apps/sqsh.c"
HELP="$ROOT/kernel32/sh/helpapp.c"
MAN="$ROOT/docs/SMSH-SQSH-MANUAL.txt"

# Both line editors must bind ASCII DC2 (Ctrl+R) and use substring matching.
has 'if(key==18)' "$SMSH" 'SMSH does not bind Ctrl+R'
has 'if(key==18)' "$SQSH" 'SQSH does not bind Ctrl+R'
has 'strstr(h,needle)!=NULL' "$SMSH" 'SMSH search is not substring based'
has 'strstr(h,needle)!=NULL' "$SQSH" 'SQSH search is not substring based'
has 'match_offset+1' "$SMSH" 'SMSH repeated Ctrl+R does not continue older'
has 'match_offset+1' "$SQSH" 'SQSH repeated Ctrl+R does not continue older'

# Readline-compatible interaction essentials.
has '(reverse-i-search)`' "$SMSH" 'SMSH search prompt missing'
has '(failed reverse-i-search)`' "$SMSH" 'SMSH failed search prompt missing'
has '(reverse-i-search)`' "$SQSH" 'SQSH search prompt missing'
has '(failed reverse-i-search)`' "$SQSH" 'SQSH failed search prompt missing'
has 'if(key==7)' "$SMSH" 'SMSH Ctrl+G abort missing'
has 'if(key==7)' "$SQSH" 'SQSH Ctrl+G abort missing'
has 'sh_last_isearch' "$SMSH" 'SMSH remembered search string missing'
has 'sqsh_last_isearch' "$SQSH" 'SQSH remembered search string missing'
has 'Esc keeps the match editable' "$SMSH" 'SMSH Esc edit behavior missing'
has 'Esc: keep the match as the editable line' "$SQSH" 'SQSH Esc edit behavior missing'

has 'Ctrl+R - reverse incremental history search' "$HELP" 'SMSH help missing Ctrl+R'
has 'Ctrl+R starts a Bash/Readline-' "$MAN" 'manual missing Ctrl+R behavior'
has 'Ctrl+G aborts the search and restores the original draft' "$MAN" 'manual missing Ctrl+G behavior'

# Behavioral model for the newest-first 32-entry history contract used by both
# implementations.  This tests the intended repeat-Ctrl+R search position.
python3 - <<'PYMODEL'
history=[
    'echo newest',
    'git status --short',
    'make utilities.iso',
    'git log --oneline',
    'echo oldest',
]
def find(needle,start):
    for off in range(start,len(history)):
        if needle in history[off]:
            return off,history[off]
    return -1,None

off,line=find('git',0)
assert (off,line)==(1,'git status --short')
off,line=find('git',off+1)
assert (off,line)==(3,'git log --oneline')
off,line=find('utilities',0)
assert line=='make utilities.iso'
off,line=find('does-not-exist',0)
assert off==-1 and line is None
print('V69.60 Ctrl+R behavioral model: PASS')
PYMODEL

echo 'V69.60 Ctrl+R isearch: PASS'
