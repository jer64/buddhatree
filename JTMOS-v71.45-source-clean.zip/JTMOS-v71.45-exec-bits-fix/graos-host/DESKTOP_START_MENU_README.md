# JTMOS GraOS desktop: Start menu, Terminal and Control Panel

This tree extends the central Linux/SDL2 GraOS server architecture.

## Start the desktop

```sh
make
./build/bin/graos
```

The `graos` process owns the SDL2 desktop and starts `taskbar` by default.

## Start button and Start menu

The taskbar Start button now opens a GraOS popup menu over IPC. The menu contains:

- Terminal Shell
- File Manager
- Text Editor
- Task Manager
- Control Panel
- Close Menu

Applications are launched as separate processes. They connect back to the central `graos` server through the normal GraOS wrappers.

## Terminal Shell

`build/bin/terminal` creates a remote terminal with `CreateTerminal()`, attaches a `TYPE_TERMINAL_EMULATION` surface to a GraOS window, and launches `sqsh` with `bgexecEx()`. Shell output therefore goes through the terminal engine and the central GraOS compositor; the shell does not create its own SDL2 window.

The 2026 update integrates the kernel System Maintenance Shell (SMSH) command set into SQSH. The terminal now accepts `cd/chdir`, `ls/dir`, `mkfs/format`, `sqa`, `sqarc`, `nzip`, `help/smsh`, and `exit/quit` alongside the historical SQSH script commands. Native application lookup first preserves an explicitly named command and then retries a bare command as `NAME.bin`.

Interactive input deliberately does **not** depend on `fgets()`: native JTMOS reads the attached GraOS terminal through `getch()` with a 4095-character bound, Backspace handling and overlong-line rejection. Pipes are therefore not required for the shell integration.

## Control Panel

`build/bin/controlpanel` provides buttons for launching Terminal, Editor and File Manager. It also demonstrates a central GraOS setting by changing the desktop colour through `GRAOS_OP_SET_DESKTOP_COLOR` IPC.

## JTMOS compatibility

Linux-only process launching is inside `#ifndef JTMOS`. The JTMOS branch uses `cexec()` and `.bin` application names. Native per-application Makefiles `terminal.mak` and `controlpanel.mak` are included, and the native dispatcher also keeps `taskbar.mak` and `winshell.mak` in the GUI build path.
